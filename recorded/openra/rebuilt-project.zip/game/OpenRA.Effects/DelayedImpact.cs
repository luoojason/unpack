using System.Collections.Generic;
using OpenRA.GameRules;
using OpenRA.Graphics;
using OpenRA.Traits;

namespace OpenRA.Effects;

public class DelayedImpact : IEffect
{
	private readonly Target target;

	private readonly IWarhead wh;

	private readonly WarheadArgs args;

	private int delay;

	public DelayedImpact(int delay, IWarhead wh, Target target, WarheadArgs args)
	{
		this.wh = wh;
		this.delay = delay;
		this.target = target;
		this.args = args;
	}

	public void Tick(World world)
	{
		if (--delay <= 0)
		{
			world.AddFrameEndTask((World w) =>
			{
				w.Remove(this);
				wh.DoImpact(in target, args);
			});
		}
	}

	public IEnumerable<IRenderable> Render(WorldRenderer wr)
	{
		yield break;
	}
}
