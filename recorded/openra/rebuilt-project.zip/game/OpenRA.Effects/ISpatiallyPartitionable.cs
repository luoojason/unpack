namespace OpenRA.Effects;

public interface ISpatiallyPartitionable
{
}
