using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Effects;

public interface IEffectAboveShroud
{
	IEnumerable<IRenderable> RenderAboveShroud(WorldRenderer wr);
}
