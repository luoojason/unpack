using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Effects;

public interface IEffectAnnotation
{
	IEnumerable<IRenderable> RenderAnnotation(WorldRenderer wr);
}
