using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Effects;

public interface IEffect
{
	void Tick(World world);

	IEnumerable<IRenderable> Render(WorldRenderer r);
}
