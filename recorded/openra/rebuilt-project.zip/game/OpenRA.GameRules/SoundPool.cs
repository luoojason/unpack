using System.Collections.Generic;

namespace OpenRA.GameRules;

public class SoundPool
{
	public enum InterruptType
	{
		DoNotPlay,
		Interrupt,
		Overlap
	}

	public const InterruptType DefaultInterruptType = InterruptType.DoNotPlay;

	public readonly float VolumeModifier;

	public readonly InterruptType Type;

	private readonly string[] clips;

	private readonly List<string> liveclips = new List<string>();

	public SoundPool(float volumeModifier, InterruptType interruptType, params string[] clips)
	{
		VolumeModifier = volumeModifier;
		Type = interruptType;
		this.clips = clips;
	}

	public string GetNext()
	{
		if (liveclips.Count == 0)
		{
			liveclips.AddRange(clips);
		}
		if (liveclips.Count == 0)
		{
			return null;
		}
		int index = Game.CosmeticRandom.Next(liveclips.Count);
		string result = liveclips[index];
		liveclips.RemoveAt(index);
		return result;
	}
}
