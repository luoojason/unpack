using System;
using OpenRA.Traits;

namespace OpenRA.GameRules;

public class ProjectileArgs
{
	public WeaponInfo Weapon;

	public int[] DamageModifiers;

	public int[] InaccuracyModifiers;

	public int[] RangeModifiers;

	public WAngle Facing;

	public Func<WAngle> CurrentMuzzleFacing;

	public WPos Source;

	public Func<WPos> CurrentSource;

	public Actor SourceActor;

	public WPos PassiveTarget;

	public Target GuidedTarget;
}
