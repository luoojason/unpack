namespace OpenRA.GameRules;

public interface IProjectileInfo
{
	IProjectile Create(ProjectileArgs args);
}
