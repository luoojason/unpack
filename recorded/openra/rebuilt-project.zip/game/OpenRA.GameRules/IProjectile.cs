using OpenRA.Effects;

namespace OpenRA.GameRules;

public interface IProjectile : IEffect
{
}
