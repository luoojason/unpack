using System;
using System.Collections.Generic;
using System.Linq;

namespace OpenRA.GameRules;

public class SoundInfo
{
	public readonly Dictionary<string, string[]> Variants = new Dictionary<string, string[]>();

	public readonly Dictionary<string, string[]> Prefixes = new Dictionary<string, string[]>();

	public readonly Dictionary<string, string[]> Voices = new Dictionary<string, string[]>();

	public readonly Dictionary<string, string[]> Notifications = new Dictionary<string, string[]>();

	public readonly string DefaultVariant = ".aud";

	public readonly string DefaultPrefix = "";

	public readonly HashSet<string> DisableVariants = new HashSet<string>();

	public readonly HashSet<string> DisablePrefixes = new HashSet<string>();

	public readonly Lazy<Dictionary<string, SoundPool>> VoicePools;

	public readonly Lazy<Dictionary<string, SoundPool>> NotificationsPools;

	public SoundInfo(MiniYaml y)
	{
		SoundInfo soundInfo = this;
		FieldLoader.Load(this, y);
		VoicePools = Exts.Lazy(() => soundInfo.Voices.ToDictionary((KeyValuePair<string, string[]> a) => a.Key, (KeyValuePair<string, string[]> a) => new SoundPool(1f, SoundPool.InterruptType.DoNotPlay, a.Value)));
		NotificationsPools = Exts.Lazy(() => ParseSoundPool(y, "Notifications"));
	}

	private static Dictionary<string, SoundPool> ParseSoundPool(MiniYaml y, string key)
	{
		Dictionary<string, SoundPool> dictionary = new Dictionary<string, SoundPool>();
		MiniYamlNode miniYamlNode = y.NodeWithKey(key);
		foreach (MiniYamlNode node in miniYamlNode.Value.Nodes)
		{
			float volumeModifier = 1f;
			MiniYamlNode miniYamlNode2 = node.Value.NodeWithKeyOrDefault("VolumeModifier");
			if (miniYamlNode2 != null)
			{
				volumeModifier = FieldLoader.GetValue<float>(miniYamlNode2.Key, miniYamlNode2.Value.Value);
			}
			SoundPool.InterruptType interruptType = SoundPool.InterruptType.DoNotPlay;
			MiniYamlNode miniYamlNode3 = node.Value.NodeWithKeyOrDefault("InterruptType");
			if (miniYamlNode3 != null)
			{
				interruptType = FieldLoader.GetValue<SoundPool.InterruptType>(miniYamlNode3.Key, miniYamlNode3.Value.Value);
			}
			string[] value = FieldLoader.GetValue<string[]>(node.Key, node.Value.Value);
			SoundPool value2 = new SoundPool(volumeModifier, interruptType, value);
			dictionary.Add(node.Key, value2);
		}
		return dictionary;
	}
}
