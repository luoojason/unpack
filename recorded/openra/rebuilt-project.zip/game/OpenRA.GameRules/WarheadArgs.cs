using System;
using OpenRA.Traits;

namespace OpenRA.GameRules;

public class WarheadArgs
{
	public WeaponInfo Weapon;

	public int[] DamageModifiers = Array.Empty<int>();

	public WPos? Source;

	public WRot ImpactOrientation;

	public WPos ImpactPosition;

	public Actor SourceActor;

	public Target WeaponTarget;

	public WarheadArgs(ProjectileArgs args)
	{
		Weapon = args.Weapon;
		DamageModifiers = args.DamageModifiers;
		ImpactPosition = args.PassiveTarget;
		Source = args.Source;
		SourceActor = args.SourceActor;
		WeaponTarget = args.GuidedTarget;
	}

	public WarheadArgs(WarheadArgs args)
	{
		Weapon = args.Weapon;
		DamageModifiers = args.DamageModifiers;
		Source = args.Source;
		SourceActor = args.SourceActor;
		WeaponTarget = args.WeaponTarget;
	}

	public WarheadArgs()
	{
	}
}
