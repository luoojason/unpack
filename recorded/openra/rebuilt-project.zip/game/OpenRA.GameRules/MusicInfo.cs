using System.Collections.Generic;
using OpenRA.FileSystem;

namespace OpenRA.GameRules;

public class MusicInfo
{
	public readonly string Filename;

	public readonly string Title;

	public readonly bool Hidden;

	public readonly float VolumeModifier = 1f;

	public int Length { get; private set; }

	public bool Exists { get; private set; }

	public MusicInfo(string key, MiniYaml value)
	{
		Title = value.Value;
		Dictionary<string, MiniYaml> dictionary = value.ToDictionary();
		if (dictionary.TryGetValue("Hidden", out var value2))
		{
			bool.TryParse(value2.Value, out Hidden);
		}
		if (dictionary.TryGetValue("VolumeModifier", out value2))
		{
			VolumeModifier = FieldLoader.GetValue<float>("VolumeModifier", value2.Value);
		}
		string text = (dictionary.TryGetValue("Extension", out value2) ? value2.Value : "aud");
		Filename = (dictionary.TryGetValue("Filename", out value2) ? value2.Value : key) + "." + text;
	}

	public void Load(IReadOnlyFileSystem fileSystem)
	{
		if (!fileSystem.TryOpen(Filename, out var s))
		{
			return;
		}
		try
		{
			Exists = true;
			ISoundLoader[] soundLoaders = Game.ModData.SoundLoaders;
			foreach (ISoundLoader soundLoader in soundLoaders)
			{
				if (soundLoader.TryParseSound(s, out var sound))
				{
					Length = (int)sound.LengthInSeconds;
					sound.Dispose();
					break;
				}
			}
		}
		finally
		{
			s.Dispose();
		}
	}
}
