using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Effects;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA.GameRules;

public sealed class WeaponInfo
{
	[Desc(new string[] { "The maximum range the weapon can fire." })]
	public readonly WDist Range = WDist.Zero;

	[Desc(new string[] { "First burst is aimed at this offset relative to target position." })]
	public readonly WVec FirstBurstTargetOffset = WVec.Zero;

	[Desc(new string[] { "Each burst after the first lands by this offset away from the previous burst." })]
	public readonly WVec FollowingBurstTargetOffset = WVec.Zero;

	[Desc(new string[] { "The sound played each time the weapon is fired." })]
	public readonly string[] Report;

	[Desc(new string[] { "Sound played only on first burst in a salvo." })]
	public readonly string[] StartBurstReport;

	[Desc(new string[] { "The sound played when the weapon is reloaded." })]
	public readonly string[] AfterFireSound;

	[Desc(new string[] { "Delay in ticks to play reloading sound." })]
	public readonly int AfterFireSoundDelay;

	[Desc(new string[] { "Delay in ticks between reloading ammo magazines." })]
	public readonly int ReloadDelay = 1;

	[Desc(new string[] { "Number of shots in a single ammo magazine." })]
	public readonly int Burst = 1;

	[Desc(new string[] { "Can this weapon target the attacker itself?" })]
	public readonly bool CanTargetSelf;

	[Desc(new string[] { "What types of targets are affected." })]
	public readonly BitSet<TargetableType> ValidTargets = new BitSet<TargetableType>("Ground", "Water");

	[Desc(new string[] { "What types of targets are unaffected.", "Overrules ValidTargets." })]
	public readonly BitSet<TargetableType> InvalidTargets;

	private static readonly BitSet<TargetableType> TargetTypeAir = new BitSet<TargetableType>("Air");

	[Desc(new string[] { "If weapon is not directly targeting an actor and targeted position is above this altitude,", "the weapon will ignore terrain target types and only check TargetTypeAir for validity." })]
	public readonly WDist AirThreshold = new WDist(128);

	[Desc(new string[] { "Delay in ticks between firing shots from the same ammo magazine. If one entry, it will be used for all bursts.", "If multiple entries, their number needs to match Burst - 1." })]
	public readonly int[] BurstDelays = new int[1] { 5 };

	[Desc(new string[] { "The minimum range the weapon can fire." })]
	public readonly WDist MinRange = WDist.Zero;

	[Desc(new string[] { "Does this weapon aim at the target's center regardless of other targetable offsets?" })]
	public readonly bool TargetActorCenter;

	[FieldLoader.LoadUsing("LoadProjectile", false)]
	public readonly IProjectileInfo Projectile;

	[FieldLoader.LoadUsing("LoadWarheads", false)]
	public readonly List<IWarhead> Warheads = new List<IWarhead>();

	public WeaponInfo()
	{
	}

	public WeaponInfo(MiniYaml content)
	{
		content = content.WithNodes(MiniYaml.Merge(new IReadOnlyCollection<MiniYamlNode>[1] { content.Nodes }));
		FieldLoader.Load(this, content);
	}

	private static object LoadProjectile(MiniYaml yaml)
	{
		MiniYaml miniYaml = yaml.NodeWithKeyOrDefault("Projectile")?.Value;
		if (miniYaml == null)
		{
			return null;
		}
		IProjectileInfo projectileInfo = Game.CreateObject<IProjectileInfo>(miniYaml.Value + "Info");
		if (projectileInfo == null)
		{
			return null;
		}
		FieldLoader.Load(projectileInfo, miniYaml);
		return projectileInfo;
	}

	private static object LoadWarheads(MiniYaml yaml)
	{
		List<IWarhead> list = new List<IWarhead>();
		foreach (MiniYamlNode item in yaml.Nodes.Where((MiniYamlNode n) => n.Key.StartsWith("Warhead", StringComparison.Ordinal)))
		{
			IWarhead warhead = Game.CreateObject<IWarhead>(item.Value.Value + "Warhead");
			if (warhead != null)
			{
				FieldLoader.Load(warhead, item.Value);
				list.Add(warhead);
			}
		}
		return list;
	}

	public bool IsValidTarget(BitSet<TargetableType> targetTypes)
	{
		if (ValidTargets.Overlaps(targetTypes))
		{
			return !InvalidTargets.Overlaps(targetTypes);
		}
		return false;
	}

	public bool IsValidAgainst(in Target target, World world, Actor firedBy)
	{
		if (target.Type == TargetType.Actor)
		{
			return IsValidAgainst(target.Actor, firedBy);
		}
		if (target.Type == TargetType.FrozenActor)
		{
			return IsValidAgainst(target.FrozenActor, firedBy);
		}
		if (target.Type == TargetType.Terrain)
		{
			WDist wDist = world.Map.DistanceAboveTerrain(target.CenterPosition);
			if (wDist > AirThreshold)
			{
				return IsValidTarget(TargetTypeAir);
			}
			CPos cell = world.Map.CellContaining(target.CenterPosition);
			if (!world.Map.Contains(cell))
			{
				return false;
			}
			TerrainTypeInfo terrainInfo = world.Map.GetTerrainInfo(cell);
			if (!IsValidTarget(terrainInfo.TargetTypes))
			{
				return false;
			}
			return true;
		}
		return false;
	}

	public bool IsValidAgainst(Actor victim, Actor firedBy)
	{
		if (!CanTargetSelf && victim == firedBy)
		{
			return false;
		}
		BitSet<TargetableType> enabledTargetTypes = victim.GetEnabledTargetTypes();
		return IsValidTarget(enabledTargetTypes);
	}

	public bool IsValidAgainst(FrozenActor victim, Actor firedBy)
	{
		if (!victim.IsValid)
		{
			return false;
		}
		if (!CanTargetSelf && victim.Actor == firedBy)
		{
			return false;
		}
		return IsValidTarget(victim.TargetTypes);
	}

	public void Impact(in Target target, WarheadArgs args)
	{
		World world = args.SourceActor.World;
		foreach (IWarhead warhead in Warheads)
		{
			if (warhead.Delay > 0)
			{
				Target delayedTarget = target;
				world.AddFrameEndTask((World w) =>
				{
					w.Add(new DelayedImpact(warhead.Delay, warhead, delayedTarget, args));
				});
			}
			else
			{
				warhead.DoImpact(in target, args);
			}
		}
	}

	public void Impact(in Target target, Actor firedBy)
	{
		WarheadArgs warheadArgs = new WarheadArgs
		{
			Weapon = this,
			SourceActor = firedBy,
			WeaponTarget = target
		};
		if (firedBy.OccupiesSpace != null)
		{
			warheadArgs.Source = firedBy.CenterPosition;
		}
		Impact(in target, warheadArgs);
	}
}
