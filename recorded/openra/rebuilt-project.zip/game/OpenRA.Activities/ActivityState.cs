namespace OpenRA.Activities;

public enum ActivityState
{
	Queued,
	Active,
	Canceling,
	Done
}
