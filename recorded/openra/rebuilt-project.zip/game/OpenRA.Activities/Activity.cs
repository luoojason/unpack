using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Traits;

namespace OpenRA.Activities;

public abstract class Activity : IActivityInterface
{
	private Activity childActivity;

	private Activity nextActivity;

	private bool finishing;

	private bool firstRunCompleted;

	private bool lastRun;

	public ActivityState State { get; private set; }

	protected Activity ChildActivity
	{
		get
		{
			return SkipDoneActivities(childActivity);
		}
		private set
		{
			childActivity = value;
		}
	}

	public Activity NextActivity
	{
		get
		{
			return SkipDoneActivities(nextActivity);
		}
		private set
		{
			nextActivity = value;
		}
	}

	public bool IsInterruptible { get; protected set; }

	public bool ChildHasPriority { get; protected set; }

	public bool IsCanceling => State == ActivityState.Canceling;

	internal static Activity SkipDoneActivities(Activity first)
	{
		while (first != null && first.State == ActivityState.Done)
		{
			first = first.nextActivity;
		}
		return first;
	}

	protected Activity()
	{
		IsInterruptible = true;
		ChildHasPriority = true;
	}

	public Activity TickOuter(Actor self)
	{
		if (State == ActivityState.Done)
		{
			throw new InvalidOperationException($"Actor {self} attempted to tick activity {GetType()} after it had already completed.");
		}
		if (State == ActivityState.Queued)
		{
			OnFirstRun(self);
			firstRunCompleted = true;
			State = ActivityState.Active;
		}
		if (!firstRunCompleted)
		{
			throw new InvalidOperationException($"Actor {self} attempted to tick activity {GetType()} before running its OnFirstRun method.");
		}
		if (ChildHasPriority)
		{
			lastRun = TickChild(self) && (finishing || Tick(self));
			finishing |= lastRun;
		}
		else
		{
			lastRun = Tick(self);
		}
		Activity activity = ChildActivity;
		if (activity != null && activity.State == ActivityState.Queued)
		{
			if (ChildHasPriority)
			{
				lastRun = TickChild(self) && finishing;
			}
			else
			{
				TickChild(self);
			}
		}
		if (lastRun)
		{
			State = ActivityState.Done;
			OnLastRun(self);
			return NextActivity;
		}
		return this;
	}

	protected bool TickChild(Actor self)
	{
		ChildActivity = ActivityUtils.RunActivity(self, ChildActivity);
		return ChildActivity == null;
	}

	public virtual bool Tick(Actor self)
	{
		return true;
	}

	protected virtual void OnFirstRun(Actor self)
	{
	}

	protected virtual void OnLastRun(Actor self)
	{
	}

	protected virtual void OnActorDispose(Actor self)
	{
	}

	internal void OnActorDisposeOuter(Actor self)
	{
		ChildActivity?.OnActorDisposeOuter(self);
		OnActorDispose(self);
	}

	public virtual void Cancel(Actor self, bool keepQueue = false)
	{
		if (!keepQueue)
		{
			NextActivity = null;
		}
		if (IsInterruptible)
		{
			ChildActivity?.Cancel(self);
			State = ((State == ActivityState.Queued) ? ActivityState.Done : ActivityState.Canceling);
		}
	}

	public void Queue(Activity activity)
	{
		Activity activity2 = this;
		while (activity2.nextActivity != null)
		{
			activity2 = activity2.nextActivity;
		}
		activity2.nextActivity = activity;
	}

	public void QueueChild(Activity activity)
	{
		if (childActivity != null)
		{
			childActivity.Queue(activity);
		}
		else
		{
			childActivity = activity;
		}
	}

	protected void PrintActivityTree(Actor self, Activity origin = null, int level = 0)
	{
		if (origin == null)
		{
			self.CurrentActivity.PrintActivityTree(self, this);
			return;
		}
		Console.Write(new string(' ', level * 2));
		if (origin == this)
		{
			Console.Write("*");
		}
		Console.WriteLine(GetType().ToString().Split('.').Last());
		ChildActivity?.PrintActivityTree(self, origin, level + 1);
		NextActivity?.PrintActivityTree(self, origin, level);
	}

	public virtual IEnumerable<Target> GetTargets(Actor self)
	{
		yield break;
	}

	public virtual IEnumerable<TargetLineNode> TargetLineNodes(Actor self)
	{
		yield break;
	}

	public IEnumerable<string> DebugLabelComponents()
	{
		for (Activity act = this; act != null; act = act.ChildActivity)
		{
			yield return act.GetType().Name;
		}
	}

	public IEnumerable<T> ActivitiesImplementing<T>(bool includeChildren = true) where T : IActivityInterface
	{
		if (includeChildren)
		{
			Activity activity = ChildActivity;
			if (activity != null)
			{
				foreach (T item in activity.ActivitiesImplementing<T>())
				{
					yield return item;
				}
			}
		}
		if (this is T)
		{
			yield return (T)(object)this;
		}
		Activity activity2 = NextActivity;
		if (activity2 == null)
		{
			yield break;
		}
		foreach (T item2 in activity2.ActivitiesImplementing<T>())
		{
			yield return item2;
		}
	}
}
