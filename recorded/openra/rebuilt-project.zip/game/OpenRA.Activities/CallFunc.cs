using System;

namespace OpenRA.Activities;

public class CallFunc : Activity
{
	private readonly Action a;

	public CallFunc(Action a)
	{
		this.a = a;
	}

	public CallFunc(Action a, bool interruptible)
	{
		this.a = a;
		IsInterruptible = interruptible;
	}

	public override bool Tick(Actor self)
	{
		a();
		return true;
	}
}
