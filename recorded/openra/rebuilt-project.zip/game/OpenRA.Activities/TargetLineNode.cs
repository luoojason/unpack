using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA.Activities;

public class TargetLineNode
{
	public readonly Target Target;

	public readonly Color Color;

	public readonly Sprite Tile;

	public TargetLineNode(in Target target, Color color, Sprite tile = null)
	{
		Target = target;
		Color = color;
		Tile = tile;
	}
}
