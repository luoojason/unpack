using System.Collections.Generic;
using System.Numerics;

namespace OpenRA.Primitives;

internal static class BitSetAllocator<T> where T : class
{
	private static readonly Cache<string, BigInteger> Bits = new Cache<string, BigInteger>(Allocate);

	private static BigInteger nextBits = 1;

	private static BigInteger Allocate(string value)
	{
		lock (Bits)
		{
			BigInteger result = nextBits;
			nextBits <<= 1;
			return result;
		}
	}

	public static BigInteger GetBits(string[] values)
	{
		BigInteger result = 0;
		lock (Bits)
		{
			foreach (string key in values)
			{
				result |= Bits[key];
			}
			return result;
		}
	}

	public static BigInteger GetBitsNoAlloc(string[] values)
	{
		BigInteger result = 0;
		lock (Bits)
		{
			foreach (string key in values)
			{
				if (Bits.TryGetValue(key, out var value))
				{
					result |= value;
				}
			}
			return result;
		}
	}

	public static IEnumerable<string> GetStrings(BigInteger bits)
	{
		List<string> list = new List<string>();
		lock (Bits)
		{
			foreach (KeyValuePair<string, BigInteger> bit in Bits)
			{
				if ((bit.Value & bits) != 0L)
				{
					list.Add(bit.Key);
				}
			}
			return list;
		}
	}

	public static bool BitsContainString(BigInteger bits, string value)
	{
		BigInteger value2;
		lock (Bits)
		{
			if (!Bits.TryGetValue(value, out value2))
			{
				return false;
			}
		}
		return (bits & value2) != 0L;
	}
}
