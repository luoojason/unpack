using System;

namespace OpenRA.Primitives;

public sealed class DisposableAction : IDisposable
{
	private readonly Action onDispose;

	private readonly Action onFinalize;

	private bool disposed;

	public DisposableAction(Action onDispose, Action onFinalize)
	{
		this.onDispose = onDispose;
		this.onFinalize = onFinalize;
	}

	public void Dispose()
	{
		if (!disposed)
		{
			disposed = true;
			onDispose();
			GC.SuppressFinalize(this);
		}
	}

	~DisposableAction()
	{
		onFinalize();
	}
}
