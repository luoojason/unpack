using System;

namespace OpenRA.Primitives;

public readonly struct Size : IEquatable<Size>
{
	public readonly int Width;

	public readonly int Height;

	public bool IsEmpty
	{
		get
		{
			if (Width == 0)
			{
				return Height == 0;
			}
			return false;
		}
	}

	public static Size operator +(Size left, Size right)
	{
		return new Size(left.Width + right.Width, left.Height + right.Height);
	}

	public static bool operator ==(Size left, Size right)
	{
		if (left.Width == right.Width)
		{
			return left.Height == right.Height;
		}
		return false;
	}

	public static bool operator !=(Size left, Size right)
	{
		return !(left == right);
	}

	public static Size operator -(Size sz1, Size sz2)
	{
		return new Size(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
	}

	public Size(int width, int height)
	{
		Width = width;
		Height = height;
	}

	public bool Equals(Size other)
	{
		return this == other;
	}

	public override bool Equals(object obj)
	{
		if (!(obj is Size))
		{
			return false;
		}
		return this == (Size)obj;
	}

	public override int GetHashCode()
	{
		return Width ^ Height;
	}

	public override string ToString()
	{
		return $"{{Width={Width}, Height={Height}}}";
	}
}
