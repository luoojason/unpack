using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class RingBuffer<T> : ICollection<T>, IEnumerable<T>, IEnumerable
{
	private readonly IComparer<T> comparer;

	private readonly T[] values;

	private int start;

	public int Capacity => values.Length;

	public int Count { get; private set; }

	public bool IsReadOnly => false;

	public T this[int pos]
	{
		get
		{
			return values[(start + pos) % values.Length];
		}
		set
		{
			if (pos >= Count)
			{
				throw new ArgumentException($"Index out of bounds: {pos}");
			}
			values[(start + pos) % values.Length] = value;
		}
	}

	public RingBuffer(int capacity, IComparer<T> comparer)
	{
		this.comparer = comparer;
		values = new T[capacity];
		start = 0;
		Count = 0;
	}

	public RingBuffer(int capacity)
		: this(capacity, (IComparer<T>)Comparer<T>.Default)
	{
	}

	public void Add(T value)
	{
		values[(start + Count) % values.Length] = value;
		if (Count < values.Length)
		{
			Count++;
		}
		else
		{
			start = (start + 1) % values.Length;
		}
	}

	public void Clear()
	{
		Array.Clear(values, 0, values.Length);
		start = 0;
		Count = 0;
	}

	public bool Contains(T value)
	{
		int num = values.Length;
		int num2 = start + Count;
		for (int i = start; i < num2; i++)
		{
			if (comparer.Compare(values[i % num], value) == 0)
			{
				return true;
			}
		}
		return false;
	}

	public void CopyTo(T[] array, int arrayIndex)
	{
		if (array == null)
		{
			throw new ArgumentNullException("array");
		}
		if (arrayIndex < 0)
		{
			throw new ArgumentNullException("arrayIndex");
		}
		if (arrayIndex + Count >= array.Length)
		{
			throw new ArgumentException("Invalid array capacity");
		}
		int num = arrayIndex;
		int num2 = start + Count;
		int num3 = values.Length;
		for (int i = start; i < num2; i++)
		{
			array[num++] = values[i % num3];
		}
	}

	public bool Remove(T value)
	{
		int num = values.Length;
		int num2 = start + Count;
		for (int i = start; i < num2; i++)
		{
			if (comparer.Compare(values[i % num], value) == 0)
			{
				num2--;
				for (int j = i; j < num2; j++)
				{
					values[j % num] = values[(j + 1) % num];
				}
				Count--;
				return true;
			}
		}
		return false;
	}

	public T First()
	{
		if (Count == 0)
		{
			throw new ArgumentException("Empty buffer");
		}
		return values[start];
	}

	public T Last()
	{
		if (Count == 0)
		{
			throw new ArgumentException("Empty buffer");
		}
		return values[(start + Count - 1) % values.Length];
	}

	public IEnumerator<T> GetEnumerator()
	{
		int initState = start + Count;
		for (int i = 0; i < Count; i++)
		{
			if (start + Count != initState)
			{
				throw new InvalidOperationException("Collection was modified; enumeration operation may not execute");
			}
			yield return values[(start + i) % values.Length];
		}
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
