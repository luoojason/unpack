using System.Collections.Generic;

namespace OpenRA.Primitives;

public class ObservableSortedDictionary<TKey, TValue> : ObservableDictionary<TKey, TValue>
{
	public ObservableSortedDictionary(IComparer<TKey> comparer)
	{
		innerDict = new SortedDictionary<TKey, TValue>(comparer);
	}

	public override void Add(TKey key, TValue value)
	{
		innerDict.Add(key, value);
		FireOnRefresh();
	}
}
