using System;

namespace OpenRA.Primitives;

public class PredictedCachedTransform<T, U>
{
	private readonly Func<T, U> transform;

	private bool initialized;

	private T lastInput;

	private U lastOutput;

	private bool predicted;

	private U prediction;

	public PredictedCachedTransform(Func<T, U> transform)
	{
		this.transform = transform;
	}

	public void Predict(U value)
	{
		predicted = true;
		prediction = value;
	}

	public U Update(T input)
	{
		if ((predicted || initialized) && ((input == null && lastInput == null) || (input != null && input.Equals(lastInput))))
		{
			if (!predicted)
			{
				return lastOutput;
			}
			return prediction;
		}
		predicted = false;
		initialized = true;
		lastInput = input;
		lastOutput = transform(input);
		return lastOutput;
	}
}
