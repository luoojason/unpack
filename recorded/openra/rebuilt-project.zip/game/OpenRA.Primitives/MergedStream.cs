using System;
using System.IO;

namespace OpenRA.Primitives;

public class MergedStream : Stream
{
	private long position;

	public Stream Stream1 { get; set; }

	public Stream Stream2 { get; set; }

	private long VirtualLength { get; }

	public override bool CanRead
	{
		get
		{
			if (Stream1.CanRead)
			{
				return Stream2.CanRead;
			}
			return false;
		}
	}

	public override bool CanSeek
	{
		get
		{
			if (Stream1.CanSeek)
			{
				return Stream2.CanSeek;
			}
			return false;
		}
	}

	public override bool CanWrite => false;

	public override long Length => VirtualLength;

	public override long Position
	{
		get
		{
			return position;
		}
		set
		{
			Seek(value, SeekOrigin.Begin);
		}
	}

	public MergedStream(Stream stream1, Stream stream2)
	{
		Stream1 = stream1;
		Stream2 = stream2;
		VirtualLength = Stream1.Length + Stream2.Length;
	}

	public override void Flush()
	{
		Stream1.Flush();
		Stream2.Flush();
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		switch (origin)
		{
		case SeekOrigin.Begin:
			position = offset;
			break;
		case SeekOrigin.Current:
			position += offset;
			break;
		case SeekOrigin.End:
			position = Length;
			position += offset;
			break;
		}
		if (position >= Stream1.Length)
		{
			position = Stream1.Length + Stream2.Seek(offset - Stream1.Length, SeekOrigin.Begin);
		}
		else
		{
			position = Stream1.Seek(offset, SeekOrigin.Begin);
		}
		return position;
	}

	public override void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	public override int ReadByte()
	{
		int result = ((position < Stream1.Length) ? Stream1.ReadByte() : Stream2.ReadByte());
		position++;
		return result;
	}

	public override int Read(byte[] buffer, int offset, int count)
	{
		return Read(buffer.AsSpan(offset, count));
	}

	public override int Read(Span<byte> buffer)
	{
		int num;
		if (position >= Stream1.Length)
		{
			num = Stream2.Read(buffer);
		}
		else if (buffer.Length > Stream1.Length)
		{
			num = Stream1.Read(buffer.Slice(0, (int)Stream1.Length));
			num += Stream2.Read(buffer.Slice((int)Stream1.Length));
		}
		else
		{
			num = Stream1.Read(buffer);
		}
		position += num;
		return num;
	}

	public override void WriteByte(byte value)
	{
		throw new NotSupportedException();
	}

	public override void Write(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	public override void Write(ReadOnlySpan<byte> buffer)
	{
		throw new NotSupportedException();
	}
}
