using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;

namespace OpenRA.Primitives;

public readonly struct BitSet<T> : IEnumerable<string>, IEnumerable, IEquatable<BitSet<T>> where T : class
{
	private readonly BigInteger bits;

	public bool IsEmpty => bits == 0L;

	public BitSet(params string[] values)
		: this(BitSetAllocator<T>.GetBits(values))
	{
	}

	private BitSet(BigInteger bits)
	{
		this.bits = bits;
	}

	public static BitSet<T> FromStringsNoAlloc(string[] values)
	{
		return new BitSet<T>(BitSetAllocator<T>.GetBitsNoAlloc(values));
	}

	public override string ToString()
	{
		return BitSetAllocator<T>.GetStrings(bits).JoinWith(",");
	}

	public static bool operator ==(BitSet<T> me, BitSet<T> other)
	{
		return me.bits == other.bits;
	}

	public static bool operator !=(BitSet<T> me, BitSet<T> other)
	{
		return !(me == other);
	}

	public bool Equals(BitSet<T> other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is BitSet<T> other)
		{
			return Equals(other);
		}
		return false;
	}

	public override int GetHashCode()
	{
		return bits.GetHashCode();
	}

	public bool IsProperSubsetOf(BitSet<T> other)
	{
		if (IsSubsetOf(other))
		{
			return !SetEquals(other);
		}
		return false;
	}

	public bool IsProperSupersetOf(BitSet<T> other)
	{
		if (IsSupersetOf(other))
		{
			return !SetEquals(other);
		}
		return false;
	}

	public bool IsSubsetOf(BitSet<T> other)
	{
		return (bits | other.bits) == other.bits;
	}

	public bool IsSupersetOf(BitSet<T> other)
	{
		return (bits | other.bits) == bits;
	}

	public bool Overlaps(BitSet<T> other)
	{
		return (bits & other.bits) != 0L;
	}

	public bool SetEquals(BitSet<T> other)
	{
		return bits == other.bits;
	}

	public bool Contains(string value)
	{
		return BitSetAllocator<T>.BitsContainString(bits, value);
	}

	public IEnumerator<string> GetEnumerator()
	{
		return BitSetAllocator<T>.GetStrings(bits).GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}

	public BitSet<T> Except(BitSet<T> other)
	{
		return new BitSet<T>(bits & ~other.bits);
	}

	public BitSet<T> Intersect(BitSet<T> other)
	{
		return new BitSet<T>(bits & other.bits);
	}

	public BitSet<T> SymmetricExcept(BitSet<T> other)
	{
		return new BitSet<T>(bits ^ other.bits);
	}

	public BitSet<T> Union(BitSet<T> other)
	{
		return new BitSet<T>(bits | other.bits);
	}
}
