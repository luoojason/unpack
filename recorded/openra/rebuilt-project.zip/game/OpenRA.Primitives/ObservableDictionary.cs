using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class ObservableDictionary<TKey, TValue> : IDictionary<TKey, TValue>, ICollection<KeyValuePair<TKey, TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>, IEnumerable, IObservableCollection
{
	protected IDictionary<TKey, TValue> innerDict;

	public ICollection<TKey> Keys => innerDict.Keys;

	public ICollection<TValue> Values => innerDict.Values;

	public TValue this[TKey key]
	{
		get
		{
			return innerDict[key];
		}
		set
		{
			innerDict[key] = value;
		}
	}

	public int Count => innerDict.Count;

	public bool IsReadOnly => innerDict.IsReadOnly;

	public IEnumerable ObservedItems => innerDict.Keys;

	public event Action<IObservableCollection, object> OnAdd = (IObservableCollection x, object k) =>
	{
	};

	public event Action<IObservableCollection, object> OnRemove = (IObservableCollection x, object k) =>
	{
	};

	public event Action<IObservableCollection, int> OnRemoveAt = (IObservableCollection x, int i) =>
	{
	};

	public event Action<IObservableCollection, object, object> OnSet = (IObservableCollection x, object o, object n) =>
	{
	};

	public event Action<IObservableCollection> OnRefresh = (IObservableCollection x) =>
	{
	};

	protected void FireOnRefresh()
	{
		OnRefresh(this);
	}

	protected ObservableDictionary()
	{
	}

	public ObservableDictionary(IEqualityComparer<TKey> comparer)
	{
		innerDict = new Dictionary<TKey, TValue>(comparer);
	}

	public virtual void Add(TKey key, TValue value)
	{
		innerDict.Add(key, value);
		OnAdd(this, key);
	}

	public bool Remove(TKey key)
	{
		bool flag = innerDict.Remove(key);
		if (flag)
		{
			OnRemove(this, key);
		}
		return flag;
	}

	public bool ContainsKey(TKey key)
	{
		return innerDict.ContainsKey(key);
	}

	public bool TryGetValue(TKey key, out TValue value)
	{
		return innerDict.TryGetValue(key, out value);
	}

	public void Clear()
	{
		innerDict.Clear();
		OnRefresh(this);
	}

	public void Add(KeyValuePair<TKey, TValue> item)
	{
		Add(item.Key, item.Value);
	}

	public bool Contains(KeyValuePair<TKey, TValue> item)
	{
		return innerDict.Contains(item);
	}

	public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
	{
		innerDict.CopyTo(array, arrayIndex);
	}

	public bool Remove(KeyValuePair<TKey, TValue> item)
	{
		return Remove(item.Key);
	}

	public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
	{
		return innerDict.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return innerDict.GetEnumerator();
	}
}
