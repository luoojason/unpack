using System;
using System.Collections.Generic;

namespace OpenRA.Primitives;

internal static class LongBitSetAllocator<T> where T : class
{
	private static readonly Cache<string, long> Bits = new Cache<string, long>(Allocate);

	private static long nextBits = 1L;

	private static long Allocate(string value)
	{
		lock (Bits)
		{
			long result = nextBits;
			nextBits <<= 1;
			if (nextBits == 0L)
			{
				throw new OverflowException("Trying to allocate bit index outside of index 64.");
			}
			return result;
		}
	}

	public static long GetBits(string[] values)
	{
		long num = 0L;
		lock (Bits)
		{
			foreach (string key in values)
			{
				num |= Bits[key];
			}
			return num;
		}
	}

	public static long GetBitsNoAlloc(string[] values)
	{
		long num = 0L;
		lock (Bits)
		{
			foreach (string key in values)
			{
				if (Bits.TryGetValue(key, out var value))
				{
					num |= value;
				}
			}
			return num;
		}
	}

	public static IEnumerable<string> GetStrings(long bits)
	{
		List<string> list = new List<string>();
		lock (Bits)
		{
			foreach (KeyValuePair<string, long> bit in Bits)
			{
				if ((bit.Value & bits) != 0L)
				{
					list.Add(bit.Key);
				}
			}
			return list;
		}
	}

	public static bool BitsContainString(long bits, string value)
	{
		long value2;
		lock (Bits)
		{
			if (!Bits.TryGetValue(value, out value2))
			{
				return false;
			}
		}
		return (bits & value2) != 0;
	}

	public static void Reset()
	{
		lock (Bits)
		{
			Bits.Clear();
			nextBits = 1L;
		}
	}
}
