using System;
using System.Linq;

namespace OpenRA.Primitives;

public readonly struct Polygon
{
	public static readonly Polygon Empty = new Polygon(Rectangle.Empty);

	public readonly Rectangle BoundingRect;

	public readonly int2[] Vertices;

	private readonly bool isRectangle;

	public bool IsEmpty => BoundingRect.IsEmpty;

	public Polygon(Rectangle bounds)
	{
		BoundingRect = bounds;
		Vertices = new int2[4] { bounds.TopLeft, bounds.BottomLeft, bounds.BottomRight, bounds.TopRight };
		isRectangle = true;
	}

	public Polygon(int2[] vertices)
	{
		if (vertices != null && vertices.Length != 0)
		{
			Vertices = vertices;
			int num = int.MaxValue;
			int num2 = int.MinValue;
			int num3 = int.MaxValue;
			int num4 = int.MinValue;
			for (int i = 0; i < vertices.Length; i++)
			{
				int2 int3 = vertices[i];
				num = Math.Min(num, int3.X);
				num2 = Math.Max(num2, int3.X);
				num3 = Math.Min(num3, int3.Y);
				num4 = Math.Max(num4, int3.Y);
			}
			BoundingRect = Rectangle.FromLTRB(num, num3, num2, num4);
			isRectangle = false;
		}
		else
		{
			isRectangle = true;
			BoundingRect = Rectangle.Empty;
			Vertices = Exts.MakeArray(4, (int _) => int2.Zero);
		}
	}

	public bool Contains(int2 xy)
	{
		if (!isRectangle)
		{
			return Vertices.PolygonContains(xy);
		}
		return BoundingRect.Contains(xy);
	}

	public bool IntersectsWith(Rectangle rect)
	{
		bool flag = BoundingRect.Left < rect.Right && BoundingRect.Right > rect.Left && BoundingRect.Top < rect.Bottom && BoundingRect.Bottom > rect.Top;
		if (isRectangle)
		{
			return flag;
		}
		if (!flag)
		{
			return false;
		}
		if ((rect.Left <= BoundingRect.Left && rect.Right >= BoundingRect.Right) || (rect.Top <= BoundingRect.Top && rect.Bottom >= BoundingRect.Bottom))
		{
			return true;
		}
		if (Vertices.PolygonContains(rect.TopLeft) || Vertices.PolygonContains(rect.TopRight) || Vertices.PolygonContains(rect.BottomLeft) || Vertices.PolygonContains(rect.BottomRight))
		{
			return true;
		}
		if (Vertices.Any((int2 p) => rect.Contains(p)))
		{
			return true;
		}
		int2[] array = new int2[4] { rect.TopLeft, rect.BottomLeft, rect.BottomRight, rect.TopRight };
		for (int num = 0; num < Vertices.Length; num++)
		{
			for (int num2 = 0; num2 < 4; num2++)
			{
				if (Exts.LinesIntersect(Vertices[num], Vertices[(num + 1) % Vertices.Length], array[num2], array[(num2 + 1) % 4]))
				{
					return true;
				}
			}
		}
		return false;
	}

	public override int GetHashCode()
	{
		int num = BoundingRect.GetHashCode();
		int2[] vertices = Vertices;
		for (int i = 0; i < vertices.Length; i++)
		{
			int2 int3 = vertices[i];
			num = ((num << 5) + num) ^ int3.GetHashCode();
		}
		return num;
	}
}
