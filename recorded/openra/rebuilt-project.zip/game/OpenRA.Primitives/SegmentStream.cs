using System;
using System.ComponentModel;
using System.IO;

namespace OpenRA.Primitives;

public class SegmentStream : Stream
{
	public readonly Stream BaseStream;

	public readonly long BaseOffset;

	public readonly long BaseCount;

	public override bool CanSeek => true;

	public override bool CanRead => BaseStream.CanRead;

	public override bool CanWrite => BaseStream.CanWrite;

	public override long Length => BaseCount;

	public override long Position
	{
		get
		{
			return BaseStream.Position - BaseOffset;
		}
		set
		{
			BaseStream.Position = BaseOffset + value;
		}
	}

	public override bool CanTimeout => BaseStream.CanTimeout;

	public override int ReadTimeout
	{
		get
		{
			return BaseStream.ReadTimeout;
		}
		set
		{
			BaseStream.ReadTimeout = value;
		}
	}

	public override int WriteTimeout
	{
		get
		{
			return BaseStream.WriteTimeout;
		}
		set
		{
			BaseStream.WriteTimeout = value;
		}
	}

	public SegmentStream(Stream stream, long offset, long count)
	{
		if (stream == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream.CanSeek)
		{
			throw new ArgumentException("stream must be seekable.", "stream");
		}
		if (offset < 0)
		{
			throw new ArgumentOutOfRangeException("offset", "offset must be non-negative.");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count", "count must be non-negative.");
		}
		BaseStream = stream;
		BaseOffset = offset;
		BaseCount = count;
		stream.Seek(BaseOffset, SeekOrigin.Begin);
	}

	public override int ReadByte()
	{
		if (Position < Length)
		{
			return BaseStream.ReadByte();
		}
		return -1;
	}

	public override int Read(byte[] buffer, int offset, int count)
	{
		return Read(buffer.AsSpan(offset, count));
	}

	public override int Read(Span<byte> buffer)
	{
		long num = Length - Position;
		if (num <= 0)
		{
			return 0;
		}
		return BaseStream.Read(buffer.Slice(0, (int)Math.Min(num, buffer.Length)));
	}

	public override void WriteByte(byte value)
	{
		if (Position < Length)
		{
			BaseStream.WriteByte(value);
		}
		throw new IOException("Attempted to write past the end of the stream.");
	}

	public override void Write(byte[] buffer, int offset, int count)
	{
		Write(buffer.AsSpan(offset, count));
	}

	public override void Write(ReadOnlySpan<byte> buffer)
	{
		if (Position + buffer.Length >= Length)
		{
			throw new IOException("Attempted to write past the end of the stream.");
		}
		BaseStream.Write(buffer);
	}

	public override void Flush()
	{
		BaseStream.Flush();
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		return origin switch
		{
			SeekOrigin.Begin => BaseStream.Seek(BaseOffset + offset, SeekOrigin.Begin) - offset, 
			SeekOrigin.Current => BaseStream.Seek(offset, SeekOrigin.Current) - offset, 
			SeekOrigin.End => BaseStream.Seek(offset, SeekOrigin.End) - offset, 
			_ => throw new InvalidEnumArgumentException("origin", (int)origin, typeof(SeekOrigin)), 
		};
	}

	public override void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			BaseStream.Dispose();
		}
		base.Dispose(disposing);
	}

	private static long GetOverallNestedOffset(Stream stream, out Stream overallBaseStream)
	{
		long num = 0L;
		overallBaseStream = stream;
		if (stream is SegmentStream segmentStream)
		{
			num += segmentStream.BaseOffset + GetOverallNestedOffset(segmentStream.BaseStream, out overallBaseStream);
		}
		return num;
	}

	public static Stream CreateWithoutOwningStream(Stream stream, long offset, int count)
	{
		long offset2 = offset + GetOverallNestedOffset(stream, out var overallBaseStream);
		if (overallBaseStream.GetType() == typeof(FileStream))
		{
			string name = ((FileStream)overallBaseStream).Name;
			return new SegmentStream(File.OpenRead(name), offset2, count);
		}
		stream.Seek(offset, SeekOrigin.Begin);
		return new MemoryStream(stream.ReadBytes(count));
	}
}
