using System;

namespace OpenRA.Primitives;

public readonly struct Rectangle : IEquatable<Rectangle>
{
	public readonly int X;

	public readonly int Y;

	public readonly int Width;

	public readonly int Height;

	public static readonly Rectangle Empty;

	public int Left => X;

	public int Right => X + Width;

	public int Top => Y;

	public int Bottom => Y + Height;

	public bool IsEmpty
	{
		get
		{
			if (X == 0 && Y == 0 && Width == 0)
			{
				return Height == 0;
			}
			return false;
		}
	}

	public int2 Location => new int2(X, Y);

	public Size Size => new Size(Width, Height);

	public int2 TopLeft => Location;

	public int2 TopRight => new int2(X + Width, Y);

	public int2 BottomLeft => new int2(X, Y + Height);

	public int2 BottomRight => new int2(X + Width, Y + Height);

	public static Rectangle FromLTRB(int left, int top, int right, int bottom)
	{
		return new Rectangle(left, top, right - left, bottom - top);
	}

	public static Rectangle Union(Rectangle a, Rectangle b)
	{
		return FromLTRB(Math.Min(a.Left, b.Left), Math.Min(a.Top, b.Top), Math.Max(a.Right, b.Right), Math.Max(a.Bottom, b.Bottom));
	}

	public static bool operator ==(Rectangle left, Rectangle right)
	{
		if (left.X == right.X && left.Y == right.Y && left.Width == right.Width)
		{
			return left.Height == right.Height;
		}
		return false;
	}

	public static bool operator !=(Rectangle left, Rectangle right)
	{
		return !(left == right);
	}

	public Rectangle(int x, int y, int width, int height)
	{
		X = x;
		Y = y;
		Width = width;
		Height = height;
	}

	public Rectangle(int2 location, Size size)
	{
		X = location.X;
		Y = location.Y;
		Width = size.Width;
		Height = size.Height;
	}

	public bool Contains(int x, int y)
	{
		if (x >= Left && x < Right && y >= Top)
		{
			return y < Bottom;
		}
		return false;
	}

	public bool Contains(int2 pt)
	{
		return Contains(pt.X, pt.Y);
	}

	public bool Equals(Rectangle other)
	{
		return this == other;
	}

	public override bool Equals(object obj)
	{
		if (!(obj is Rectangle))
		{
			return false;
		}
		return this == (Rectangle)obj;
	}

	public override int GetHashCode()
	{
		return (Height + Width) ^ (X + Y);
	}

	public bool IntersectsWith(Rectangle rect)
	{
		if (Left < rect.Right && Right > rect.Left && Top < rect.Bottom)
		{
			return Bottom > rect.Top;
		}
		return false;
	}

	private bool IntersectsWithInclusive(Rectangle r)
	{
		if (Left <= r.Right && Right >= r.Left && Top <= r.Bottom)
		{
			return Bottom >= r.Top;
		}
		return false;
	}

	public static Rectangle Intersect(Rectangle a, Rectangle b)
	{
		if (!a.IntersectsWithInclusive(b))
		{
			return Empty;
		}
		return FromLTRB(Math.Max(a.Left, b.Left), Math.Max(a.Top, b.Top), Math.Min(a.Right, b.Right), Math.Min(a.Bottom, b.Bottom));
	}

	public bool Contains(Rectangle rect)
	{
		return rect == Intersect(this, rect);
	}

	public static Rectangle operator *(int a, Rectangle b)
	{
		return new Rectangle(a * b.X, a * b.Y, a * b.Width, a * b.Height);
	}

	public override string ToString()
	{
		return $"{X},{Y},{Width},{Height}";
	}
}
