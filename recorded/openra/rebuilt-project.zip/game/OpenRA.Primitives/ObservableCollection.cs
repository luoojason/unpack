using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace OpenRA.Primitives;

public class ObservableCollection<T> : Collection<T>, IObservableCollection
{
	public IEnumerable ObservedItems => Items;

	public event Action<IObservableCollection, object> OnAdd = (IObservableCollection x, object k) =>
	{
	};

	public event Action<IObservableCollection, object> OnRemove = (IObservableCollection x, object k) =>
	{
	};

	public event Action<IObservableCollection, int> OnRemoveAt = (IObservableCollection x, int i) =>
	{
	};

	public event Action<IObservableCollection, object, object> OnSet = (IObservableCollection x, object o, object n) =>
	{
	};

	public event Action<IObservableCollection> OnRefresh = (IObservableCollection x) =>
	{
	};

	public ObservableCollection()
	{
	}

	public ObservableCollection(IList<T> list)
		: base(list)
	{
	}

	protected override void SetItem(int index, T item)
	{
		T val = base[index];
		base.SetItem(index, item);
		OnSet(this, val, item);
	}

	protected override void InsertItem(int index, T item)
	{
		base.InsertItem(index, item);
		OnAdd(this, item);
	}

	protected override void ClearItems()
	{
		base.ClearItems();
		OnRefresh(this);
	}

	protected override void RemoveItem(int index)
	{
		base.RemoveItem(index);
		OnRemoveAt(this, index);
	}
}
