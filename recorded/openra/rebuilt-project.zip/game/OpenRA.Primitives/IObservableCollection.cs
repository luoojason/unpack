using System;
using System.Collections;

namespace OpenRA.Primitives;

public interface IObservableCollection
{
	IEnumerable ObservedItems { get; }

	event Action<IObservableCollection, object> OnAdd;

	event Action<IObservableCollection, object> OnRemove;

	event Action<IObservableCollection, int> OnRemoveAt;

	event Action<IObservableCollection, object, object> OnSet;

	event Action<IObservableCollection> OnRefresh;
}
