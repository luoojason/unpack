using System;

namespace OpenRA.Primitives;

public class CachedTransform<T, U>
{
	private readonly Func<T, U> transform;

	private bool initialized;

	private T lastInput;

	private U lastOutput;

	public CachedTransform(Func<T, U> transform)
	{
		this.transform = transform;
	}

	public U Update(T input)
	{
		if (initialized && ((input == null && lastInput == null) || (input != null && input.Equals(lastInput))))
		{
			return lastOutput;
		}
		lastInput = input;
		lastOutput = transform(input);
		initialized = true;
		return lastOutput;
	}
}
