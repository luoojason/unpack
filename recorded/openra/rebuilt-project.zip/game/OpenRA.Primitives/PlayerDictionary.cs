using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public readonly struct PlayerDictionary<T> : IReadOnlyList<T>, IEnumerable<T>, IEnumerable, IReadOnlyCollection<T>, IReadOnlyDictionary<Player, T>, IEnumerable<KeyValuePair<Player, T>>, IReadOnlyCollection<KeyValuePair<Player, T>> where T : class
{
	private readonly T[] valueByPlayerIndex;

	private readonly Dictionary<Player, T> valueByPlayer;

	public T this[Player player] => valueByPlayer[player];

	public T this[int playerIndex] => valueByPlayerIndex[playerIndex];

	public int Count => valueByPlayerIndex.Length;

	public IEnumerable<Player> Keys => ((IReadOnlyDictionary<Player, T>)valueByPlayer).Keys;

	public IEnumerable<T> Values => ((IReadOnlyDictionary<Player, T>)valueByPlayer).Values;

	public PlayerDictionary(World world, Func<Player, int, T> valueFactory)
	{
		Player[] players = world.Players;
		if (players.Length == 0)
		{
			throw new InvalidOperationException("The players in the world have not yet been set.");
		}
		valueByPlayerIndex = new T[players.Length];
		valueByPlayer = new Dictionary<Player, T>(players.Length);
		for (int i = 0; i < players.Length; i++)
		{
			Player player = players[i];
			T val = valueFactory(player, i);
			valueByPlayerIndex[i] = val;
			valueByPlayer[player] = val;
		}
	}

	public PlayerDictionary(World world, Func<Player, T> valueFactory)
		: this(world, (Player player, int _) => valueFactory(player))
	{
	}

	public IEnumerator<T> GetEnumerator()
	{
		return ((IEnumerable<T>)valueByPlayerIndex).GetEnumerator();
	}

	bool IReadOnlyDictionary<Player, T>.ContainsKey(Player key)
	{
		return valueByPlayer.ContainsKey(key);
	}

	bool IReadOnlyDictionary<Player, T>.TryGetValue(Player key, out T value)
	{
		return valueByPlayer.TryGetValue(key, out value);
	}

	IEnumerator<KeyValuePair<Player, T>> IEnumerable<KeyValuePair<Player, T>>.GetEnumerator()
	{
		return valueByPlayer.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
