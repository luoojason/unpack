using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class ObservableList<T> : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable, IObservableCollection
{
	protected IList<T> innerList;

	public int Count => innerList.Count;

	public T this[int index]
	{
		get
		{
			return innerList[index];
		}
		set
		{
			T val = innerList[index];
			innerList[index] = value;
			OnSet(this, val, value);
		}
	}

	public IEnumerable ObservedItems => innerList;

	public bool IsReadOnly => innerList.IsReadOnly;

	public event Action<IObservableCollection, object> OnAdd = (IObservableCollection x, object k) =>
	{
	};

	public event Action<IObservableCollection, object> OnRemove = (IObservableCollection x, object k) =>
	{
	};

	public event Action<IObservableCollection, int> OnRemoveAt = (IObservableCollection x, int i) =>
	{
	};

	public event Action<IObservableCollection, object, object> OnSet = (IObservableCollection x, object o, object n) =>
	{
	};

	public event Action<IObservableCollection> OnRefresh = (IObservableCollection x) =>
	{
	};

	protected void FireOnRefresh()
	{
		OnRefresh(this);
	}

	public ObservableList()
	{
		innerList = new List<T>();
	}

	public virtual void Add(T item)
	{
		innerList.Add(item);
		OnAdd(this, item);
	}

	public bool Remove(T item)
	{
		bool flag = innerList.Remove(item);
		if (flag)
		{
			OnRemove(this, item);
		}
		return flag;
	}

	public void Clear()
	{
		innerList.Clear();
		OnRefresh(this);
	}

	public void Insert(int index, T item)
	{
		innerList.Insert(index, item);
		OnRefresh(this);
	}

	public int IndexOf(T item)
	{
		return innerList.IndexOf(item);
	}

	public bool Contains(T item)
	{
		return innerList.Contains(item);
	}

	public void RemoveAt(int index)
	{
		innerList.RemoveAt(index);
		OnRemoveAt(this, index);
	}

	public void CopyTo(T[] array, int arrayIndex)
	{
		innerList.CopyTo(array, arrayIndex);
	}

	public IEnumerator<T> GetEnumerator()
	{
		return innerList.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return innerList.GetEnumerator();
	}
}
