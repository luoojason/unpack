using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public readonly struct LongBitSet<T> : IEnumerable<string>, IEnumerable, IEquatable<LongBitSet<T>> where T : class
{
	private readonly long bits;

	public bool IsEmpty => bits == 0;

	public LongBitSet(params string[] values)
		: this(LongBitSetAllocator<T>.GetBits(values))
	{
	}

	private LongBitSet(long bits)
	{
		this.bits = bits;
	}

	public static LongBitSet<T> FromStringsNoAlloc(string[] values)
	{
		return new LongBitSet<T>(LongBitSetAllocator<T>.GetBitsNoAlloc(values));
	}

	public static void Reset()
	{
		LongBitSetAllocator<T>.Reset();
	}

	public override string ToString()
	{
		return LongBitSetAllocator<T>.GetStrings(bits).JoinWith(",");
	}

	public static bool operator ==(LongBitSet<T> me, LongBitSet<T> other)
	{
		return me.bits == other.bits;
	}

	public static bool operator !=(LongBitSet<T> me, LongBitSet<T> other)
	{
		return !(me == other);
	}

	public bool Equals(LongBitSet<T> other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is LongBitSet<T> other)
		{
			return Equals(other);
		}
		return false;
	}

	public override int GetHashCode()
	{
		return bits.GetHashCode();
	}

	public bool IsProperSubsetOf(LongBitSet<T> other)
	{
		if (IsSubsetOf(other))
		{
			return !SetEquals(other);
		}
		return false;
	}

	public bool IsProperSupersetOf(LongBitSet<T> other)
	{
		if (IsSupersetOf(other))
		{
			return !SetEquals(other);
		}
		return false;
	}

	public bool IsSubsetOf(LongBitSet<T> other)
	{
		return (bits | other.bits) == other.bits;
	}

	public bool IsSupersetOf(LongBitSet<T> other)
	{
		return (bits | other.bits) == bits;
	}

	public bool Overlaps(LongBitSet<T> other)
	{
		return (bits & other.bits) != 0;
	}

	public bool SetEquals(LongBitSet<T> other)
	{
		return bits == other.bits;
	}

	public bool Contains(string value)
	{
		return LongBitSetAllocator<T>.BitsContainString(bits, value);
	}

	public IEnumerator<string> GetEnumerator()
	{
		return LongBitSetAllocator<T>.GetStrings(bits).GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}

	public LongBitSet<T> Except(LongBitSet<T> other)
	{
		return new LongBitSet<T>(bits & ~other.bits);
	}

	public LongBitSet<T> Intersect(LongBitSet<T> other)
	{
		return new LongBitSet<T>(bits & other.bits);
	}

	public LongBitSet<T> SymmetricExcept(LongBitSet<T> other)
	{
		return new LongBitSet<T>(bits ^ other.bits);
	}

	public LongBitSet<T> Union(LongBitSet<T> other)
	{
		return new LongBitSet<T>(bits | other.bits);
	}
}
