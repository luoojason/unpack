using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class Cache<T, U> : IReadOnlyDictionary<T, U>, IEnumerable<KeyValuePair<T, U>>, IEnumerable, IReadOnlyCollection<KeyValuePair<T, U>>
{
	private readonly Dictionary<T, U> cache;

	private readonly Func<T, U> loader;

	public U this[T key] => cache.GetOrAdd(key, loader);

	public int Count => cache.Count;

	public ICollection<T> Keys => cache.Keys;

	public ICollection<U> Values => cache.Values;

	IEnumerable<T> IReadOnlyDictionary<T, U>.Keys => cache.Keys;

	IEnumerable<U> IReadOnlyDictionary<T, U>.Values => cache.Values;

	public Cache(Func<T, U> loader, IEqualityComparer<T> c)
	{
		if (loader == null)
		{
			throw new ArgumentNullException("loader");
		}
		this.loader = loader;
		cache = new Dictionary<T, U>(c);
	}

	public Cache(Func<T, U> loader)
		: this(loader, (IEqualityComparer<T>)EqualityComparer<T>.Default)
	{
	}

	public bool ContainsKey(T key)
	{
		return cache.ContainsKey(key);
	}

	public bool TryGetValue(T key, out U value)
	{
		return cache.TryGetValue(key, out value);
	}

	public void Clear()
	{
		cache.Clear();
	}

	public IEnumerator<KeyValuePair<T, U>> GetEnumerator()
	{
		return cache.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
