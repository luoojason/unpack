using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class TypeDictionary : IEnumerable<object>, IEnumerable
{
	private interface ITypeContainer
	{
		int Count { get; }

		void Add(object value);

		void Remove(object value);

		void TrimExcess();
	}

	private sealed class TypeContainer<T> : ITypeContainer
	{
		public List<T> Objects { get; } = new List<T>();

		public int Count => Objects.Count;

		public void Add(object value)
		{
			Objects.Add((T)value);
		}

		public void Remove(object value)
		{
			Objects.Remove((T)value);
		}

		public void TrimExcess()
		{
			Objects.TrimExcess();
		}
	}

	private static readonly Func<Type, ITypeContainer> CreateTypeContainer = (Type t) => (ITypeContainer)typeof(TypeContainer<>).MakeGenericType(t).GetConstructor(Type.EmptyTypes).Invoke(null);

	private readonly Dictionary<Type, ITypeContainer> data = new Dictionary<Type, ITypeContainer>();

	private ITypeContainer InnerGet(Type t)
	{
		return data.GetOrAdd(t, CreateTypeContainer);
	}

	public void Add(object val)
	{
		Type type = val.GetType();
		Type[] interfaces = type.GetInterfaces();
		foreach (Type t in interfaces)
		{
			InnerAdd(t, val);
		}
		foreach (Type item in type.BaseTypes())
		{
			InnerAdd(item, val);
		}
	}

	private void InnerAdd(Type t, object val)
	{
		InnerGet(t).Add(val);
	}

	public bool Contains<T>()
	{
		return data.ContainsKey(typeof(T));
	}

	public bool Contains(Type t)
	{
		return data.ContainsKey(t);
	}

	public T Get<T>()
	{
		return Get<T>(throwsIfMissing: true);
	}

	public T GetOrDefault<T>()
	{
		return Get<T>(throwsIfMissing: false);
	}

	private T Get<T>(bool throwsIfMissing)
	{
		if (!data.TryGetValue(typeof(T), out var value))
		{
			if (throwsIfMissing)
			{
				throw new InvalidOperationException($"TypeDictionary does not contain instance of type `{typeof(T)}`");
			}
			return default;
		}
		List<T> objects = ((TypeContainer<T>)value).Objects;
		if (objects.Count > 1)
		{
			throw new InvalidOperationException($"TypeDictionary contains multiple instances of type `{typeof(T)}`");
		}
		return objects[0];
	}

	public IReadOnlyCollection<T> WithInterface<T>()
	{
		if (data.TryGetValue(typeof(T), out var value))
		{
			return ((TypeContainer<T>)value).Objects;
		}
		return Array.Empty<T>();
	}

	public void Remove<T>(T val)
	{
		Type type = val.GetType();
		Type[] interfaces = type.GetInterfaces();
		foreach (Type t in interfaces)
		{
			InnerRemove(t, val);
		}
		foreach (Type item in type.BaseTypes())
		{
			InnerRemove(item, val);
		}
	}

	private void InnerRemove(Type t, object val)
	{
		if (data.TryGetValue(t, out var value))
		{
			value.Remove(val);
			if (value.Count == 0)
			{
				data.Remove(t);
			}
		}
	}

	public void TrimExcess()
	{
		data.TrimExcess();
		foreach (Type key in data.Keys)
		{
			InnerGet(key).TrimExcess();
		}
	}

	public IEnumerator<object> GetEnumerator()
	{
		return WithInterface<object>().GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
