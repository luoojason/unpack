using System;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public sealed class PriorityQueue<T, TComparer> : IPriorityQueue<T> where TComparer : struct, IComparer<T>
{
	private readonly TComparer comparer;

	private T[] items;

	private int level;

	private int index;

	public bool Empty => level == 0;

	public PriorityQueue(TComparer comparer)
	{
		this.comparer = comparer;
		items = new T[1];
	}

	public void Add(T item)
	{
		int num = level;
		int num2 = index;
		while (num >= 1)
		{
			T val = items[AboveIndex(num, num2)];
			if (comparer.Compare(val, item) <= 0)
			{
				break;
			}
			items[Index(num, num2)] = val;
			num--;
			num2 >>= 1;
		}
		items[Index(num, num2)] = item;
		if (++index >= 1 << level)
		{
			index = 0;
			int num3 = 2 * (1 << ++level);
			if (num3 - 1 >= items.Length)
			{
				Array.Resize(ref items, num3);
			}
		}
	}

	private static int Index(int level, int index)
	{
		return (1 << level) - 1 + index;
	}

	private static int AboveIndex(int level, int index)
	{
		return (1 << level - 1) - 1 + (index >> 1);
	}

	private int IndexLast()
	{
		int num = level;
		int num2 = index;
		if (--num2 < 0)
		{
			num2 = (1 << --num) - 1;
		}
		return Index(num, num2);
	}

	public T Peek()
	{
		if (level <= 0 && index <= 0)
		{
			throw new InvalidOperationException("PriorityQueue empty.");
		}
		return items[Index(0, 0)];
	}

	public T Pop()
	{
		T result = Peek();
		BubbleInto(0, 0, items[IndexLast()]);
		if (--index < 0)
		{
			index = (1 << --level) - 1;
		}
		return result;
	}

	private void BubbleInto(int intoLevel, int intoIndex, T val)
	{
		while (true)
		{
			int num = intoLevel + 1;
			int num2 = intoIndex << 1;
			if (num > level || (num == level && num2 >= index))
			{
				items[Index(intoLevel, intoIndex)] = val;
				return;
			}
			T val2 = items[Index(num, num2)];
			if (num < level || (num == level && num2 < index - 1))
			{
				T val3 = items[Index(num, num2 + 1)];
				if (comparer.Compare(val2, val3) >= 0)
				{
					val2 = val3;
					num2++;
				}
			}
			if (comparer.Compare(val, val2) <= 0)
			{
				break;
			}
			items[Index(intoLevel, intoIndex)] = val2;
			intoLevel = num;
			intoIndex = num2;
		}
		items[Index(intoLevel, intoIndex)] = val;
	}
}
