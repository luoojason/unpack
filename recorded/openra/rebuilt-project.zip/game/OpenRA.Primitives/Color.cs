using System;
using System.Globalization;
using OpenRA.Scripting;

namespace OpenRA.Primitives;

public readonly struct Color : IEquatable<Color>, IScriptBindable
{
	private readonly uint argb;

	public byte A => (byte)(argb >> 24);

	public byte R => (byte)(argb >> 16);

	public byte G => (byte)(argb >> 8);

	public byte B => (byte)argb;

	public static Color Transparent => FromArgb(16777215u);

	public static Color AliceBlue => FromArgb(4293982463u);

	public static Color AntiqueWhite => FromArgb(4294634455u);

	public static Color Aqua => FromArgb(4278255615u);

	public static Color Aquamarine => FromArgb(4286578644u);

	public static Color Azure => FromArgb(4293984255u);

	public static Color Beige => FromArgb(4294309340u);

	public static Color Bisque => FromArgb(4294960324u);

	public static Color Black => FromArgb(4278190080u);

	public static Color BlanchedAlmond => FromArgb(4294962125u);

	public static Color Blue => FromArgb(4278190335u);

	public static Color BlueViolet => FromArgb(4287245282u);

	public static Color Brown => FromArgb(4289014314u);

	public static Color BurlyWood => FromArgb(4292786311u);

	public static Color CadetBlue => FromArgb(4284456608u);

	public static Color Chartreuse => FromArgb(4286578432u);

	public static Color Chocolate => FromArgb(4291979550u);

	public static Color Coral => FromArgb(4294934352u);

	public static Color CornflowerBlue => FromArgb(4284782061u);

	public static Color Cornsilk => FromArgb(4294965468u);

	public static Color Crimson => FromArgb(4292613180u);

	public static Color Cyan => FromArgb(4278255615u);

	public static Color DarkBlue => FromArgb(4278190219u);

	public static Color DarkCyan => FromArgb(4278225803u);

	public static Color DarkGoldenrod => FromArgb(4290283019u);

	public static Color DarkGray => FromArgb(4289309097u);

	public static Color DarkGreen => FromArgb(4278215680u);

	public static Color DarkKhaki => FromArgb(4290623339u);

	public static Color DarkMagenta => FromArgb(4287299723u);

	public static Color DarkOliveGreen => FromArgb(4283788079u);

	public static Color DarkOrange => FromArgb(4294937600u);

	public static Color DarkOrchid => FromArgb(4288230092u);

	public static Color DarkRed => FromArgb(4287299584u);

	public static Color DarkSalmon => FromArgb(4293498490u);

	public static Color DarkSeaGreen => FromArgb(4287609995u);

	public static Color DarkSlateBlue => FromArgb(4282924427u);

	public static Color DarkSlateGray => FromArgb(4281290575u);

	public static Color DarkTurquoise => FromArgb(4278243025u);

	public static Color DarkViolet => FromArgb(4287889619u);

	public static Color DeepPink => FromArgb(4294907027u);

	public static Color DeepSkyBlue => FromArgb(4278239231u);

	public static Color DimGray => FromArgb(4285098345u);

	public static Color DodgerBlue => FromArgb(4280193279u);

	public static Color Firebrick => FromArgb(4289864226u);

	public static Color FloralWhite => FromArgb(4294966000u);

	public static Color ForestGreen => FromArgb(4280453922u);

	public static Color Fuchsia => FromArgb(4294902015u);

	public static Color Gainsboro => FromArgb(4292664540u);

	public static Color GhostWhite => FromArgb(4294506751u);

	public static Color Gold => FromArgb(4294956800u);

	public static Color Goldenrod => FromArgb(4292519200u);

	public static Color Gray => FromArgb(4286611584u);

	public static Color Green => FromArgb(4278222848u);

	public static Color GreenYellow => FromArgb(4289593135u);

	public static Color Honeydew => FromArgb(4293984240u);

	public static Color HotPink => FromArgb(4294928820u);

	public static Color IndianRed => FromArgb(4291648604u);

	public static Color Indigo => FromArgb(4283105410u);

	public static Color Ivory => FromArgb(4294967280u);

	public static Color Khaki => FromArgb(4293977740u);

	public static Color Lavender => FromArgb(4293322490u);

	public static Color LavenderBlush => FromArgb(4294963445u);

	public static Color LawnGreen => FromArgb(4286381056u);

	public static Color LemonChiffon => FromArgb(4294965965u);

	public static Color LightBlue => FromArgb(4289583334u);

	public static Color LightCoral => FromArgb(4293951616u);

	public static Color LightCyan => FromArgb(4292935679u);

	public static Color LightGoldenrodYellow => FromArgb(4294638290u);

	public static Color LightGray => FromArgb(4292072403u);

	public static Color LightGreen => FromArgb(4287688336u);

	public static Color LightPink => FromArgb(4294948545u);

	public static Color LightSalmon => FromArgb(4294942842u);

	public static Color LightSeaGreen => FromArgb(4280332970u);

	public static Color LightSkyBlue => FromArgb(4287090426u);

	public static Color LightSlateGray => FromArgb(4286023833u);

	public static Color LightSteelBlue => FromArgb(4289774814u);

	public static Color LightYellow => FromArgb(4294967264u);

	public static Color Lime => FromArgb(4278255360u);

	public static Color LimeGreen => FromArgb(4281519410u);

	public static Color Linen => FromArgb(4294635750u);

	public static Color Magenta => FromArgb(4294902015u);

	public static Color Maroon => FromArgb(4286578688u);

	public static Color MediumAquamarine => FromArgb(4284927402u);

	public static Color MediumBlue => FromArgb(4278190285u);

	public static Color MediumOrchid => FromArgb(4290401747u);

	public static Color MediumPurple => FromArgb(4287852763u);

	public static Color MediumSeaGreen => FromArgb(4282168177u);

	public static Color MediumSlateBlue => FromArgb(4286277870u);

	public static Color MediumSpringGreen => FromArgb(4278254234u);

	public static Color MediumTurquoise => FromArgb(4282962380u);

	public static Color MediumVioletRed => FromArgb(4291237253u);

	public static Color MidnightBlue => FromArgb(4279834992u);

	public static Color MintCream => FromArgb(4294311930u);

	public static Color MistyRose => FromArgb(4294960353u);

	public static Color Moccasin => FromArgb(4294960309u);

	public static Color NavajoWhite => FromArgb(4294958765u);

	public static Color Navy => FromArgb(4278190208u);

	public static Color OldLace => FromArgb(4294833638u);

	public static Color Olive => FromArgb(4286611456u);

	public static Color OliveDrab => FromArgb(4285238819u);

	public static Color Orange => FromArgb(4294944000u);

	public static Color OrangeRed => FromArgb(4294919424u);

	public static Color Orchid => FromArgb(4292505814u);

	public static Color PaleGoldenrod => FromArgb(4293847210u);

	public static Color PaleGreen => FromArgb(4288215960u);

	public static Color PaleTurquoise => FromArgb(4289720046u);

	public static Color PaleVioletRed => FromArgb(4292571283u);

	public static Color PapayaWhip => FromArgb(4294963157u);

	public static Color PeachPuff => FromArgb(4294957753u);

	public static Color Peru => FromArgb(4291659071u);

	public static Color Pink => FromArgb(4294951115u);

	public static Color Plum => FromArgb(4292714717u);

	public static Color PowderBlue => FromArgb(4289781990u);

	public static Color Purple => FromArgb(4286578816u);

	public static Color Red => FromArgb(4294901760u);

	public static Color RosyBrown => FromArgb(4290547599u);

	public static Color RoyalBlue => FromArgb(4282477025u);

	public static Color SaddleBrown => FromArgb(4287317267u);

	public static Color Salmon => FromArgb(4294606962u);

	public static Color SandyBrown => FromArgb(4294222944u);

	public static Color SeaGreen => FromArgb(4281240407u);

	public static Color SeaShell => FromArgb(4294964718u);

	public static Color Sienna => FromArgb(4288696877u);

	public static Color Silver => FromArgb(4290822336u);

	public static Color SkyBlue => FromArgb(4287090411u);

	public static Color SlateBlue => FromArgb(4285160141u);

	public static Color SlateGray => FromArgb(4285563024u);

	public static Color Snow => FromArgb(4294966010u);

	public static Color SpringGreen => FromArgb(4278255487u);

	public static Color SteelBlue => FromArgb(4282811060u);

	public static Color Tan => FromArgb(4291998860u);

	public static Color Teal => FromArgb(4278222976u);

	public static Color Thistle => FromArgb(4292394968u);

	public static Color Tomato => FromArgb(4294927175u);

	public static Color Turquoise => FromArgb(4282441936u);

	public static Color Violet => FromArgb(4293821166u);

	public static Color Wheat => FromArgb(4294303411u);

	public static Color White => FromArgb(uint.MaxValue);

	public static Color WhiteSmoke => FromArgb(4294309365u);

	public static Color Yellow => FromArgb(4294967040u);

	public static Color YellowGreen => FromArgb(4288335154u);

	public static Color FromArgb(int red, int green, int blue)
	{
		return FromArgb(255, red, green, blue);
	}

	public static Color FromArgb(int alpha, int red, int green, int blue)
	{
		return new Color((uint)(((byte)alpha << 24) + ((byte)red << 16) + ((byte)green << 8) + (byte)blue));
	}

	public static Color FromAhsl(int alpha, float h, float s, float l)
	{
		float num = l + s * Math.Min(l, 1f - l);
		float s2 = ((num > 0f) ? (2f * (1f - l / num)) : 0f);
		return FromAhsv(alpha, h, s2, num);
	}

	public static Color FromAhsv(int alpha, float h, float s, float v)
	{
		var (num, num2, num3) = HsvToRgb(h, s, v);
		return FromArgb(alpha, (byte)Math.Round(255f * num), (byte)Math.Round(255f * num2), (byte)Math.Round(255f * num3));
	}

	public static Color FromAhsv(float h, float s, float v)
	{
		return FromAhsv(255, h, s, v);
	}

	public (int A, float H, float S, float V) ToAhsv()
	{
		var (item, item2, item3) = RgbToHsv(R, G, B);
		return (A: A, H: item, S: item2, V: item3);
	}

	private Color(uint argb)
	{
		this.argb = argb;
	}

	public uint ToArgb()
	{
		return argb;
	}

	public static Color FromArgb(int alpha, Color baseColor)
	{
		return FromArgb(alpha, baseColor.R, baseColor.G, baseColor.B);
	}

	public static Color FromArgb(uint argb)
	{
		return new Color(argb);
	}

	private static float SrgbToLinear(float c)
	{
		if (!(c <= 0.04045f))
		{
			return (float)Math.Pow((c + 0.055f) / 1.055f, 2.4000000953674316);
		}
		return c / 12.92f;
	}

	private static float LinearToSrgb(float c)
	{
		if (!(c <= 0.0031308f))
		{
			return 1.055f * (float)Math.Pow(c, 0.4166666567325592) - 0.055f;
		}
		return c * 12.92f;
	}

	public (float R, float G, float B) ToLinear()
	{
		float item = SrgbToLinear((float)(int)R / (float)(int)A);
		float item2 = SrgbToLinear((float)(int)G / (float)(int)A);
		float item3 = SrgbToLinear((float)(int)B / (float)(int)A);
		return (R: item, G: item2, B: item3);
	}

	public static Color FromLinear(byte a, float r, float g, float b)
	{
		return FromArgb(a, (byte)Math.Round(LinearToSrgb(r) * (float)(int)a), (byte)Math.Round(LinearToSrgb(g) * (float)(int)a), (byte)Math.Round(LinearToSrgb(b) * (float)(int)a));
	}

	public static (float R, float G, float B) HsvToRgb(float h, float s, float v)
	{
		float num = Math.Abs(h * 6f - 3f);
		float num2 = Math.Abs((h + 2f / 3f) % 1f * 6f - 3f);
		float num3 = Math.Abs((h + 1f / 3f) % 1f * 6f - 3f);
		float item = v * float2.Lerp(1f, (num - 1f).Clamp(0f, 1f), s);
		float item2 = v * float2.Lerp(1f, (num2 - 1f).Clamp(0f, 1f), s);
		float item3 = v * float2.Lerp(1f, (num3 - 1f).Clamp(0f, 1f), s);
		return (R: item, G: item2, B: item3);
	}

	public static (float H, float S, float V) RgbToHsv(byte r, byte g, byte b)
	{
		return RgbToHsv((float)(int)r / 255f, (float)(int)g / 255f, (float)(int)b / 255f);
	}

	public static (float H, float S, float V) RgbToHsv(float r, float g, float b)
	{
		float num = Math.Max(r, Math.Max(g, b));
		float num2 = Math.Min(r, Math.Min(g, b));
		float num3 = num - num2;
		float item = num;
		if (num3 == 0f)
		{
			return (H: 0f, S: 0f, V: item);
		}
		float num4;
		if (r == num)
		{
			num4 = (g - b) / (6f * num3);
		}
		else
		{
			num4 = ((g != num) ? ((r - g) / (6f * num3) + 2f / 3f) : ((b - r) / (6f * num3) + 1f / 3f));
		}
		float num5 = num4 - (float)(int)num4;
		if (num5 < 0f)
		{
			num5++;
		}
		float item2 = num3 / num;
		return (H: num5, S: item2, V: item);
	}

	public static bool TryParse(string value, out Color color)
	{
		color = default;
		value = value.Trim();
		if (value.Length != 6 && value.Length != 8)
		{
			return false;
		}
		byte result = byte.MaxValue;
		if (!byte.TryParse(value.AsSpan(0, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result2) || !byte.TryParse(value.AsSpan(2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result3) || !byte.TryParse(value.AsSpan(4, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result4))
		{
			return false;
		}
		if (value.Length == 8 && !byte.TryParse(value.AsSpan(6, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result))
		{
			return false;
		}
		color = FromArgb(result, result2, result3, result4);
		return true;
	}

	public static bool operator ==(Color left, Color right)
	{
		return left.argb == right.argb;
	}

	public static bool operator !=(Color left, Color right)
	{
		return !(left == right);
	}

	public float GetBrightness()
	{
		byte b = Math.Min(R, Math.Min(G, B));
		byte b2 = Math.Max(R, Math.Max(G, B));
		return (float)(b2 + b) / 510f;
	}

	public bool Equals(Color other)
	{
		return this == other;
	}

	public override bool Equals(object obj)
	{
		if (!(obj is Color))
		{
			return false;
		}
		return this == (Color)obj;
	}

	public override int GetHashCode()
	{
		return (int)(argb ^ argb);
	}

	public override string ToString()
	{
		scoped Span<byte> span;
		if (A == byte.MaxValue)
		{
			span = stackalloc byte[3] { R, G, B };
			return CryptoUtil.ToHex(span);
		}
		span = stackalloc byte[4] { R, G, B, A };
		return CryptoUtil.ToHex(span);
	}
}
