using System;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public sealed class SpatiallyPartitioned<T>
{
	private readonly int rows;

	private readonly int cols;

	private readonly int binSize;

	private readonly Dictionary<T, Rectangle>[] itemBoundsBins;

	private readonly Dictionary<T, Rectangle> itemBounds = new Dictionary<T, Rectangle>();

	private readonly Action<Dictionary<T, Rectangle>, T, Rectangle> addItem = (Dictionary<T, Rectangle> bin, T actor, Rectangle bounds) =>
	{
		bin.Add(actor, bounds);
	};

	private readonly Action<Dictionary<T, Rectangle>, T, Rectangle> removeItem = (Dictionary<T, Rectangle> bin, T actor, Rectangle bounds) =>
	{
		bin.Remove(actor);
	};

	public IEnumerable<Rectangle> ItemBounds => itemBounds.Values;

	public IEnumerable<T> Items => itemBounds.Keys;

	public SpatiallyPartitioned(int width, int height, int binSize)
	{
		this.binSize = binSize;
		rows = Exts.IntegerDivisionRoundingAwayFromZero(height, binSize);
		cols = Exts.IntegerDivisionRoundingAwayFromZero(width, binSize);
		itemBoundsBins = Exts.MakeArray(rows * cols, (int _) => new Dictionary<T, Rectangle>());
	}

	private static void ValidateBounds(T actor, Rectangle bounds)
	{
		if (bounds.Width == 0 || bounds.Height == 0)
		{
			throw new ArgumentException($"Bounds of actor {actor} are empty.", "bounds");
		}
	}

	public void Add(T item, Rectangle bounds)
	{
		ValidateBounds(item, bounds);
		itemBounds.Add(item, bounds);
		MutateBins(item, bounds, addItem);
	}

	public void Update(T item, Rectangle bounds)
	{
		ValidateBounds(item, bounds);
		MutateBins(item, itemBounds[item], removeItem);
		Rectangle bounds2 = (itemBounds[item] = bounds);
		MutateBins(item, bounds2, addItem);
	}

	public bool Remove(T item)
	{
		if (!itemBounds.TryGetValue(item, out var value))
		{
			return false;
		}
		MutateBins(item, value, removeItem);
		itemBounds.Remove(item);
		return true;
	}

	public bool Contains(T item)
	{
		return itemBounds.ContainsKey(item);
	}

	private Dictionary<T, Rectangle> BinAt(int row, int col)
	{
		return itemBoundsBins[row * cols + col];
	}

	private Rectangle BinBounds(int row, int col)
	{
		return new Rectangle(col * binSize, row * binSize, binSize, binSize);
	}

	private void BoundsToBinRowsAndCols(Rectangle bounds, out int minRow, out int maxRow, out int minCol, out int maxCol)
	{
		int num = Math.Min(bounds.Top, bounds.Bottom);
		int dividend = Math.Max(bounds.Top, bounds.Bottom);
		int num2 = Math.Min(bounds.Left, bounds.Right);
		int dividend2 = Math.Max(bounds.Left, bounds.Right);
		minRow = Math.Max(0, num / binSize);
		minCol = Math.Max(0, num2 / binSize);
		maxRow = Math.Min(rows, Exts.IntegerDivisionRoundingAwayFromZero(dividend, binSize));
		maxCol = Math.Min(cols, Exts.IntegerDivisionRoundingAwayFromZero(dividend2, binSize));
	}

	private void MutateBins(T actor, Rectangle bounds, Action<Dictionary<T, Rectangle>, T, Rectangle> action)
	{
		BoundsToBinRowsAndCols(bounds, out var minRow, out var maxRow, out var minCol, out var maxCol);
		for (int i = minRow; i < maxRow; i++)
		{
			for (int j = minCol; j < maxCol; j++)
			{
				action(BinAt(i, j), actor, bounds);
			}
		}
	}

	public IEnumerable<T> At(int2 location)
	{
		int col = (location.X / binSize).Clamp(0, cols - 1);
		int row = (location.Y / binSize).Clamp(0, rows - 1);
		foreach (KeyValuePair<T, Rectangle> item in BinAt(row, col))
		{
			if (item.Value.Contains(location))
			{
				yield return item.Key;
			}
		}
	}

	public IEnumerable<T> InBox(Rectangle box)
	{
		BoundsToBinRowsAndCols(box, out var minRow, out var maxRow, out var minCol, out var maxCol);
		HashSet<T> items = ((minRow >= maxRow || minCol >= maxCol) ? null : new HashSet<T>());
		for (int row = minRow; row < maxRow; row++)
		{
			for (int col = minCol; col < maxCol; col++)
			{
				Rectangle binBounds = BinBounds(row, col);
				foreach (KeyValuePair<T, Rectangle> item in BinAt(row, col))
				{
					T key = item.Key;
					Rectangle value = item.Value;
					if (value.IntersectsWith(box) && (items == null || binBounds.Contains(value) || items.Add(key)))
					{
						yield return key;
					}
				}
			}
		}
	}
}
