namespace OpenRA.Primitives;

public interface IPriorityQueue<T>
{
	bool Empty { get; }

	void Add(T item);

	T Peek();

	T Pop();
}
