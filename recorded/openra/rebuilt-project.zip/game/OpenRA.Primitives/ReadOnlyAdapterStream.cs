using System;
using System.Collections.Generic;
using System.IO;

namespace OpenRA.Primitives;

public abstract class ReadOnlyAdapterStream : Stream
{
	private readonly Queue<byte> data = new Queue<byte>(1024);

	private readonly Stream baseStream;

	private bool baseStreamEmpty;

	public sealed override bool CanSeek => false;

	public sealed override bool CanRead => true;

	public sealed override bool CanWrite => false;

	public override long Length
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	public sealed override long Position
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	protected ReadOnlyAdapterStream(Stream stream)
	{
		if (stream == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream.CanRead)
		{
			throw new ArgumentException("stream must be readable.", "stream");
		}
		baseStream = stream;
	}

	public sealed override long Seek(long offset, SeekOrigin origin)
	{
		throw new NotSupportedException();
	}

	public sealed override void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	public sealed override void WriteByte(byte value)
	{
		throw new NotSupportedException();
	}

	public sealed override void Write(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	public override void Write(ReadOnlySpan<byte> buffer)
	{
		throw new NotSupportedException();
	}

	public sealed override void Flush()
	{
		throw new NotSupportedException();
	}

	public sealed override int ReadByte()
	{
		if (data.Count > 0)
		{
			return data.Dequeue();
		}
		while (!baseStreamEmpty)
		{
			baseStreamEmpty = BufferData(baseStream, data);
			if (data.Count > 0)
			{
				return data.Dequeue();
			}
		}
		return -1;
	}

	public sealed override int Read(byte[] buffer, int offset, int count)
	{
		return Read(buffer.AsSpan(offset, count));
	}

	public override int Read(Span<byte> buffer)
	{
		int copied = 0;
		ConsumeData(buffer, ref copied);
		while (copied < buffer.Length && !baseStreamEmpty)
		{
			baseStreamEmpty = BufferData(baseStream, data);
			ConsumeData(buffer, ref copied);
		}
		return copied;
	}

	protected abstract bool BufferData(Stream baseStream, Queue<byte> data);

	private void ConsumeData(Span<byte> buffer, ref int copied)
	{
		while (copied < buffer.Length && data.Count > 0)
		{
			buffer[copied++] = data.Dequeue();
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			baseStream.Dispose();
		}
		base.Dispose(disposing);
	}
}
