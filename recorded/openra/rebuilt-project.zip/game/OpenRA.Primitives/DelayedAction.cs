using System;
using System.Collections.Generic;

namespace OpenRA.Primitives;

internal readonly struct DelayedAction(Action action, long time)
{
	private sealed class DelayedActionTimeComparer : IComparer<DelayedAction>
	{
		public int Compare(DelayedAction x, DelayedAction y)
		{
			return x.Time.CompareTo(y.Time);
		}
	}

	public static IComparer<DelayedAction> TimeComparer = new DelayedActionTimeComparer();

	public readonly long Time = time;

	public readonly Action Action = action;

	public override string ToString()
	{
		return "Time: " + Time + " Action: " + Action;
	}
}
