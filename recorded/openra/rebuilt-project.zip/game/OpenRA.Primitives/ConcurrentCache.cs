using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class ConcurrentCache<T, U> : IReadOnlyDictionary<T, U>, IEnumerable<KeyValuePair<T, U>>, IEnumerable, IReadOnlyCollection<KeyValuePair<T, U>>
{
	private readonly ConcurrentDictionary<T, U> cache;

	private readonly Func<T, U> loader;

	public U this[T key] => cache.GetOrAdd(key, loader);

	public IEnumerable<T> Keys => cache.Keys;

	public IEnumerable<U> Values => cache.Values;

	public int Count => cache.Count;

	public ConcurrentCache(Func<T, U> loader, IEqualityComparer<T> c)
	{
		if (loader == null)
		{
			throw new ArgumentNullException("loader");
		}
		this.loader = loader;
		cache = new ConcurrentDictionary<T, U>(c);
	}

	public ConcurrentCache(Func<T, U> loader)
		: this(loader, (IEqualityComparer<T>)EqualityComparer<T>.Default)
	{
	}

	public bool ContainsKey(T key)
	{
		return cache.ContainsKey(key);
	}

	public bool TryGetValue(T key, out U value)
	{
		return cache.TryGetValue(key, out value);
	}

	public IEnumerator<KeyValuePair<T, U>> GetEnumerator()
	{
		return cache.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
