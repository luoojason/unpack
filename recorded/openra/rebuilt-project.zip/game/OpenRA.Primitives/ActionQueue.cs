using System;
using System.Collections.Generic;

namespace OpenRA.Primitives;

public class ActionQueue
{
	private readonly List<DelayedAction> actions = new List<DelayedAction>();

	public void Add(Action a, long desiredTime)
	{
		if (a == null)
		{
			throw new ArgumentNullException("a");
		}
		lock (actions)
		{
			DelayedAction delayedAction = new DelayedAction(a, desiredTime);
			int index = Index(delayedAction);
			actions.Insert(index, delayedAction);
		}
	}

	public void PerformActions(long currentTime)
	{
		DelayedAction[] array;
		lock (actions)
		{
			DelayedAction action = new DelayedAction(null, currentTime);
			int num = Index(action);
			if (num <= 0)
			{
				return;
			}
			array = new DelayedAction[num];
			actions.CopyTo(0, array, 0, num);
			actions.RemoveRange(0, num);
		}
		DelayedAction[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			DelayedAction delayedAction = array2[i];
			delayedAction.Action();
		}
	}

	private int Index(DelayedAction action)
	{
		int i = actions.BinarySearch(action, DelayedAction.TimeComparer);
		if (i < 0)
		{
			return ~i;
		}
		for (; i < actions.Count && DelayedAction.TimeComparer.Compare(action, actions[i]) >= 0; i++)
		{
		}
		return i;
	}
}
