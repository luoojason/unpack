using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Numerics;
using ICSharpCode.SharpZipLib.Zip;

namespace OpenRA.Network;

public static class GeoIP
{
	private sealed class IP2LocationReader
	{
		public readonly DateTime Date;

		private readonly Stream stream;

		private readonly uint columnCount;

		private readonly uint v4Count;

		private readonly uint v4Offset;

		private readonly uint v6Count;

		private readonly uint v6Offset;

		public IP2LocationReader(Stream source)
		{
			stream = new MemoryStream();
			source.CopyTo(stream);
			stream.Position = 0L;
			if (stream.ReadUInt8() != 1)
			{
				throw new InvalidDataException("Only IP2Location type 1 databases are supported.");
			}
			columnCount = stream.ReadUInt8();
			byte b = stream.ReadUInt8();
			byte month = stream.ReadUInt8();
			byte day = stream.ReadUInt8();
			Date = new DateTime(2000 + b, month, day);
			v4Count = stream.ReadUInt32();
			v4Offset = stream.ReadUInt32();
			v6Count = stream.ReadUInt32();
			v6Offset = stream.ReadUInt32();
		}

		private BigInteger AddressForIndex(long index, bool isIPv6)
		{
			uint num = (isIPv6 ? v6Offset : v4Offset);
			int num2 = (isIPv6 ? 12 : 0);
			stream.Seek(num + index * (4 * columnCount + num2) - 1, SeekOrigin.Begin);
			return new BigInteger(stream.ReadBytes(isIPv6 ? 16 : 4).Append(default(byte)).ToArray());
		}

		private string CountryForIndex(long index, bool isIPv6)
		{
			uint num = (isIPv6 ? v6Offset : v4Offset);
			int num2 = (isIPv6 ? 12 : 0);
			stream.Seek(num + index * (4 * columnCount + num2) + num2 + 3, SeekOrigin.Begin);
			uint num3 = stream.ReadUInt32();
			stream.Seek(num3 + 3, SeekOrigin.Begin);
			byte length = stream.ReadUInt8();
			string text = stream.ReadASCII(length);
			if (!(text != "-"))
			{
				return null;
			}
			return text;
		}

		public string LookupCountry(IPAddress ip)
		{
			bool flag = ip.AddressFamily == AddressFamily.InterNetworkV6;
			if (!flag && ip.AddressFamily != AddressFamily.InterNetwork)
			{
				return null;
			}
			long num = 0L;
			long num2 = (flag ? v6Count : v4Count);
			BigInteger bigInteger = new BigInteger(Enumerable.Reverse(ip.GetAddressBytes()).Append(default(byte)).ToArray());
			while (num <= num2)
			{
				long num3 = (num + num2) / 2;
				BigInteger bigInteger2 = AddressForIndex(num3, flag);
				BigInteger bigInteger3 = AddressForIndex(num3 + 1, flag);
				if (bigInteger2 <= bigInteger && bigInteger < bigInteger3)
				{
					return CountryForIndex(num3, flag);
				}
				if (bigInteger < bigInteger2)
				{
					num2 = num3 - 1;
				}
				else
				{
					num = num3 + 1;
				}
			}
			return null;
		}
	}

	private static IP2LocationReader database;

	public static void Initialize(string databasePath = "IP2LOCATION-LITE-DB1.IPV6.BIN.ZIP")
	{
		if (!File.Exists(databasePath))
		{
			return;
		}
		try
		{
			using ZipFile zipFile = new ZipFile(databasePath);
			int num = zipFile.FindEntry("IP2LOCATION-LITE-DB1.IPV6.BIN", ignoreCase: false);
			database = new IP2LocationReader(zipFile.GetInputStream(num));
		}
		catch (Exception e)
		{
			Log.Write("geoip", "DatabaseReader failed:");
			Log.Write("geoip", e);
		}
	}

	public static string LookupCountry(IPAddress ip)
	{
		if (database != null)
		{
			try
			{
				return database.LookupCountry(ip);
			}
			catch (Exception e)
			{
				Log.Write("geoip", "LookupCountry failed:");
				Log.Write("geoip", e);
			}
		}
		return null;
	}
}
