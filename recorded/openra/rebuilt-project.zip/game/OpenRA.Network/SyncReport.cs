using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using OpenRA.Primitives;

namespace OpenRA.Network;

internal sealed class SyncReport
{
	private sealed class Report
	{
		public int Frame;

		public int SyncedRandom;

		public int TotalCount;

		public readonly List<TraitReport> Traits = new List<TraitReport>();

		public readonly List<EffectReport> Effects = new List<EffectReport>();

		public readonly List<OrderManager.ClientOrder> Orders = new List<OrderManager.ClientOrder>();
	}

	private struct TraitReport
	{
		public uint ActorID;

		public string Type;

		public string Owner;

		public string Trait;

		public int Hash;

		public (string[] Names, Values Values) NamesValues;
	}

	private struct EffectReport
	{
		public string Name;

		public int Hash;

		public (string[] Names, Values Values) NamesValues;
	}

	private readonly struct TypeInfo
	{
		private static readonly ParameterExpression SyncParam = Expression.Parameter(typeof(ISync), "sync");

		private static readonly ConstantExpression NullString = Expression.Constant(null, typeof(string));

		private static readonly ConstantExpression TrueString = Expression.Constant(bool.TrueString, typeof(string));

		private static readonly ConstantExpression FalseString = Expression.Constant(bool.FalseString, typeof(string));

		public readonly Func<ISync, object>[] SerializableCopyOfMemberFunctions;

		public readonly string[] Names;

		public TypeInfo(Type type)
		{
			List<FieldInfo> source = (from fi in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
				where !fi.IsLiteral && !fi.IsStatic && fi.HasAttribute<SyncAttribute>()
				select fi).ToList();
			List<PropertyInfo> list = (from pi in type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
				where pi.HasAttribute<SyncAttribute>()
				select pi).ToList();
			foreach (PropertyInfo item in list)
			{
				if (!item.CanRead || item.GetIndexParameters().Length != 0)
				{
					throw new InvalidOperationException("Properties using the Sync attribute must be readable and must not use index parameters.\nInvalid Property: " + item.DeclaringType.FullName + "." + item.Name);
				}
			}
			UnaryExpression sync = Expression.Convert(SyncParam, type);
			SerializableCopyOfMemberFunctions = source.Select((FieldInfo fi) => SerializableCopyOfMember(Expression.Field(sync, fi), fi.FieldType, fi.Name)).Concat(list.Select((PropertyInfo pi) => SerializableCopyOfMember(Expression.Property(sync, pi), pi.PropertyType, pi.Name))).ToArray();
			Names = source.Select((FieldInfo fi) => fi.Name).Concat(list.Select((PropertyInfo pi) => pi.Name)).ToArray();
		}

		private static Func<ISync, object> SerializableCopyOfMember(MemberExpression getMember, Type memberType, string name)
		{
			if (memberType.IsValueType)
			{
				if (memberType == typeof(bool))
				{
					ConditionalExpression body = Expression.Condition(getMember, TrueString, FalseString);
					return Expression.Lambda<Func<ISync, string>>(body, name, new ParameterExpression[1] { SyncParam }).Compile();
				}
				UnaryExpression body2 = Expression.Convert(getMember, typeof(object));
				return Expression.Lambda<Func<ISync, object>>(body2, name, new ParameterExpression[1] { SyncParam }).Compile();
			}
			return MemberToString(getMember, memberType, name);
		}

		private static Func<ISync, string> MemberToString(MemberExpression getMember, Type memberType, string name)
		{
			MethodInfo method = memberType.GetMethod("ToString", Type.EmptyTypes);
			Expression body;
			if (memberType.IsValueType)
			{
				body = Expression.Call(getMember, method);
			}
			else
			{
				ParameterExpression parameterExpression = Expression.Variable(memberType, getMember.Member.Name);
				BinaryExpression binaryExpression = Expression.Assign(parameterExpression, getMember);
				BlockExpression blockExpression = Expression.Block(new ParameterExpression[1] { parameterExpression }, binaryExpression);
				body = Expression.Call(blockExpression, method);
				ConstantExpression right = Expression.Constant(null, memberType);
				body = Expression.Condition(Expression.Equal(blockExpression, right), NullString, body);
			}
			return Expression.Lambda<Func<ISync, string>>(body, name, new ParameterExpression[1] { SyncParam }).Compile();
		}
	}

	private struct Values
	{
		private static readonly object Sentinel = new object();

		private object item1OrArray = null;

		private object item2OrSentinel = null;

		private object item3 = null;

		private object item4 = null;

		public object this[int index]
		{
			readonly get
			{
				if (item2OrSentinel == Sentinel)
				{
					return ((object[])item1OrArray)[index];
				}
				return index switch
				{
					0 => item1OrArray, 
					1 => item2OrSentinel, 
					2 => item3, 
					3 => item4, 
					_ => throw new ArgumentOutOfRangeException("index"), 
				};
			}
			set
			{
				if (item2OrSentinel == Sentinel)
				{
					((object[])item1OrArray)[index] = value;
					return;
				}
				switch (index)
				{
				case 0:
					item1OrArray = value;
					break;
				case 1:
					item2OrSentinel = value;
					break;
				case 2:
					item3 = value;
					break;
				case 3:
					item4 = value;
					break;
				default:
					throw new ArgumentOutOfRangeException("index");
				}
			}
		}

		public Values(int size)
		{
			if (size > 4)
			{
				item1OrArray = new object[size];
				item2OrSentinel = Sentinel;
			}
		}
	}

	private const int NumSyncReports = 7;

	private static readonly Cache<Type, TypeInfo> TypeInfoCache = new Cache<Type, TypeInfo>((Type t) => new TypeInfo(t));

	private readonly OrderManager orderManager;

	private readonly Report[] syncReports = new Report[7];

	private int curIndex;

	private static (string[] Names, Values Values) DumpSyncTrait(ISync sync)
	{
		Type type = sync.GetType();
		TypeInfo typeInfo;
		lock (TypeInfoCache)
		{
			typeInfo = TypeInfoCache[type];
		}
		Values item = new Values(typeInfo.Names.Length);
		int num = 0;
		Func<ISync, object>[] serializableCopyOfMemberFunctions = typeInfo.SerializableCopyOfMemberFunctions;
		foreach (Func<ISync, object> func in serializableCopyOfMemberFunctions)
		{
			item[num++] = func(sync);
		}
		return (Names: typeInfo.Names, Values: item);
	}

	public SyncReport(OrderManager orderManager)
	{
		this.orderManager = orderManager;
		for (int i = 0; i < 7; i++)
		{
			syncReports[i] = new Report();
		}
	}

	internal void UpdateSyncReport(IEnumerable<OrderManager.ClientOrder> orders)
	{
		GenerateSyncReport(syncReports[curIndex], orders);
		curIndex = ++curIndex % 7;
	}

	private void GenerateSyncReport(Report report, IEnumerable<OrderManager.ClientOrder> orders)
	{
		report.Frame = orderManager.NetFrameNumber;
		report.SyncedRandom = orderManager.World.SharedRandom.Last;
		report.TotalCount = orderManager.World.SharedRandom.TotalCount;
		report.Traits.Clear();
		report.Effects.Clear();
		report.Orders.Clear();
		report.Orders.AddRange(orders);
		foreach (Actor item in orderManager.World.ActorsHavingTrait<ISync>())
		{
			Actor.SyncHash[] syncHashes = item.SyncHashes;
			for (int i = 0; i < syncHashes.Length; i++)
			{
				Actor.SyncHash syncHash = syncHashes[i];
				int num = syncHash.Hash();
				if (num != 0)
				{
					report.Traits.Add(new TraitReport
					{
						ActorID = item.ActorID,
						Type = item.Info.Name,
						Owner = ((item.Owner == null) ? "null" : item.Owner.PlayerName),
						Trait = syncHash.Trait.GetType().Name,
						Hash = num,
						NamesValues = DumpSyncTrait(syncHash.Trait)
					});
				}
			}
		}
		foreach (ISync syncedEffect in orderManager.World.SyncedEffects)
		{
			int num2 = Sync.Hash(syncedEffect);
			if (num2 != 0)
			{
				report.Effects.Add(new EffectReport
				{
					Name = syncedEffect.GetType().Name,
					Hash = num2,
					NamesValues = DumpSyncTrait(syncedEffect)
				});
			}
		}
	}

	internal void DumpSyncReport(int frame)
	{
		string value = DateTime.UtcNow.ToString("yyyy-MM-ddTHHmmssZ", CultureInfo.InvariantCulture);
		string baseFilename = $"syncreport-{value}-{orderManager.LocalClient?.Index}.log";
		Log.AddChannel("sync", baseFilename);
		List<int> list = new List<int>();
		bool flag = false;
		Report[] array = syncReports;
		foreach (Report report in array)
		{
			list.Add(report.Frame);
			if (report.Frame != frame)
			{
				continue;
			}
			flag = true;
			ModMetadata metadata = Game.ModData.Manifest.Metadata;
			Log.Write("sync", $"Player: {Game.Settings.Player.Name} ({Platform.CurrentPlatform} {Environment.OSVersion} {Platform.RuntimeVersion})");
			if (Game.IsHost)
			{
				Log.Write("sync", "Player is host.");
			}
			Log.Write("sync", $"Game ID: {orderManager.LobbyInfo.GlobalSettings.GameUid} (Mod: {metadata.TitleTranslated} at Version {metadata.Version})");
			Log.Write("sync", $"Sync for net frame {report.Frame} -------------");
			Log.Write("sync", $"SharedRandom: {report.SyncedRandom} (#{report.TotalCount})");
			Log.Write("sync", "Synced Traits:");
			foreach (TraitReport trait in report.Traits)
			{
				Log.Write("sync", $"\t {trait.ActorID} {trait.Type} {trait.Owner} {trait.Trait} ({trait.Hash})");
				(string[], Values) namesValues = trait.NamesValues;
				for (int j = 0; j < namesValues.Item1.Length; j++)
				{
					if (namesValues.Item2[j] != null)
					{
						Log.Write("sync", $"\t\t {namesValues.Item1[j]}: {namesValues.Item2[j]}");
					}
				}
			}
			Log.Write("sync", "Synced Effects:");
			foreach (EffectReport effect in report.Effects)
			{
				Log.Write("sync", $"\t {effect.Name} ({effect.Hash})");
				(string[], Values) namesValues2 = effect.NamesValues;
				for (int k = 0; k < namesValues2.Item1.Length; k++)
				{
					if (namesValues2.Item2[k] != null)
					{
						Log.Write("sync", $"\t\t {namesValues2.Item1[k]}: {namesValues2.Item2[k]}");
					}
				}
			}
			Log.Write("sync", "Orders Issued:");
			foreach (OrderManager.ClientOrder order in report.Orders)
			{
				Log.Write("sync", $"\t {order}");
			}
		}
		Log.Write("sync", "Sync Report System Info:");
		Log.Write("sync", $"Out of sync frame: {frame}");
		Log.Write("sync", "Recorded frames: " + string.Join(",", list));
		if (!flag)
		{
			Log.Write("sync", $"Recorded frames do not contain the frame {frame}. No sync report available!");
		}
	}
}
