using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace OpenRA.Network;

public sealed class NetworkConnection : IConnection, IDisposable
{
	public readonly ConnectionTarget Target;

	private readonly Queue<(int Frame, int SyncHash, ulong DefeatState)> sentSync = new Queue<(int, int, ulong)>();

	private readonly Queue<(int Frame, int SyncHash, ulong DefeatState)> queuedSyncPackets = new Queue<(int, int, ulong)>();

	private readonly Queue<(int Frame, OrderPacket Orders)> sentOrders = new Queue<(int, OrderPacket)>();

	private readonly Queue<OrderPacket> sentImmediateOrders = new Queue<OrderPacket>();

	private readonly ConcurrentQueue<(int FromClient, byte[] Data)> receivedPackets = new ConcurrentQueue<(int, byte[])>();

	private TcpClient tcp;

	private volatile ConnectionState connectionState = ConnectionState.Connecting;

	private volatile int clientId;

	private bool disposed;

	internal ReplayRecorder Recorder { get; private set; }

	public ConnectionState ConnectionState => connectionState;

	public IPEndPoint EndPoint { get; private set; }

	public string ErrorMessage { get; private set; }

	int IConnection.LocalClientId => clientId;

	public NetworkConnection(ConnectionTarget target)
	{
		Target = target;
		Thread thread = new Thread(NetworkConnectionConnect);
		thread.Name = $"{GetType().Name} (connect to {target})";
		thread.IsBackground = true;
		thread.Start();
	}

	private void NetworkConnectionConnect()
	{
		BlockingCollection<TcpClient> queue = new BlockingCollection<TcpClient>();
		bool flag = false;
		foreach (IPEndPoint endpoint in Target.GetConnectEndPoints())
		{
			flag = true;
			Thread thread = new Thread(() =>
			{
				try
				{
					TcpClient tcpClient = new TcpClient(endpoint.AddressFamily)
					{
						NoDelay = true
					};
					tcpClient.Connect(endpoint.Address, endpoint.Port);
					try
					{
						queue.Add(tcpClient);
					}
					catch (InvalidOperationException)
					{
						tcpClient.Close();
					}
				}
				catch (Exception ex2)
				{
					ErrorMessage = "Failed to connect";
					Log.Write("client", $"Failed to connect to {endpoint}: {ex2.Message}");
				}
			});
			thread.Name = $"{GetType().Name} (connect to {endpoint})";
			thread.IsBackground = true;
			thread.Start();
		}
		if (!flag)
		{
			ErrorMessage = "Failed to resolve address";
			connectionState = ConnectionState.NotConnected;
		}
		else if (queue.TryTake(out tcp, 5000))
		{
			EndPoint = (IPEndPoint)tcp.Client.RemoteEndPoint;
			Thread thread2 = new Thread(NetworkConnectionReceive);
			thread2.Name = $"{GetType().Name} (receive from {tcp.Client.RemoteEndPoint})";
			thread2.IsBackground = true;
			thread2.Start();
		}
		else
		{
			connectionState = ConnectionState.NotConnected;
		}
		queue.CompleteAdding();
		foreach (TcpClient item in (IEnumerable<TcpClient>)queue)
		{
			item.Close();
		}
	}

	private void NetworkConnectionReceive()
	{
		try
		{
			NetworkStream stream = tcp.GetStream();
			int num = stream.ReadInt32();
			if (num != 7)
			{
				throw new InvalidOperationException($"Handshake protocol version mismatch. Server={num} Client={7}");
			}
			clientId = stream.ReadInt32();
			connectionState = ConnectionState.Connected;
			while (true)
			{
				int num2 = stream.ReadInt32();
				int item = stream.ReadInt32();
				byte[] item2 = stream.ReadBytes(num2);
				if (num2 == 0)
				{
					break;
				}
				receivedPackets.Enqueue((item, item2));
			}
			throw new NotImplementedException();
		}
		catch (Exception ex)
		{
			ErrorMessage = "Connection failed";
			Log.Write("client", $"Connection to {EndPoint} failed: {ex.Message}");
		}
		finally
		{
			connectionState = ConnectionState.NotConnected;
		}
	}

	void IConnection.StartGame()
	{
	}

	void IConnection.Send(int frame, IEnumerable<Order> orders)
	{
		OrderPacket orderPacket = new OrderPacket(orders);
		sentOrders.Enqueue((frame, orderPacket));
		Send(orderPacket.Serialize(frame));
	}

	void IConnection.SendImmediate(IEnumerable<Order> orders)
	{
		OrderPacket orderPacket = new OrderPacket(orders);
		sentImmediateOrders.Enqueue(orderPacket);
		Send(orderPacket.Serialize(0));
	}

	void IConnection.SendSync(int frame, int syncHash, ulong defeatState)
	{
		queuedSyncPackets.Enqueue((frame, syncHash, defeatState));
	}

	private void Send(byte[] packet)
	{
		try
		{
			MemoryStream memoryStream = new MemoryStream();
			memoryStream.Write(packet.Length);
			memoryStream.Write(packet);
			foreach (var queuedSyncPacket in queuedSyncPackets)
			{
				byte[] array = OrderIO.SerializeSync(queuedSyncPacket);
				memoryStream.Write(array.Length);
				memoryStream.Write(array);
				sentSync.Enqueue(queuedSyncPacket);
			}
			queuedSyncPackets.Clear();
			memoryStream.WriteTo(tcp.GetStream());
		}
		catch (SocketException)
		{
		}
		catch (ObjectDisposedException)
		{
		}
		catch (InvalidOperationException)
		{
		}
		catch (IOException)
		{
		}
	}

	void IConnection.Receive(OrderManager orderManager)
	{
		OrderPacket result;
		while (sentImmediateOrders.TryDequeue(out result))
		{
			orderManager.ReceiveImmediateOrders(clientId, result);
			Recorder?.Receive(clientId, result.Serialize(0));
			if (disposed)
			{
				return;
			}
		}
		(int, int, ulong) result2;
		while (sentSync.TryDequeue(out result2))
		{
			orderManager.ReceiveSync(result2);
			Recorder?.Receive(clientId, OrderIO.SerializeSync(result2));
		}
		(int, byte[]) result3;
		while (receivedPackets.TryDequeue(out result3))
		{
			(int, int, ulong) data;
			float scale;
			long timestamp;
			int frame;
			byte count;
			if (OrderIO.TryParseDisconnect(result3, out (int, int) disconnect))
			{
				orderManager.ReceiveDisconnect(disconnect.Item2, disconnect.Item1);
				Recorder?.Receive(result3.Item1, result3.Item2);
			}
			else if (OrderIO.TryParseSync(result3.Item2, out data))
			{
				orderManager.ReceiveSync(data);
				Recorder?.Receive(result3.Item1, result3.Item2);
			}
			else if (OrderIO.TryParseTickScale(result3, out scale))
			{
				orderManager.ReceiveTickScale(scale);
			}
			else if (OrderIO.TryParsePingRequest(result3, out timestamp))
			{
				Send(OrderIO.SerializePingResponse(timestamp, (byte)orderManager.OrderQueueLength));
			}
			else if (OrderIO.TryParseAck(result3, out frame, out count))
			{
				if (count > sentOrders.Count)
				{
					throw new InvalidOperationException($"Received Ack for {count} > {sentOrders.Count} frames.");
				}
				OrderPacket orderPacket;
				if (count != 1)
				{
					IEnumerable<OrderPacket> packets = from i in Enumerable.Range(0, count)
						select sentOrders.Dequeue().Orders;
					orderPacket = OrderPacket.Combine(packets);
				}
				else
				{
					orderPacket = sentOrders.Dequeue().Orders;
				}
				orderManager.ReceiveOrders(clientId, (Frame: frame, Orders: orderPacket));
				Recorder?.Receive(clientId, orderPacket.Serialize(frame));
			}
			else
			{
				if (!OrderIO.TryParseOrderPacket(result3.Item2, out (int, OrderPacket) data2))
				{
					throw new InvalidDataException($"Received unknown packet from client {result3.Item1} with length {result3.Item2.Length}");
				}
				if (data2.Item1 == 0)
				{
					orderManager.ReceiveImmediateOrders(result3.Item1, data2.Item2);
				}
				else
				{
					orderManager.ReceiveOrders(result3.Item1, data2);
				}
				Recorder?.Receive(result3.Item1, result3.Item2);
			}
			if (disposed)
			{
				break;
			}
		}
	}

	public void StartRecording(Func<string> chooseFilename)
	{
		Recorder?.Dispose();
		Recorder = new ReplayRecorder(chooseFilename);
	}

	void IDisposable.Dispose()
	{
		if (!disposed)
		{
			disposed = true;
			tcp?.Close();
			Recorder?.Dispose();
		}
	}
}
