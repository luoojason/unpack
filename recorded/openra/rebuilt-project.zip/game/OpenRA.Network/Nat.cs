using System;
using System.Threading;
using Mono.Nat;

namespace OpenRA.Network;

public static class Nat
{
	private static Mapping mapping;

	private static INatDevice natDevice;

	private static bool initialized;

	private static readonly SemaphoreSlim Locker = new SemaphoreSlim(1, 1);

	public static NatStatus Status
	{
		get
		{
			if (!NatUtility.IsSearching)
			{
				return NatStatus.Disabled;
			}
			if (natDevice == null)
			{
				return NatStatus.NotSupported;
			}
			return NatStatus.Enabled;
		}
	}

	public static void Initialize()
	{
		if (!initialized)
		{
			if (Game.Settings.Server.DiscoverNatDevices)
			{
				NatUtility.DeviceFound += DeviceFound;
				NatUtility.StartDiscovery();
			}
			initialized = true;
		}
	}

	private static async void DeviceFound(object sender, DeviceEventArgs args)
	{
		await Locker.WaitAsync();
		try
		{
			natDevice = args.Device;
			Log.Write("nat", $"Device found: {natDevice.DeviceEndpoint}");
			Log.Write("nat", $"Type: {natDevice.NatProtocol}");
		}
		finally
		{
			Locker.Release();
		}
	}

	public static bool TryForwardPort(int listen, int external)
	{
		if (natDevice == null)
		{
			return false;
		}
		int natPortMappingLifetime = Game.Settings.Server.NatPortMappingLifetime;
		mapping = new Mapping(Protocol.Tcp, listen, external, natPortMappingLifetime, "OpenRA");
		try
		{
			natDevice.CreatePortMap(mapping);
		}
		catch (Exception e)
		{
			Log.Write("nat", "Port forwarding failed.");
			Log.Write("nat", e);
			return false;
		}
		return true;
	}

	public static bool TryRemovePortForward()
	{
		if (natDevice == null)
		{
			return false;
		}
		try
		{
			natDevice.DeletePortMap(mapping);
		}
		catch (Exception e)
		{
			Log.Write("nat", "Port removal failed.");
			Log.Write("nat", e);
			return false;
		}
		return true;
	}
}
