namespace OpenRA.Network;

public enum NatStatus
{
	Enabled,
	Disabled,
	NotSupported
}
