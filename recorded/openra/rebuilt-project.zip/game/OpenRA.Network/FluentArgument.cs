using Linguini.Shared.Types.Bundle;

namespace OpenRA.Network;

public class FluentArgument
{
	public enum FluentArgumentType
	{
		String,
		Number
	}

	public readonly string Key;

	public readonly string Value;

	public readonly FluentArgumentType Type;

	public FluentArgument()
	{
	}

	public FluentArgument(string key, object value)
	{
		Key = key;
		Value = value.ToString();
		Type = GetFluentArgumentType(value);
	}

	private static FluentArgumentType GetFluentArgumentType(object value)
	{
		IFluentType fluentType = value.ToFluentType();
		if (fluentType is FluentNumber)
		{
			return FluentArgumentType.Number;
		}
		return FluentArgumentType.String;
	}
}
