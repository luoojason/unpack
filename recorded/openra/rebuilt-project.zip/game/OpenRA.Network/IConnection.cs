using System;
using System.Collections.Generic;

namespace OpenRA.Network;

public interface IConnection : IDisposable
{
	int LocalClientId { get; }

	void StartGame();

	void Send(int frame, IEnumerable<Order> orders);

	void SendImmediate(IEnumerable<Order> orders);

	void SendSync(int frame, int syncHash, ulong defeatState);

	void Receive(OrderManager orderManager);
}
