using System.Collections.Generic;
using System.Linq;

namespace OpenRA.Network;

public class HandshakeRequest
{
	public string Mod;

	public string Version;

	public string AuthToken;

	public static HandshakeRequest Deserialize(string data, string name)
	{
		HandshakeRequest handshakeRequest = new HandshakeRequest();
		FieldLoader.Load(handshakeRequest, MiniYaml.FromString(data, name).First().Value);
		return handshakeRequest;
	}

	public string Serialize()
	{
		List<MiniYamlNode> y = new List<MiniYamlNode>
		{
			new MiniYamlNode("Handshake", FieldSaver.Save(this))
		};
		return y.WriteToString();
	}
}
