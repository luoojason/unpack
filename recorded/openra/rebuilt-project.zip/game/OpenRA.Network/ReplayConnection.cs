using System;
using System.Collections.Generic;
using System.IO;
using OpenRA.FileFormats;

namespace OpenRA.Network;

public sealed class ReplayConnection : IConnection, IDisposable
{
	private sealed class Chunk
	{
		public int Frame;

		public (int ClientId, byte[] Packet)[] Packets;
	}

	private readonly Queue<Chunk> chunks = new Queue<Chunk>();

	private readonly Queue<(int Frame, int SyncHash, ulong DefeatState)> sync = new Queue<(int, int, ulong)>();

	private readonly int orderLatency;

	public readonly int TickCount;

	public readonly int FinalGameTick;

	public readonly bool IsValid;

	public readonly Session LobbyInfo;

	public readonly string Filename;

	int IConnection.LocalClientId => -1;

	public ReplayConnection(string replayFilename)
	{
		Filename = replayFilename;
		FinalGameTick = ReplayMetadata.Read(replayFilename).GameInfo.FinalGameTick;
		using (FileStream fileStream = File.OpenRead(replayFilename))
		{
			List<(int, byte[])> list = new List<(int, byte[])>();
			Chunk chunk = new Chunk();
			while (fileStream.Position < fileStream.Length)
			{
				int num = fileStream.ReadInt32();
				if (num == -1)
				{
					break;
				}
				int count = fileStream.ReadInt32();
				byte[] array = fileStream.ReadBytes(count);
				int num2 = BitConverter.ToInt32(array, 0);
				list.Add((num, array));
				if (array.Length > 4 && (array[4] == 191 || array[4] == 101))
				{
					continue;
				}
				if (num2 == 0)
				{
					if (!OrderIO.TryParseOrderPacket(array, out (int, OrderPacket) data))
					{
						continue;
					}
					foreach (Order order in data.Item2.GetOrders(null))
					{
						if (order.OrderString == "StartGame")
						{
							IsValid = true;
						}
						else if (order.OrderString == "SyncInfo" && !IsValid)
						{
							LobbyInfo = Session.Deserialize(order.TargetString, order.OrderString);
						}
					}
				}
				else
				{
					chunk.Frame = num2;
					chunk.Packets = list.ToArray();
					list.Clear();
					chunks.Enqueue(chunk);
					chunk = new Chunk();
					TickCount = Math.Max(TickCount, num2);
				}
			}
		}
		GameSpeeds gameSpeeds = Game.ModData.Manifest.Get<GameSpeeds>();
		string key = LobbyInfo.GlobalSettings.OptionOrDefault("gamespeed", gameSpeeds.DefaultSpeed);
		orderLatency = gameSpeeds.Speeds[key].OrderLatency;
	}

	void IConnection.StartGame()
	{
	}

	void IConnection.Send(int frame, IEnumerable<Order> orders)
	{
	}

	void IConnection.SendImmediate(IEnumerable<Order> orders)
	{
	}

	void IConnection.SendSync(int frame, int syncHash, ulong defeatState)
	{
		sync.Enqueue((frame, syncHash, defeatState));
	}

	void IConnection.Receive(OrderManager orderManager)
	{
		while (sync.Count != 0)
		{
			orderManager.ReceiveSync(sync.Dequeue());
		}
		while (chunks.Count != 0 && chunks.Peek().Frame <= orderManager.NetFrameNumber + orderLatency)
		{
			(int, byte[])[] packets = chunks.Dequeue().Packets;
			for (int i = 0; i < packets.Length; i++)
			{
				(int, byte[]) packet = packets[i];
				if (OrderIO.TryParseDisconnect(packet, out (int, int) disconnect))
				{
					orderManager.ReceiveDisconnect(disconnect.Item2, disconnect.Item1);
					continue;
				}
				if (OrderIO.TryParseSync(packet.Item2, out (int, int, ulong) data))
				{
					orderManager.ReceiveSync(data);
					continue;
				}
				if (OrderIO.TryParseOrderPacket(packet.Item2, out (int, OrderPacket) data2))
				{
					if (data2.Item1 == 0)
					{
						orderManager.ReceiveImmediateOrders(packet.Item1, data2.Item2);
					}
					else
					{
						orderManager.ReceiveOrders(packet.Item1, data2);
					}
					continue;
				}
				throw new InvalidDataException($"Received unknown packet from client {packet.Item1} with length {packet.Item2.Length}");
			}
		}
	}

	void IDisposable.Dispose()
	{
	}
}
