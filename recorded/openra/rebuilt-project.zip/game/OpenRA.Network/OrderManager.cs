using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.Support;

namespace OpenRA.Network;

public sealed class OrderManager : IDisposable
{
	public struct ClientOrder
	{
		public int Client;

		public Order Order;

		public override readonly string ToString()
		{
			return $"ClientId: {Client} {Order}";
		}
	}

	private const OrderPacket ClientDisconnected = null;

	[FluentReference(new string[] { "frame" })]
	private const string DesyncCompareLogs = "notification-desync-compare-logs";

	private readonly SyncReport syncReport;

	private readonly Dictionary<int, Queue<(int Frame, OrderPacket Orders)>> pendingOrders = new Dictionary<int, Queue<(int, OrderPacket)>>();

	private readonly Dictionary<int, (int SyncHash, ulong DefeatState)> syncForFrame = new Dictionary<int, (int, ulong)>();

	public Session LobbyInfo = new Session();

	public World World;

	public string ServerError;

	public bool AuthenticationFailed;

	public HashSet<string> ServerMapPool;

	public int LocalFrameNumber;

	public TickTime LastTickTime;

	internal int GameSaveLastFrame = -1;

	internal int GameSaveLastSyncFrame = -1;

	private readonly List<Order> localOrders = new List<Order>();

	private readonly List<Order> localImmediateOrders = new List<Order>();

	private readonly List<ClientOrder> processClientOrders = new List<ClientOrder>();

	private readonly List<int> processClientsToRemove = new List<int>();

	private bool disposed;

	private bool generateSyncReport;

	private int sentOrdersFrame;

	private float tickScale = 1f;

	public Session.Client LocalClient => LobbyInfo.ClientWithIndex(Connection.LocalClientId);

	public int OrderQueueLength
	{
		get
		{
			if (pendingOrders.Count <= 0)
			{
				return 0;
			}
			return pendingOrders.Min((KeyValuePair<int, Queue<(int Frame, OrderPacket Orders)>> q) => q.Value.Count);
		}
	}

	public int NetFrameNumber { get; private set; }

	public bool GameStarted => NetFrameNumber != 0;

	public IConnection Connection { get; }

	public bool IsOutOfSync { get; private set; }

	private bool IsReadyForNextFrame
	{
		get
		{
			if (GameStarted)
			{
				return pendingOrders.All((KeyValuePair<int, Queue<(int Frame, OrderPacket Orders)>> p) => p.Value.Count > 0);
			}
			return false;
		}
	}

	public int SuggestedTimestep
	{
		get
		{
			if (World == null)
			{
				return 40;
			}
			if (World.IsLoadingGameSave)
			{
				return 1;
			}
			if (World.IsReplay)
			{
				return World.ReplayTimestep;
			}
			if (tickScale != 1f)
			{
				return Math.Max((int)(tickScale * (float)World.Timestep), 1);
			}
			return World.Timestep;
		}
	}

	private bool IsNetFrame => LocalFrameNumber % LobbyInfo.GlobalSettings.NetFrameInterval == 0;

	private void OutOfSync(int frame)
	{
		if (!IsOutOfSync)
		{
			syncReport.DumpSyncReport(frame);
			World.OutOfSync();
			IsOutOfSync = true;
			TextNotificationsManager.AddSystemLine("notification-desync-compare-logs", "frame", frame);
		}
	}

	public void StartGame()
	{
		if (GameStarted)
		{
			return;
		}
		foreach (Session.Client client in LobbyInfo.Clients)
		{
			if (!client.IsBot)
			{
				pendingOrders.Add(client.Index, new Queue<(int, OrderPacket)>());
			}
		}
		generateSyncReport = !(Connection is ReplayConnection) && LobbyInfo.GlobalSettings.EnableSyncReports;
		NetFrameNumber = 1;
		LocalFrameNumber = 0;
		LastTickTime.Value = Game.RunTime;
		Connection.StartGame();
	}

	public OrderManager(IConnection conn)
	{
		Connection = conn;
		syncReport = new SyncReport(this);
		LastTickTime = new TickTime(() => SuggestedTimestep, Game.RunTime);
	}

	public void IssueOrders(Order[] orders)
	{
		foreach (Order order in orders)
		{
			IssueOrder(order);
		}
	}

	public void IssueOrder(Order order)
	{
		if (order.IsImmediate)
		{
			localImmediateOrders.Add(order);
		}
		else
		{
			localOrders.Add(order);
		}
	}

	private void SendImmediateOrders()
	{
		if (localImmediateOrders.Count != 0 && GameSaveLastFrame < NetFrameNumber)
		{
			Connection.SendImmediate(localImmediateOrders);
		}
		localImmediateOrders.Clear();
	}

	public void ReceiveDisconnect(int clientId, int frame)
	{
		if (GameStarted)
		{
			ReceiveOrders(clientId, (Frame: frame, Orders: null));
		}
		Session.Client client = LobbyInfo.ClientWithIndex(clientId);
		if (client != null)
		{
			client.State = Session.ClientState.Disconnected;
		}
	}

	public void ReceiveSync((int Frame, int SyncHash, ulong DefeatState) sync)
	{
		if (syncForFrame.TryGetValue(sync.Frame, out (int, ulong) value))
		{
			if (value.Item1 != sync.SyncHash || value.Item2 != sync.DefeatState)
			{
				OutOfSync(sync.Frame);
			}
		}
		else
		{
			syncForFrame.Add(sync.Frame, (sync.SyncHash, sync.DefeatState));
		}
	}

	public void ReceiveTickScale(float scale)
	{
		tickScale = scale;
	}

	public void ReceiveImmediateOrders(int clientId, OrderPacket orders)
	{
		foreach (Order order in orders.GetOrders(World))
		{
			UnitOrders.ProcessOrder(this, World, clientId, order);
			if (disposed)
			{
				break;
			}
		}
	}

	public void ReceiveOrders(int clientId, (int Frame, OrderPacket Orders) orders)
	{
		if (pendingOrders.TryGetValue(clientId, out Queue<(int, OrderPacket)> value))
		{
			value.Enqueue((orders.Frame, orders.Orders));
			return;
		}
		throw new InvalidDataException($"Received packet from disconnected client '{clientId}'");
	}

	private void ReceiveAllOrdersAndCheckSync()
	{
		Connection.Receive(this);
	}

	private void SendOrders()
	{
		if (GameStarted && GameSaveLastFrame < NetFrameNumber && sentOrdersFrame < NetFrameNumber)
		{
			Connection.Send(NetFrameNumber, localOrders);
			localOrders.Clear();
			sentOrdersFrame = NetFrameNumber;
		}
	}

	private void ProcessOrders()
	{
		foreach (var (num2, queue2) in pendingOrders)
		{
			var (num3, orderPacket) = queue2.Dequeue();
			if (num3 != NetFrameNumber)
			{
				throw new InvalidDataException($"Attempted to process orders from client {num2} for frame {num3} on frame {NetFrameNumber}");
			}
			if (orderPacket == null)
			{
				processClientsToRemove.Add(num2);
				World.OnClientDisconnected(num2);
				continue;
			}
			foreach (Order order in orderPacket.GetOrders(World))
			{
				UnitOrders.ProcessOrder(this, World, num2, order);
				processClientOrders.Add(new ClientOrder
				{
					Client = num2,
					Order = order
				});
			}
		}
		foreach (int item in processClientsToRemove)
		{
			pendingOrders.Remove(item);
		}
		if (NetFrameNumber >= GameSaveLastSyncFrame)
		{
			ulong num4 = 0uL;
			for (int i = 0; i < World.Players.Length; i++)
			{
				if (World.Players[i].WinState == WinState.Lost)
				{
					num4 |= (ulong)(1L << i);
				}
			}
			Connection.SendSync(NetFrameNumber, World.SyncHash(), num4);
		}
		else
		{
			Connection.SendSync(NetFrameNumber, 0, 0uL);
		}
		if (generateSyncReport)
		{
			using (new PerfSample("sync_report"))
			{
				syncReport.UpdateSyncReport(processClientOrders);
			}
		}
		processClientOrders.Clear();
		processClientsToRemove.Clear();
		int netFrameNumber = NetFrameNumber + 1;
		NetFrameNumber = netFrameNumber;
	}

	public void Dispose()
	{
		disposed = true;
		Connection?.Dispose();
	}

	public void TickImmediate()
	{
		SendImmediateOrders();
		ReceiveAllOrdersAndCheckSync();
	}

	public bool TryTick()
	{
		bool flag = true;
		if (IsNetFrame)
		{
			flag = pendingOrders.All((KeyValuePair<int, Queue<(int Frame, OrderPacket Orders)>> p) => p.Key == Connection.LocalClientId || p.Value.Count > 0);
			if (flag)
			{
				SendOrders();
			}
		}
		bool flag2 = flag;
		if (flag2 && IsNetFrame)
		{
			flag2 = IsReadyForNextFrame;
			if (flag2)
			{
				ProcessOrders();
			}
		}
		if (flag2)
		{
			LocalFrameNumber++;
		}
		return flag2;
	}
}
