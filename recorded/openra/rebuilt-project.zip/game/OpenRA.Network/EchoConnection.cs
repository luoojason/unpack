using System;
using System.Collections.Generic;

namespace OpenRA.Network;

public sealed class EchoConnection : IConnection, IDisposable
{
	private const int LocalClientId = 1;

	private readonly Queue<(int Frame, int SyncHash, ulong DefeatState)> sync = new Queue<(int, int, ulong)>();

	private readonly Queue<(int Frame, OrderPacket Orders)> orders = new Queue<(int, OrderPacket)>();

	private readonly Queue<OrderPacket> immediateOrders = new Queue<OrderPacket>();

	private bool disposed;

	int IConnection.LocalClientId => 1;

	void IConnection.StartGame()
	{
		orders.Enqueue((0, new OrderPacket(Array.Empty<Order>())));
	}

	void IConnection.Send(int frame, IEnumerable<Order> o)
	{
		orders.Enqueue((frame, new OrderPacket(o)));
	}

	void IConnection.SendImmediate(IEnumerable<Order> o)
	{
		immediateOrders.Enqueue(new OrderPacket(o));
	}

	void IConnection.SendSync(int frame, int syncHash, ulong defeatState)
	{
		sync.Enqueue((frame, syncHash, defeatState));
	}

	void IConnection.Receive(OrderManager orderManager)
	{
		OrderPacket result;
		while (immediateOrders.TryDequeue(out result))
		{
			orderManager.ReceiveImmediateOrders(1, result);
			if (disposed)
			{
				break;
			}
		}
		(int, OrderPacket) result2;
		while (orders.TryDequeue(out result2))
		{
			orderManager.ReceiveOrders(1, (Frame: result2.Item1 + 1, Orders: result2.Item2));
		}
		(int, int, ulong) result3;
		while (sync.TryDequeue(out result3))
		{
			orderManager.ReceiveSync(result3);
		}
	}

	void IDisposable.Dispose()
	{
		disposed = true;
	}
}
