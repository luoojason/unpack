using OpenRA.Primitives;

namespace OpenRA.Network;

public class GameClient
{
	public readonly string Name;

	public readonly string Fingerprint;

	public readonly Color Color;

	public readonly string Faction;

	public readonly int Team;

	public readonly int SpawnPoint;

	public readonly bool IsAdmin;

	public readonly bool IsSpectator;

	public readonly bool IsBot;

	public GameClient()
	{
	}

	public GameClient(Session.Client c)
	{
		Name = c.Name;
		Fingerprint = c.Fingerprint;
		Color = c.Color;
		Faction = c.Faction;
		Team = c.Team;
		SpawnPoint = c.SpawnPoint;
		IsAdmin = c.IsAdmin;
		IsSpectator = c.Slot == null && c.Bot == null;
		IsBot = c.Bot != null;
	}
}
