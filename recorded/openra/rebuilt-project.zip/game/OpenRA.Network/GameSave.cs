using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using OpenRA.Server;

namespace OpenRA.Network;

public class GameSave
{
	public const int EOFMarker = -2;

	public const int MetadataMarker = -1;

	public const int TraitDataMarker = -3;

	private readonly MemoryStream ordersStream = new MemoryStream();

	private byte[] lastSyncPacket = Array.Empty<byte>();

	public Dictionary<int, MiniYaml> TraitData = new Dictionary<int, MiniYaml>();

	private int[] clientsBySlotIndex = Array.Empty<int>();

	private int firstBotSlotIndex = -1;

	public int LastOrdersFrame { get; private set; }

	public int LastSyncFrame { get; private set; }

	public Session.Global GlobalSettings { get; private set; }

	public Dictionary<string, Session.Slot> Slots { get; private set; }

	public Dictionary<string, SlotClient> SlotClients { get; private set; }

	public GameSave()
	{
		LastOrdersFrame = -1;
		Slots = new Dictionary<string, Session.Slot>();
	}

	public GameSave(string filepath)
	{
		using FileStream fileStream = File.OpenRead(filepath);
		fileStream.Seek(-12L, SeekOrigin.End);
		int num = fileStream.ReadInt32();
		int num2 = fileStream.ReadInt32();
		if (fileStream.ReadInt32() != -2)
		{
			throw new InvalidDataException("Invalid orasav file");
		}
		fileStream.Seek(num, SeekOrigin.Begin);
		if (fileStream.ReadInt32() != -1)
		{
			throw new InvalidDataException("Invalid orasav file");
		}
		LastOrdersFrame = fileStream.ReadInt32();
		LastSyncFrame = fileStream.ReadInt32();
		lastSyncPacket = fileStream.ReadBytes(13);
		List<MiniYamlNode> list = MiniYaml.FromString(fileStream.ReadLengthPrefixedString(Encoding.UTF8, 131072), filepath + ":globalSettings");
		GlobalSettings = Session.Global.Deserialize(list[0].Value);
		List<MiniYamlNode> list2 = MiniYaml.FromString(fileStream.ReadLengthPrefixedString(Encoding.UTF8, 131072), filepath + ":slots");
		Slots = new Dictionary<string, Session.Slot>();
		foreach (MiniYamlNode item in list2)
		{
			Session.Slot slot = Session.Slot.Deserialize(item.Value);
			Slots.Add(slot.PlayerReference, slot);
		}
		List<MiniYamlNode> list3 = MiniYaml.FromString(fileStream.ReadLengthPrefixedString(Encoding.UTF8, 131072), filepath + ":slotClients");
		SlotClients = new Dictionary<string, SlotClient>();
		foreach (MiniYamlNode item2 in list3)
		{
			SlotClient slotClient = SlotClient.Deserialize(item2.Value);
			SlotClients.Add(slotClient.Slot, slotClient);
		}
		if (fileStream.Position != num2 || fileStream.ReadInt32() != -3)
		{
			throw new InvalidDataException("Invalid orasav file");
		}
		List<MiniYamlNode> list4 = MiniYaml.FromString(fileStream.ReadLengthPrefixedString(Encoding.UTF8, 131072), filepath + ":traitData");
		foreach (MiniYamlNode item3 in list4)
		{
			TraitData.Add(Exts.ParseInt32Invariant(item3.Key), item3.Value);
		}
		fileStream.Seek(0L, SeekOrigin.Begin);
		ordersStream.Write(fileStream.ReadBytes(num), 0, num);
	}

	public void StartGame(Session lobbyInfo, MapPreview map)
	{
		clientsBySlotIndex = lobbyInfo.Slots.Keys.Select((string s) => lobbyInfo.ClientInSlot(s)?.Index ?? (-1)).ToArray();
		GlobalSettings = Session.Global.Deserialize(lobbyInfo.GlobalSettings.Serialize().Value);
		Slots = new Dictionary<string, Session.Slot>();
		SlotClients = new Dictionary<string, SlotClient>();
		foreach (KeyValuePair<string, Session.Slot> slot in lobbyInfo.Slots)
		{
			Slots[slot.Key] = Session.Slot.Deserialize(slot.Value.Serialize().Value);
			PlayerReference playerReference = map.Players.Players[slot.Value.PlayerReference];
			Session.Client client = lobbyInfo.ClientInSlot(slot.Key);
			if (playerReference.Playable && client != null)
			{
				SlotClients[slot.Key] = new SlotClient(client);
				if (client.Bot != null && firstBotSlotIndex < 0)
				{
					firstBotSlotIndex = clientsBySlotIndex.IndexOf(client.Index);
				}
			}
		}
	}

	public void DispatchOrders(Connection conn, int frame, byte[] data)
	{
		if (data.Length != 0 && data[0] == 101 && frame > LastSyncFrame)
		{
			if (data.Length != 13)
			{
				Log.Write("debug", $"Dropped sync order with length {data.Length}. Expected length {13}.");
				return;
			}
			LastSyncFrame = frame;
			lastSyncPacket = data;
		}
		if (frame > LastOrdersFrame && (data.Length == 0 || data[0] != 254))
		{
			int num = clientsBySlotIndex.IndexOf(conn.PlayerIndex);
			if (num == -1)
			{
				num = firstBotSlotIndex;
			}
			ordersStream.Write(data.Length + 8);
			ordersStream.Write(frame);
			ordersStream.Write(num);
			ordersStream.Write(data);
			LastOrdersFrame = frame;
		}
	}

	public void ParseOrders(Session lobbyInfo, Action<int, int, byte[]> packetFn)
	{
		foreach (KeyValuePair<int, MiniYaml> traitDatum in TraitData)
		{
			string targetString = new List<MiniYamlNode>
			{
				new MiniYamlNode(traitDatum.Key.ToStringInvariant(), traitDatum.Value)
			}.WriteToString();
			packetFn(0, 0, Order.FromTargetString("SaveTraitData", targetString, isImmediate: true).Serialize());
		}
		ordersStream.Seek(0L, SeekOrigin.Begin);
		while (ordersStream.Position < ordersStream.Length)
		{
			int count = ordersStream.ReadInt32() - 8;
			int arg = ordersStream.ReadInt32();
			int num = ordersStream.ReadInt32();
			byte[] arg2 = ordersStream.ReadBytes(count);
			int num2 = clientsBySlotIndex[num];
			Session.Client client = lobbyInfo.ClientWithIndex(num2);
			if (client.Bot != null)
			{
				num2 = client.BotControllerClientIndex;
			}
			packetFn(arg, num2, arg2);
		}
		packetFn(LastSyncFrame, 0, lastSyncPacket);
	}

	public void AddTraitData(int traitIndex, MiniYaml data)
	{
		TraitData[traitIndex] = data;
	}

	public void Save(string path)
	{
		using FileStream fileStream = File.Create(path);
		ordersStream.Seek(0L, SeekOrigin.Begin);
		ordersStream.CopyTo(fileStream);
		fileStream.Write(-1);
		fileStream.Write(LastOrdersFrame);
		fileStream.Write(LastSyncFrame);
		fileStream.Write(lastSyncPacket, 0, 13);
		List<MiniYamlNode> y = new List<MiniYamlNode> { GlobalSettings.Serialize() };
		fileStream.WriteLengthPrefixedString(Encoding.UTF8, y.WriteToString());
		List<MiniYamlNode> y2 = Slots.Select((KeyValuePair<string, Session.Slot> s) => s.Value.Serialize()).ToList();
		fileStream.WriteLengthPrefixedString(Encoding.UTF8, y2.WriteToString());
		List<MiniYamlNode> y3 = SlotClients.Select((KeyValuePair<string, SlotClient> s) => s.Value.Serialize(s.Key)).ToList();
		fileStream.WriteLengthPrefixedString(Encoding.UTF8, y3.WriteToString());
		long length = fileStream.Length;
		fileStream.Write(-3);
		List<MiniYamlNode> y4 = TraitData.Select((KeyValuePair<int, MiniYaml> kv) => new MiniYamlNode(kv.Key.ToStringInvariant(), kv.Value)).ToList();
		fileStream.WriteLengthPrefixedString(Encoding.UTF8, y4.WriteToString());
		fileStream.Write((int)ordersStream.Length);
		fileStream.Write((int)length);
		fileStream.Write(-2);
	}
}
