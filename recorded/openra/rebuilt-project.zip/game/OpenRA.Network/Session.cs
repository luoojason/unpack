using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using OpenRA.Primitives;

namespace OpenRA.Network;

public class Session
{
	public enum ClientState
	{
		NotReady = 0,
		Invalid = 1,
		Ready = 2,
		Disconnected = 1000
	}

	public enum ConnectionQuality
	{
		Good,
		Moderate,
		Poor
	}

	public class Client
	{
		public int Index;

		public Color PreferredColor;

		public Color Color;

		public string Faction;

		public int SpawnPoint;

		public string Name;

		[FieldLoader.Ignore]
		public string IPAddress;

		public string AnonymizedIPAddress;

		public string Location;

		public ConnectionQuality ConnectionQuality;

		public ClientState State = ClientState.Invalid;

		public int Team;

		public int Handicap;

		public string Slot;

		public string Bot;

		public int BotControllerClientIndex;

		public bool IsAdmin;

		public string Fingerprint;

		public bool IsReady => State == ClientState.Ready;

		public bool IsInvalid => State == ClientState.Invalid;

		public bool IsObserver => Slot == null;

		public bool IsBot => Bot != null;

		public static Client Deserialize(MiniYaml data)
		{
			return FieldLoader.Load<Client>(data);
		}

		public MiniYamlNode Serialize()
		{
			return new MiniYamlNode($"Client@{Index}", FieldSaver.Save(this));
		}
	}

	public class Slot
	{
		public string PlayerReference;

		public bool Closed;

		public bool AllowBots;

		public bool LockFaction;

		public bool LockColor;

		public bool LockTeam;

		public bool LockHandicap;

		public bool LockSpawn;

		public bool Required;

		public static Slot Deserialize(MiniYaml data)
		{
			return FieldLoader.Load<Slot>(data);
		}

		public MiniYamlNode Serialize()
		{
			return new MiniYamlNode("Slot@" + PlayerReference, FieldSaver.Save(this));
		}
	}

	public class LobbyOptionState
	{
		public string Value;

		public string PreferredValue;

		public bool IsLocked;

		public bool IsEnabled => Value == "True";
	}

	[Flags]
	public enum MapStatus
	{
		Unknown = 0,
		Validating = 1,
		Playable = 2,
		Incompatible = 4,
		UnsafeCustomRules = 8
	}

	public class Global
	{
		public string ServerName;

		public string Map;

		public MapStatus MapStatus;

		public int RandomSeed;

		public bool AllowSpectators = true;

		public string GameUid;

		public bool EnableSingleplayer;

		public bool EnableSyncReports;

		public bool Dedicated;

		public bool GameSavesEnabled;

		public int NetFrameInterval = 3;

		[FieldLoader.Ignore]
		public Dictionary<string, LobbyOptionState> LobbyOptions = new Dictionary<string, LobbyOptionState>();

		public static Global Deserialize(MiniYaml data)
		{
			Global global = FieldLoader.Load<Global>(data);
			MiniYamlNode miniYamlNode = data.NodeWithKeyOrDefault("Options");
			if (miniYamlNode != null)
			{
				foreach (MiniYamlNode node in miniYamlNode.Value.Nodes)
				{
					global.LobbyOptions[node.Key] = FieldLoader.Load<LobbyOptionState>(node.Value);
				}
			}
			return global;
		}

		public MiniYamlNode Serialize()
		{
			MiniYamlNode miniYamlNode = new MiniYamlNode("GlobalSettings", FieldSaver.Save(this));
			IEnumerable<MiniYamlNode> nodes = LobbyOptions.Select((KeyValuePair<string, LobbyOptionState> kv) => new MiniYamlNode(kv.Key, FieldSaver.Save(kv.Value)));
			return miniYamlNode.WithValue(miniYamlNode.Value.WithNodesAppended(new MiniYamlNode[1]
			{
				new MiniYamlNode("Options", new MiniYaml(null, nodes))
			}));
		}

		public bool OptionOrDefault(string id, bool def)
		{
			if (LobbyOptions.TryGetValue(id, out var value))
			{
				return value.IsEnabled;
			}
			return def;
		}

		public string OptionOrDefault(string id, string def)
		{
			if (LobbyOptions.TryGetValue(id, out var value))
			{
				return value.Value;
			}
			return def;
		}
	}

	public List<Client> Clients = new List<Client>();

	public Dictionary<string, Slot> Slots = new Dictionary<string, Slot>();

	public HashSet<int> DisabledSpawnPoints = new HashSet<int>();

	public Global GlobalSettings = new Global();

	public IEnumerable<Client> NonBotClients => Clients.Where((Client c) => c.Bot == null);

	public IEnumerable<Client> NonBotPlayers => Clients.Where((Client c) => c.Bot == null && c.Slot != null);

	public static string AnonymizeIP(IPAddress ip)
	{
		if (ip.AddressFamily == AddressFamily.InterNetwork)
		{
			byte[] addressBytes = ip.GetAddressBytes();
			return $"{addressBytes[0]}.{addressBytes[1]}.{addressBytes[2]}.*";
		}
		return null;
	}

	public static Session Deserialize(string data, string name)
	{
		try
		{
			Session session = new Session();
			List<MiniYamlNode> list = MiniYaml.FromString(data, name);
			foreach (MiniYamlNode item in list)
			{
				string[] array = item.Key.Split('@');
				switch (array[0])
				{
				case "Client":
					session.Clients.Add(Client.Deserialize(item.Value));
					break;
				case "GlobalSettings":
					session.GlobalSettings = Global.Deserialize(item.Value);
					break;
				case "Slot":
				{
					Slot slot = Slot.Deserialize(item.Value);
					session.Slots.Add(slot.PlayerReference, slot);
					break;
				}
				case "DisabledSpawnPoints":
					session.DisabledSpawnPoints = FieldLoader.GetValue<HashSet<int>>("DisabledSpawnPoints", item.Value.Value);
					break;
				}
			}
			return session;
		}
		catch (YamlException)
		{
			throw new YamlException("Session deserialized invalid MiniYaml:\n" + data);
		}
		catch (InvalidOperationException)
		{
			throw new YamlException("Session deserialized invalid MiniYaml:\n" + data);
		}
	}

	public Client ClientWithIndex(int clientID)
	{
		return Clients.SingleOrDefault((Client c) => c.Index == clientID);
	}

	public Client ClientInSlot(string slot)
	{
		return Clients.SingleOrDefault((Client c) => c.Slot == slot);
	}

	public string FirstEmptySlot()
	{
		return Slots.FirstOrDefault((KeyValuePair<string, Slot> s) => !s.Value.Closed && ClientInSlot(s.Key) == null).Key;
	}

	public string FirstEmptyBotSlot()
	{
		return Slots.FirstOrDefault((KeyValuePair<string, Slot> s) => !s.Value.Closed && ClientInSlot(s.Key) == null && s.Value.AllowBots).Key;
	}

	public string Serialize()
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>
		{
			new MiniYamlNode("DisabledSpawnPoints", FieldSaver.FormatValue(DisabledSpawnPoints))
		};
		foreach (Client client in Clients)
		{
			list.Add(client.Serialize());
		}
		foreach (KeyValuePair<string, Slot> slot in Slots)
		{
			list.Add(slot.Value.Serialize());
		}
		list.Add(GlobalSettings.Serialize());
		return list.WriteToString();
	}
}
