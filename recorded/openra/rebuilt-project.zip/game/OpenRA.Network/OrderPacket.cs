using System.Collections.Generic;
using System.IO;

namespace OpenRA.Network;

public class OrderPacket
{
	private readonly MemoryStream data;

	public OrderPacket(IEnumerable<Order> orders)
	{
		data = new MemoryStream();
		foreach (Order order in orders)
		{
			data.Write(order.Serialize());
		}
	}

	public OrderPacket(MemoryStream data)
	{
		this.data = data;
	}

	public IEnumerable<Order> GetOrders(World world)
	{
		if (data.Length == 0L)
		{
			yield break;
		}
		data.Position = 0L;
		BinaryReader reader = new BinaryReader(data);
		while (data.Position < data.Length)
		{
			Order order = Order.Deserialize(world, reader);
			if (order != null)
			{
				yield return order;
			}
		}
	}

	public byte[] Serialize(int frame)
	{
		MemoryStream memoryStream = new MemoryStream((int)data.Length + 4);
		memoryStream.Write(frame);
		data.Position = 0L;
		data.CopyTo(memoryStream);
		return memoryStream.GetBuffer();
	}

	public static OrderPacket Combine(IEnumerable<OrderPacket> packets)
	{
		MemoryStream destination = new MemoryStream();
		foreach (OrderPacket packet in packets)
		{
			packet.data.Position = 0L;
			packet.data.CopyTo(destination);
		}
		return new OrderPacket(destination);
	}
}
