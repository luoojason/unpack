namespace OpenRA.Network;

public enum ConnectionState
{
	PreConnecting,
	NotConnected,
	Connecting,
	Connected
}
