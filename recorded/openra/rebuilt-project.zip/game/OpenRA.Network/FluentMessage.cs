using System;
using System.Collections.Generic;

namespace OpenRA.Network;

public class FluentMessage
{
	public const int ProtocolVersion = 1;

	public readonly string Key = string.Empty;

	[FieldLoader.LoadUsing("LoadArguments", false)]
	public readonly object[] Arguments;

	private static object LoadArguments(MiniYaml yaml)
	{
		List<object> list = new List<object>();
		MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault("Arguments");
		if (miniYamlNode != null)
		{
			foreach (MiniYamlNode node in miniYamlNode.Value.Nodes)
			{
				FluentArgument fluentArgument = FieldLoader.Load<FluentArgument>(node.Value);
				list.Add(fluentArgument.Key);
				if (fluentArgument.Type == FluentArgument.FluentArgumentType.Number)
				{
					if (!double.TryParse(fluentArgument.Value, out var result))
					{
						Log.Write("debug", "Failed to parse " + fluentArgument.Value);
					}
					list.Add(result);
				}
				else
				{
					list.Add(fluentArgument.Value);
				}
			}
		}
		return list.ToArray();
	}

	public FluentMessage(MiniYaml yaml)
	{
		FieldLoader.Load(this, yaml);
	}

	public static string Serialize(string key, object[] args)
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>
		{
			new MiniYamlNode("Protocol", 1.ToStringInvariant()),
			new MiniYamlNode("Key", key)
		};
		if (args != null)
		{
			List<MiniYamlNode> list2 = new List<MiniYamlNode>();
			for (int i = 0; i < args.Length; i += 2)
			{
				string text = args[i] as string;
				if (string.IsNullOrEmpty(text))
				{
					throw new ArgumentException($"Expected the argument at index {i} to be a non-empty string", "args");
				}
				object obj = args[i + 1];
				if (obj == null)
				{
					throw new ArgumentNullException("args", $"Expected the argument at index {i + 1} to be a non-null value");
				}
				list2.Add(new MiniYamlNode($"Argument@{i / 2}", FieldSaver.Save(new FluentArgument(text, obj))));
			}
			list.Add(new MiniYamlNode("Arguments", new MiniYaml("", list2)));
		}
		return new MiniYaml("", list).ToLines("FluentMessage").JoinWith("\n");
	}
}
