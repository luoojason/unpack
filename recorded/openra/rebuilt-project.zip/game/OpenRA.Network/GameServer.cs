using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using OpenRA.Server;

namespace OpenRA.Network;

public class GameServer
{
	private static readonly string[] SerializeFields = new string[13]
	{
		"Name", "Address", "Mod", "Version", "ModTitle", "ModWebsite", "ModIcon32", "Map", "State", "MaxPlayers",
		"Protected", "Authentication", "DisabledSpawnPoints"
	};

	public const int ProtocolVersion = 2;

	public readonly int Id = -1;

	public readonly string Name;

	public readonly string Address;

	public readonly int Port;

	public readonly int State;

	public readonly int MaxPlayers;

	public readonly string Map;

	public readonly string Mod = "";

	public readonly string Version = "";

	public readonly string ModTitle = "";

	public readonly string ModWebsite = "";

	public readonly string ModIcon32 = "";

	public readonly string Location = "";

	public readonly bool Protected;

	public readonly bool Authentication;

	public readonly string Started;

	public readonly int Players;

	public readonly int Bots;

	public readonly int Spectators;

	public readonly int PlayTime = -1;

	[FieldLoader.Ignore]
	public readonly bool IsCompatible;

	[FieldLoader.Ignore]
	public readonly bool IsJoinable;

	[FieldLoader.LoadUsing("LoadClients", false)]
	public readonly GameClient[] Clients;

	public readonly int[] DisabledSpawnPoints = Array.Empty<int>();

	public string ModLabel => ModTitle + " (" + Version + ")";

	private static object LoadClients(MiniYaml yaml)
	{
		List<GameClient> list = new List<GameClient>();
		MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault("Clients");
		if (miniYamlNode != null)
		{
			Regex regex = new Regex("Client@\\d+");
			foreach (MiniYamlNode node in miniYamlNode.Value.Nodes)
			{
				if (regex.IsMatch(node.Key))
				{
					list.Add(FieldLoader.Load<GameClient>(node.Value));
				}
			}
		}
		return list.ToArray();
	}

	public GameServer(MiniYaml yaml)
	{
		FieldLoader.Load(this, yaml);
		if (Mod == null || Version == null)
		{
			MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault("Mods");
			if (miniYamlNode != null)
			{
				string[] array = miniYamlNode.Value.Value.Split('@');
				Mod = array[0];
				Version = array[1];
			}
		}
		if (State == 2 && PlayTime < 0 && DateTime.TryParse(Started, out var result))
		{
			PlayTime = (int)(DateTime.UtcNow - result).TotalSeconds;
		}
		string key = ExternalMod.MakeKey(Mod, Version);
		if (Game.ExternalMods.TryGetValue(key, out var value) && value.Version == Version)
		{
			IsCompatible = true;
		}
		if (string.IsNullOrEmpty(ModTitle))
		{
			Manifest value2;
			if (value != null && value.Version == Version)
			{
				ModTitle = value.Id;
			}
			else if (Game.Mods.TryGetValue(Mod, out value2))
			{
				ModTitle = value2.Metadata.TitleTranslated;
			}
			else
			{
				ExternalMod externalMod = Game.ExternalMods.Values.OrderByDescending((ExternalMod m) => m.Version).FirstOrDefault((ExternalMod m) => m.Id == Mod);
				if (externalMod != null)
				{
					ModTitle = externalMod.Id;
				}
				else
				{
					ModTitle = "Unknown mod: " + Mod;
				}
			}
		}
		bool flag = Game.Settings.Game.AllowDownloading || Game.ModData.MapCache[Map].Status == MapStatus.Available;
		IsJoinable = (IsCompatible && State == 1) & flag;
	}

	public GameServer(OpenRA.Server.Server server)
	{
		Manifest manifest = server.ModData.Manifest;
		Name = server.Settings.Name;
		Address = "0.0.0.0:" + server.Settings.ListenPort.ToStringInvariant();
		State = (int)server.State;
		MaxPlayers = server.LobbyInfo.Slots.Count((KeyValuePair<string, Session.Slot> s) => !s.Value.Closed) - server.LobbyInfo.Clients.Count((Session.Client c1) => c1.Bot != null);
		Map = server.Map.Uid;
		Mod = manifest.Id;
		Version = manifest.Metadata.Version;
		ModTitle = manifest.Metadata.TitleTranslated;
		ModWebsite = manifest.Metadata.Website;
		ModIcon32 = manifest.Metadata.WebIcon32;
		Protected = !string.IsNullOrEmpty(server.Settings.Password);
		Authentication = server.Settings.RequireAuthentication || server.Settings.ProfileIDWhitelist.Length != 0;
		Clients = server.LobbyInfo.Clients.Select((Session.Client c) => new GameClient(c)).ToArray();
		DisabledSpawnPoints = server.LobbyInfo.DisabledSpawnPoints?.ToArray() ?? Array.Empty<int>();
	}

	public string ToPOSTData(bool lanGame)
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>
		{
			new MiniYamlNode("Protocol", 2.ToStringInvariant())
		};
		string[] serializeFields = SerializeFields;
		foreach (string field in serializeFields)
		{
			list.Add(FieldSaver.SaveField(this, field));
		}
		if (lanGame)
		{
			list.Add(new MiniYamlNode("Id", Platform.SessionGUID.ToString()));
			list.Add(new MiniYamlNode("Players", Clients.Count((GameClient c) => !c.IsBot && !c.IsSpectator).ToStringInvariant()));
			list.Add(new MiniYamlNode("Spectators", Clients.Count((GameClient c) => c.IsSpectator).ToStringInvariant()));
			list.Add(new MiniYamlNode("Bots", Clients.Count((GameClient c) => c.IsBot).ToStringInvariant()));
			list.Add(new MiniYamlNode("Mods", Mod + "@" + Version));
		}
		MiniYaml v = new MiniYaml("", Clients.Select((GameClient c, int num) => new MiniYamlNode("Client@" + num, FieldSaver.Save(c))));
		list.Add(new MiniYamlNode("Clients", v));
		return new MiniYaml("", list).ToLines("Game").JoinWith("\n");
	}
}
