using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace OpenRA.Network;

public sealed class ConnectionTarget
{
	private readonly DnsEndPoint[] endpoints;

	public ConnectionTarget()
	{
		endpoints = new DnsEndPoint[1]
		{
			new DnsEndPoint("invalid", 0)
		};
	}

	public ConnectionTarget(string host, int port)
	{
		endpoints = new DnsEndPoint[1]
		{
			new DnsEndPoint(host, port)
		};
	}

	public ConnectionTarget(IEnumerable<DnsEndPoint> endpoints)
	{
		this.endpoints = endpoints.ToArray();
		if (this.endpoints.Length == 0)
		{
			throw new ArgumentException("ConnectionTarget must have at least one address.");
		}
	}

	public IEnumerable<IPEndPoint> GetConnectEndPoints()
	{
		return endpoints.SelectMany((DnsEndPoint e) =>
		{
			try
			{
				return from a in Dns.GetHostAddresses(e.Host)
					select new IPEndPoint(a, e.Port);
			}
			catch (Exception)
			{
				return Enumerable.Empty<IPEndPoint>();
			}
		}).ToList();
	}

	public override string ToString()
	{
		return endpoints.Select((DnsEndPoint e) => $"{e.Host}:{e.Port}").JoinWith("/");
	}
}
