using System.Collections.Generic;
using System.Linq;

namespace OpenRA.Network;

public class HandshakeResponse
{
	public string Mod;

	public string Version;

	public string Password;

	public int OrdersProtocol = 7;

	public string Fingerprint;

	public string AuthSignature;

	[FieldLoader.Ignore]
	public Session.Client Client;

	public static HandshakeResponse Deserialize(string data, string name)
	{
		HandshakeResponse handshakeResponse = new HandshakeResponse
		{
			Client = new Session.Client()
		};
		List<MiniYamlNode> list = MiniYaml.FromString(data, name);
		foreach (MiniYamlNode item in list)
		{
			string key = item.Key;
			if (!(key == "Handshake"))
			{
				if (key == "Client")
				{
					FieldLoader.Load(handshakeResponse.Client, item.Value);
				}
			}
			else
			{
				FieldLoader.Load(handshakeResponse, item.Value);
			}
		}
		return handshakeResponse;
	}

	public string Serialize()
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>();
		list.Add(new MiniYamlNode("Handshake", null, new string[6] { "Mod", "Version", "Password", "Fingerprint", "AuthSignature", "OrdersProtocol" }.Select((string p) => FieldSaver.SaveField(this, p)).ToList()));
		list.Add(new MiniYamlNode("Client", FieldSaver.Save(Client)));
		List<MiniYamlNode> y = list;
		return y.WriteToString();
	}
}
