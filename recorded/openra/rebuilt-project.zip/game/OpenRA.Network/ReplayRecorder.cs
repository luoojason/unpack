using System;
using System.IO;
using System.Linq;
using OpenRA.FileFormats;

namespace OpenRA.Network;

public sealed class ReplayRecorder
{
	private const int CreateReplayFileMaxRetryCount = 128;

	public ReplayMetadata Metadata;

	private BinaryWriter writer;

	private readonly Func<string> chooseFilename;

	private MemoryStream preStartBuffer = new MemoryStream();

	private bool disposed;

	private static bool IsGameStart(byte[] data)
	{
		if (!OrderIO.TryParseOrderPacket(data, out (int, OrderPacket) data2))
		{
			return false;
		}
		if (data2.Item1 == 0)
		{
			return data2.Item2.GetOrders(null).Any((Order o) => o.OrderString == "StartGame");
		}
		return false;
	}

	public ReplayRecorder(Func<string> chooseFilename)
	{
		this.chooseFilename = chooseFilename;
		writer = new BinaryWriter(preStartBuffer);
	}

	private void StartSavingReplay(byte[] initialContent)
	{
		string text = chooseFilename();
		Manifest manifest = Game.ModData.Manifest;
		string text2 = Path.Combine(Platform.SupportDir, "Replays", manifest.Id, manifest.Metadata.Version);
		if (!Directory.Exists(text2))
		{
			Directory.CreateDirectory(text2);
		}
		FileStream fileStream = null;
		int num = -1;
		while (fileStream == null)
		{
			string path = Path.Combine(text2, (num < 0) ? (text + ".orarep") : $"{text}-{num}.orarep");
			num++;
			try
			{
				fileStream = File.Create(path);
			}
			catch (IOException innerException)
			{
				if (num > 128)
				{
					throw new ArgumentException("Error creating replay file \"" + text + ".orarep\"", innerException);
				}
			}
		}
		fileStream.Write(initialContent);
		writer = new BinaryWriter(fileStream);
	}

	public void Receive(int clientID, byte[] data)
	{
		if (!disposed)
		{
			if (preStartBuffer != null && IsGameStart(data))
			{
				writer.Flush();
				byte[] initialContent = preStartBuffer.ToArray();
				preStartBuffer = null;
				StartSavingReplay(initialContent);
			}
			writer.Write(clientID);
			writer.Write(data.Length);
			writer.Write(data);
		}
	}

	public void ReceiveFrame(int clientID, int frame, byte[] data)
	{
		MemoryStream memoryStream = new MemoryStream(4 + data.Length);
		memoryStream.Write(frame);
		memoryStream.Write(data);
		Receive(clientID, memoryStream.GetBuffer());
	}

	public void Dispose()
	{
		if (disposed)
		{
			return;
		}
		disposed = true;
		if (Metadata != null)
		{
			if (Metadata.GameInfo != null)
			{
				Metadata.GameInfo.EndTimeUtc = DateTime.UtcNow;
			}
			Metadata.Write(writer);
		}
		preStartBuffer?.Dispose();
		writer.Close();
	}
}
