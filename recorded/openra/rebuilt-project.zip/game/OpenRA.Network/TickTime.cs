using System;

namespace OpenRA.Network;

public sealed class TickTime
{
	private readonly Func<int> timestep;

	public long Value { get; set; }

	public TickTime(Func<int> timestep, long lastTickTime)
	{
		this.timestep = timestep;
		Value = lastTickTime;
	}

	public bool ShouldAdvance(long tick)
	{
		int num = timestep();
		if (num == 0)
		{
			return false;
		}
		long num2 = tick - Value;
		return num2 >= num;
	}

	public void AdvanceTickTime(long tick)
	{
		long num = tick - Value;
		int num2 = timestep();
		long num3 = num / num2 * num2;
		Value += ((num3 >= 250) ? num3 : num2);
	}
}
