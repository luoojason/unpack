using System;
using System.IO;

namespace OpenRA.Network;

public static class OrderIO
{
	private static readonly OrderPacket NoOrders = new OrderPacket(Array.Empty<Order>());

	public static byte[] SerializeSync((int Frame, int SyncHash, ulong DefeatState) data)
	{
		MemoryStream memoryStream = new MemoryStream(17);
		memoryStream.Write(data.Frame);
		memoryStream.WriteByte(101);
		memoryStream.Write(data.SyncHash);
		memoryStream.Write(data.DefeatState);
		return memoryStream.GetBuffer();
	}

	public static byte[] SerializePingResponse(long timestamp, byte queueLength)
	{
		MemoryStream memoryStream = new MemoryStream(14);
		memoryStream.Write(0);
		memoryStream.WriteByte(32);
		memoryStream.Write(timestamp);
		memoryStream.WriteByte(queueLength);
		return memoryStream.GetBuffer();
	}

	public static bool TryParseDisconnect((int FromClient, byte[] Data) packet, out (int Frame, int ClientId) disconnect)
	{
		if (packet.FromClient != 0 || packet.Data.Length != 9 || packet.Data[4] != 191)
		{
			disconnect = (Frame: 0, ClientId: 0);
			return false;
		}
		int item = BitConverter.ToInt32(packet.Data, 0);
		int item2 = BitConverter.ToInt32(packet.Data, 5);
		disconnect = (Frame: item, ClientId: item2);
		return true;
	}

	public static bool TryParseSync(byte[] packet, out (int Frame, int SyncHash, ulong DefeatState) data)
	{
		if (packet.Length != 17 || packet[4] != 101)
		{
			data = (Frame: 0, SyncHash: 0, DefeatState: 0uL);
			return false;
		}
		int item = BitConverter.ToInt32(packet, 0);
		int item2 = BitConverter.ToInt32(packet, 5);
		ulong item3 = BitConverter.ToUInt64(packet, 9);
		data = (Frame: item, SyncHash: item2, DefeatState: item3);
		return true;
	}

	public static bool TryParseTickScale((int FromClient, byte[] Data) packet, out float scale)
	{
		if (packet.FromClient != 0 || packet.Data.Length != 9 || packet.Data[4] != 118)
		{
			scale = 1f;
			return false;
		}
		if (BitConverter.ToInt32(packet.Data, 0) != 0)
		{
			scale = 1f;
			return false;
		}
		scale = BitConverter.ToSingle(packet.Data, 5);
		return true;
	}

	public static bool TryParsePingRequest((int FromClient, byte[] Data) packet, out long timestamp)
	{
		if (packet.FromClient != 0 || packet.Data.Length != 13 || packet.Data[4] != 32)
		{
			timestamp = 0L;
			return false;
		}
		if (BitConverter.ToInt32(packet.Data, 0) != 0)
		{
			timestamp = 0L;
			return false;
		}
		timestamp = BitConverter.ToInt64(packet.Data, 5);
		return true;
	}

	public static bool TryParseAck((int FromClient, byte[] Data) packet, out int frame, out byte count)
	{
		if (packet.FromClient != 0 || packet.Data.Length != 6 || packet.Data[4] != 16)
		{
			frame = (count = 0);
			return false;
		}
		frame = BitConverter.ToInt32(packet.Data, 0);
		count = packet.Data[5];
		return true;
	}

	public static bool TryParseOrderPacket(byte[] packet, out (int Frame, OrderPacket Orders) data)
	{
		if (packet.Length < 4)
		{
			data = (Frame: 0, Orders: null);
			return false;
		}
		if (packet.Length >= 5 && (packet[4] == 191 || packet[4] == 101))
		{
			data = (Frame: 0, Orders: null);
			return false;
		}
		int item = BitConverter.ToInt32(packet, 0);
		OrderPacket item2 = ((packet.Length > 4) ? new OrderPacket(new MemoryStream(packet, 4, packet.Length - 4)) : NoOrders);
		data = (Frame: item, Orders: item2);
		return true;
	}
}
