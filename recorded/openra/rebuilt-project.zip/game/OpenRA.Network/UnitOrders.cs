using System.Collections.Generic;
using System.Linq;
using OpenRA.Traits;

namespace OpenRA.Network;

public static class UnitOrders
{
	public const int ChatMessageMaxLength = 2500;

	[FluentReference(new string[] { "player" })]
	private const string Joined = "notification-joined";

	[FluentReference(new string[] { "player" })]
	private const string Left = "notification-lobby-disconnected";

	[FluentReference]
	private const string GameStarted = "notification-game-has-started";

	[FluentReference]
	private const string GameSaved = "notification-game-saved";

	[FluentReference(new string[] { "player" })]
	private const string GamePaused = "notification-game-paused";

	[FluentReference(new string[] { "player" })]
	private const string GameUnpaused = "notification-game-unpaused";

	public static int? KickVoteTarget { get; internal set; }

	private static Player FindPlayerByClient(this World world, Session.Client c)
	{
		return world.Players.FirstOrDefault((Player p) => p.ClientIndex == c.Index && p.PlayerReference.Playable);
	}

	private static bool OrderNotFromServerOrWorldIsReplay(int clientId, World world)
	{
		if (clientId == 0)
		{
			return world?.IsReplay ?? false;
		}
		return true;
	}

	internal static void ProcessOrder(OrderManager orderManager, World world, int clientId, Order order)
	{
		switch (order.OrderString)
		{
		case "Message":
			TextNotificationsManager.AddSystemLine(order.TargetString);
			break;
		case "FluentMessage":
		{
			if (string.IsNullOrEmpty(order.TargetString))
			{
				break;
			}
			List<MiniYamlNode> list6 = MiniYaml.FromString(order.TargetString, order.OrderString);
			{
				foreach (MiniYamlNode item in list6)
				{
					FluentMessage fluentMessage = new FluentMessage(item.Value);
					if (fluentMessage.Key == "notification-joined")
					{
						TextNotificationsManager.AddPlayerJoinedLine(fluentMessage.Key, fluentMessage.Arguments);
					}
					else if (fluentMessage.Key == "notification-lobby-disconnected")
					{
						TextNotificationsManager.AddPlayerLeftLine(fluentMessage.Key, fluentMessage.Arguments);
					}
					else
					{
						TextNotificationsManager.AddSystemLine(fluentMessage.Key, fluentMessage.Arguments);
					}
				}
				break;
			}
		}
		case "DisableChatEntry":
			if (!OrderNotFromServerOrWorldIsReplay(clientId, world))
			{
				if (order.ExtraData == uint.MaxValue)
				{
					TextNotificationsManager.ChatDisabledUntil = 4294967295L;
				}
				else
				{
					TextNotificationsManager.ChatDisabledUntil = Game.RunTime + order.ExtraData;
				}
			}
			break;
		case "StartKickVote":
			if (!OrderNotFromServerOrWorldIsReplay(clientId, world))
			{
				KickVoteTarget = (int)order.ExtraData;
			}
			break;
		case "EndKickVote":
			if (!OrderNotFromServerOrWorldIsReplay(clientId, world) && KickVoteTarget == (int?)order.ExtraData)
			{
				KickVoteTarget = null;
			}
			break;
		case "Chat":
		{
			Session.Client client3 = orderManager.LobbyInfo.ClientWithIndex(clientId);
			if (client3 == null)
			{
				break;
			}
			string text = order.TargetString;
			if (text.Length > 2500)
			{
				text = order.TargetString.Substring(0, 2500);
			}
			if (order.ExtraData == 0)
			{
				Player player = ((world != null) ? world.FindPlayerByClient(client3) : null);
				string text2 = ((player != null && player.WinState == WinState.Lost) ? " (Dead)" : "");
				text2 = (client3.IsObserver ? " (Spectator)" : text2);
				if (orderManager.LocalClient != null && client3 != orderManager.LocalClient && client3.Team > 0 && client3.Team == orderManager.LocalClient.Team)
				{
					text2 += " (Ally)";
				}
				TextNotificationsManager.AddChatLine(clientId, client3.Name + text2, text, client3.Color);
				break;
			}
			if (world == null)
			{
				string text3 = ((order.ExtraData == uint.MaxValue) ? "[Spectators] " : "[Team] ");
				if (orderManager.LocalClient != null && client3.Team == orderManager.LocalClient.Team)
				{
					TextNotificationsManager.AddChatLine(clientId, text3 + client3.Name, text, client3.Color);
				}
				break;
			}
			Player player2 = world.FindPlayerByClient(client3);
			bool flag2 = world.IsReplay || (orderManager.LocalClient != null && orderManager.LocalClient.IsObserver) || (world.LocalPlayer != null && world.LocalPlayer.WinState != WinState.Undefined);
			if ((order.ExtraData == uint.MaxValue) & flag2)
			{
				if (client3.IsObserver || (player2 != null && player2.WinState != WinState.Undefined))
				{
					TextNotificationsManager.AddChatLine(clientId, "[Spectators] " + client3.Name, text, client3.Color);
				}
				break;
			}
			bool flag3 = client3.Team == order.ExtraData && player2 != null && player2.WinState == WinState.Undefined;
			bool flag4 = orderManager.LocalClient != null && order.ExtraData == orderManager.LocalClient.Team && world.LocalPlayer != null && world.LocalPlayer.WinState == WinState.Undefined;
			if (flag3 && (flag4 || world.IsReplay))
			{
				TextNotificationsManager.AddChatLine(clientId, "[Team" + (world.IsReplay ? (" " + order.ExtraData) : "") + "] " + client3.Name, text, client3.Color);
			}
			break;
		}
		case "StartGame":
			if (Game.ModData.MapCache[orderManager.LobbyInfo.GlobalSettings.Map].Status != MapStatus.Available)
			{
				Game.Disconnect();
				Game.LoadShellMap();
				break;
			}
			if (!string.IsNullOrEmpty(order.TargetString))
			{
				List<MiniYamlNode> list7 = MiniYaml.FromString(order.TargetString, order.OrderString);
				MiniYamlNode miniYamlNode2 = list7.FirstOrDefault((MiniYamlNode n) => n.Key == "SaveLastOrdersFrame");
				if (miniYamlNode2 != null)
				{
					orderManager.GameSaveLastFrame = FieldLoader.GetValue<int>("saveLastOrdersFrame", miniYamlNode2.Value.Value);
				}
				MiniYamlNode miniYamlNode3 = list7.FirstOrDefault((MiniYamlNode n) => n.Key == "SaveSyncFrame");
				if (miniYamlNode3 != null)
				{
					orderManager.GameSaveLastSyncFrame = FieldLoader.GetValue<int>("SaveSyncFrame", miniYamlNode3.Value.Value);
				}
			}
			else
			{
				TextNotificationsManager.AddSystemLine("notification-game-has-started");
			}
			Game.StartGame(orderManager.LobbyInfo.GlobalSettings.Map, WorldType.Regular);
			break;
		case "SaveTraitData":
		{
			MiniYamlNode miniYamlNode = MiniYaml.FromString(order.TargetString, order.OrderString)[0];
			int traitIndex = Exts.ParseInt32Invariant(miniYamlNode.Key);
			world?.AddGameSaveTraitData(traitIndex, miniYamlNode.Value);
			break;
		}
		case "GameSaved":
			if (!orderManager.World.IsReplay)
			{
				TextNotificationsManager.AddSystemLine("notification-game-saved");
			}
			{
				foreach (INotifyGameSaved item2 in orderManager.World.WorldActor.TraitsImplementing<INotifyGameSaved>())
				{
					item2.GameSaved(orderManager.World);
				}
				break;
			}
		case "PauseGame":
		{
			Session.Client client2 = orderManager.LobbyInfo.ClientWithIndex(clientId);
			if (client2 == null)
			{
				break;
			}
			bool flag = order.TargetString == "Pause";
			if (!orderManager.World.IsGameOver || flag)
			{
				if (orderManager.World.Paused != flag && world != null && world.LobbyInfo.NonBotClients.Count() > 1)
				{
					TextNotificationsManager.AddSystemLine(flag ? "notification-game-paused" : "notification-game-unpaused", "player", client2.Name);
				}
				orderManager.World.Paused = flag;
				orderManager.World.PredictedPaused = flag;
			}
			break;
		}
		case "HandshakeRequest":
		{
			Manifest manifest = Game.ModData.Manifest;
			HandshakeRequest handshakeRequest = HandshakeRequest.Deserialize(order.TargetString, order.OrderString);
			string key = ExternalMod.MakeKey(handshakeRequest.Mod, handshakeRequest.Version);
			if ((handshakeRequest.Mod != manifest.Id || handshakeRequest.Version != manifest.Metadata.Version) && Game.ExternalMods.TryGetValue(key, out var value))
			{
				CurrentServerSettings.ServerExternalMod = value;
				orderManager.Connection.Dispose();
				break;
			}
			Game.Settings.Player.Name = Settings.SanitizedPlayerName(Game.Settings.Player.Name);
			Game.Settings.Save();
			Session.Client client4 = new Session.Client
			{
				Name = Game.Settings.Player.Name,
				PreferredColor = Game.Settings.Player.Color,
				Color = Game.Settings.Player.Color,
				Faction = "Random",
				SpawnPoint = 0,
				Team = 0,
				State = Session.ClientState.Invalid
			};
			LocalPlayerProfile localPlayerProfile = Game.LocalPlayerProfile;
			HandshakeResponse handshakeResponse = new HandshakeResponse
			{
				Client = client4,
				Mod = manifest.Id,
				Version = manifest.Metadata.Version,
				Password = CurrentServerSettings.Password,
				Fingerprint = localPlayerProfile.Fingerprint,
				OrdersProtocol = 21
			};
			if (handshakeRequest.AuthToken != null && handshakeResponse.Fingerprint != null)
			{
				handshakeResponse.AuthSignature = localPlayerProfile.Sign(handshakeRequest.AuthToken);
			}
			orderManager.IssueOrder(new Order("HandshakeResponse", null, queued: false)
			{
				Type = OrderType.Handshake,
				IsImmediate = true,
				TargetString = handshakeResponse.Serialize()
			});
			break;
		}
		case "ServerError":
			orderManager.ServerError = order.TargetString;
			orderManager.AuthenticationFailed = false;
			break;
		case "AuthenticationError":
			orderManager.ServerError = order.TargetString;
			orderManager.AuthenticationFailed = true;
			break;
		case "SyncInfo":
			orderManager.LobbyInfo = Session.Deserialize(order.TargetString, order.OrderString);
			Game.SyncLobbyInfo();
			break;
		case "SyncLobbyClients":
		{
			List<Session.Client> list4 = new List<Session.Client>();
			List<MiniYamlNode> list5 = MiniYaml.FromString(order.TargetString, order.OrderString);
			foreach (MiniYamlNode item3 in list5)
			{
				string[] array3 = item3.Key.Split('@');
				if (array3[0] == "Client")
				{
					list4.Add(Session.Client.Deserialize(item3.Value));
				}
			}
			orderManager.LobbyInfo.Clients = list4;
			Game.SyncLobbyInfo();
			break;
		}
		case "SyncLobbySlots":
		{
			Dictionary<string, Session.Slot> dictionary = new Dictionary<string, Session.Slot>();
			List<MiniYamlNode> list3 = MiniYaml.FromString(order.TargetString, order.OrderString);
			foreach (MiniYamlNode item4 in list3)
			{
				string[] array2 = item4.Key.Split('@');
				if (array2[0] == "Slot")
				{
					Session.Slot slot = Session.Slot.Deserialize(item4.Value);
					dictionary.Add(slot.PlayerReference, slot);
				}
			}
			orderManager.LobbyInfo.Slots = dictionary;
			Game.SyncLobbyInfo();
			break;
		}
		case "SyncLobbyGlobalSettings":
		{
			List<MiniYamlNode> list2 = MiniYaml.FromString(order.TargetString, order.OrderString);
			foreach (MiniYamlNode item5 in list2)
			{
				string[] array = item5.Key.Split('@');
				if (array[0] == "GlobalSettings")
				{
					orderManager.LobbyInfo.GlobalSettings = Session.Global.Deserialize(item5.Value);
				}
			}
			Game.SyncLobbyInfo();
			break;
		}
		case "SyncConnectionQuality":
		{
			List<MiniYamlNode> list = MiniYaml.FromString(order.TargetString, order.OrderString);
			{
				foreach (MiniYamlNode item6 in list)
				{
					string[] strings = item6.Key.Split('@');
					if (strings[0] == "ConnectionQuality")
					{
						Session.Client client = orderManager.LobbyInfo.Clients.FirstOrDefault((Session.Client c) => c.Index == Exts.ParseInt32Invariant(strings[1]));
						if (client != null)
						{
							client.ConnectionQuality = FieldLoader.GetValue<Session.ConnectionQuality>("ConnectionQuality", item6.Value.Value);
						}
					}
				}
				break;
			}
		}
		case "SyncMapPool":
			orderManager.ServerMapPool = FieldLoader.GetValue<HashSet<string>>("SyncMapPool", order.TargetString);
			break;
		default:
		{
			if (world == null)
			{
				break;
			}
			if (order.GroupedActors == null)
			{
				ResolveOrder(order, world, orderManager, clientId);
				break;
			}
			Actor[] groupedActors = order.GroupedActors;
			foreach (Actor subject in groupedActors)
			{
				ResolveOrder(Order.FromGroupedOrder(order, subject), world, orderManager, clientId);
			}
			break;
		}
		}
	}

	private static void ResolveOrder(Order order, World world, OrderManager orderManager, int clientId)
	{
		if (order.Subject != null && !order.Subject.IsDead && world.OrderValidators.All((IValidateOrder vo) => vo.OrderValidation(orderManager, world, clientId, order)))
		{
			order.Subject.ResolveOrder(order);
		}
	}

	public static void Clear()
	{
		KickVoteTarget = null;
	}
}
