namespace OpenRA.Graphics;

public enum SpriteFrameType
{
	Indexed8,
	Bgra32,
	Bgr24,
	Rgba32,
	Rgb24
}
