using System;

namespace OpenRA.Graphics;

[Serializable]
public class SheetOverflowException : Exception
{
	public SheetOverflowException(string message)
		: base(message)
	{
	}
}
