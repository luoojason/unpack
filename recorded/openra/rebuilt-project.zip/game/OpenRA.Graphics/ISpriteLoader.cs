using System.IO;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public interface ISpriteLoader
{
	bool TryParseSprite(Stream s, string filename, out ISpriteFrame[] frames, out TypeDictionary metadata);
}
