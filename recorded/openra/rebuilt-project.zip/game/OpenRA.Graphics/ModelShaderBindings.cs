namespace OpenRA.Graphics;

public sealed class ModelShaderBindings : ShaderBindings
{
	public override ShaderVertexAttribute[] Attributes { get; } = new ShaderVertexAttribute[3]
	{
		new ShaderVertexAttribute("aVertexPosition", ShaderVertexAttributeType.Float, 3, 0),
		new ShaderVertexAttribute("aVertexTexCoord", ShaderVertexAttributeType.Float, 4, 12),
		new ShaderVertexAttribute("aVertexTexMetadata", ShaderVertexAttributeType.Float, 2, 28)
	};

	public ModelShaderBindings()
		: base("model")
	{
	}
}
