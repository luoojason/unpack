using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.FileSystem;
using OpenRA.Traits;

namespace OpenRA.Graphics;

public sealed class CursorProvider
{
	public readonly IReadOnlyDictionary<string, CursorSequence> Cursors;

	public readonly IReadOnlyDictionary<string, ImmutablePalette> Palettes;

	public CursorProvider(ModData modData)
	{
		IReadOnlyFileSystem fileSystem = modData.DefaultFileSystem;
		HashSet<string> stringPool = new HashSet<string>();
		List<MiniYamlNode> nodes = MiniYaml.Merge(modData.Manifest.Cursors.Select((string s) => MiniYaml.FromStream(fileSystem.Open(s), s, discardCommentsAndWhitespace: true, stringPool)));
		MiniYaml value = new MiniYaml(null, nodes).NodeWithKey("Cursors").Value;
		Dictionary<string, IProvidesCursorPaletteInfo> pals = new Dictionary<string, IProvidesCursorPaletteInfo>();
		foreach (IProvidesCursorPaletteInfo item in modData.DefaultRules.Actors[SystemActors.World].TraitInfos<IProvidesCursorPaletteInfo>())
		{
			if (item.Palette != null)
			{
				pals[item.Palette] = item;
			}
		}
		Palettes = (from n in value.Nodes
			select n.Value.Value into p
			where p != null
			select p).Distinct().ToDictionary((string p) => p, (string p) => pals[p].ReadPalette(modData.DefaultFileSystem));
		FrameCache cache = new FrameCache(fileSystem, modData.SpriteLoaders);
		Dictionary<string, CursorSequence> dictionary = new Dictionary<string, CursorSequence>();
		foreach (MiniYamlNode node in value.Nodes)
		{
			foreach (MiniYamlNode node2 in node.Value.Nodes)
			{
				dictionary.Add(node2.Key, new CursorSequence(cache, node2.Key, node.Key, node.Value.Value, node2.Value));
			}
		}
		Cursors = dictionary;
	}

	public bool HasCursorSequence(string cursor)
	{
		return Cursors.ContainsKey(cursor);
	}

	public CursorSequence GetCursorSequence(string cursor)
	{
		try
		{
			return Cursors[cursor];
		}
		catch (KeyNotFoundException)
		{
			throw new InvalidOperationException("Cursor does not have a sequence `" + cursor + "`");
		}
	}
}
