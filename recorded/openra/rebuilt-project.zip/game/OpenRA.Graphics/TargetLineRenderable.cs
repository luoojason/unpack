using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class TargetLineRenderable : IRenderable, IFinalizedRenderable
{
	private readonly IEnumerable<WPos> waypoints;

	private readonly Color color;

	private readonly int width;

	private readonly int markerSize;

	public WPos Pos => waypoints.First();

	public int ZOffset => 0;

	public bool IsDecoration => true;

	public TargetLineRenderable(IEnumerable<WPos> waypoints, Color color, int width, int markerSize)
	{
		this.waypoints = waypoints;
		this.color = color;
		this.width = width;
		this.markerSize = markerSize;
	}

	public IRenderable WithZOffset(int newOffset)
	{
		return this;
	}

	public IRenderable OffsetBy(in WVec vec)
	{
		WVec offset = vec;
		return new TargetLineRenderable(waypoints.Select((WPos w) => w + offset), color, width, markerSize);
	}

	public IRenderable AsDecoration()
	{
		return this;
	}

	public IFinalizedRenderable PrepareRender(WorldRenderer wr)
	{
		return this;
	}

	public void Render(WorldRenderer wr)
	{
		if (!waypoints.Any())
		{
			return;
		}
		int2 int3 = wr.Viewport.WorldToViewPx(wr.Screen3DPosition(waypoints.First()));
		int2 int4 = int3;
		foreach (int2 item in from pos in waypoints.Skip(1)
			select wr.Viewport.WorldToViewPx(wr.Screen3DPosition(pos)))
		{
			Game.Renderer.RgbaColorRenderer.DrawLine((float3)int4, (float3)item, width, color);
			DrawTargetMarker(color, item, markerSize);
			int4 = item;
		}
		DrawTargetMarker(color, int3);
	}

	public static void DrawTargetMarker(Color color, int2 screenPos, int size = 1)
	{
		int2 int3 = new int2(size, size);
		int2 int4 = screenPos - int3;
		int2 int5 = screenPos + int3;
		Game.Renderer.RgbaColorRenderer.FillRect((float3)int4, (float3)int5, color);
	}

	public void RenderDebugGeometry(WorldRenderer wr)
	{
	}

	public Rectangle ScreenBounds(WorldRenderer wr)
	{
		return Rectangle.Empty;
	}

	IRenderable IRenderable.OffsetBy(in WVec offset)
	{
		return OffsetBy(in offset);
	}
}
