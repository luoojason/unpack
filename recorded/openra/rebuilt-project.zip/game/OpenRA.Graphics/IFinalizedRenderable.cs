using OpenRA.Primitives;

namespace OpenRA.Graphics;

public interface IFinalizedRenderable
{
	void Render(WorldRenderer wr);

	void RenderDebugGeometry(WorldRenderer wr);

	Rectangle ScreenBounds(WorldRenderer wr);
}
