using System;

namespace OpenRA.Graphics;

public class RgbaSpriteRenderer
{
	private readonly SpriteRenderer parent;

	public RgbaSpriteRenderer(SpriteRenderer parent)
	{
		this.parent = parent;
	}

	public void DrawSprite(Sprite s, in float3 location, in float3 scale, float rotation = 0f)
	{
		if (s.Channel != TextureChannel.RGBA)
		{
			throw new InvalidOperationException("DrawRGBASprite requires a RGBA sprite.");
		}
		parent.DrawSprite(s, 0, in location, in scale, rotation);
	}

	public void DrawSprite(Sprite s, in float3 location, float scale = 1f, float rotation = 0f)
	{
		if (s.Channel != TextureChannel.RGBA)
		{
			throw new InvalidOperationException("DrawRGBASprite requires a RGBA sprite.");
		}
		parent.DrawSprite(s, 0, in location, scale, rotation);
	}

	public void DrawSprite(Sprite s, in float3 location, float scale, in float3 tint, float alpha, float rotation = 0f)
	{
		if (s.Channel != TextureChannel.RGBA)
		{
			throw new InvalidOperationException("DrawRGBASprite requires a RGBA sprite.");
		}
		parent.DrawSprite(s, 0, in location, scale, in tint, alpha, rotation);
	}

	public void DrawSprite(Sprite s, in float3 a, in float3 b, in float3 c, in float3 d, in float3 tint, float alpha)
	{
		if (s.Channel != TextureChannel.RGBA)
		{
			throw new InvalidOperationException("DrawRGBASprite requires a RGBA sprite.");
		}
		parent.DrawSprite(s, 0, in a, in b, in c, in d, in tint, alpha);
	}
}
