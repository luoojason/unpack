using OpenRA.Primitives;

namespace OpenRA.Graphics;

public interface IModel
{
	uint Frames { get; }

	uint Sections { get; }

	float[] Size { get; }

	Rectangle AggregateBounds { get; }

	float[] TransformationMatrix(uint section, uint frame);

	float[] Bounds(uint frame);

	ModelRenderData RenderData(uint section);
}
