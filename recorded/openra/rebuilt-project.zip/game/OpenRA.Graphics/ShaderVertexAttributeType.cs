namespace OpenRA.Graphics;

public enum ShaderVertexAttributeType
{
	Float = 5126,
	Int = 5124,
	UInt = 5125
}
