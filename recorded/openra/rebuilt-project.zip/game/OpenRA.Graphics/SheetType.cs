namespace OpenRA.Graphics;

public enum SheetType
{
	Indexed = 1,
	BGRA = 4
}
