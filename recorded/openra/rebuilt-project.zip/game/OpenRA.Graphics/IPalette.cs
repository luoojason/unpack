using System;

namespace OpenRA.Graphics;

public interface IPalette
{
	uint this[int index] { get; }

	void CopyToArray(Array destination, int destinationOffset);
}
