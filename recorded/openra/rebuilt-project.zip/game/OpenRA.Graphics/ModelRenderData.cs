namespace OpenRA.Graphics;

public readonly struct ModelRenderData(int start, int count, Sheet sheet)
{
	public readonly int Start = start;

	public readonly int Count = count;

	public readonly Sheet Sheet = sheet;
}
