using System;

namespace OpenRA.Graphics;

[Flags]
public enum TintModifiers
{
	None = 0,
	IgnoreWorldTint = 1,
	ReplaceColor = 2
}
