using System;
using System.IO;
using OpenRA.FileFormats;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public sealed class Sheet : IDisposable
{
	private bool dirty;

	private bool releaseBufferOnCommit;

	private ITexture texture;

	private byte[] data;

	public readonly Size Size;

	public readonly SheetType Type;

	public bool Buffered
	{
		get
		{
			if (data == null)
			{
				return texture == null;
			}
			return true;
		}
	}

	public byte[] GetData()
	{
		CreateBuffer();
		return data;
	}

	public Sheet(SheetType type, Size size)
	{
		Type = type;
		Size = size;
	}

	public Sheet(SheetType type, ITexture texture)
	{
		Type = type;
		this.texture = texture;
		Size = texture.Size;
	}

	public Sheet(SheetType type, Stream stream)
	{
		Png png = new Png(stream);
		Size = new Size(png.Width, png.Height);
		data = new byte[4 * Size.Width * Size.Height];
		Util.FastCopyIntoSprite(new Sprite(this, new Rectangle(0, 0, png.Width, png.Height), TextureChannel.Red), png);
		Type = type;
		ReleaseBuffer();
	}

	public ITexture GetTexture()
	{
		if (texture == null)
		{
			texture = Game.Renderer.Context.CreateTexture();
			dirty = true;
		}
		if (data != null && dirty)
		{
			texture.SetData(data, Size.Width, Size.Height);
			dirty = false;
			if (releaseBufferOnCommit)
			{
				data = null;
			}
		}
		return texture;
	}

	public Png AsPng()
	{
		if (Type == SheetType.Indexed)
		{
			throw new InvalidOperationException("AsPng() cannot be called on Indexed sheets.");
		}
		return new Png(GetData(), SpriteFrameType.Bgra32, Size.Width, Size.Height);
	}

	public Png AsPng(TextureChannel channel, IPalette pal)
	{
		if (Type != SheetType.Indexed)
		{
			throw new InvalidOperationException("AsPng(TextureChannel, IPalette) can only be called on Indexed sheets.");
		}
		byte[] array = GetData();
		byte[] array2 = new byte[Size.Width * Size.Height];
		int num = 4 * Size.Width;
		for (int i = 0; i < Size.Height; i++)
		{
			for (int j = 0; j < Size.Width; j++)
			{
				array2[i * Size.Width + j] = array[i * num + (int)channel + 4 * j];
			}
		}
		Color[] array3 = new Color[256];
		for (int k = 0; k < 256; k++)
		{
			array3[k] = pal.GetColor(k);
		}
		return new Png(array2, SpriteFrameType.Indexed8, Size.Width, Size.Height, array3);
	}

	public void CreateBuffer()
	{
		if (data == null)
		{
			if (texture == null)
			{
				data = new byte[4 * Size.Width * Size.Height];
			}
			else
			{
				data = texture.GetData();
			}
			releaseBufferOnCommit = false;
		}
	}

	public void CommitBufferedData()
	{
		if (!Buffered)
		{
			throw new InvalidOperationException("This sheet is unbuffered. You cannot call CommitBufferedData on an unbuffered sheet. If you need to completely replace the texture data you should set data into the texture directly. If you need to make only small changes to the texture data consider creating a buffered sheet instead.");
		}
		dirty = true;
	}

	public void ReleaseBuffer()
	{
		if (Buffered)
		{
			dirty = true;
			releaseBufferOnCommit = true;
			if (Game.Renderer != null)
			{
				GetTexture();
			}
		}
	}

	public bool ReleaseBufferAndTryTransferTo(Sheet destination)
	{
		if (Size != destination.Size)
		{
			throw new ArgumentException("Destination sheet does not have the same size", "destination");
		}
		byte[] array = data;
		ReleaseBuffer();
		if (Game.Renderer == null)
		{
			return false;
		}
		if (array != null && destination.data == null && destination.texture == null)
		{
			Array.Clear(array, 0, array.Length);
			destination.data = array;
			return true;
		}
		return false;
	}

	public void Dispose()
	{
		texture?.Dispose();
	}
}
