namespace OpenRA.Graphics;

public readonly struct RenderPostProcessPassTexturedVertex(float x, float y, float s, float t)
{
	public readonly float X = x;

	public readonly float Y = y;

	public readonly float S = s;

	public readonly float T = t;
}
