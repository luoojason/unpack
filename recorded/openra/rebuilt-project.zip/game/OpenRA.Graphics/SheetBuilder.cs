using System;
using System.Collections.Generic;
using OpenRA.FileFormats;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public sealed class SheetBuilder : IDisposable
{
	public readonly SheetType Type;

	private readonly List<Sheet> sheets = new List<Sheet>();

	private readonly Func<Sheet> allocateSheet;

	private readonly int margin;

	private int rowHeight;

	private int2 p;

	public Sheet Current { get; private set; }

	public TextureChannel CurrentChannel { get; private set; }

	public IEnumerable<Sheet> AllSheets => sheets;

	public static Sheet AllocateSheet(SheetType type, int sheetSize)
	{
		return new Sheet(type, new Size(sheetSize, sheetSize));
	}

	public static SheetType FrameTypeToSheetType(SpriteFrameType t)
	{
		switch (t)
		{
		case SpriteFrameType.Indexed8:
			return SheetType.Indexed;
		case SpriteFrameType.Bgra32:
		case SpriteFrameType.Bgr24:
		case SpriteFrameType.Rgba32:
		case SpriteFrameType.Rgb24:
			return SheetType.BGRA;
		default:
			throw new NotImplementedException($"Unknown SpriteFrameType {t}");
		}
	}

	public SheetBuilder(SheetType t)
		: this(t, Game.Settings.Graphics.SheetSize)
	{
	}

	public SheetBuilder(SheetType t, int sheetSize, int margin = 1)
		: this(t, () => AllocateSheet(t, sheetSize), margin)
	{
	}

	public SheetBuilder(SheetType t, Func<Sheet> allocateSheet, int margin = 1)
	{
		CurrentChannel = ((t != SheetType.Indexed) ? TextureChannel.RGBA : TextureChannel.Red);
		Type = t;
		Current = allocateSheet();
		sheets.Add(Current);
		this.allocateSheet = allocateSheet;
		this.margin = margin;
	}

	public Sprite Add(ISpriteFrame frame, bool premultiplied = false)
	{
		return Add(frame.Data, frame.Type, frame.Size, 0f, (float3)frame.Offset, premultiplied);
	}

	public Sprite Add(byte[] src, SpriteFrameType type, Size size, bool premultiplied = false)
	{
		return Add(src, type, size, 0f, in float3.Zero, premultiplied);
	}

	public Sprite Add(byte[] src, SpriteFrameType type, Size size, float zRamp, in float3 spriteOffset, bool premultiplied = false)
	{
		if (size.Width == 0 || size.Height == 0)
		{
			return new Sprite(Current, Rectangle.Empty, 0f, in spriteOffset, CurrentChannel);
		}
		Sprite sprite = Allocate(size, zRamp, in spriteOffset);
		Util.FastCopyIntoChannel(sprite, src, type, premultiplied);
		Current.CommitBufferedData();
		return sprite;
	}

	public Sprite Add(Png src, float scale = 1f)
	{
		Sprite sprite = Allocate(new Size(src.Width, src.Height), scale);
		Util.FastCopyIntoSprite(sprite, src);
		Current.CommitBufferedData();
		return sprite;
	}

	private TextureChannel? NextChannel(TextureChannel t)
	{
		int num = (int)t + (int)Type;
		if (num > 3)
		{
			return null;
		}
		return (TextureChannel)num;
	}

	public Sprite Allocate(Size imageSize, float scale = 1f)
	{
		return Allocate(imageSize, 0f, in float3.Zero, scale);
	}

	public Sprite Allocate(Size imageSize, float zRamp, in float3 spriteOffset, float scale = 1f)
	{
		if (imageSize.Width + p.X + margin > Current.Size.Width)
		{
			p = new int2(0, p.Y + rowHeight + margin);
			rowHeight = imageSize.Height;
		}
		if (imageSize.Height > rowHeight)
		{
			rowHeight = imageSize.Height;
		}
		if (p.Y + imageSize.Height + margin > Current.Size.Height)
		{
			TextureChannel? textureChannel = NextChannel(CurrentChannel);
			if (!textureChannel.HasValue)
			{
				Sheet current = Current;
				Current = allocateSheet();
				current.ReleaseBufferAndTryTransferTo(Current);
				sheets.Add(Current);
				CurrentChannel = ((Type != SheetType.Indexed) ? TextureChannel.RGBA : TextureChannel.Red);
			}
			else
			{
				CurrentChannel = textureChannel.Value;
			}
			rowHeight = imageSize.Height;
			p = int2.Zero;
		}
		Sprite result = new Sprite(Current, new Rectangle(p.X + margin, p.Y + margin, imageSize.Width, imageSize.Height), zRamp, in spriteOffset, CurrentChannel, BlendMode.Alpha, scale);
		p += new int2(imageSize.Width + margin, 0);
		return result;
	}

	public void Dispose()
	{
		foreach (Sheet sheet in sheets)
		{
			sheet.Dispose();
		}
		sheets.Clear();
	}
}
