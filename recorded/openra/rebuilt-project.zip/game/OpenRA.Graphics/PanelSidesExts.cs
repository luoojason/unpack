namespace OpenRA.Graphics;

public static class PanelSidesExts
{
	public static bool HasSide(this PanelSides self, PanelSides m)
	{
		return (self & m) == m;
	}
}
