namespace OpenRA.Graphics;

public interface IModelCache
{
	IVertexBuffer<ModelVertex> VertexBuffer { get; }

	IModel GetModel(string model);

	IModel GetModelSequence(string model, string sequence);

	bool HasModelSequence(string model, string sequence);
}
