using System;
using System.Collections.Generic;
using System.IO;

namespace OpenRA.Graphics;

public class ImmutablePalette : IPalette
{
	private readonly uint[] colors = new uint[256];

	public uint this[int index] => colors[index];

	public void CopyToArray(Array destination, int destinationOffset)
	{
		Buffer.BlockCopy(colors, 0, destination, destinationOffset * 4, 1024);
	}

	public ImmutablePalette(string filename, int[] remapTransparent, int[] remap)
	{
		using FileStream s = File.OpenRead(filename);
		LoadFromStream(s, remapTransparent, remap);
	}

	public ImmutablePalette(Stream s, int[] remapTransparent, int[] remapShadow)
	{
		LoadFromStream(s, remapTransparent, remapShadow);
	}

	private void LoadFromStream(Stream s, int[] remapTransparent, int[] remapShadow)
	{
		using (BinaryReader binaryReader = new BinaryReader(s))
		{
			for (int i = 0; i < 256; i++)
			{
				byte b = (byte)(binaryReader.ReadByte() << 2);
				byte b2 = (byte)(binaryReader.ReadByte() << 2);
				byte b3 = (byte)(binaryReader.ReadByte() << 2);
				b |= (byte)(b >> 6);
				b2 |= (byte)(b2 >> 6);
				b3 |= (byte)(b3 >> 6);
				colors[i] = (uint)(-16777216 | (b << 16) | (b2 << 8) | b3);
			}
		}
		foreach (int num in remapTransparent)
		{
			colors[num] = 0u;
		}
		foreach (int num2 in remapShadow)
		{
			colors[num2] = 2348810240u;
		}
	}

	public ImmutablePalette(IPalette p, IPaletteRemap r)
		: this(p)
	{
		for (int i = 0; i < 256; i++)
		{
			colors[i] = r.GetRemappedColor(this.GetColor(i), i).ToArgb();
		}
	}

	public ImmutablePalette(IPalette p)
	{
		for (int i = 0; i < 256; i++)
		{
			colors[i] = p[i];
		}
	}

	public ImmutablePalette(IEnumerable<uint> sourceColors)
	{
		int num = 0;
		foreach (uint sourceColor in sourceColors)
		{
			colors[num++] = sourceColor;
		}
	}
}
