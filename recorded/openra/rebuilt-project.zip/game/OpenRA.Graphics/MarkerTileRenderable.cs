using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class MarkerTileRenderable : IRenderable, IFinalizedRenderable
{
	private readonly CPos pos;

	private readonly Color color;

	public WPos Pos => WPos.Zero;

	public int ZOffset => 0;

	public bool IsDecoration => true;

	public MarkerTileRenderable(CPos pos, Color color)
	{
		this.pos = pos;
		this.color = color;
	}

	public IRenderable WithZOffset(int newOffset)
	{
		return this;
	}

	public IRenderable OffsetBy(in WVec vec)
	{
		return new MarkerTileRenderable(pos, color);
	}

	public IRenderable AsDecoration()
	{
		return this;
	}

	public IFinalizedRenderable PrepareRender(WorldRenderer wr)
	{
		return this;
	}

	public void Render(WorldRenderer wr)
	{
		Map map = wr.World.Map;
		CellRamp cellRamp = map.Grid.Ramps[map.Ramp[pos]];
		WPos wpos = map.CenterOfCell(pos) - new WVec(0, 0, cellRamp.CenterHeightOffset);
		List<int2> list = cellRamp.Corners.Select((WVec corner) => wr.Viewport.WorldToViewPx(wr.Screen3DPosition(wpos + corner))).ToList();
		Game.Renderer.RgbaColorRenderer.FillRect((float3)list[0], (float3)list[1], (float3)list[2], (float3)list[3], color);
	}

	public void RenderDebugGeometry(WorldRenderer wr)
	{
	}

	public Rectangle ScreenBounds(WorldRenderer wr)
	{
		return Rectangle.Empty;
	}

	IRenderable IRenderable.OffsetBy(in WVec offset)
	{
		return OffsetBy(in offset);
	}
}
