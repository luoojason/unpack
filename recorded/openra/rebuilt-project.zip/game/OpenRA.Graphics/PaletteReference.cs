namespace OpenRA.Graphics;

public sealed class PaletteReference
{
	private readonly HardwarePalette hardwarePalette;

	public readonly string Name;

	public IPalette Palette { get; internal set; }

	public int TextureIndex { get; }

	public bool HasColorShift => hardwarePalette.HasColorShift(Name);

	public PaletteReference(string name, int index, IPalette palette, HardwarePalette hardwarePalette)
	{
		Name = name;
		Palette = palette;
		TextureIndex = index;
		this.hardwarePalette = hardwarePalette;
	}
}
