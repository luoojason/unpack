using OpenRA.Primitives;

namespace OpenRA.Graphics;

public interface ISpriteSequence
{
	string Name { get; }

	int Length { get; }

	int Facings { get; }

	int Tick { get; }

	int ZOffset { get; }

	int ShadowZOffset { get; }

	Rectangle Bounds { get; }

	bool IgnoreWorldTint { get; }

	float Scale { get; }

	void ResolveSprites(SpriteCache cache);

	Sprite GetSprite(int frame);

	Sprite GetSprite(int frame, WAngle facing);

	(Sprite Sprite, WAngle Rotation) GetSpriteWithRotation(int frame, WAngle facing);

	Sprite GetShadow(int frame, WAngle facing);

	float GetAlpha(int frame);
}
