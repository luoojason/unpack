namespace OpenRA.Graphics;

public enum TextureChannel : byte
{
	Red,
	Green,
	Blue,
	Alpha,
	RGBA
}
