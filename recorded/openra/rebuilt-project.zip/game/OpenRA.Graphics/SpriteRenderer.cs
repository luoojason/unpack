using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class SpriteRenderer : Renderer.IBatchRenderer
{
	public const int SheetCount = 8;

	private static readonly string[] SheetIndexToTextureName = Exts.MakeArray(8, (int i) => $"Texture{i}");

	private static readonly int UintSize = Marshal.SizeOf<uint>();

	private readonly Renderer renderer;

	private readonly IShader shader;

	private Vertex[] vertices;

	private readonly Sheet[] sheets = new Sheet[8];

	private BlendMode currentBlend = BlendMode.Alpha;

	private int vertexCount;

	private int sheetCount;

	public SpriteRenderer(Renderer renderer, IShader shader)
	{
		this.renderer = renderer;
		this.shader = shader;
		vertices = renderer.Context.CreateVertices<Vertex>(renderer.TempVertexBufferSize);
	}

	public void Flush()
	{
		if (vertexCount > 0)
		{
			for (int i = 0; i < sheetCount; i++)
			{
				shader.SetTexture(SheetIndexToTextureName[i], sheets[i].GetTexture());
				sheets[i] = null;
			}
			renderer.Context.SetBlendMode(currentBlend);
			shader.PrepareRender();
			renderer.DrawQuadBatch(ref vertices, shader, vertexCount);
			renderer.Context.SetBlendMode(BlendMode.None);
			vertexCount = 0;
			sheetCount = 0;
		}
	}

	private int2 SetRenderStateForSprite(Sprite s)
	{
		renderer.CurrentBatchRenderer = this;
		if (s.BlendMode != currentBlend || vertexCount + 4 > renderer.TempVertexBufferSize)
		{
			Flush();
		}
		currentBlend = s.BlendMode;
		Sheet sheet = s.Sheet;
		int i;
		for (i = 0; i < sheetCount && sheets[i] != sheet; i++)
		{
		}
		int j = 0;
		SpriteWithSecondaryData spriteWithSecondaryData = s as SpriteWithSecondaryData;
		if (spriteWithSecondaryData != null)
		{
			Sheet secondarySheet;
			for (secondarySheet = spriteWithSecondaryData.SecondarySheet; j < sheetCount && sheets[j] != secondarySheet; j++)
			{
			}
			if (j == i && secondarySheet != sheet)
			{
				j++;
			}
		}
		if (Math.Max(i, j) >= sheets.Length)
		{
			Flush();
			i = 0;
			j = ((spriteWithSecondaryData != null && spriteWithSecondaryData.SecondarySheet != sheet) ? 1 : 0);
		}
		if (i >= sheetCount)
		{
			sheets[i] = sheet;
			sheetCount++;
		}
		if (j >= sheetCount && spriteWithSecondaryData != null)
		{
			sheets[j] = spriteWithSecondaryData.SecondarySheet;
			sheetCount++;
		}
		return new int2(i, j);
	}

	private static int ResolveTextureIndex(Sprite s, PaletteReference pal)
	{
		if (pal == null)
		{
			return 0;
		}
		if (s.Channel == TextureChannel.RGBA && !pal.HasColorShift)
		{
			return 0;
		}
		return pal.TextureIndex;
	}

	internal void DrawSprite(Sprite s, int paletteTextureIndex, in float3 location, in float3 scale, float rotation = 0f)
	{
		int2 samplers = SetRenderStateForSprite(s);
		Util.FastCreateQuad(vertices, location + scale * s.Offset, s, samplers, paletteTextureIndex, vertexCount, scale * s.Size, in float3.Ones, 1f, rotation);
		vertexCount += 4;
	}

	internal void DrawSprite(Sprite s, int paletteTextureIndex, in float3 location, float scale, float rotation = 0f)
	{
		int2 samplers = SetRenderStateForSprite(s);
		Util.FastCreateQuad(vertices, location + scale * s.Offset, s, samplers, paletteTextureIndex, vertexCount, scale * s.Size, in float3.Ones, 1f, rotation);
		vertexCount += 4;
	}

	public void DrawSprite(Sprite s, PaletteReference pal, in float3 location, float scale = 1f, float rotation = 0f)
	{
		DrawSprite(s, ResolveTextureIndex(s, pal), in location, scale, rotation);
	}

	internal void DrawSprite(Sprite s, int paletteTextureIndex, in float3 location, float scale, in float3 tint, float alpha, float rotation = 0f)
	{
		int2 samplers = SetRenderStateForSprite(s);
		Util.FastCreateQuad(vertices, location + scale * s.Offset, s, samplers, paletteTextureIndex, vertexCount, scale * s.Size, in tint, alpha, rotation);
		vertexCount += 4;
	}

	public void DrawSprite(Sprite s, PaletteReference pal, in float3 location, float scale, in float3 tint, float alpha, float rotation = 0f)
	{
		DrawSprite(s, ResolveTextureIndex(s, pal), in location, scale, in tint, alpha, rotation);
	}

	internal void DrawSprite(Sprite s, int paletteTextureIndex, in float3 a, in float3 b, in float3 c, in float3 d, in float3 tint, float alpha)
	{
		int2 samplers = SetRenderStateForSprite(s);
		Util.FastCreateQuad(vertices, in a, in b, in c, in d, s, samplers, paletteTextureIndex, in tint, alpha, vertexCount);
		vertexCount += 4;
	}

	public void DrawVertexBuffer(IVertexBuffer<Vertex> buffer, IIndexBuffer indices, int start, int length, IEnumerable<Sheet> sheets, BlendMode blendMode)
	{
		int num = 0;
		foreach (Sheet sheet in sheets)
		{
			if (num >= 8)
			{
				ThrowSheetOverflow("sheets");
			}
			if (sheet != null)
			{
				shader.SetTexture(SheetIndexToTextureName[num++], sheet.GetTexture());
			}
		}
		renderer.Context.SetBlendMode(blendMode);
		shader.PrepareRender();
		renderer.DrawQuadBatch(buffer, indices, shader, length, UintSize * start);
		renderer.Context.SetBlendMode(BlendMode.None);
	}

	private static void ThrowSheetOverflow(string paramName)
	{
		throw new ArgumentException($"SpriteRenderer only supports {8} simultaneous textures", paramName);
	}

	internal void DrawRGBAQuad(Vertex[] v, BlendMode blendMode)
	{
		renderer.CurrentBatchRenderer = this;
		if (currentBlend != blendMode || vertexCount + 4 > renderer.TempVertexBufferSize)
		{
			Flush();
		}
		currentBlend = blendMode;
		Array.Copy(v, 0, vertices, vertexCount, v.Length);
		vertexCount += 4;
	}

	public void SetPalette(HardwarePalette palette)
	{
		shader.SetTexture("Palette", palette.Texture);
		shader.SetTexture("ColorShifts", palette.ColorShifts);
		shader.SetVec("PaletteRows", palette.Height);
	}

	public void SetViewportParams(Size sheetSize, int downscale, float depthMargin, int2 scroll)
	{
		float x = 2f / (float)(downscale * sheetSize.Width);
		float y = 2f / (float)(downscale * sheetSize.Height);
		float num = ((depthMargin != 0f) ? (2f / ((float)downscale * ((float)sheetSize.Height + depthMargin))) : 0f);
		shader.SetVec("DepthTextureScale", 128f * num);
		shader.SetVec("Scroll", scroll.X, scroll.Y, (depthMargin != 0f) ? scroll.Y : 0);
		shader.SetVec("p1", x, y, 0f - num);
		shader.SetVec("p2", -1f, -1f, (depthMargin != 0f) ? 1 : 0);
	}

	public void SetDepthPreview(bool enabled, float contrast, float offset)
	{
		shader.SetBool("EnableDepthPreview", enabled);
		shader.SetVec("DepthPreviewParams", contrast, offset);
	}

	public void EnablePixelArtScaling(bool enabled)
	{
		shader.SetBool("EnablePixelArtScaling", enabled);
	}
}
