using System.IO;
using System.Linq;

namespace OpenRA.Graphics;

public abstract class ShaderBindings : IShaderBindings
{
	public string VertexShaderName { get; }

	public string VertexShaderCode { get; }

	public string FragmentShaderName { get; }

	public string FragmentShaderCode { get; }

	public int Stride { get; }

	public abstract ShaderVertexAttribute[] Attributes { get; }

	protected ShaderBindings(string name)
		: this(name, name)
	{
	}

	protected ShaderBindings(string vertexName, string fragmentName)
	{
		Stride = Attributes.Sum((ShaderVertexAttribute a) => a.Components * 4);
		VertexShaderName = vertexName;
		VertexShaderCode = GetShaderCode(VertexShaderName + ".vert");
		FragmentShaderName = fragmentName;
		FragmentShaderCode = GetShaderCode(FragmentShaderName + ".frag");
	}

	public static string GetShaderCode(string filename)
	{
		string path = Path.Combine(Platform.EngineDir, "glsl", filename);
		return File.ReadAllText(path);
	}
}
