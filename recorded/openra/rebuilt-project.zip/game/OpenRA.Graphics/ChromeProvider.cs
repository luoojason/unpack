using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.FileSystem;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public static class ChromeProvider
{
	public class Collection
	{
		public readonly string Image;

		public readonly string Image2x;

		public readonly string Image3x;

		public readonly int[] PanelRegion;

		public readonly PanelSides PanelSides = PanelSides.All;

		public readonly Dictionary<string, Rectangle> Regions = new Dictionary<string, Rectangle>();
	}

	private static Dictionary<string, Collection> collections;

	private static Dictionary<string, (Sheet Sheet, int Density)> cachedSheets;

	private static Dictionary<string, Dictionary<string, Sprite>> cachedSprites;

	private static Dictionary<string, Sprite[]> cachedPanelSprites;

	private static Dictionary<Collection, (Sheet Sheet, int)> cachedCollectionSheets;

	private static IReadOnlyFileSystem fileSystem;

	private static float dpiScale = 1f;

	public static IReadOnlyDictionary<string, Collection> Collections => collections;

	public static void Initialize(ModData modData)
	{
		Deinitialize();
		if (Game.Renderer != null)
		{
			dpiScale = Game.Renderer.WindowScale;
		}
		fileSystem = modData.DefaultFileSystem;
		collections = new Dictionary<string, Collection>();
		cachedSheets = new Dictionary<string, (Sheet, int)>();
		cachedSprites = new Dictionary<string, Dictionary<string, Sprite>>();
		cachedPanelSprites = new Dictionary<string, Sprite[]>();
		cachedCollectionSheets = new Dictionary<Collection, (Sheet, int)>();
		HashSet<string> stringPool = new HashSet<string>();
		List<MiniYamlNode> list = MiniYaml.Merge(modData.Manifest.Chrome.Select((string s) => MiniYaml.FromStream(fileSystem.Open(s), s, discardCommentsAndWhitespace: true, stringPool)));
		foreach (MiniYamlNode item in list)
		{
			if (!item.Key.StartsWith('^'))
			{
				LoadCollection(item.Key, item.Value);
			}
		}
	}

	public static void Deinitialize()
	{
		if (cachedSheets != null)
		{
			foreach (var value in cachedSheets.Values)
			{
				value.Sheet.Dispose();
			}
		}
		collections = null;
		cachedSheets = null;
		cachedSprites = null;
		cachedPanelSprites = null;
		cachedCollectionSheets = null;
	}

	private static void LoadCollection(string name, MiniYaml yaml)
	{
		Game.ModData.LoadScreen?.Display();
		collections.Add(name, FieldLoader.Load<Collection>(yaml));
	}

	private static (Sheet Sheet, int Density) SheetForCollection(Collection c)
	{
		if (!cachedCollectionSheets.TryGetValue(c, out (Sheet, int) value))
		{
			string text = c.Image;
			int item = 1;
			if (dpiScale > 2f && !string.IsNullOrEmpty(c.Image3x))
			{
				text = c.Image3x;
				item = 3;
			}
			else if (dpiScale > 1f && !string.IsNullOrEmpty(c.Image2x))
			{
				text = c.Image2x;
				item = 2;
			}
			if (!cachedSheets.TryGetValue(text, out value))
			{
				Sheet sheet;
				using (Stream stream = fileSystem.Open(text))
				{
					sheet = new Sheet(SheetType.BGRA, stream);
				}
				sheet.GetTexture().ScaleFilter = TextureScaleFilter.Linear;
				value = (sheet, item);
				cachedSheets.Add(text, value);
			}
			cachedCollectionSheets.Add(c, value);
		}
		return value;
	}

	public static Sprite GetImage(string collectionName, string imageName)
	{
		Sprite sprite = TryGetImage(collectionName, imageName);
		if (sprite == null)
		{
			throw new ArgumentException($"Sprite `{collectionName}/{imageName}` was not found.");
		}
		return sprite;
	}

	public static Sprite TryGetImage(string collectionName, string imageName)
	{
		if (string.IsNullOrEmpty(collectionName))
		{
			return null;
		}
		if (cachedSprites.TryGetValue(collectionName, out var value) && value.TryGetValue(imageName, out var value2))
		{
			return value2;
		}
		if (!collections.TryGetValue(collectionName, out var value3))
		{
			return null;
		}
		if (!value3.Regions.TryGetValue(imageName, out var value4))
		{
			return null;
		}
		(Sheet, int) tuple = SheetForCollection(value3);
		if (value == null)
		{
			value = new Dictionary<string, Sprite>();
			cachedSprites.Add(collectionName, value);
		}
		Sprite sprite = new Sprite(tuple.Item1, tuple.Item2 * value4, TextureChannel.RGBA, 1f / (float)tuple.Item2);
		value.Add(imageName, sprite);
		return sprite;
	}

	public static Sprite[] GetPanelImages(string collectionName)
	{
		Sprite[] array = TryGetPanelImages(collectionName);
		if (array == null)
		{
			throw new ArgumentException("Panel `" + collectionName + "` was not found.");
		}
		return array;
	}

	public static Sprite[] TryGetPanelImages(string collectionName)
	{
		if (string.IsNullOrEmpty(collectionName))
		{
			return null;
		}
		if (cachedPanelSprites.TryGetValue(collectionName, out var value))
		{
			return value;
		}
		if (!collections.TryGetValue(collectionName, out var value2))
		{
			return null;
		}
		Sprite[] array;
		if (value2.PanelRegion != null)
		{
			if (value2.PanelRegion.Length != 8)
			{
				Log.Write("debug", "Collection '" + collectionName + "' does not define a valid PanelRegion");
				return null;
			}
			(Sheet Sheet, int Density) sheetDensity = SheetForCollection(value2);
			int[] panelRegion = value2.PanelRegion;
			PanelSides ps = value2.PanelSides;
			(PanelSides, Rectangle)[] source = new (PanelSides, Rectangle)[9]
			{
				(PanelSides.Left | PanelSides.Top, new Rectangle(panelRegion[0], panelRegion[1], panelRegion[2], panelRegion[3])),
				(PanelSides.Top, new Rectangle(panelRegion[0] + panelRegion[2], panelRegion[1], panelRegion[4], panelRegion[3])),
				(PanelSides.Top | PanelSides.Right, new Rectangle(panelRegion[0] + panelRegion[2] + panelRegion[4], panelRegion[1], panelRegion[6], panelRegion[3])),
				(PanelSides.Left, new Rectangle(panelRegion[0], panelRegion[1] + panelRegion[3], panelRegion[2], panelRegion[5])),
				(PanelSides.Center, new Rectangle(panelRegion[0] + panelRegion[2], panelRegion[1] + panelRegion[3], panelRegion[4], panelRegion[5])),
				(PanelSides.Right, new Rectangle(panelRegion[0] + panelRegion[2] + panelRegion[4], panelRegion[1] + panelRegion[3], panelRegion[6], panelRegion[5])),
				(PanelSides.Left | PanelSides.Bottom, new Rectangle(panelRegion[0], panelRegion[1] + panelRegion[3] + panelRegion[5], panelRegion[2], panelRegion[7])),
				(PanelSides.Bottom, new Rectangle(panelRegion[0] + panelRegion[2], panelRegion[1] + panelRegion[3] + panelRegion[5], panelRegion[4], panelRegion[7])),
				(PanelSides.Right | PanelSides.Bottom, new Rectangle(panelRegion[0] + panelRegion[2] + panelRegion[4], panelRegion[1] + panelRegion[3] + panelRegion[5], panelRegion[6], panelRegion[7]))
			};
			array = source.Select(((PanelSides PanelSides, Rectangle Bounds) x) => (!ps.HasSide(x.PanelSides)) ? null : new Sprite(sheetDensity.Sheet, sheetDensity.Density * x.Bounds, TextureChannel.RGBA, 1f / (float)sheetDensity.Density)).ToArray();
		}
		else
		{
			if (value2.Regions.Count == 0)
			{
				return Array.Empty<Sprite>();
			}
			array = new Sprite[9]
			{
				TryGetImage(collectionName, "corner-tl"),
				TryGetImage(collectionName, "border-t"),
				TryGetImage(collectionName, "corner-tr"),
				TryGetImage(collectionName, "border-l"),
				TryGetImage(collectionName, "background"),
				TryGetImage(collectionName, "border-r"),
				TryGetImage(collectionName, "corner-bl"),
				TryGetImage(collectionName, "border-b"),
				TryGetImage(collectionName, "corner-br")
			};
		}
		cachedPanelSprites.Add(collectionName, array);
		return array;
	}

	public static Size GetMinimumPanelSize(string collectionName)
	{
		if (string.IsNullOrEmpty(collectionName))
		{
			return new Size(0, 0);
		}
		if (!collections.TryGetValue(collectionName, out var value))
		{
			Log.Write("debug", "Could not find collection '" + collectionName + "'");
			return new Size(0, 0);
		}
		if (value.PanelRegion == null || value.PanelRegion.Length != 8)
		{
			Log.Write("debug", "Collection '" + collectionName + "' does not define a valid PanelRegion");
			return new Size(0, 0);
		}
		int[] panelRegion = value.PanelRegion;
		return new Size(panelRegion[2] + panelRegion[6], panelRegion[3] + panelRegion[7]);
	}

	public static void SetDPIScale(float scale)
	{
		if (dpiScale != scale)
		{
			dpiScale = scale;
			cachedSprites.Clear();
			cachedPanelSprites.Clear();
			cachedCollectionSheets.Clear();
		}
	}
}
