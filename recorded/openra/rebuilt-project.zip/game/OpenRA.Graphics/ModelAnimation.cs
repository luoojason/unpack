using System;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public readonly struct ModelAnimation(IModel model, Func<WVec> offset, Func<WRot> rotation, Func<bool> disable, Func<uint> frame, bool showshadow)
{
	public readonly IModel Model = model;

	public readonly Func<WVec> OffsetFunc = offset;

	public readonly Func<WRot> RotationFunc = rotation;

	public readonly Func<bool> DisableFunc = disable;

	public readonly Func<uint> FrameFunc = frame;

	public readonly bool ShowShadow = showshadow;

	public bool IsVisible
	{
		get
		{
			if (DisableFunc != null)
			{
				return !DisableFunc();
			}
			return true;
		}
	}

	public Rectangle ScreenBounds(WPos pos, WorldRenderer wr, float scale)
	{
		Rectangle aggregateBounds = Model.AggregateBounds;
		WVec vec = ((OffsetFunc != null) ? OffsetFunc() : WVec.Zero);
		int2 int3 = wr.ScreenPxPosition(pos) + wr.ScreenPxOffset(in vec);
		return Rectangle.FromLTRB(int3.X + (int)((float)aggregateBounds.Left * scale), int3.Y + (int)((float)aggregateBounds.Top * scale), int3.X + (int)((float)aggregateBounds.Right * scale), int3.Y + (int)((float)aggregateBounds.Bottom * scale));
	}
}
