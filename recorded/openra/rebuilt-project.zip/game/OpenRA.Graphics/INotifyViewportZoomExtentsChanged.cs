namespace OpenRA.Graphics;

public interface INotifyViewportZoomExtentsChanged
{
	void ViewportZoomExtentsChanged(float minZoom, float maxZoom);
}
