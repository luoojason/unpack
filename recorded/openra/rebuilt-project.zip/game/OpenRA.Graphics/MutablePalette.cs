using System;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class MutablePalette : IPalette
{
	private readonly uint[] colors = new uint[256];

	public uint this[int index]
	{
		get
		{
			return colors[index];
		}
		set
		{
			colors[index] = value;
		}
	}

	public void CopyToArray(Array destination, int destinationOffset)
	{
		Buffer.BlockCopy(colors, 0, destination, destinationOffset * 4, 1024);
	}

	public MutablePalette(IPalette p)
	{
		SetFromPalette(p);
	}

	public void SetColor(int index, Color color)
	{
		colors[index] = color.ToArgb();
	}

	public void SetFromPalette(IPalette p)
	{
		p.CopyToArray(colors, 0);
	}

	public void ApplyRemap(IPaletteRemap r)
	{
		for (int i = 0; i < 256; i++)
		{
			colors[i] = r.GetRemappedColor(this.GetColor(i), i).ToArgb();
		}
	}
}
