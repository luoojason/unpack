using System;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class PlayerColorRemap : IPaletteRemap
{
	private readonly int[] remapIndices;

	private readonly float hue;

	private readonly float saturation;

	private readonly float value;

	public PlayerColorRemap(int[] remapIndices, Color color)
	{
		this.remapIndices = remapIndices;
		var (r, g, b) = color.ToLinear();
		(hue, saturation, value) = Color.RgbToHsv(r, g, b);
	}

	public Color GetRemappedColor(Color original, int index)
	{
		if (!Enumerable.Contains(remapIndices, index))
		{
			return original;
		}
		(float R, float G, float B) tuple = original.ToLinear();
		float item = tuple.R;
		float item2 = tuple.G;
		float item3 = tuple.B;
		float num = Math.Max(Math.Max(item, item2), item3);
		(item, item2, item3) = Color.HsvToRgb(hue, saturation, num * value);
		return Color.FromLinear(original.A, item, item2, item3);
	}
}
