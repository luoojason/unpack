using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class RgbaColorRenderer
{
	private static readonly float3 Offset = new float3(0.5f, 0.5f, 0f);

	private readonly SpriteRenderer parent;

	private readonly Vertex[] vertices = new Vertex[4];

	public RgbaColorRenderer(SpriteRenderer parent)
	{
		this.parent = parent;
	}

	public void DrawLine(in float3 start, in float3 end, float width, Color startColor, Color endColor, BlendMode blendMode = BlendMode.Alpha)
	{
		float3 float4 = (end - start) / (end - start).XY.Length;
		float3 b = width / 2f * new float3(0f - float4.Y, float4.X, float4.Z);
		startColor = Util.PremultiplyAlpha(startColor);
		float s = (float)(int)startColor.R / 255f;
		float t = (float)(int)startColor.G / 255f;
		float u = (float)(int)startColor.B / 255f;
		float v = (float)(int)startColor.A / 255f;
		endColor = Util.PremultiplyAlpha(endColor);
		float s2 = (float)(int)endColor.R / 255f;
		float t2 = (float)(int)endColor.G / 255f;
		float u2 = (float)(int)endColor.B / 255f;
		float v2 = (float)(int)endColor.A / 255f;
		vertices[0] = new Vertex(start - b + Offset, s, t, u, v, 0u);
		vertices[1] = new Vertex(start + b + Offset, s, t, u, v, 0u);
		vertices[2] = new Vertex(end + b + Offset, s2, t2, u2, v2, 0u);
		vertices[3] = new Vertex(end - b + Offset, s2, t2, u2, v2, 0u);
		parent.DrawRGBAQuad(vertices, blendMode);
	}

	public void DrawLine(in float3 start, in float3 end, float width, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		float3 float4 = (end - start) / (end - start).XY.Length;
		float2 float5 = width / 2f * new float2(0f - float4.Y, float4.X);
		color = Util.PremultiplyAlpha(color);
		float s = (float)(int)color.R / 255f;
		float t = (float)(int)color.G / 255f;
		float u = (float)(int)color.B / 255f;
		float v = (float)(int)color.A / 255f;
		vertices[0] = new Vertex(start - (float3)float5 + Offset, s, t, u, v, 0u);
		vertices[1] = new Vertex(start + (float3)float5 + Offset, s, t, u, v, 0u);
		vertices[2] = new Vertex(end + (float3)float5 + Offset, s, t, u, v, 0u);
		vertices[3] = new Vertex(end - (float3)float5 + Offset, s, t, u, v, 0u);
		parent.DrawRGBAQuad(vertices, blendMode);
	}

	private static float3 IntersectionOf(in float3 a, in float3 da, in float3 b, in float3 db)
	{
		float num = a.X * (a.Y + da.Y) - a.Y * (a.X + da.X);
		float num2 = b.X * (b.Y + db.Y) - b.Y * (b.X + db.X);
		float num3 = da.X * num2 - db.X * num;
		float num4 = da.Y * num2 - db.Y * num;
		float num5 = da.X * db.Y - da.Y * db.X;
		return new float3(num3 / num5, num4 / num5, 0.5f * (a.Z + b.Z));
	}

	private void DrawDisconnectedLine(IEnumerable<float3> points, float width, Color color, BlendMode blendMode)
	{
		using IEnumerator<float3> enumerator = points.GetEnumerator();
		if (enumerator.MoveNext())
		{
			float3 start = enumerator.Current;
			while (enumerator.MoveNext())
			{
				float3 end = enumerator.Current;
				DrawLine(in start, in end, width, color, blendMode);
				start = end;
			}
		}
	}

	private void DrawConnectedLine(float3[] points, float width, Color color, bool closed, BlendMode blendMode)
	{
		if (points.Length < 2)
		{
			return;
		}
		if (points.Length == 2)
		{
			DrawLine(in points[0], in points[1], width, color, blendMode);
			return;
		}
		color = Util.PremultiplyAlpha(color);
		float s = (float)(int)color.R / 255f;
		float t = (float)(int)color.G / 255f;
		float u = (float)(int)color.B / 255f;
		float v = (float)(int)color.A / 255f;
		float3 b = points[0];
		float3 a = points[1];
		float3 db = (a - b) / (a - b).XY.Length;
		float3 b2 = width / 2f * new float3(0f - db.Y, db.X, db.Z);
		float3 a2 = b - b2;
		float3 a3 = b + b2;
		if (closed)
		{
			float3 b3 = points[^1];
			float3 da = (b - b3) / (b - b3).XY.Length;
			float3 b4 = width / 2f * new float3(0f - da.Y, da.X, da.Z);
			a2 = IntersectionOf(b - b4, in da, b - b2, in db);
			a3 = IntersectionOf(b + b4, in da, b + b2, in db);
		}
		int num = (closed ? points.Length : (points.Length - 1));
		for (int i = 0; i < num; i++)
		{
			float3 a4 = points[(i + 2) % points.Length];
			float3 db2 = (a4 - a) / (a4 - a).XY.Length;
			float3 b5 = width / 2f * new float3(0f - db2.Y, db2.X, db2.Z);
			float3 a5 = ((closed || i < num - 1) ? IntersectionOf(a + b2, in db, a + b5, in db2) : (a + b2));
			float3 a6 = ((closed || i < num - 1) ? IntersectionOf(a - b2, in db, a - b5, in db2) : (a - b2));
			vertices[0] = new Vertex(a2 + Offset, s, t, u, v, 0u);
			vertices[1] = new Vertex(a3 + Offset, s, t, u, v, 0u);
			vertices[2] = new Vertex(a5 + Offset, s, t, u, v, 0u);
			vertices[3] = new Vertex(a6 + Offset, s, t, u, v, 0u);
			parent.DrawRGBAQuad(vertices, blendMode);
			a = a4;
			db = db2;
			b2 = b5;
			a2 = a6;
			a3 = a5;
		}
	}

	public void DrawLine(IEnumerable<float3> points, float width, Color color, bool connectSegments = false, BlendMode blendMode = BlendMode.Alpha)
	{
		if (!connectSegments)
		{
			DrawDisconnectedLine(points, width, color, blendMode);
		}
		else
		{
			DrawConnectedLine((points as float3[]) ?? points.ToArray(), width, color, closed: false, blendMode);
		}
	}

	public void DrawPolygon(float3[] vertices, float width, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		DrawConnectedLine(vertices, width, color, closed: true, blendMode);
	}

	public void DrawPolygon(float2[] vertices, float width, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		DrawConnectedLine(vertices.Select((float2 v) => new float3(v, 0f)).ToArray(), width, color, closed: true, blendMode);
	}

	public void DrawRect(in float3 tl, in float3 br, float width, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		float3 float4 = new float3(br.X, tl.Y, tl.Z);
		float3 float5 = new float3(tl.X, br.Y, br.Z);
		DrawPolygon(new float3[4] { tl, float4, br, float5 }, width, color, blendMode);
	}

	public void FillRect(in float3 tl, in float3 br, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		FillRect(in tl, new float3(br.X, tl.Y, tl.Z), in br, new float3(tl.X, br.Y, br.Z), color, blendMode);
	}

	public void FillRect(in float3 a, in float3 b, in float3 c, in float3 d, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		color = Util.PremultiplyAlpha(color);
		float s = (float)(int)color.R / 255f;
		float t = (float)(int)color.G / 255f;
		float u = (float)(int)color.B / 255f;
		float v = (float)(int)color.A / 255f;
		vertices[0] = new Vertex(a + Offset, s, t, u, v, 0u);
		vertices[1] = new Vertex(b + Offset, s, t, u, v, 0u);
		vertices[2] = new Vertex(c + Offset, s, t, u, v, 0u);
		vertices[3] = new Vertex(d + Offset, s, t, u, v, 0u);
		parent.DrawRGBAQuad(vertices, blendMode);
	}

	public void FillRect(in float3 a, in float3 b, in float3 c, in float3 d, Color topLeftColor, Color topRightColor, Color bottomRightColor, Color bottomLeftColor, BlendMode blendMode = BlendMode.Alpha)
	{
		vertices[0] = VertexWithColor(a + Offset, topLeftColor);
		vertices[1] = VertexWithColor(b + Offset, topRightColor);
		vertices[2] = VertexWithColor(c + Offset, bottomRightColor);
		vertices[3] = VertexWithColor(d + Offset, bottomLeftColor);
		parent.DrawRGBAQuad(vertices, blendMode);
	}

	private static Vertex VertexWithColor(in float3 xyz, Color color)
	{
		color = Util.PremultiplyAlpha(color);
		float s = (float)(int)color.R / 255f;
		float t = (float)(int)color.G / 255f;
		float u = (float)(int)color.B / 255f;
		float v = (float)(int)color.A / 255f;
		return new Vertex(in xyz, s, t, u, v, 0u);
	}

	public void FillEllipse(in float3 tl, in float3 br, Color color, BlendMode blendMode = BlendMode.Alpha)
	{
		float num = (br.X - tl.X) / 2f;
		float num2 = (br.Y - tl.Y) / 2f;
		float num3 = (br.X + tl.X) / 2f;
		float num4 = (br.Y + tl.Y) / 2f;
		for (float num5 = tl.Y; num5 <= br.Y; num5++)
		{
			float z = float2.Lerp(tl.Z, br.Z, (num5 - tl.Y) / (br.Y - tl.Y));
			float num6 = num * (float)Math.Sqrt(1f - (num5 - num4) * (num5 - num4) / num2 / num2);
			DrawLine(new float3(num3 - num6, num5, z), new float3(num3 + num6, num5, z), 1f, color, blendMode);
		}
	}
}
