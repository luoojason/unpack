using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using OpenRA.Traits;

namespace OpenRA.Graphics;

public sealed class TerrainSpriteLayer : IDisposable
{
	private sealed class IndexBufferRc : IDisposable
	{
		public IIndexBuffer Buffer;

		private int count;

		public IndexBufferRc(World world)
		{
			Buffer = Game.Renderer.Context.CreateIndexBuffer(Util.CreateQuadIndices(world.Map.MapSize.X * world.Map.MapSize.Y));
		}

		public void AddRef()
		{
			count++;
		}

		public void Dispose()
		{
			count--;
			if (count == 0)
			{
				Buffer.Dispose();
			}
		}
	}

	private static readonly ConditionalWeakTable<World, IndexBufferRc> IndexBuffers = new ConditionalWeakTable<World, IndexBufferRc>();

	private readonly IndexBufferRc indexBufferWrapper;

	public readonly BlendMode BlendMode;

	private readonly Sheet[] sheets;

	private readonly Sprite emptySprite;

	private readonly IVertexBuffer<Vertex> vertexBuffer;

	private readonly Vertex[] vertices;

	private readonly bool[] ignoreTint;

	private readonly HashSet<int> dirtyRows = new HashSet<int>();

	private readonly int indexRowStride;

	private readonly int vertexRowStride;

	private readonly bool restrictToBounds;

	private readonly WorldRenderer worldRenderer;

	private readonly Map map;

	private readonly PaletteReference[] palettes;

	public TerrainSpriteLayer(World world, WorldRenderer wr, Sprite emptySprite, BlendMode blendMode, bool restrictToBounds)
	{
		worldRenderer = wr;
		this.restrictToBounds = restrictToBounds;
		this.emptySprite = emptySprite;
		sheets = new Sheet[8];
		BlendMode = blendMode;
		map = world.Map;
		vertexRowStride = 4 * map.MapSize.X;
		vertices = new Vertex[vertexRowStride * map.MapSize.Y];
		vertexBuffer = Game.Renderer.Context.CreateVertexBuffer<Vertex>(vertices.Length);
		indexRowStride = 6 * map.MapSize.X;
		lock (IndexBuffers)
		{
			indexBufferWrapper = IndexBuffers.GetValue(world, (World world2) => new IndexBufferRc(world2));
			indexBufferWrapper.AddRef();
		}
		palettes = new PaletteReference[map.MapSize.X * map.MapSize.Y];
		wr.PaletteInvalidated += UpdatePaletteIndices;
		if (wr.TerrainLighting != null)
		{
			ignoreTint = new bool[vertexRowStride * map.MapSize.Y];
			wr.TerrainLighting.CellChanged += UpdateTint;
		}
	}

	private void UpdatePaletteIndices()
	{
		for (int i = 0; i < vertices.Length; i++)
		{
			Vertex vertex = vertices[i];
			int num = palettes[i / 4]?.TextureIndex ?? 0;
			uint c = (uint)((num & 0xFFFF) << 16) | (vertex.C & 0xFFFF);
			vertices[i] = new Vertex(vertex.X, vertex.Y, vertex.Z, vertex.S, vertex.T, vertex.U, vertex.V, c, vertex.R, vertex.G, vertex.B, vertex.A);
		}
		for (int j = 0; j < map.MapSize.Y; j++)
		{
			dirtyRows.Add(j);
		}
	}

	public void Clear(CPos cell)
	{
		Update(cell, null, null, 1f, 1f, ignoreTint: true);
	}

	public void Update(CPos cell, ISpriteSequence sequence, PaletteReference palette, int frame)
	{
		Update(cell, sequence.GetSprite(frame), palette, sequence.Scale, sequence.GetAlpha(frame), sequence.IgnoreWorldTint);
	}

	public void Update(CPos cell, Sprite sprite, PaletteReference palette, float scale = 1f, float alpha = 1f, bool ignoreTint = false)
	{
		float3 pos = float3.Zero;
		if (sprite != null)
		{
			WPos pos2 = map.CenterOfCell(cell) - new WVec(0, 0, map.Grid.Ramps[map.Ramp[cell]].CenterHeightOffset);
			pos = worldRenderer.Screen3DPosition(pos2) + scale * (sprite.Offset - 0.5f * sprite.Size);
		}
		Update(cell.ToMPos(map.Grid.Type), sprite, palette, in pos, scale, alpha, ignoreTint);
	}

	private void UpdateTint(MPos uv)
	{
		int num = vertexRowStride * uv.V + 4 * uv.U;
		if (ignoreTint[num])
		{
			for (int i = 0; i < 4; i++)
			{
				Vertex vertex = vertices[num + i];
				vertices[num + i] = new Vertex(vertex.X, vertex.Y, vertex.Z, vertex.S, vertex.T, vertex.U, vertex.V, vertex.C, vertex.A * float3.Ones, vertex.A);
			}
			return;
		}
		ITerrainLighting terrainLighting = worldRenderer.TerrainLighting;
		WPos a = map.CenterOfCell(uv.ToCPos(map));
		int num2 = map.Grid.TileScale / 2;
		float3[] array = new float3[4]
		{
			terrainLighting.TintAt(a + ILSpyHelper_AsRefReadOnly(new WVec(-num2, -num2, 0))),
			terrainLighting.TintAt(a + ILSpyHelper_AsRefReadOnly(new WVec(num2, -num2, 0))),
			terrainLighting.TintAt(a + ILSpyHelper_AsRefReadOnly(new WVec(num2, num2, 0))),
			terrainLighting.TintAt(a + ILSpyHelper_AsRefReadOnly(new WVec(-num2, num2, 0)))
		};
		for (int j = 0; j < 4; j++)
		{
			Vertex vertex2 = vertices[num + j];
			vertices[num + j] = new Vertex(vertex2.X, vertex2.Y, vertex2.Z, vertex2.S, vertex2.T, vertex2.U, vertex2.V, vertex2.C, vertex2.A * array[j], vertex2.A);
		}
		dirtyRows.Add(uv.V);
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	private int GetOrAddSheetIndex(Sheet sheet)
	{
		if (sheet == null)
		{
			return 0;
		}
		for (int i = 0; i < sheets.Length; i++)
		{
			if (sheets[i] == sheet)
			{
				return i;
			}
			if (sheets[i] == null)
			{
				sheets[i] = sheet;
				return i;
			}
		}
		throw new InvalidDataException("Sheet overflow");
	}

	public void Update(MPos uv, Sprite sprite, PaletteReference palette, in float3 pos, float scale, float alpha, bool ignoreTint)
	{
		int2 samplers;
		if (sprite != null)
		{
			if (sprite.BlendMode != BlendMode)
			{
				throw new InvalidDataException("Attempted to add sprite with a different blend mode");
			}
			samplers = new int2(GetOrAddSheetIndex(sprite.Sheet), GetOrAddSheetIndex((sprite as SpriteWithSecondaryData)?.SecondarySheet));
			if (sprite.Channel == TextureChannel.RGBA && (palette == null || !palette.HasColorShift))
			{
				palette = null;
			}
		}
		else
		{
			sprite = emptySprite;
			samplers = int2.Zero;
		}
		if (map.Tiles.Contains(uv))
		{
			int num = vertexRowStride * uv.V + 4 * uv.U;
			Util.FastCreateQuad(vertices, in pos, sprite, samplers, palette?.TextureIndex ?? 0, num, scale * sprite.Size, alpha * float3.Ones, alpha);
			palettes[uv.V * map.MapSize.X + uv.U] = palette;
			if (worldRenderer.TerrainLighting != null)
			{
				this.ignoreTint[num] = ignoreTint;
				UpdateTint(uv);
			}
			dirtyRows.Add(uv.V);
		}
	}

	public void Draw(Viewport viewport)
	{
		ProjectedCellRegion projectedCellRegion = (restrictToBounds ? viewport.VisibleCellsInsideBounds : viewport.AllVisibleCells);
		int num = projectedCellRegion.CandidateMapCoords.TopLeft.V.Clamp(0, map.MapSize.Y);
		int num2 = (projectedCellRegion.CandidateMapCoords.BottomRight.V + 1).Clamp(num, map.MapSize.Y);
		Game.Renderer.Flush();
		for (int i = num; i <= num2; i++)
		{
			if (dirtyRows.Remove(i))
			{
				int num3 = vertexRowStride * i;
				vertexBuffer.SetData(vertices, num3, num3, vertexRowStride);
			}
		}
		Game.Renderer.WorldSpriteRenderer.DrawVertexBuffer(vertexBuffer, indexBufferWrapper.Buffer, indexRowStride * num, indexRowStride * (num2 - num), sheets, BlendMode);
		Game.Renderer.Flush();
	}

	public void Dispose()
	{
		worldRenderer.PaletteInvalidated -= UpdatePaletteIndices;
		if (worldRenderer.TerrainLighting != null)
		{
			worldRenderer.TerrainLighting.CellChanged -= UpdateTint;
		}
		vertexBuffer.Dispose();
		lock (IndexBuffers)
		{
			indexBufferWrapper.Dispose();
		}
	}
}
