using System;
using System.Linq;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA.Graphics;

public class Animation
{
	private readonly Map map;

	private readonly SequenceSet sequences;

	private readonly Func<WAngle> facingFunc;

	private readonly Func<bool> paused;

	private int frame;

	private bool backwards;

	private bool tickAlways;

	private int timeUntilNextFrame;

	private Action tickFunc;

	public ISpriteSequence CurrentSequence { get; private set; }

	public string Name { get; private set; }

	public bool IsDecoration { get; set; }

	public int CurrentFrame
	{
		get
		{
			if (!backwards)
			{
				return frame;
			}
			return CurrentSequence.Length - frame - 1;
		}
	}

	public Sprite Image => CurrentSequence.GetSprite(CurrentFrame, facingFunc());

	public Animation(World world, string name)
		: this(world, name, () => WAngle.Zero)
	{
	}

	public Animation(World world, string name, Func<WAngle> facingFunc)
		: this(world, name, facingFunc, null)
	{
	}

	public Animation(World world, string name, Func<bool> paused)
		: this(world, name, () => WAngle.Zero, paused)
	{
	}

	public Animation(World world, string name, Func<WAngle> facingFunc, Func<bool> paused)
	{
		map = world.Map;
		sequences = world.Map.Sequences;
		Name = name.ToLowerInvariant();
		this.facingFunc = facingFunc;
		this.paused = paused;
	}

	public IRenderable[] Render(WPos pos, in WVec offset, int zOffset, PaletteReference palette)
	{
		TintModifiers tintModifiers = (CurrentSequence.IgnoreWorldTint ? TintModifiers.IgnoreWorldTint : TintModifiers.None);
		float alpha = CurrentSequence.GetAlpha(CurrentFrame);
		(Sprite Sprite, WAngle Rotation) spriteWithRotation = CurrentSequence.GetSpriteWithRotation(CurrentFrame, facingFunc());
		Sprite item = spriteWithRotation.Sprite;
		WAngle item2 = spriteWithRotation.Rotation;
		SpriteRenderable spriteRenderable = new SpriteRenderable(item, pos, offset, CurrentSequence.ZOffset + zOffset, palette, CurrentSequence.Scale, alpha, float3.Ones, tintModifiers, IsDecoration, item2);
		Sprite shadow = CurrentSequence.GetShadow(CurrentFrame, facingFunc());
		if (shadow != null)
		{
			int length = map.DistanceAboveTerrain(pos).Length;
			SpriteRenderable spriteRenderable2 = new SpriteRenderable(shadow, pos, offset - new WVec(0, 0, length), CurrentSequence.ShadowZOffset + zOffset + length, palette, CurrentSequence.Scale, 1f, float3.Ones, tintModifiers, isDecoration: true, item2);
			return new IRenderable[2] { spriteRenderable2, spriteRenderable };
		}
		return new IRenderable[1] { spriteRenderable };
	}

	public IRenderable[] RenderUI(WorldRenderer wr, int2 pos, in WVec offset, int zOffset, PaletteReference palette, float scale = 1f, float rotation = 0f)
	{
		scale *= CurrentSequence.Scale;
		int2 int3 = (scale * wr.ScreenVectorComponents(in offset)).XY.ToInt2();
		int2 screenPos = pos + int3 - new int2((int)(scale * Image.Size.X / 2f), (int)(scale * Image.Size.Y / 2f));
		float alpha = CurrentSequence.GetAlpha(CurrentFrame);
		UISpriteRenderable uISpriteRenderable = new UISpriteRenderable(Image, WPos.Zero + offset, screenPos, CurrentSequence.ZOffset + zOffset, palette, scale, alpha, rotation);
		Sprite shadow = CurrentSequence.GetShadow(CurrentFrame, facingFunc());
		if (shadow != null)
		{
			int2 screenPos2 = pos - new int2((int)(scale * shadow.Size.X / 2f), (int)(scale * shadow.Size.Y / 2f));
			UISpriteRenderable uISpriteRenderable2 = new UISpriteRenderable(shadow, WPos.Zero + offset, screenPos2, CurrentSequence.ShadowZOffset + zOffset, palette, scale, 1f, rotation);
			return new IRenderable[2] { uISpriteRenderable2, uISpriteRenderable };
		}
		return new IRenderable[1] { uISpriteRenderable };
	}

	public Rectangle ScreenBounds(WorldRenderer wr, WPos pos, in WVec offset)
	{
		float scale = CurrentSequence.Scale;
		int2 int3 = wr.ScreenPxPosition(pos) + wr.ScreenPxOffset(in offset);
		Rectangle bounds = CurrentSequence.Bounds;
		return Rectangle.FromLTRB(int3.X + (int)((float)bounds.Left * scale), int3.Y + (int)((float)bounds.Top * scale), int3.X + (int)((float)bounds.Right * scale), int3.Y + (int)((float)bounds.Bottom * scale));
	}

	public IRenderable[] Render(WPos pos, PaletteReference palette)
	{
		return Render(pos, in WVec.Zero, 0, palette);
	}

	public void Play(string sequenceName)
	{
		PlayThen(sequenceName, null);
	}

	private int CurrentSequenceTickOrDefault()
	{
		return CurrentSequence?.Tick ?? 40;
	}

	private void PlaySequence(string sequenceName)
	{
		CurrentSequence = GetSequence(sequenceName);
		timeUntilNextFrame = CurrentSequenceTickOrDefault();
	}

	public void PlayRepeating(string sequenceName)
	{
		backwards = false;
		tickAlways = false;
		PlaySequence(sequenceName);
		frame = 0;
		tickFunc = () =>
		{
			frame++;
			if (frame >= CurrentSequence.Length)
			{
				frame = 0;
			}
		};
	}

	public bool ReplaceAnim(string sequenceName)
	{
		if (!HasSequence(sequenceName))
		{
			return false;
		}
		CurrentSequence = GetSequence(sequenceName);
		timeUntilNextFrame = Math.Min(CurrentSequenceTickOrDefault(), timeUntilNextFrame);
		frame %= CurrentSequence.Length;
		return true;
	}

	public void PlayThen(string sequenceName, Action after)
	{
		backwards = false;
		tickAlways = false;
		PlaySequence(sequenceName);
		frame = 0;
		tickFunc = () =>
		{
			frame++;
			if (frame >= CurrentSequence.Length)
			{
				frame = CurrentSequence.Length - 1;
				tickFunc = null;
				after?.Invoke();
			}
		};
	}

	public void PlayBackwardsThen(string sequenceName, Action after)
	{
		PlayThen(sequenceName, after);
		backwards = true;
	}

	public void PlayFetchIndex(string sequenceName, Func<int> func)
	{
		backwards = false;
		tickAlways = true;
		PlaySequence(sequenceName);
		frame = func();
		tickFunc = () =>
		{
			frame = func();
		};
	}

	public void PlayFetchDirection(string sequenceName, Func<int> direction)
	{
		tickAlways = false;
		PlaySequence(sequenceName);
		frame = 0;
		tickFunc = () =>
		{
			int num = direction();
			if (num > 0 && ++frame >= CurrentSequence.Length)
			{
				frame = 0;
			}
			if (num < 0 && --frame < 0)
			{
				frame = CurrentSequence.Length - 1;
			}
		};
	}

	public void Tick()
	{
		if (paused == null || !paused())
		{
			Tick(40);
		}
	}

	public void Tick(int t)
	{
		if (tickAlways)
		{
			tickFunc?.Invoke();
			return;
		}
		timeUntilNextFrame -= t;
		while (timeUntilNextFrame <= 0)
		{
			tickFunc?.Invoke();
			timeUntilNextFrame += CurrentSequenceTickOrDefault();
		}
	}

	public void ChangeImage(string newImage, string newAnimIfMissing)
	{
		newImage = newImage.ToLowerInvariant();
		if (Name != newImage)
		{
			Name = newImage;
			if (!ReplaceAnim(CurrentSequence.Name))
			{
				ReplaceAnim(newAnimIfMissing);
			}
		}
	}

	public bool HasSequence(string seq)
	{
		return sequences.HasSequence(Name, seq);
	}

	public ISpriteSequence GetSequence(string sequenceName)
	{
		return sequences.GetSequence(Name, sequenceName);
	}

	public string GetRandomExistingSequence(string[] sequences, MersenneTwister random)
	{
		return sequences.Where((string s) => HasSequence(s)).RandomOrDefault(random);
	}
}
