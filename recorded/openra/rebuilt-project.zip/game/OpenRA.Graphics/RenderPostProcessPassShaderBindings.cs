namespace OpenRA.Graphics;

public sealed class RenderPostProcessPassShaderBindings(string name) : ShaderBindings("postprocess", "postprocess_" + name)
{
	public override ShaderVertexAttribute[] Attributes { get; } = new ShaderVertexAttribute[1]
	{
		new ShaderVertexAttribute("aVertexPosition", ShaderVertexAttributeType.Float, 2, 0)
	};
}
