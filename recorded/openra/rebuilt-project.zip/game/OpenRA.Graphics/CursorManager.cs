using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public sealed class CursorManager : IDisposable
{
	private sealed class Cursor
	{
		public string Name;

		public int2 PaddedSize;

		public Rectangle Bounds;

		public int Length;

		public Sprite[] Sprites;

		public IHardwareCursor[] Cursors;
	}

	private readonly Dictionary<string, Cursor> cursors = new Dictionary<string, Cursor>();

	private readonly SheetBuilder sheetBuilder;

	private readonly GraphicSettings graphicSettings;

	private Cursor cursor;

	private bool isLocked;

	private int2 lockedPosition;

	private readonly bool hardwareCursorsDisabled;

	private bool hardwareCursorsDoubled;

	private int frame;

	private int ticks;

	public CursorManager(CursorProvider cursorProvider, int cursorSheetSize)
	{
		hardwareCursorsDisabled = Game.Settings.Graphics.DisableHardwareCursors;
		graphicSettings = Game.Settings.Graphics;
		sheetBuilder = new SheetBuilder(SheetType.BGRA, cursorSheetSize);
		foreach (KeyValuePair<string, CursorSequence> item in cursorProvider.Cursors.OrderBy((KeyValuePair<string, CursorSequence> kvp) => kvp.Value.Frames.Max((ISpriteFrame f) => f.Size.Height)))
		{
			ISpriteFrame[] frames = item.Value.Frames;
			ImmutablePalette palette = ((!string.IsNullOrEmpty(item.Value.Palette)) ? cursorProvider.Palettes[item.Value.Palette] : null);
			Cursor cursor = new Cursor
			{
				Name = item.Key,
				Bounds = Rectangle.FromLTRB(0, 0, 1, 1),
				Length = 0,
				Sprites = new Sprite[frames.Length],
				Cursors = new IHardwareCursor[frames.Length]
			};
			ISpriteFrame[] array = frames;
			foreach (ISpriteFrame spriteFrame in array)
			{
				int2 int3 = spriteFrame.Offset.ToInt2() - item.Value.Hotspot - new int2(spriteFrame.Size) / 2;
				byte[] src = spriteFrame.Data;
				SpriteFrameType spriteFrameType = spriteFrame.Type;
				if (spriteFrameType == SpriteFrameType.Indexed8)
				{
					src = ConvertIndexedToBgra(item.Key, spriteFrame, palette);
					spriteFrameType = SpriteFrameType.Bgra32;
				}
				cursor.Sprites[cursor.Length++] = sheetBuilder.Add(src, spriteFrameType, spriteFrame.Size, 0f, (float3)int3);
				cursor.Bounds = Rectangle.Union(cursor.Bounds, new Rectangle(int3, spriteFrame.Size));
			}
			cursor.PaddedSize = 8 * new int2((cursor.Bounds.Width + 7) / 8, (cursor.Bounds.Height + 7) / 8);
			cursors.Add(item.Key, cursor);
		}
		CreateOrUpdateHardwareCursors();
		Update();
	}

	private void CreateOrUpdateHardwareCursors()
	{
		if (hardwareCursorsDisabled)
		{
			return;
		}
		ClearHardwareCursors();
		foreach (KeyValuePair<string, Cursor> cursor in cursors)
		{
			Cursor value = cursor.Value;
			for (int i = 0; i < value.Sprites.Length; i++)
			{
				value.Cursors[i]?.Dispose();
				int2 int3 = -(value.Bounds.Location - value.Sprites[i].Offset.XY.ToInt2());
				int2 paddingBR = value.PaddedSize - new int2(value.Sprites[i].Bounds.Size) - int3;
				IHardwareCursor hardwareCursor = CreateHardwareCursor(cursor.Key, value.Sprites[i], int3, paddingBR, -value.Bounds.Location);
				if (hardwareCursor != null)
				{
					value.Cursors[i] = hardwareCursor;
					continue;
				}
				Log.Write("debug", "Failed to initialize hardware cursor for " + value.Name + ".");
				Console.WriteLine("Failed to initialize hardware cursor for " + value.Name + ".");
			}
		}
		sheetBuilder.Current.ReleaseBuffer();
		hardwareCursorsDoubled = graphicSettings.CursorDouble;
	}

	public void SetCursor(string cursorName)
	{
		if ((cursorName != null || cursor != null) && (cursor == null || !(cursorName == cursor.Name)))
		{
			if (cursorName == null || !cursors.TryGetValue(cursorName, out cursor))
			{
				cursor = null;
			}
			Update();
		}
	}

	public void Tick()
	{
		if (hardwareCursorsDoubled != graphicSettings.CursorDouble)
		{
			CreateOrUpdateHardwareCursors();
			Update();
		}
		if (cursor != null && cursor.Cursors.Length != 1 && ++ticks > 2)
		{
			ticks -= 2;
			frame++;
			Update();
		}
	}

	private void Update()
	{
		if (this.cursor != null && frame >= this.cursor.Cursors.Length)
		{
			frame %= this.cursor.Cursors.Length;
		}
		Cursor cursor = this.cursor;
		IHardwareCursor hardwareCursor = ((cursor != null) ? cursor.Cursors[frame] : null);
		if (hardwareCursor == null || isLocked)
		{
			Game.Renderer.Window.SetHardwareCursor(null);
		}
		else
		{
			Game.Renderer.Window.SetHardwareCursor(hardwareCursor);
		}
	}

	public void Render(Renderer renderer)
	{
		if (cursor != null && (isLocked || cursor.Cursors[frame % cursor.Length] == null))
		{
			bool cursorDouble = graphicSettings.CursorDouble;
			Sprite s = cursor.Sprites[frame % cursor.Length];
			int num = ((!cursorDouble) ? 1 : 2);
			if (Game.Renderer.NativeWindowScale > 1.5f)
			{
				num *= 2;
			}
			int2 int3 = (isLocked ? lockedPosition : Viewport.LastMousePos);
			renderer.RgbaSpriteRenderer.DrawSprite(s, (float3)int3, (float)num / Game.Renderer.WindowScale);
		}
	}

	public void Lock()
	{
		lockedPosition = Viewport.LastMousePos;
		Game.Renderer.Window.SetRelativeMouseMode(mode: true);
		isLocked = true;
		Update();
	}

	public void Unlock()
	{
		Game.Renderer.Window.SetRelativeMouseMode(mode: false);
		isLocked = false;
		Update();
	}

	public unsafe static byte[] ConvertIndexedToBgra(string name, ISpriteFrame frame, ImmutablePalette palette)
	{
		if (frame.Type != SpriteFrameType.Indexed8)
		{
			throw new ArgumentException("ConvertIndexedToBgra requires input frames to be indexed.", "frame");
		}
		if (palette == null)
		{
			throw new InvalidOperationException("Cursor sequence `" + name + "` attempted to load an indexed sprite but does not define Palette");
		}
		int width = frame.Size.Width;
		int height = frame.Size.Height;
		if (width == 0 || height == 0)
		{
			return Array.Empty<byte>();
		}
		byte[] array = new byte[4 * width * height];
		fixed (byte* ptr = &array[0])
		{
			uint* ptr2 = (uint*)ptr;
			for (int i = 0; i < height; i++)
			{
				for (int j = 0; j < width; j++)
				{
					ptr2[i * width + j] = palette[frame.Data[i * width + j]];
				}
			}
		}
		return array;
	}

	private IHardwareCursor CreateHardwareCursor(string name, Sprite data, int2 paddingTL, int2 paddingBR, int2 hotspot)
	{
		Size size = data.Bounds.Size;
		int width = data.Sheet.Size.Width;
		byte[] data2 = data.Sheet.GetData();
		int num = paddingTL.X + size.Width + paddingBR.X;
		int num2 = paddingTL.Y + size.Height + paddingBR.Y;
		byte[] array = new byte[4 * num * num2];
		for (int i = 0; i < size.Height; i++)
		{
			for (int j = 0; j < size.Width; j++)
			{
				int sourceIndex = 4 * ((i + data.Bounds.Top) * width + data.Bounds.Left + j);
				int destinationIndex = 4 * ((i + paddingTL.Y) * num + j + paddingTL.X);
				Array.Copy(data2, sourceIndex, array, destinationIndex, 4);
			}
		}
		return Game.Renderer.Window.CreateHardwareCursor(name, new Size(num, num2), array, hotspot, graphicSettings.CursorDouble);
	}

	private void ClearHardwareCursors()
	{
		foreach (Cursor value in cursors.Values)
		{
			for (int i = 0; i < value.Cursors.Length; i++)
			{
				if (value.Cursors[i] != null)
				{
					value.Cursors[i].Dispose();
					value.Cursors[i] = null;
				}
			}
		}
	}

	public void Dispose()
	{
		ClearHardwareCursors();
		cursors.Clear();
		sheetBuilder.Dispose();
	}
}
