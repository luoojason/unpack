namespace OpenRA.Graphics;

public interface IPalettedRenderable : IRenderable
{
	PaletteReference Palette { get; }

	IPalettedRenderable WithPalette(PaletteReference newPalette);
}
