namespace OpenRA.Graphics;

public sealed class CombinedShaderBindings : ShaderBindings
{
	public override ShaderVertexAttribute[] Attributes { get; } = new ShaderVertexAttribute[4]
	{
		new ShaderVertexAttribute("aVertexPosition", ShaderVertexAttributeType.Float, 3, 0),
		new ShaderVertexAttribute("aVertexTexCoord", ShaderVertexAttributeType.Float, 4, 12),
		new ShaderVertexAttribute("aVertexAttributes", ShaderVertexAttributeType.UInt, 1, 28),
		new ShaderVertexAttribute("aVertexTint", ShaderVertexAttributeType.Float, 4, 32)
	};

	public CombinedShaderBindings()
		: base("combined")
	{
	}
}
