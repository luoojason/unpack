namespace OpenRA.Graphics;

public readonly struct Vertex
{
	public readonly float X;

	public readonly float Y;

	public readonly float Z;

	public readonly float S;

	public readonly float T;

	public readonly float U;

	public readonly float V;

	public readonly uint C;

	public readonly float R;

	public readonly float G;

	public readonly float B;

	public readonly float A;

	public Vertex(in float3 xyz, float s, float t, float u, float v, uint c)
		: this(xyz.X, xyz.Y, xyz.Z, s, t, u, v, c, in float3.Ones, 1f)
	{
	}

	public Vertex(in float3 xyz, float s, float t, float u, float v, uint c, in float3 tint, float a)
		: this(xyz.X, xyz.Y, xyz.Z, s, t, u, v, c, tint.X, tint.Y, tint.Z, a)
	{
	}

	public Vertex(float x, float y, float z, float s, float t, float u, float v, uint c, in float3 tint, float a)
		: this(x, y, z, s, t, u, v, c, tint.X, tint.Y, tint.Z, a)
	{
	}

	public Vertex(float x, float y, float z, float s, float t, float u, float v, uint c, float r, float g, float b, float a)
	{
		X = x;
		Y = y;
		Z = z;
		S = s;
		T = t;
		U = u;
		V = v;
		C = c;
		R = r;
		G = g;
		B = b;
		A = a;
	}
}
