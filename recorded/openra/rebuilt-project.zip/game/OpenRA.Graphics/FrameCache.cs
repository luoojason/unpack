using OpenRA.FileSystem;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class FrameCache
{
	private readonly Cache<string, ISpriteFrame[]> frames;

	public ISpriteFrame[] this[string filename] => frames[filename];

	public FrameCache(IReadOnlyFileSystem fileSystem, ISpriteLoader[] loaders)
	{
		frames = new Cache<string, ISpriteFrame[]>((string filename) => FrameLoader.GetFrames(fileSystem, filename, loaders, out var _));
	}
}
