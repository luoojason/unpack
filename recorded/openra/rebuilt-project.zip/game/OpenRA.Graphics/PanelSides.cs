using System;

namespace OpenRA.Graphics;

[Flags]
public enum PanelSides
{
	Left = 1,
	Top = 2,
	Right = 4,
	Bottom = 8,
	Center = 0x10,
	Edges = Left | Top | Right | Bottom,
	All = Edges | Center
}
