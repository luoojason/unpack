namespace OpenRA.Graphics;

public readonly struct ShaderVertexAttribute(string name, ShaderVertexAttributeType type, int components, int offset)
{
	public readonly string Name = name;

	public readonly ShaderVertexAttributeType Type = type;

	public readonly int Components = components;

	public readonly int Offset = offset;
}
