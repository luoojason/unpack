using System;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class AnimationWithOffset
{
	public readonly Animation Animation;

	public readonly Func<WVec> OffsetFunc;

	public readonly Func<bool> DisableFunc;

	public readonly Func<WPos, int> ZOffset;

	public AnimationWithOffset(Animation a, Func<WVec> offset, Func<bool> disable)
		: this(a, offset, disable, null)
	{
	}

	public AnimationWithOffset(Animation a, Func<WVec> offset, Func<bool> disable, int zOffset)
		: this(a, offset, disable, (WPos _) => zOffset)
	{
	}

	public AnimationWithOffset(Animation a, Func<WVec> offset, Func<bool> disable, Func<WPos, int> zOffset)
	{
		Animation = a;
		OffsetFunc = offset;
		DisableFunc = disable;
		ZOffset = zOffset;
	}

	public IRenderable[] Render(Actor self, PaletteReference pal)
	{
		WPos a = self.CenterPosition;
		WVec b = OffsetFunc?.Invoke() ?? WVec.Zero;
		int zOffset = ZOffset?.Invoke(a + b) ?? 0;
		return Animation.Render(a, in b, zOffset, pal);
	}

	public Rectangle ScreenBounds(Actor self, WorldRenderer wr)
	{
		WPos centerPosition = self.CenterPosition;
		WVec offset = OffsetFunc?.Invoke() ?? WVec.Zero;
		return Animation.ScreenBounds(wr, centerPosition, in offset);
	}

	public static implicit operator AnimationWithOffset(Animation a)
	{
		return new AnimationWithOffset(a, null, null, null);
	}
}
