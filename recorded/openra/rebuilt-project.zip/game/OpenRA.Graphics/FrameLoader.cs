using System.IO;
using OpenRA.FileSystem;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public static class FrameLoader
{
	public static ISpriteFrame[] GetFrames(IReadOnlyFileSystem fileSystem, string filename, ISpriteLoader[] loaders, out TypeDictionary metadata)
	{
		using Stream stream = fileSystem.Open(filename);
		ISpriteFrame[] frames = GetFrames(stream, loaders, filename, out metadata);
		if (frames == null)
		{
			throw new InvalidDataException(filename + " is not a valid sprite file!");
		}
		return frames;
	}

	public static ISpriteFrame[] GetFrames(Stream stream, ISpriteLoader[] loaders, string filename, out TypeDictionary metadata)
	{
		metadata = null;
		foreach (ISpriteLoader spriteLoader in loaders)
		{
			if (spriteLoader.TryParseSprite(stream, filename, out var frames, out metadata))
			{
				return frames;
			}
		}
		return null;
	}
}
