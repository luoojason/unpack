using System;
using System.Runtime.InteropServices;
using OpenRA.FileFormats;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public static class Util
{
	private static readonly int[] ChannelMasks = new int[4] { 2, 1, 0, 3 };

	public static uint[] CreateQuadIndices(int quads)
	{
		uint[] array = new uint[quads * 6];
		Span<uint> span = stackalloc uint[6] { 0u, 1u, 2u, 2u, 3u, 0u };
		ReadOnlySpan<uint> readOnlySpan = span;
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = readOnlySpan[i % 6] + (uint)(4 * (i / 6));
		}
		return array;
	}

	public static void FastCreateQuad(Vertex[] vertices, in float3 o, Sprite r, int2 samplers, int paletteTextureIndex, int nv, in float3 size, in float3 tint, float alpha, float rotation = 0f)
	{
		float3 a2;
		float3 b3;
		float3 c;
		float3 d;
		if (rotation != 0f)
		{
			float3 a = o + 0.5f * size;
			float num = (float)Math.Sin(0f - rotation);
			float num2 = (float)Math.Cos(0f - rotation);
			float3 b = 0.5f * new float3(size.X * num2 - size.Y * num, size.X * num + size.Y * num2, (size.X * num + size.Y * num2) * size.Z / size.Y);
			float3 b2 = 0.5f * new float3(size.X * num2 + size.Y * num, size.X * num - size.Y * num2, (size.X * num - size.Y * num2) * size.Z / size.Y);
			a2 = a - b;
			b3 = a + b2;
			c = a + b;
			d = a - b2;
		}
		else
		{
			a2 = o;
			b3 = new float3(o.X + size.X, o.Y, o.Z);
			c = new float3(o.X + size.X, o.Y + size.Y, o.Z + size.Z);
			d = new float3(o.X, o.Y + size.Y, o.Z + size.Z);
		}
		FastCreateQuad(vertices, in a2, in b3, in c, in d, r, samplers, paletteTextureIndex, in tint, alpha, nv);
	}

	public static void FastCreateQuad(Vertex[] vertices, in float3 a, in float3 b, in float3 c, in float3 d, Sprite r, int2 samplers, int paletteTextureIndex, in float3 tint, float alpha, int nv)
	{
		float u = 0f;
		float v = 0f;
		float u2 = 0f;
		float v2 = 0f;
		int num = (int)((r.Channel == TextureChannel.RGBA) ? 2 : (((uint)r.Channel << 1) | 1));
		num |= samplers.X << 6;
		if (r is SpriteWithSecondaryData spriteWithSecondaryData)
		{
			u = spriteWithSecondaryData.SecondaryLeft;
			v = spriteWithSecondaryData.SecondaryTop;
			u2 = spriteWithSecondaryData.SecondaryRight;
			v2 = spriteWithSecondaryData.SecondaryBottom;
			num |= (int)(((uint)spriteWithSecondaryData.SecondaryChannel << 4) | 8);
			num |= samplers.Y << 9;
		}
		num |= (paletteTextureIndex & 0xFFFF) << 16;
		uint c2 = (uint)num;
		vertices[nv] = new Vertex(in a, r.Left, r.Top, u, v, c2, in tint, alpha);
		vertices[nv + 1] = new Vertex(in b, r.Right, r.Top, u2, v, c2, in tint, alpha);
		vertices[nv + 2] = new Vertex(in c, r.Right, r.Bottom, u2, v2, c2, in tint, alpha);
		vertices[nv + 3] = new Vertex(in d, r.Left, r.Bottom, u, v2, c2, in tint, alpha);
	}

	public static void FastCopyIntoChannel(Sprite dest, byte[] src, SpriteFrameType srcType, bool premultiplied = false)
	{
		byte[] data = dest.Sheet.GetData();
		int width = dest.Sheet.Size.Width;
		int left = dest.Bounds.Left;
		int top = dest.Bounds.Top;
		int width2 = dest.Bounds.Width;
		int height = dest.Bounds.Height;
		if (dest.Channel == TextureChannel.RGBA)
		{
			CopyIntoRgba(src, srcType, premultiplied, data, left, top, width2, height, width);
			return;
		}
		int num = width * 4;
		int num2 = num * top + left * 4 + ChannelMasks[(uint)dest.Channel];
		int num3 = num - 4 * width2;
		int num4 = 0;
		for (int i = 0; i < height; i++)
		{
			int num5 = 0;
			while (num5 < width2)
			{
				data[num2] = src[num4];
				num2 += 4;
				num5++;
				num4++;
			}
			num2 += num3;
		}
	}

	private static void CopyIntoRgba(byte[] src, SpriteFrameType srcType, bool premultiplied, byte[] dest, int x, int y, int width, int height, int stride)
	{
		int num = 0;
		int num2 = y * stride + x;
		Span<uint> span = MemoryMarshal.Cast<byte, uint>((Span<byte>)dest);
		if (srcType == SpriteFrameType.Bgra32)
		{
			Span<uint> span2 = MemoryMarshal.Cast<byte, uint>((Span<byte>)src);
			for (int i = 0; i < height; i++)
			{
				int num3 = num;
				Span<uint> span3 = span2.Slice(num3, num + width - num3);
				int num4 = num2;
				span3.CopyTo(span.Slice(num4, num2 + width - num4));
				if (!premultiplied)
				{
					for (int j = 0; j < width; j++)
					{
						span[num2] = PremultiplyAlpha(Color.FromArgb(span[num2])).ToArgb();
						num2++;
					}
					num2 -= width;
				}
				num += width;
				num2 += stride;
			}
			return;
		}
		for (int k = 0; k < height; k++)
		{
			for (int l = 0; l < width; l++)
			{
				byte blue;
				byte green;
				byte red;
				byte alpha;
				switch (srcType)
				{
				case SpriteFrameType.Bgra32:
				case SpriteFrameType.Bgr24:
					blue = src[num++];
					green = src[num++];
					red = src[num++];
					alpha = ((srcType == SpriteFrameType.Bgra32) ? src[num++] : byte.MaxValue);
					break;
				case SpriteFrameType.Rgba32:
				case SpriteFrameType.Rgb24:
					red = src[num++];
					green = src[num++];
					blue = src[num++];
					alpha = ((srcType == SpriteFrameType.Rgba32) ? src[num++] : byte.MaxValue);
					break;
				default:
					throw new InvalidOperationException($"Unknown SpriteFrameType {srcType}");
				}
				Color c = Color.FromArgb(alpha, red, green, blue);
				if (!premultiplied)
				{
					c = PremultiplyAlpha(c);
				}
				span[num2++] = c.ToArgb();
			}
			num2 += stride - width;
		}
	}

	public static void FastCopyIntoSprite(Sprite dest, Png src)
	{
		byte[] data = dest.Sheet.GetData();
		int width = dest.Sheet.Size.Width;
		int left = dest.Bounds.Left;
		int top = dest.Bounds.Top;
		int width2 = dest.Bounds.Width;
		int height = dest.Bounds.Height;
		int num = 0;
		int num2 = top * width + left;
		Span<uint> span = MemoryMarshal.Cast<byte, uint>((Span<byte>)data);
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width2; j++)
			{
				Color c;
				switch (src.Type)
				{
				case SpriteFrameType.Indexed8:
					c = src.Palette[src.Data[num++]];
					break;
				case SpriteFrameType.Rgba32:
				case SpriteFrameType.Rgb24:
				{
					byte red = src.Data[num++];
					byte green = src.Data[num++];
					byte blue = src.Data[num++];
					byte alpha = ((src.Type == SpriteFrameType.Rgba32) ? src.Data[num++] : byte.MaxValue);
					c = Color.FromArgb(alpha, red, green, blue);
					break;
				}
				default:
					throw new InvalidOperationException($"Unknown SpriteFrameType {src.Type}");
				}
				span[num2++] = PremultiplyAlpha(c).ToArgb();
			}
			num2 += width - width2;
		}
	}

	public static float3[] RotateQuad(float3 tl, float3 size, float rotation)
	{
		float3 a = tl + 0.5f * size;
		float num = (float)Math.Sin(0f - rotation);
		float num2 = (float)Math.Cos(0f - rotation);
		float3 b = 0.5f * new float3(size.X * num2 - size.Y * num, size.X * num + size.Y * num2, (size.X * num + size.Y * num2) * size.Z / size.Y);
		float3 b2 = 0.5f * new float3(size.X * num2 + size.Y * num, size.X * num - size.Y * num2, (size.X * num - size.Y * num2) * size.Z / size.Y);
		return new float3[4]
		{
			a - b,
			a + b2,
			a + b,
			a - b2
		};
	}

	public static Rectangle BoundingRectangle(float3 offset, float3 size, float rotation)
	{
		if (rotation == 0f)
		{
			return new Rectangle((int)offset.X, (int)offset.Y, (int)size.X, (int)size.Y);
		}
		float3[] array = RotateQuad(offset, size, rotation);
		float num = array[0].X;
		float num2 = array[0].X;
		float num3 = array[0].Y;
		float num4 = array[0].Y;
		for (int i = 1; i < array.Length; i++)
		{
			num = Math.Min(array[i].X, num);
			num2 = Math.Max(array[i].X, num2);
			num3 = Math.Min(array[i].Y, num3);
			num4 = Math.Max(array[i].Y, num4);
		}
		return new Rectangle((int)num, (int)num3, (int)Math.Ceiling(num2) - (int)num, (int)Math.Ceiling(num4) - (int)num3);
	}

	public static Color PremultiplyAlpha(Color c)
	{
		if (c.A == byte.MaxValue)
		{
			return c;
		}
		float num = (float)(int)c.A / 255f;
		return Color.FromArgb(c.A, (byte)((float)(int)c.R * num + 0.5f), (byte)((float)(int)c.G * num + 0.5f), (byte)((float)(int)c.B * num + 0.5f));
	}

	public static Color PremultipliedColorLerp(float t, Color c1, Color c2)
	{
		float num = 255f / (float)(int)c1.A;
		float num2 = 255f / (float)(int)c2.A;
		return PremultiplyAlpha(Color.FromArgb((int)(t * (float)(int)c2.A + (1f - t) * (float)(int)c1.A), (int)((float)(int)(byte)(t * num2 * (float)(int)c2.R + 0.5f) + (1f - t) * (float)(int)(byte)(num * (float)(int)c1.R + 0.5f)), (int)((float)(int)(byte)(t * num2 * (float)(int)c2.G + 0.5f) + (1f - t) * (float)(int)(byte)(num * (float)(int)c1.G + 0.5f)), (int)((float)(int)(byte)(t * num2 * (float)(int)c2.B + 0.5f) + (1f - t) * (float)(int)(byte)(num * (float)(int)c1.B + 0.5f))));
	}
}
