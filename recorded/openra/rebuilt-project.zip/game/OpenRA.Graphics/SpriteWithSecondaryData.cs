using System;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class SpriteWithSecondaryData : Sprite
{
	public readonly Sheet SecondarySheet;

	public readonly Rectangle SecondaryBounds;

	public readonly TextureChannel SecondaryChannel;

	public readonly float SecondaryTop;

	public readonly float SecondaryLeft;

	public readonly float SecondaryBottom;

	public readonly float SecondaryRight;

	public SpriteWithSecondaryData(Sprite s, Sheet secondarySheet, Rectangle secondaryBounds, TextureChannel secondaryChannel)
		: base(s.Sheet, s.Bounds, s.ZRamp, in s.Offset, s.Channel, s.BlendMode)
	{
		SecondarySheet = secondarySheet;
		SecondaryBounds = secondaryBounds;
		SecondaryChannel = secondaryChannel;
		SecondaryLeft = (float)Math.Min(secondaryBounds.Left, secondaryBounds.Right) / (float)s.Sheet.Size.Width;
		SecondaryTop = (float)Math.Min(secondaryBounds.Top, secondaryBounds.Bottom) / (float)s.Sheet.Size.Height;
		SecondaryRight = (float)Math.Max(secondaryBounds.Left, secondaryBounds.Right) / (float)s.Sheet.Size.Width;
		SecondaryBottom = (float)Math.Max(secondaryBounds.Top, secondaryBounds.Bottom) / (float)s.Sheet.Size.Height;
	}
}
