using System;
using System.Collections.Generic;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class SpriteRenderable : IPalettedRenderable, IRenderable, IModifyableRenderable, IFinalizedRenderable
{
	public static readonly IEnumerable<IRenderable> None = Array.Empty<IRenderable>();

	private readonly Sprite sprite;

	private readonly WPos pos;

	private readonly float scale;

	private readonly WAngle rotation = WAngle.Zero;

	public WPos Pos
	{
		get
		{
			return pos + ILSpyHelper_AsRefReadOnly(Offset);
			static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
			{
				//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
				return ref temp;
			}
		}
	}

	public WVec Offset { get; }

	public PaletteReference Palette { get; }

	public int ZOffset { get; }

	public bool IsDecoration { get; }

	public float Alpha { get; }

	public float3 Tint { get; }

	public TintModifiers TintModifiers { get; }

	public SpriteRenderable(Sprite sprite, WPos pos, WVec offset, int zOffset, PaletteReference palette, float scale, float alpha, float3 tint, TintModifiers tintModifiers, bool isDecoration, WAngle rotation)
	{
		this.sprite = sprite;
		this.pos = pos;
		Offset = offset;
		ZOffset = zOffset;
		Palette = palette;
		this.scale = scale;
		this.rotation = rotation;
		Tint = tint;
		IsDecoration = isDecoration;
		TintModifiers = tintModifiers;
		Alpha = alpha;
		if (sprite.Channel == TextureChannel.RGBA && (palette == null || !palette.HasColorShift))
		{
			Palette = null;
		}
	}

	public SpriteRenderable(Sprite sprite, WPos pos, WVec offset, int zOffset, PaletteReference palette, float scale, float alpha, float3 tint, TintModifiers tintModifiers, bool isDecoration)
		: this(sprite, pos, offset, zOffset, palette, scale, alpha, tint, tintModifiers, isDecoration, WAngle.Zero)
	{
	}

	public IPalettedRenderable WithPalette(PaletteReference newPalette)
	{
		return new SpriteRenderable(sprite, pos, Offset, ZOffset, newPalette, scale, Alpha, Tint, TintModifiers, IsDecoration, rotation);
	}

	public IRenderable WithZOffset(int newOffset)
	{
		return new SpriteRenderable(sprite, pos, Offset, newOffset, Palette, scale, Alpha, Tint, TintModifiers, IsDecoration, rotation);
	}

	public IRenderable OffsetBy(in WVec vec)
	{
		return new SpriteRenderable(sprite, pos + vec, Offset, ZOffset, Palette, scale, Alpha, Tint, TintModifiers, IsDecoration, rotation);
	}

	public IRenderable AsDecoration()
	{
		return new SpriteRenderable(sprite, pos, Offset, ZOffset, Palette, scale, Alpha, Tint, TintModifiers, isDecoration: true, rotation);
	}

	public IModifyableRenderable WithAlpha(float newAlpha)
	{
		return new SpriteRenderable(sprite, pos, Offset, ZOffset, Palette, scale, newAlpha, Tint, TintModifiers, IsDecoration, rotation);
	}

	public IModifyableRenderable WithTint(in float3 newTint, TintModifiers newTintModifiers)
	{
		return new SpriteRenderable(sprite, pos, Offset, ZOffset, Palette, scale, Alpha, newTint, newTintModifiers, IsDecoration, rotation);
	}

	private float3 ScreenPosition(WorldRenderer wr)
	{
		float3 float4 = 0.5f * scale * sprite.Size;
		return wr.Screen3DPxPosition(pos) + (float3)wr.ScreenPxOffset(Offset) - new float3((int)float4.X, (int)float4.Y, float4.Z);
	}

	public IFinalizedRenderable PrepareRender(WorldRenderer wr)
	{
		return this;
	}

	public void Render(WorldRenderer wr)
	{
		SpriteRenderer worldSpriteRenderer = Game.Renderer.WorldSpriteRenderer;
		float3 a = Alpha * Tint;
		if (wr.TerrainLighting != null && (TintModifiers & TintModifiers.IgnoreWorldTint) == 0)
		{
			a *= wr.TerrainLighting.TintAt(pos);
		}
		float num = Alpha;
		if ((TintModifiers & TintModifiers.ReplaceColor) != 0)
		{
			num *= -1f;
		}
		worldSpriteRenderer.DrawSprite(sprite, Palette, ScreenPosition(wr), scale, in a, num, rotation.RendererRadians());
	}

	public void RenderDebugGeometry(WorldRenderer wr)
	{
		float3 world = ScreenPosition(wr) + sprite.Offset;
		int2 int3 = wr.Viewport.WorldToViewPx(in world);
		int2 int4 = wr.Viewport.WorldToViewPx(world + sprite.Size);
		if (rotation == WAngle.Zero)
		{
			Game.Renderer.RgbaColorRenderer.DrawRect((float3)int3, (float3)int4, 1f, Color.Red);
		}
		else
		{
			Game.Renderer.RgbaColorRenderer.DrawPolygon(Util.RotateQuad(int3, int4 - int3, rotation.RendererRadians()), 1f, Color.Red);
		}
	}

	public Rectangle ScreenBounds(WorldRenderer wr)
	{
		float3 offset = ScreenPosition(wr) + sprite.Offset;
		return Util.BoundingRectangle(offset, sprite.Size, rotation.RendererRadians());
	}

	IModifyableRenderable IModifyableRenderable.WithTint(in float3 newTint, TintModifiers newTintModifiers)
	{
		return WithTint(in newTint, newTintModifiers);
	}

	IRenderable IRenderable.OffsetBy(in WVec offset)
	{
		return OffsetBy(in offset);
	}
}
