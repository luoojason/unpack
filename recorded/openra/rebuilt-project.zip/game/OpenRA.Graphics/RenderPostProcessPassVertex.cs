namespace OpenRA.Graphics;

public readonly struct RenderPostProcessPassVertex(float x, float y)
{
	public readonly float X = x;

	public readonly float Y = y;
}
