using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.FileSystem;

namespace OpenRA.Graphics;

public sealed class SpriteCache : IDisposable
{
	public readonly Dictionary<SheetType, SheetBuilder> SheetBuilders;

	private readonly ISpriteLoader[] loaders;

	private readonly IReadOnlyFileSystem fileSystem;

	private readonly Dictionary<int, (int[] Frames, MiniYamlNode.SourceLocation Location, AdjustFrame AdjustFrame, bool Premultiplied)> spriteReservations = new Dictionary<int, (int[], MiniYamlNode.SourceLocation, AdjustFrame, bool)>();

	private readonly Dictionary<string, List<int>> reservationsByFilename = new Dictionary<string, List<int>>();

	private readonly Dictionary<int, Sprite[]> resolvedSprites = new Dictionary<int, Sprite[]>();

	private readonly Dictionary<int, (string Filename, MiniYamlNode.SourceLocation Location)> missingFiles = new Dictionary<int, (string, MiniYamlNode.SourceLocation)>();

	private int nextReservationToken = 1;

	public IEnumerable<(string Filename, MiniYamlNode.SourceLocation Location)> MissingFiles => missingFiles.Values.ToHashSet();

	public SpriteCache(IReadOnlyFileSystem fileSystem, ISpriteLoader[] loaders, int bgraSheetSize, int indexedSheetSize, int bgraSheetMargin = 1, int indexedSheetMargin = 1)
	{
		SheetBuilders = new Dictionary<SheetType, SheetBuilder>
		{
			{
				SheetType.Indexed,
				new SheetBuilder(SheetType.Indexed, indexedSheetSize, indexedSheetMargin)
			},
			{
				SheetType.BGRA,
				new SheetBuilder(SheetType.BGRA, bgraSheetSize, bgraSheetMargin)
			}
		};
		this.fileSystem = fileSystem;
		this.loaders = loaders;
	}

	public int ReserveSprites(string filename, IEnumerable<int> frames, MiniYamlNode.SourceLocation location, AdjustFrame adjustFrame = null, bool premultiplied = false)
	{
		int num = nextReservationToken++;
		spriteReservations[num] = (frames?.ToArray(), location, adjustFrame, premultiplied);
		reservationsByFilename.GetOrAdd(filename, (string _) => new List<int>()).Add(num);
		return num;
	}

	private static ISpriteFrame[] GetFrames(IReadOnlyFileSystem fileSystem, string filename, ISpriteLoader[] loaders)
	{
		if (!fileSystem.TryOpen(filename, out var s))
		{
			return null;
		}
		using (s)
		{
			foreach (ISpriteLoader spriteLoader in loaders)
			{
				if (spriteLoader.TryParseSprite(s, filename, out var frames, out var _))
				{
					return frames;
				}
			}
			return null;
		}
	}

	public ISpriteFrame[] LoadFramesUncached(string filename)
	{
		return GetFrames(fileSystem, filename, loaders);
	}

	public void LoadReservations(ModData modData)
	{
		List<(string, int, bool, AdjustFrame, ISpriteFrame, Sprite[])> list = new List<(string, int, bool, AdjustFrame, ISpriteFrame, Sprite[])>();
		foreach (var (text2, list3) in reservationsByFilename)
		{
			modData.LoadScreen?.Display();
			ISpriteFrame[] loadedFrames = GetFrames(fileSystem, text2, loaders);
			foreach (int item4 in list3)
			{
				if (!spriteReservations.TryGetValue(item4, out (int[], MiniYamlNode.SourceLocation, AdjustFrame, bool) value))
				{
					continue;
				}
				if (loadedFrames != null)
				{
					Sprite[] array = new Sprite[loadedFrames.Length];
					resolvedSprites[item4] = array;
					if (value.Item1 != null && value.Item1.Any((int i) => i >= loadedFrames.Length))
					{
						throw new InvalidOperationException($"{value.Item2}: {text2} does not contain frames: " + string.Join(',', value.Item1.Where((int f) => f >= loadedFrames.Length)));
					}
					IEnumerable<int> item = value.Item1;
					IEnumerable<int> enumerable = item ?? Enumerable.Range(0, loadedFrames.Length);
					int total = value.Item1?.Length ?? loadedFrames.Length;
					int num = 0;
					foreach (int item5 in enumerable)
					{
						ISpriteFrame spriteFrame = loadedFrames[item5];
						if (value.Item3 != null)
						{
							spriteFrame = value.Item3(spriteFrame, num++, total);
						}
						list.Add((text2, item5, value.Item4, value.Item3, spriteFrame, array));
					}
				}
				else
				{
					resolvedSprites[item4] = null;
					missingFiles[item4] = (text2, value.Item2);
				}
			}
		}
		spriteReservations.Clear();
		spriteReservations.TrimExcess();
		reservationsByFilename.Clear();
		reservationsByFilename.TrimExcess();
		IOrderedEnumerable<(string, int, bool, AdjustFrame, ISpriteFrame, Sprite[])> orderedEnumerable = list.OrderBy(((string Filename, int FrameIndex, bool Premultiplied, AdjustFrame AdjustFrame, ISpriteFrame Frame, Sprite[] SpritesForToken) x) => x.Frame.Size.Height);
		Dictionary<(string, int, bool, AdjustFrame), Sprite> d = new Dictionary<(string, int, bool, AdjustFrame), Sprite>(list.Count);
		foreach (var item6 in orderedEnumerable)
		{
			var (item2, num2, premultiplied, item3, frame, array2) = item6;
			array2[num2] = d.GetOrAdd((item2, num2, premultiplied, item3), ((string, int, bool, AdjustFrame) _) =>
			{
				SheetBuilder sheetBuilder = SheetBuilders[SheetBuilder.FrameTypeToSheetType(frame.Type)];
				return sheetBuilder.Add(frame, premultiplied);
			});
			modData.LoadScreen?.Display();
		}
		foreach (SheetBuilder value2 in SheetBuilders.Values)
		{
			value2.Current.ReleaseBuffer();
		}
	}

	public Sprite[] ResolveSprites(int token)
	{
		if (!resolvedSprites.Remove(token, out var value))
		{
			throw new InvalidOperationException($"{"token"} {token} has either already been resolved, or was never reserved via {"ReserveSprites"}");
		}
		resolvedSprites.TrimExcess();
		if (missingFiles.TryGetValue(token, out (string, MiniYamlNode.SourceLocation) value2))
		{
			throw new FileNotFoundException($"{value2.Item2}: {value2.Item1} not found", value2.Item1);
		}
		return value;
	}

	public void Dispose()
	{
		foreach (SheetBuilder value in SheetBuilders.Values)
		{
			value.Dispose();
		}
	}
}
