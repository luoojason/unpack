using System;

namespace OpenRA.Graphics;

[Flags]
public enum ScrollDirection
{
	None = 0,
	Up = 1,
	Left = 2,
	Down = 4,
	Right = 8
}
