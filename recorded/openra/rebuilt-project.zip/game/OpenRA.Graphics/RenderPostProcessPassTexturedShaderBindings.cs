namespace OpenRA.Graphics;

public sealed class RenderPostProcessPassTexturedShaderBindings(string name) : ShaderBindings("postprocess_textured", "postprocess_textured_" + name)
{
	public override ShaderVertexAttribute[] Attributes { get; } = new ShaderVertexAttribute[2]
	{
		new ShaderVertexAttribute("aVertexPosition", ShaderVertexAttributeType.Float, 2, 0),
		new ShaderVertexAttribute("aVertexTexCoord", ShaderVertexAttributeType.Float, 2, 8)
	};
}
