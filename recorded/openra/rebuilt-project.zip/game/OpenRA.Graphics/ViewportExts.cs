namespace OpenRA.Graphics;

public static class ViewportExts
{
	public static bool Includes(this ScrollDirection d, ScrollDirection s)
	{
		return (d & s) == s;
	}

	public static ScrollDirection Set(this ScrollDirection d, ScrollDirection s, bool val)
	{
		if (d.Includes(s) == val)
		{
			return d;
		}
		return d ^ s;
	}
}
