namespace OpenRA.Graphics;

public delegate ISpriteFrame AdjustFrame(ISpriteFrame input, int index, int total);
