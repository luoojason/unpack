using System;
using System.Collections.Generic;
using OpenRA.FileSystem;
using OpenRA.Support;

namespace OpenRA.Graphics;

public sealed class SequenceSet : IDisposable
{
	private readonly ModData modData;

	private readonly string tileSet;

	private readonly IReadOnlyDictionary<string, IReadOnlyDictionary<string, ISpriteSequence>> images;

	public SpriteCache SpriteCache { get; }

	public IEnumerable<string> Images => images.Keys;

	public SequenceSet(IReadOnlyFileSystem fileSystem, ModData modData, string tileSet, MiniYaml additionalSequences)
	{
		this.modData = modData;
		this.tileSet = tileSet;
		SpriteCache = new SpriteCache(fileSystem, modData.SpriteLoaders, modData.SpriteSequenceLoader.BgraSheetSize, modData.SpriteSequenceLoader.IndexedSheetSize);
		using (new PerfTimer("LoadSequences"))
		{
			images = Load(fileSystem, additionalSequences);
		}
	}

	public ISpriteSequence GetSequence(string image, string sequence)
	{
		if (!images.TryGetValue(image, out var value))
		{
			throw new InvalidOperationException("Image `" + image + "` does not have any sequences defined.");
		}
		if (!value.TryGetValue(sequence, out var value2))
		{
			throw new InvalidOperationException($"Image `{image}` does not have a sequence named `{sequence}`.");
		}
		return value2;
	}

	public bool HasSequence(string image, string sequence)
	{
		if (!images.TryGetValue(image, out var value))
		{
			throw new InvalidOperationException("Image `" + image + "` does not have any sequences defined.");
		}
		return value.ContainsKey(sequence);
	}

	public IEnumerable<string> Sequences(string image)
	{
		if (!images.TryGetValue(image, out var value))
		{
			throw new InvalidOperationException("Image `" + image + "` does not have any sequences defined.");
		}
		return value.Keys;
	}

	private IReadOnlyDictionary<string, IReadOnlyDictionary<string, ISpriteSequence>> Load(IReadOnlyFileSystem fileSystem, MiniYaml additionalSequences)
	{
		List<MiniYamlNode> list = MiniYaml.Load(fileSystem, modData.Manifest.Sequences, additionalSequences);
		Dictionary<string, IReadOnlyDictionary<string, ISpriteSequence>> dictionary = new Dictionary<string, IReadOnlyDictionary<string, ISpriteSequence>>();
		foreach (MiniYamlNode item in list)
		{
			if (!item.Key.StartsWith('^'))
			{
				dictionary[item.Key] = modData.SpriteSequenceLoader.ParseSequences(modData, tileSet, SpriteCache, item);
			}
		}
		return dictionary;
	}

	public void LoadSprites()
	{
		SpriteCache.LoadReservations(modData);
		foreach (IReadOnlyDictionary<string, ISpriteSequence> value in images.Values)
		{
			foreach (KeyValuePair<string, ISpriteSequence> item in value)
			{
				item.Value.ResolveSprites(SpriteCache);
			}
		}
	}

	public void Dispose()
	{
		SpriteCache.Dispose();
	}
}
