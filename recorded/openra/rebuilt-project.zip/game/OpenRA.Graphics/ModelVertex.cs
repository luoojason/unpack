namespace OpenRA.Graphics;

public readonly struct ModelVertex
{
	public readonly float X;

	public readonly float Y;

	public readonly float Z;

	public readonly float S;

	public readonly float T;

	public readonly float U;

	public readonly float V;

	public readonly float P;

	public readonly float C;

	public ModelVertex(in float3 xyz, float s, float t, float u, float v, float p, float c)
		: this(xyz.X, xyz.Y, xyz.Z, s, t, u, v, p, c)
	{
	}

	public ModelVertex(float x, float y, float z, float s, float t, float u, float v, float p, float c)
	{
		X = x;
		Y = y;
		Z = z;
		S = s;
		T = t;
		U = u;
		V = v;
		P = p;
		C = c;
	}
}
