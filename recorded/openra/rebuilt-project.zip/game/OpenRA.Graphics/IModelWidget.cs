using System;

namespace OpenRA.Graphics;

public interface IModelWidget
{
	string Palette { get; }

	float Scale { get; }

	void Setup(Func<bool> isVisible, Func<string> getPalette, Func<string> getPlayerPalette, Func<float> getScale, Func<IModel> getVoxel, Func<WRot> getRotation);
}
