namespace OpenRA.Graphics;

public interface IModifyableRenderable : IRenderable
{
	float Alpha { get; }

	float3 Tint { get; }

	TintModifiers TintModifiers { get; }

	IModifyableRenderable WithAlpha(float newAlpha);

	IModifyableRenderable WithTint(in float3 newTint, TintModifiers newTintModifiers);
}
