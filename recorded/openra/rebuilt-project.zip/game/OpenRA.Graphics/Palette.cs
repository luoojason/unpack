using System;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public static class Palette
{
	private sealed class ReadOnlyPalette : IPalette
	{
		private readonly IPalette palette;

		public uint this[int index] => palette[index];

		public ReadOnlyPalette(IPalette palette)
		{
			this.palette = palette;
		}

		public void CopyToArray(Array destination, int destinationOffset)
		{
			palette.CopyToArray(destination, destinationOffset);
		}
	}

	public const int Size = 256;

	public static Color GetColor(this IPalette palette, int index)
	{
		return Color.FromArgb(palette[index]);
	}

	public static IPalette AsReadOnly(this IPalette palette)
	{
		if (palette is ImmutablePalette)
		{
			return palette;
		}
		return new ReadOnlyPalette(palette);
	}
}
