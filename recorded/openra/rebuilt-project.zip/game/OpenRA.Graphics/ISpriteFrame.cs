using OpenRA.Primitives;

namespace OpenRA.Graphics;

public interface ISpriteFrame
{
	SpriteFrameType Type { get; }

	Size Size { get; }

	Size FrameSize { get; }

	float2 Offset { get; }

	byte[] Data { get; }

	bool DisableExportPadding { get; }
}
