using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class Viewport
{
	private readonly WorldRenderer worldRenderer;

	private readonly WorldViewportSizes viewportSizes;

	private readonly GraphicSettings graphicSettings;

	private readonly Rectangle mapBounds;

	private readonly Size tileSize;

	private int2 viewportSize;

	private ProjectedCellRegion cells;

	private bool cellsDirty = true;

	private ProjectedCellRegion allCells;

	private bool allCellsDirty = true;

	private WorldViewport lastViewportDistance;

	private float zoom = 1f;

	private bool unlockMinZoom;

	private float unlockedMinZoomScale;

	private float unlockedMinZoom = 1f;

	public static long LastMoveRunTime;

	public static int2 LastMousePos;

	public int2 CenterLocation { get; private set; }

	public WPos CenterPosition => worldRenderer.ProjectedPosition(CenterLocation);

	public Rectangle Rectangle => new Rectangle(TopLeft, new Size(viewportSize.X, viewportSize.Y));

	public int2 TopLeft => CenterLocation - viewportSize / 2;

	public int2 BottomRight => CenterLocation + viewportSize / 2;

	public float Zoom
	{
		get
		{
			return zoom;
		}
		private set
		{
			zoom = value;
			viewportSize = (1f / zoom * new float2(Game.Renderer.NativeResolution)).ToInt2();
			cellsDirty = true;
			allCellsDirty = true;
		}
	}

	public float MinZoom { get; private set; } = 1f;

	public float MaxZoom { get; private set; } = 2f;

	public ProjectedCellRegion VisibleCellsInsideBounds
	{
		get
		{
			if (cellsDirty)
			{
				cells = CalculateVisibleCells(insideBounds: true);
				cellsDirty = false;
			}
			return cells;
		}
	}

	public ProjectedCellRegion AllVisibleCells
	{
		get
		{
			if (allCellsDirty)
			{
				allCells = CalculateVisibleCells(insideBounds: false);
				allCellsDirty = false;
			}
			return allCells;
		}
	}

	public void AdjustZoom(float dz)
	{
		Zoom = (zoom * (float)Math.Exp(dz)).Clamp(unlockMinZoom ? unlockedMinZoom : MinZoom, MaxZoom);
	}

	public void AdjustZoom(float dz, int2 center)
	{
		int2 int3 = worldRenderer.Viewport.ViewToWorldPx(center);
		AdjustZoom(dz);
		int2 int4 = worldRenderer.Viewport.ViewToWorldPx(center);
		CenterLocation += int3 - int4;
	}

	public void ToggleZoom()
	{
		if (zoom < MinZoom)
		{
			Zoom = MinZoom;
		}
		else
		{
			Zoom = ((zoom > MinZoom) ? MinZoom : MaxZoom);
		}
	}

	public void UnlockMinimumZoom(float scale)
	{
		unlockMinZoom = true;
		unlockedMinZoomScale = scale;
		UpdateViewportZooms(resetCurrentZoom: false);
	}

	public ScrollDirection GetBlockedDirections()
	{
		ScrollDirection scrollDirection = ScrollDirection.None;
		if (CenterLocation.Y <= mapBounds.Top)
		{
			scrollDirection |= ScrollDirection.Up;
		}
		if (CenterLocation.X <= mapBounds.Left)
		{
			scrollDirection |= ScrollDirection.Left;
		}
		if (CenterLocation.Y >= mapBounds.Bottom)
		{
			scrollDirection |= ScrollDirection.Down;
		}
		if (CenterLocation.X >= mapBounds.Right)
		{
			scrollDirection |= ScrollDirection.Right;
		}
		return scrollDirection;
	}

	public Viewport(WorldRenderer wr, Map map)
	{
		worldRenderer = wr;
		MapGrid mapGrid = Game.ModData.Manifest.Get<MapGrid>();
		viewportSizes = Game.ModData.Manifest.Get<WorldViewportSizes>();
		graphicSettings = Game.Settings.Graphics;
		if (wr.World.Type == WorldType.Editor)
		{
			int num = map.MapSize.X * mapGrid.TileSize.Width;
			int num2 = map.MapSize.Y * mapGrid.TileSize.Height;
			if (wr.World.Map.Grid.Type == MapGridType.RectangularIsometric)
			{
				num2 /= 2;
			}
			mapBounds = new Rectangle(0, 0, num, num2);
			CenterLocation = new int2(num / 2, num2 / 2);
		}
		else
		{
			int2 int3 = wr.ScreenPxPosition(map.ProjectedTopLeft);
			int2 int4 = wr.ScreenPxPosition(map.ProjectedBottomRight);
			mapBounds = Rectangle.FromLTRB(int3.X, int3.Y, int4.X, int4.Y);
			CenterLocation = (int3 + int4) / 2;
		}
		tileSize = mapGrid.TileSize;
		UpdateViewportZooms();
	}

	public void Tick()
	{
		if (lastViewportDistance != graphicSettings.ViewportDistance)
		{
			UpdateViewportZooms();
		}
	}

	private static float CalculateMinimumZoom(float minHeight, float maxHeight)
	{
		int height = Game.Renderer.NativeResolution.Height;
		if ((float)height <= maxHeight)
		{
			return 1f;
		}
		float num = 1f;
		float num2;
		while (true)
		{
			num2 = 1f;
			while (true)
			{
				float num3 = num2 + num;
				if ((float)height < minHeight * num3)
				{
					break;
				}
				num2 = num3;
			}
			if ((float)height < maxHeight * num2)
			{
				break;
			}
			num /= 2f;
		}
		return num2;
	}

	private void UpdateViewportZooms(bool resetCurrentZoom = true)
	{
		lastViewportDistance = graphicSettings.ViewportDistance;
		WorldViewport viewportDistance = graphicSettings.ViewportDistance;
		if (viewportSizes.AllowNativeZoom && viewportDistance == WorldViewport.Native)
		{
			MinZoom = viewportSizes.DefaultScale;
		}
		else
		{
			int2 sizeRange = viewportSizes.GetSizeRange(viewportDistance);
			MinZoom = CalculateMinimumZoom(sizeRange.X, sizeRange.Y) * viewportSizes.DefaultScale;
		}
		MaxZoom = Math.Min(MinZoom * viewportSizes.MaxZoomScale, (float)Game.Renderer.NativeResolution.Height * viewportSizes.DefaultScale / (float)viewportSizes.MaxZoomWindowHeight);
		if (unlockMinZoom)
		{
			unlockedMinZoom = MinZoom * unlockedMinZoomScale;
		}
		if (resetCurrentZoom)
		{
			Zoom = MinZoom;
		}
		else
		{
			Zoom = Zoom.Clamp(MinZoom, MaxZoom);
		}
		float num = (unlockMinZoom ? unlockedMinZoom : MinZoom);
		float2 float4 = 1f / num * new float2(Game.Renderer.NativeResolution);
		Game.Renderer.SetMaximumViewportSize(new Size((int)float4.X, (int)float4.Y));
		foreach (INotifyViewportZoomExtentsChanged item in worldRenderer.World.WorldActor.TraitsImplementing<INotifyViewportZoomExtentsChanged>())
		{
			item.ViewportZoomExtentsChanged(num, MaxZoom);
		}
	}

	public CPos ViewToWorld(int2 view)
	{
		int2 world = worldRenderer.Viewport.ViewToWorldPx(view);
		Map map = worldRenderer.World.Map;
		List<MPos> list = CandidateMouseoverCells(world).ToList();
		foreach (MPos item in list)
		{
			WPos pos = map.CenterOfCell(item.ToCPos(map.Grid.Type));
			int2 int3 = worldRenderer.ScreenPxPosition(pos);
			if (Math.Abs(int3.X - world.X) <= tileSize.Width && Math.Abs(int3.Y - world.Y) <= tileSize.Height)
			{
				CellRamp cellRamp = map.Grid.Ramps[map.Ramp.Contains(item) ? map.Ramp[item] : 0];
				WPos pos2 = map.CenterOfCell(item.ToCPos(map)) - new WVec(0, 0, cellRamp.CenterHeightOffset);
				int2[] polygon = cellRamp.Corners.Select((WVec c) => worldRenderer.ScreenPxPosition(pos2 + c)).ToArray();
				if (polygon.PolygonContains(world))
				{
					return item.ToCPos(map);
				}
			}
		}
		if (list.Count > 0)
		{
			return list.MinBy((MPos uv) =>
			{
				WPos pos3 = map.CenterOfCell(uv.ToCPos(map.Grid.Type));
				int2 int4 = worldRenderer.ScreenPxPosition(pos3);
				int num = Math.Abs(int4.X - world.X);
				int num2 = Math.Abs(int4.Y - world.Y);
				return num * num + num2 * num2;
			}).ToCPos(map);
		}
		return worldRenderer.World.Map.CellContaining(worldRenderer.ProjectedPosition(ViewToWorldPx(view)));
	}

	private IEnumerable<MPos> CandidateMouseoverCells(int2 world)
	{
		Map map = worldRenderer.World.Map;
		int num = map.Grid.TileScale / 2;
		WPos a = worldRenderer.ProjectedPosition(world);
		MPos a2;
		MPos b;
		if (map.Grid.Type == MapGridType.RectangularIsometric)
		{
			a2 = map.CellContaining(a - ILSpyHelper_AsRefReadOnly(new WVec(num, 0, 0))).ToMPos(map.Grid.Type);
			b = map.CellContaining(a + ILSpyHelper_AsRefReadOnly(new WVec(num, num * map.Grid.MaximumTerrainHeight, 0))).ToMPos(map.Grid.Type);
		}
		else
		{
			a2 = map.CellContaining(a).ToMPos(map.Grid.Type);
			b = map.CellContaining(a + ILSpyHelper_AsRefReadOnly(new WVec(0, num * map.Grid.MaximumTerrainHeight, 0))).ToMPos(map.Grid.Type);
		}
		for (int v = b.V; v >= a2.V; v--)
		{
			for (int u = b.U; u >= a2.U; u--)
			{
				yield return new MPos(u, v);
			}
		}
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	public int2 ViewToWorldPx(int2 view)
	{
		return (graphicSettings.UIScale / Zoom * view.ToFloat2()).ToInt2() + TopLeft;
	}

	public int2 WorldToViewPx(int2 world)
	{
		return (Zoom / graphicSettings.UIScale * (world - TopLeft).ToFloat2()).ToInt2();
	}

	public int2 WorldToViewPx(in float3 world)
	{
		return (Zoom / graphicSettings.UIScale * (world - (float3)TopLeft).XY).ToInt2();
	}

	public void Center(IEnumerable<Actor> actors)
	{
		IReadOnlyCollection<Actor> readOnlyCollection = actors as IReadOnlyCollection<Actor>;
		if (readOnlyCollection == null)
		{
			readOnlyCollection = actors.ToList();
		}
		if (readOnlyCollection.Count != 0)
		{
			Center(readOnlyCollection.Select((Actor a) => a.CenterPosition).Average());
		}
	}

	public void Center(WPos pos)
	{
		CenterLocation = worldRenderer.ScreenPxPosition(pos).Clamp(mapBounds);
		cellsDirty = true;
		allCellsDirty = true;
	}

	public void Scroll(float2 delta, bool ignoreBorders)
	{
		CenterLocation += (1f / Zoom * delta).ToInt2();
		cellsDirty = true;
		allCellsDirty = true;
		if (!ignoreBorders)
		{
			CenterLocation = CenterLocation.Clamp(mapBounds);
		}
	}

	public Rectangle GetScissorBounds(bool insideBounds)
	{
		ProjectedCellRegion projectedCellRegion = (insideBounds ? VisibleCellsInsideBounds : AllVisibleCells);
		Map map = worldRenderer.World.Map;
		WPos a = map.CenterOfCell(((MPos)projectedCellRegion.TopLeft).ToCPos(map)) - new WVec(512, 512, 0);
		WPos a2 = map.CenterOfCell(((MPos)projectedCellRegion.BottomRight).ToCPos(map)) + new WVec(512, 512, 0);
		int2 int3 = worldRenderer.ScreenPxPosition(a - ILSpyHelper_AsRefReadOnly(new WVec(0, 0, a.Z))) - TopLeft;
		int2 int4 = worldRenderer.ScreenPxPosition(a2 - ILSpyHelper_AsRefReadOnly(new WVec(0, 0, a2.Z))) - TopLeft;
		return Rectangle.FromLTRB(int3.X - tileSize.Width / 2, int3.Y - tileSize.Height / 2, int4.X + tileSize.Width / 2, int4.Y + tileSize.Height / 2);
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	private ProjectedCellRegion CalculateVisibleCells(bool insideBounds)
	{
		Map map = worldRenderer.World.Map;
		PPos pPos = (PPos)map.CellContaining(worldRenderer.ProjectedPosition(TopLeft)).ToMPos(map);
		PPos pPos2 = (PPos)map.CellContaining(worldRenderer.ProjectedPosition(BottomRight)).ToMPos(map);
		if (map.Grid.Type == MapGridType.RectangularIsometric)
		{
			pPos = new PPos(pPos.U - 1, pPos.V - 1);
			pPos2 = new PPos(pPos2.U + 1, pPos2.V + 1);
		}
		if (insideBounds)
		{
			pPos = map.Clamp(pPos);
			pPos2 = map.Clamp(pPos2);
		}
		return new ProjectedCellRegion(map, pPos, pPos2);
	}
}
