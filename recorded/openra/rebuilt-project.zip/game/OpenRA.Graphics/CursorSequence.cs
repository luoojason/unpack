using System.Collections.Generic;
using System.Linq;

namespace OpenRA.Graphics;

public class CursorSequence
{
	public readonly string Name;

	public readonly int Start;

	public readonly int Length;

	public readonly string Palette;

	public readonly int2 Hotspot;

	public readonly ISpriteFrame[] Frames;

	public CursorSequence(FrameCache cache, string name, string cursorSrc, string palette, MiniYaml info)
	{
		Dictionary<string, MiniYaml> dictionary = info.ToDictionary();
		Start = Exts.ParseInt32Invariant(dictionary["Start"].Value);
		Palette = palette;
		Name = name;
		ISpriteFrame[] array = cache[cursorSrc];
		Frames = array.Skip(Start).ToArray();
		if ((dictionary.TryGetValue("Length", out var value) && value.Value == "*") || (dictionary.TryGetValue("End", out value) && value.Value == "*"))
		{
			Length = Frames.Length;
		}
		else if (dictionary.TryGetValue("Length", out value))
		{
			Length = Exts.ParseInt32Invariant(value.Value);
		}
		else if (dictionary.TryGetValue("End", out value))
		{
			Length = Exts.ParseInt32Invariant(value.Value) - Start;
		}
		else
		{
			Length = 1;
		}
		Frames = Frames.Take(Length).ToArray();
		if (Start > array.Length)
		{
			throw new YamlException($"Cursor {name}: {"Start"} is greater than the length of the sprite sequence.");
		}
		if (Length > array.Length)
		{
			throw new YamlException($"Cursor {name}: {"Length"} is greater than the length of the sprite sequence.");
		}
		if (dictionary.TryGetValue("X", out value))
		{
			Exts.TryParseInt32Invariant(value.Value, out var i);
			Hotspot = Hotspot.WithX(i);
		}
		if (dictionary.TryGetValue("Y", out value))
		{
			Exts.TryParseInt32Invariant(value.Value, out var i2);
			Hotspot = Hotspot.WithY(i2);
		}
	}
}
