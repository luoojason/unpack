using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Effects;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA.Graphics;

public sealed class WorldRenderer : IDisposable
{
	public static readonly Func<IRenderable, int> RenderableZPositionComparisonKey = (IRenderable r) => r.Pos.Y + r.Pos.Z + r.ZOffset;

	public readonly Size TileSize;

	public readonly int TileScale;

	public readonly World World;

	public readonly ITerrainLighting TerrainLighting;

	private readonly HashSet<Actor> onScreenActors = new HashSet<Actor>();

	private readonly HardwarePalette palette = new HardwarePalette();

	private readonly Dictionary<string, PaletteReference> palettes = new Dictionary<string, PaletteReference>();

	private readonly IRenderTerrain terrainRenderer;

	private readonly Lazy<DebugVisualizations> debugVis;

	private readonly Func<string, PaletteReference> createPaletteReference;

	private readonly bool enableDepthBuffer;

	private readonly List<IFinalizedRenderable> preparedRenderables = new List<IFinalizedRenderable>();

	private readonly List<IFinalizedRenderable> preparedOverlayRenderables = new List<IFinalizedRenderable>();

	private readonly List<IFinalizedRenderable> preparedAnnotationRenderables = new List<IFinalizedRenderable>();

	private readonly List<IRenderable> renderablesBuffer = new List<IRenderable>();

	private readonly IRenderer[] renderers;

	private readonly IRenderPostProcessPass[] postProcessPasses;

	public Viewport Viewport { get; }

	public event Action PaletteInvalidated;

	internal WorldRenderer(ModData modData, World world)
	{
		World = world;
		TileSize = World.Map.Grid.TileSize;
		TileScale = World.Map.Grid.TileScale;
		Viewport = new Viewport(this, world.Map);
		createPaletteReference = CreatePaletteReference;
		MapGrid mapGrid = modData.Manifest.Get<MapGrid>();
		enableDepthBuffer = mapGrid.EnableDepthBuffer;
		foreach (TraitPair<ILoadsPalettes> item in world.TraitDict.ActorsWithTrait<ILoadsPalettes>())
		{
			item.Trait.LoadPalettes(this);
		}
		Player.SetupRelationshipColors(world.Players, world.LocalPlayer, this, firstRun: true);
		palette.Initialize();
		TerrainLighting = world.WorldActor.TraitOrDefault<ITerrainLighting>();
		renderers = world.WorldActor.TraitsImplementing<IRenderer>().ToArray();
		terrainRenderer = world.WorldActor.TraitOrDefault<IRenderTerrain>();
		debugVis = Exts.Lazy(() => world.WorldActor.TraitOrDefault<DebugVisualizations>());
		postProcessPasses = world.WorldActor.TraitsImplementing<IRenderPostProcessPass>().ToArray();
	}

	public void BeginFrame()
	{
		IRenderer[] array = renderers;
		foreach (IRenderer renderer in array)
		{
			renderer.BeginFrame();
		}
	}

	public void EndFrame()
	{
		IRenderer[] array = renderers;
		foreach (IRenderer renderer in array)
		{
			renderer.EndFrame();
		}
	}

	public void UpdatePalettesForPlayer(string internalName, Color color, bool replaceExisting)
	{
		foreach (ILoadsPlayerPalettes item in World.WorldActor.TraitsImplementing<ILoadsPlayerPalettes>())
		{
			item.LoadPlayerPalettes(this, internalName, color, replaceExisting);
		}
	}

	private PaletteReference CreatePaletteReference(string name)
	{
		IPalette palette = this.palette.GetPalette(name);
		return new PaletteReference(name, this.palette.GetPaletteIndex(name), palette, this.palette);
	}

	public PaletteReference Palette(string name)
	{
		if (!string.IsNullOrEmpty(name))
		{
			return palettes.GetOrAdd(name, createPaletteReference);
		}
		return null;
	}

	public void AddPalette(string name, ImmutablePalette pal, bool allowModifiers = false, bool allowOverwrite = false)
	{
		if (allowOverwrite && palette.Contains(name))
		{
			ReplacePalette(name, pal);
			return;
		}
		int height = palette.Height;
		palette.AddPalette(name, pal, allowModifiers);
		if (height != palette.Height)
		{
			PaletteInvalidated?.Invoke();
		}
	}

	public void ReplacePalette(string name, IPalette pal)
	{
		palette.ReplacePalette(name, pal);
		if (palettes.TryGetValue(name, out var value))
		{
			value.Palette = pal;
		}
	}

	public void SetPaletteColorShift(string name, float hueOffset, float satOffset, float valueModifier, float minHue, float maxHue)
	{
		palette.SetColorShift(name, hueOffset, satOffset, valueModifier, minHue, maxHue);
	}

	private void GenerateRenderables()
	{
		foreach (Actor onScreenActor in onScreenActors)
		{
			renderablesBuffer.AddRange(onScreenActor.Render(this));
		}
		renderablesBuffer.AddRange(World.WorldActor.Render(this));
		if (World.RenderPlayer != null)
		{
			renderablesBuffer.AddRange(World.RenderPlayer.PlayerActor.Render(this));
		}
		if (World.OrderGenerator != null)
		{
			renderablesBuffer.AddRange(World.OrderGenerator.Render(this, World));
		}
		foreach (IEffect unpartitionedEffect in World.UnpartitionedEffects)
		{
			renderablesBuffer.AddRange(unpartitionedEffect.Render(this));
		}
		foreach (IEffect item in World.ScreenMap.RenderableEffectsInBox(Viewport.TopLeft, Viewport.BottomRight))
		{
			renderablesBuffer.AddRange(item.Render(this));
		}
		foreach (IRenderable item2 in renderablesBuffer.OrderBy(RenderableZPositionComparisonKey))
		{
			preparedRenderables.Add(item2.PrepareRender(this));
		}
		renderablesBuffer.Clear();
	}

	private void GenerateOverlayRenderables()
	{
		World.ApplyToActorsWithTrait((Actor actor, IRenderAboveShroud trait) =>
		{
			if (!actor.IsInWorld || actor.Disposed || (trait.SpatiallyPartitionable && !onScreenActors.Contains(actor)))
			{
				return;
			}
			foreach (IRenderable item in trait.RenderAboveShroud(actor, this))
			{
				preparedOverlayRenderables.Add(item.PrepareRender(this));
			}
		});
		foreach (Actor actor in World.Selection.Actors)
		{
			if (!actor.IsInWorld || actor.Disposed)
			{
				continue;
			}
			foreach (IRenderAboveShroudWhenSelected item2 in actor.TraitsImplementing<IRenderAboveShroudWhenSelected>())
			{
				if (item2.SpatiallyPartitionable && !onScreenActors.Contains(actor))
				{
					continue;
				}
				foreach (IRenderable item3 in item2.RenderAboveShroud(actor, this))
				{
					preparedOverlayRenderables.Add(item3.PrepareRender(this));
				}
			}
		}
		foreach (IEffect effect in World.Effects)
		{
			if (!(effect is IEffectAboveShroud effectAboveShroud))
			{
				continue;
			}
			foreach (IRenderable item4 in effectAboveShroud.RenderAboveShroud(this))
			{
				preparedOverlayRenderables.Add(item4.PrepareRender(this));
			}
		}
		if (World.OrderGenerator == null)
		{
			return;
		}
		foreach (IRenderable item5 in World.OrderGenerator.RenderAboveShroud(this, World))
		{
			preparedOverlayRenderables.Add(item5.PrepareRender(this));
		}
	}

	private void GenerateAnnotationRenderables()
	{
		World.ApplyToActorsWithTrait((Actor actor, IRenderAnnotations trait) =>
		{
			if (!actor.IsInWorld || actor.Disposed || (trait.SpatiallyPartitionable && !onScreenActors.Contains(actor)))
			{
				return;
			}
			foreach (IRenderable item in trait.RenderAnnotations(actor, this))
			{
				preparedAnnotationRenderables.Add(item.PrepareRender(this));
			}
		});
		foreach (Actor actor in World.Selection.Actors)
		{
			if (!actor.IsInWorld || actor.Disposed)
			{
				continue;
			}
			foreach (IRenderAnnotationsWhenSelected item2 in actor.TraitsImplementing<IRenderAnnotationsWhenSelected>())
			{
				if (item2.SpatiallyPartitionable && !onScreenActors.Contains(actor))
				{
					continue;
				}
				foreach (IRenderable item3 in item2.RenderAnnotations(actor, this))
				{
					preparedAnnotationRenderables.Add(item3.PrepareRender(this));
				}
			}
		}
		foreach (IEffect effect in World.Effects)
		{
			if (!(effect is IEffectAnnotation effectAnnotation))
			{
				continue;
			}
			foreach (IRenderable item4 in effectAnnotation.RenderAnnotation(this))
			{
				preparedAnnotationRenderables.Add(item4.PrepareRender(this));
			}
		}
		if (World.OrderGenerator == null)
		{
			return;
		}
		foreach (IRenderable item5 in World.OrderGenerator.RenderAnnotations(this, World))
		{
			preparedAnnotationRenderables.Add(item5.PrepareRender(this));
		}
	}

	public void PrepareRenderables()
	{
		if (!World.WorldActor.Disposed)
		{
			RefreshPalette();
			onScreenActors.UnionWith(World.ScreenMap.RenderableActorsInBox(Viewport.TopLeft, Viewport.BottomRight));
			GenerateRenderables();
			GenerateOverlayRenderables();
			GenerateAnnotationRenderables();
			onScreenActors.Clear();
		}
	}

	public void Draw()
	{
		if (World.WorldActor.Disposed)
		{
			return;
		}
		debugVis.Value?.UpdateDepthBuffer();
		Rectangle scissorBounds = Viewport.GetScissorBounds(World.Type != WorldType.Editor);
		Game.Renderer.EnableScissor(scissorBounds);
		if (enableDepthBuffer)
		{
			Game.Renderer.Context.EnableDepthBuffer();
		}
		terrainRenderer?.RenderTerrain(this, Viewport);
		Game.Renderer.Flush();
		for (int i = 0; i < preparedRenderables.Count; i++)
		{
			preparedRenderables[i].Render(this);
		}
		if (enableDepthBuffer)
		{
			Game.Renderer.ClearDepthBuffer();
		}
		ApplyPostProcessing(PostProcessPassType.AfterActors);
		World.ApplyToActorsWithTrait((Actor actor, IRenderAboveWorld trait) =>
		{
			if (actor.IsInWorld && !actor.Disposed)
			{
				trait.RenderAboveWorld(actor, this);
			}
		});
		if (enableDepthBuffer)
		{
			Game.Renderer.ClearDepthBuffer();
		}
		ApplyPostProcessing(PostProcessPassType.AfterWorld);
		World.ApplyToActorsWithTrait((Actor actor, IRenderShroud trait) =>
		{
			trait.RenderShroud(this);
		});
		if (enableDepthBuffer)
		{
			Game.Renderer.Context.DisableDepthBuffer();
		}
		Game.Renderer.DisableScissor();
		IEnumerable<IGrouping<Type, IFinalizedRenderable>> enumerable = from prs in preparedOverlayRenderables
			group prs by prs.GetType();
		foreach (IGrouping<Type, IFinalizedRenderable> item in enumerable)
		{
			foreach (IFinalizedRenderable item2 in item)
			{
				item2.Render(this);
			}
		}
		ApplyPostProcessing(PostProcessPassType.AfterShroud);
		Game.Renderer.Flush();
	}

	private void ApplyPostProcessing(PostProcessPassType type)
	{
		IRenderPostProcessPass[] array = postProcessPasses;
		foreach (IRenderPostProcessPass renderPostProcessPass in array)
		{
			if (renderPostProcessPass.Type == type && renderPostProcessPass.Enabled)
			{
				Game.Renderer.Flush();
				renderPostProcessPass.Draw(this);
			}
		}
	}

	public void DrawAnnotations()
	{
		Game.Renderer.EnableAntialiasingFilter();
		for (int i = 0; i < preparedAnnotationRenderables.Count; i++)
		{
			preparedAnnotationRenderables[i].Render(this);
		}
		Game.Renderer.DisableAntialiasingFilter();
		if (debugVis.Value != null && debugVis.Value.RenderGeometry)
		{
			for (int j = 0; j < preparedRenderables.Count; j++)
			{
				preparedRenderables[j].RenderDebugGeometry(this);
			}
			for (int k = 0; k < preparedOverlayRenderables.Count; k++)
			{
				preparedOverlayRenderables[k].RenderDebugGeometry(this);
			}
			for (int l = 0; l < preparedAnnotationRenderables.Count; l++)
			{
				preparedAnnotationRenderables[l].RenderDebugGeometry(this);
			}
		}
		if (debugVis.Value != null && debugVis.Value.ScreenMap)
		{
			foreach (Rectangle item in World.ScreenMap.RenderBounds(World.RenderPlayer))
			{
				int2 int3 = Viewport.WorldToViewPx((float3)new float2(item.Left, item.Top));
				int2 int4 = Viewport.WorldToViewPx((float3)new float2(item.Right, item.Bottom));
				Game.Renderer.RgbaColorRenderer.DrawRect((float3)int3, (float3)int4, 1f, Color.MediumSpringGreen);
			}
			foreach (Polygon item2 in World.ScreenMap.MouseBounds(World.RenderPlayer))
			{
				float2[] array = new float2[item2.Vertices.Length];
				for (int m = 0; m < item2.Vertices.Length; m++)
				{
					int2 world = item2.Vertices[m];
					array[m] = Viewport.WorldToViewPx(world).ToFloat2();
				}
				Game.Renderer.RgbaColorRenderer.DrawPolygon(array, 1f, Color.OrangeRed);
			}
		}
		Game.Renderer.Flush();
		preparedRenderables.Clear();
		preparedOverlayRenderables.Clear();
		preparedAnnotationRenderables.Clear();
	}

	public void RefreshPalette()
	{
		palette.ApplyModifiers(World.WorldActor.TraitsImplementing<IPaletteModifier>());
		Game.Renderer.SetPalette(palette);
	}

	public float2 ScreenPosition(WPos pos)
	{
		return new float2((float)TileSize.Width * (float)pos.X / (float)TileScale, (float)TileSize.Height * (float)(pos.Y - pos.Z) / (float)TileScale);
	}

	public float3 Screen3DPosition(WPos pos)
	{
		float z = (float)pos.Y * (float)TileSize.Height / (float)TileScale;
		return new float3((float)TileSize.Width * (float)pos.X / (float)TileScale, (float)TileSize.Height * (float)(pos.Y - pos.Z) / (float)TileScale, z);
	}

	public int2 ScreenPxPosition(WPos pos)
	{
		float2 float4 = ScreenPosition(pos);
		return new int2((int)Math.Round(float4.X), (int)Math.Round(float4.Y));
	}

	public float3 Screen3DPxPosition(WPos pos)
	{
		float3 float4 = Screen3DPosition(pos);
		return new float3((float)Math.Round(float4.X), (float)Math.Round(float4.Y), float4.Z);
	}

	public float3 ScreenVectorComponents(in WVec vec)
	{
		return new float3((float)TileSize.Width * (float)vec.X / (float)TileScale, (float)TileSize.Height * (float)(vec.Y - vec.Z) / (float)TileScale, (float)TileSize.Height * (float)vec.Z / (float)TileScale);
	}

	public float[] ScreenVector(in WVec vec)
	{
		float3 float4 = ScreenVectorComponents(in vec);
		return new float[4] { float4.X, float4.Y, float4.Z, 1f };
	}

	public int2 ScreenPxOffset(in WVec vec)
	{
		float3 float4 = ScreenVectorComponents(in vec);
		return new int2((int)Math.Round(float4.X), (int)Math.Round(float4.Y));
	}

	public WPos ProjectedPosition(int2 screenPx)
	{
		return new WPos(TileScale * screenPx.X / TileSize.Width, TileScale * screenPx.Y / TileSize.Height, 0);
	}

	public void Dispose()
	{
		World.Dispose();
		palette.Dispose();
	}
}
