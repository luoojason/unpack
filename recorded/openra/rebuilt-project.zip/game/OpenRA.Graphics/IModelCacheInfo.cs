using OpenRA.Traits;

namespace OpenRA.Graphics;

public interface IModelCacheInfo : ITraitInfoInterface
{
}
