using System;
using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class Sprite
{
	public readonly Rectangle Bounds;

	public readonly Sheet Sheet;

	public readonly BlendMode BlendMode;

	public readonly TextureChannel Channel;

	public readonly float ZRamp;

	public readonly float3 Size;

	public readonly float3 Offset;

	public readonly float Top;

	public readonly float Left;

	public readonly float Bottom;

	public readonly float Right;

	public Sprite(Sheet sheet, Rectangle bounds, TextureChannel channel, float scale = 1f)
		: this(sheet, bounds, 0f, (float3)float2.Zero, channel, BlendMode.Alpha, scale)
	{
	}

	public Sprite(Sheet sheet, Rectangle bounds, float zRamp, in float3 offset, TextureChannel channel, BlendMode blendMode = BlendMode.Alpha, float scale = 1f)
	{
		Sheet = sheet;
		Bounds = bounds;
		Offset = offset;
		ZRamp = zRamp;
		Channel = channel;
		Size = scale * new float3(bounds.Size.Width, bounds.Size.Height, (float)bounds.Size.Height * zRamp);
		BlendMode = blendMode;
		Left = ((float)Math.Min(bounds.Left, bounds.Right) + 1f / 128f) / (float)sheet.Size.Width;
		Top = ((float)Math.Min(bounds.Top, bounds.Bottom) + 1f / 128f) / (float)sheet.Size.Height;
		Right = ((float)Math.Max(bounds.Left, bounds.Right) - 1f / 128f) / (float)sheet.Size.Width;
		Bottom = ((float)Math.Max(bounds.Top, bounds.Bottom) - 1f / 128f) / (float)sheet.Size.Height;
	}
}
