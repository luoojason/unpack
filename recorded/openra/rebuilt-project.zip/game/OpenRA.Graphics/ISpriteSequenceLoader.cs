using System.Collections.Generic;

namespace OpenRA.Graphics;

public interface ISpriteSequenceLoader
{
	int BgraSheetSize { get; }

	int IndexedSheetSize { get; }

	IReadOnlyDictionary<string, ISpriteSequence> ParseSequences(ModData modData, string tileSet, SpriteCache cache, MiniYamlNode node);
}
