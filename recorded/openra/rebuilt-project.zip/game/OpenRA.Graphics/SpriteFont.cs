using System;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA.Graphics;

public sealed class SpriteFont : IDisposable
{
	private readonly int size;

	private readonly SheetBuilder builder;

	private readonly IFont font;

	private readonly Cache<char, GlyphInfo> glyphs;

	private readonly Cache<(char C, int Radius), Sprite> contrastGlyphs;

	private readonly Cache<int, float[]> dilationElements;

	private float deviceScale;

	public int TopOffset { get; }

	public SpriteFont(IPlatform platform, string name, byte[] data, int size, int ascender, float scale, SheetBuilder builder)
	{
		if (builder.Type != SheetType.BGRA)
		{
			throw new ArgumentException("The sheet builder must create BGRA sheets.", "builder");
		}
		deviceScale = scale;
		this.size = size;
		this.builder = builder;
		font = platform.CreateFont(data);
		glyphs = new Cache<char, GlyphInfo>(CreateGlyph);
		contrastGlyphs = new Cache<(char, int), Sprite>(CreateContrastGlyph);
		dilationElements = new Cache<int, float[]>(CreateCircularWeightMap);
		if (size <= 24)
		{
			using (new PerfTimer($"Precache {name} {size}px"))
			{
				for (char c = ' '; c < '\u007f'; c = (char)(c + 1))
				{
					if (glyphs[c] == null)
					{
						throw new InvalidOperationException();
					}
				}
			}
		}
		TopOffset = size - ascender;
	}

	public void SetScale(float scale)
	{
		deviceScale = scale;
		glyphs.Clear();
		contrastGlyphs.Clear();
	}

	private void DrawTextContrast(string text, float2 location, Color contrastColor, int contrastOffset)
	{
		location += new float2(0f, size);
		int num = (int)((float)contrastOffset * deviceScale);
		int2 int3 = new int2((int)(location.X * deviceScale + 0.5f), (int)(location.Y * deviceScale + 0.5f));
		float2 float4 = new float2(num, num);
		float3 tint = new float3((float)(int)contrastColor.R / 255f, (float)(int)contrastColor.G / 255f, (float)(int)contrastColor.B / 255f);
		foreach (char c in text)
		{
			if (c == '\n')
			{
				location += new float2(0f, size);
				int3 = new int2((int)(location.X * deviceScale + 0.5f), (int)(location.Y * deviceScale + 0.5f));
				continue;
			}
			GlyphInfo glyphInfo = glyphs[c];
			if (glyphInfo.Sprite != null)
			{
				Sprite s = contrastGlyphs[(c, num)];
				Game.Renderer.RgbaSpriteRenderer.DrawSprite(s, (float3)((int3 + glyphInfo.Offset - float4) / deviceScale), 1f / deviceScale, in tint, 1f);
			}
			int3 += new int2((int)(glyphInfo.Advance + 0.5f), 0);
		}
	}

	public void DrawText(string text, float2 location, Color c)
	{
		location += new float2(0f, size);
		int2 int3 = new int2((int)(location.X * deviceScale + 0.5f), (int)(location.Y * deviceScale + 0.5f));
		float3 tint = new float3((float)(int)c.R / 255f, (float)(int)c.G / 255f, (float)(int)c.B / 255f);
		foreach (char c2 in text)
		{
			if (c2 == '\n')
			{
				location += new float2(0f, size);
				int3 = new int2((int)(location.X * deviceScale + 0.5f), (int)(location.Y * deviceScale + 0.5f));
				continue;
			}
			GlyphInfo glyphInfo = glyphs[c2];
			if (glyphInfo.Sprite != null)
			{
				Game.Renderer.RgbaSpriteRenderer.DrawSprite(glyphInfo.Sprite, (float3)((int3 + glyphInfo.Offset).ToFloat2() / deviceScale), 1f / deviceScale, in tint, 1f);
			}
			int3 += new int2((int)(glyphInfo.Advance + 0.5f), 0);
		}
	}

	private static float2 Rotate(float2 v, float sina, float cosa, float2 offset)
	{
		return new float2(v.X * cosa - v.Y * sina + offset.X, v.X * sina + v.Y * cosa + offset.Y);
	}

	public void DrawText(string text, float2 location, Color c, float angle)
	{
		float2 float4 = new float2(0f, size);
		float cosa = (float)Math.Cos(0f - angle);
		float sina = (float)Math.Sin(0f - angle);
		float3 tint = new float3((float)(int)c.R / 255f, (float)(int)c.G / 255f, (float)(int)c.B / 255f);
		float2 float5 = float4;
		foreach (char c2 in text)
		{
			if (c2 == '\n')
			{
				float4 += new float2(0f, size);
				float5 = float4;
				continue;
			}
			GlyphInfo glyphInfo = glyphs[c2];
			if (glyphInfo.Sprite != null)
			{
				float2 float6 = new float2(float5.X + (float)glyphInfo.Offset.X / deviceScale, float5.Y + (float)glyphInfo.Offset.Y / deviceScale);
				float2 v = float6 + glyphInfo.Sprite.Size.XY / deviceScale;
				float2 v2 = new float2(v.X, float6.Y);
				float2 v3 = new float2(float6.X, v.Y);
				float2 float7 = Rotate(float6, sina, cosa, location);
				float2 float8 = Rotate(v2, sina, cosa, location);
				float2 float9 = Rotate(v, sina, cosa, location);
				float2 float10 = Rotate(v3, sina, cosa, location);
				float2 float11 = new float2((int)(float7.X * deviceScale + 0.5f), (int)(float7.Y * deviceScale + 0.5f)) / deviceScale - float7;
				Game.Renderer.RgbaSpriteRenderer.DrawSprite(glyphInfo.Sprite, (float3)(float7 + float11), (float3)(float8 + float11), (float3)(float9 + float11), (float3)(float10 + float11), in tint, 1f);
			}
			float5 += new float2(glyphInfo.Advance / deviceScale, 0f);
		}
	}

	public void DrawTextWithContrast(string text, float2 location, Color fg, Color bg, int offset)
	{
		if (offset > 0)
		{
			DrawTextContrast(text, location, bg, offset);
		}
		DrawText(text, location, fg);
	}

	public void DrawTextWithContrast(string text, float2 location, Color fg, Color bgDark, Color bgLight, int offset)
	{
		DrawTextWithContrast(text, location, fg, GetContrastColor(fg, bgDark, bgLight), offset);
	}

	public void DrawTextWithShadow(string text, float2 location, Color fg, Color bg, int offset)
	{
		if (offset != 0)
		{
			float num = (float)(int)((float)offset * deviceScale) / deviceScale;
			DrawText(text, location + new float2(num, num), bg);
		}
		DrawText(text, location, fg);
	}

	public void DrawTextWithShadow(string text, float2 location, Color fg, Color bgDark, Color bgLight, int offset)
	{
		DrawTextWithShadow(text, location, fg, GetContrastColor(fg, bgDark, bgLight), offset);
	}

	public void DrawTextWithShadow(string text, float2 location, Color fg, Color bg, int offset, float angle)
	{
		if (offset != 0)
		{
			float num = (float)(int)((float)offset * deviceScale) / deviceScale;
			DrawText(text, location + new float2(num, num), bg, angle);
		}
		DrawText(text, location, fg, angle);
	}

	public void DrawTextWithShadow(string text, float2 location, Color fg, Color bgDark, Color bgLight, int offset, float angle)
	{
		DrawTextWithShadow(text, location, fg, GetContrastColor(fg, bgDark, bgLight), offset, angle);
	}

	public int2 Measure(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return new int2(0, size);
		}
		LineSplitEnumerator lineSplitEnumerator = text.SplitLines('\n');
		float num = 0f;
		int num2 = 0;
		LineSplitEnumerator enumerator = lineSplitEnumerator.GetEnumerator();
		while (enumerator.MoveNext())
		{
			ReadOnlySpan<char> current = enumerator.Current;
			num2++;
			num = Math.Max(num, LineWidth(current));
		}
		return new int2((int)Math.Ceiling(num), num2 * size);
	}

	private float LineWidth(ReadOnlySpan<char> line)
	{
		float num = 0f;
		ReadOnlySpan<char> readOnlySpan = line;
		for (int i = 0; i < readOnlySpan.Length; i++)
		{
			char key = readOnlySpan[i];
			num += glyphs[key].Advance;
		}
		return num / deviceScale;
	}

	private GlyphInfo CreateGlyph(char c)
	{
		FontGlyph fontGlyph = font.CreateGlyph(c, size, deviceScale);
		if (fontGlyph.Data == null)
		{
			return new GlyphInfo
			{
				Sprite = null,
				Advance = 0f,
				Offset = int2.Zero
			};
		}
		Sprite sprite = builder.Allocate(fontGlyph.Size);
		GlyphInfo result = new GlyphInfo
		{
			Sprite = sprite,
			Advance = fontGlyph.Advance,
			Offset = fontGlyph.Offset
		};
		byte[] data = sprite.Sheet.GetData();
		int num = sprite.Sheet.Size.Width * 4;
		for (int i = 0; (float)i < sprite.Size.Y; i++)
		{
			for (int j = 0; (float)j < sprite.Size.X; j++)
			{
				byte b = fontGlyph.Data[i * fontGlyph.Size.Width + j];
				if (b != 0)
				{
					int num2 = num * (i + sprite.Bounds.Top) + 4 * (j + sprite.Bounds.Left);
					data[num2] = b;
					data[num2 + 1] = b;
					data[num2 + 2] = b;
					data[num2 + 3] = b;
				}
			}
		}
		sprite.Sheet.CommitBufferedData();
		return result;
	}

	private float[] CreateCircularWeightMap(int r)
	{
		int num = 2 * r + 1;
		float[] array = new float[num * num];
		for (int i = 0; i <= 2 * r; i++)
		{
			for (int j = 0; j <= 2 * r; j++)
			{
				int num2 = j - r;
				int num3 = i - r;
				if (num2 * num2 + num3 * num3 > (r + 1) * (r + 1))
				{
					continue;
				}
				if (num2 * num2 + num3 * num3 < (r - 1) * (r - 1))
				{
					array[i * num + j] = 1f;
					continue;
				}
				for (int k = 0; k < 5; k++)
				{
					for (int l = 0; l < 5; l++)
					{
						float num4 = (float)num2 - (float)Math.Sign(num2) * (float)l / 5f;
						float num5 = (float)num3 - (float)Math.Sign(num3) * (float)k / 5f;
						if (num4 * num4 + num5 * num5 <= (float)(r * r))
						{
							array[i * num + j] += 0.04f;
						}
					}
				}
			}
		}
		return array;
	}

	private Sprite CreateContrastGlyph((char C, int Radius) c)
	{
		GlyphInfo glyphInfo = glyphs[c.C];
		int item = c.Radius;
		Sprite sprite = builder.Allocate(new Size(glyphInfo.Sprite.Bounds.Width + 2 * item, glyphInfo.Sprite.Bounds.Height + 2 * item));
		byte[] data = sprite.Sheet.GetData();
		int num = sprite.Sheet.Size.Width * 4;
		byte[] data2 = glyphInfo.Sprite.Sheet.GetData();
		int num2 = glyphInfo.Sprite.Sheet.Size.Width * 4;
		Rectangle bounds = glyphInfo.Sprite.Bounds;
		float[] array = dilationElements[item];
		int num3 = 2 * item + 1;
		for (int i = 0; (float)i < sprite.Size.Y; i++)
		{
			for (int j = 0; (float)j < sprite.Size.X; j++)
			{
				bool flag = true;
				byte b = 0;
				for (int k = 0; k <= 2 * item; k++)
				{
					for (int l = 0; l <= 2 * item; l++)
					{
						int num4 = j + l - 2 * item;
						int num5 = i + k - 2 * item;
						if (num4 >= 0 && num4 < bounds.Width && num5 >= 0 && num5 < bounds.Height)
						{
							byte b2 = (byte)(array[k * num3 + l] * (float)(int)data2[num2 * (num5 + bounds.Top) + 4 * (num4 + bounds.Left) + 3]);
							if (flag || b2 > b)
							{
								b = b2;
								flag = false;
							}
						}
					}
				}
				if (b > 0)
				{
					int num6 = num * (i + sprite.Bounds.Top) + 4 * (j + sprite.Bounds.Left);
					data[num6] = b;
					data[num6 + 1] = b;
					data[num6 + 2] = b;
					data[num6 + 3] = b;
				}
			}
		}
		sprite.Sheet.CommitBufferedData();
		return sprite;
	}

	private static Color GetContrastColor(Color fgColor, Color bgDark, Color bgLight)
	{
		if (!(fgColor == Color.White) && !((double)fgColor.GetBrightness() > 0.33))
		{
			return bgLight;
		}
		return bgDark;
	}

	public void Dispose()
	{
		font.Dispose();
	}
}
