namespace OpenRA.Graphics;

public interface IRenderable
{
	WPos Pos { get; }

	int ZOffset { get; }

	bool IsDecoration { get; }

	IRenderable WithZOffset(int newOffset);

	IRenderable OffsetBy(in WVec offset);

	IRenderable AsDecoration();

	IFinalizedRenderable PrepareRender(WorldRenderer wr);
}
