using System;
using System.Collections.Generic;
using OpenRA.Traits;

namespace OpenRA.Graphics;

public sealed class HardwarePalette : IDisposable
{
	private readonly Dictionary<string, ImmutablePalette> palettes = new Dictionary<string, ImmutablePalette>();

	private readonly Dictionary<string, MutablePalette> mutablePalettes = new Dictionary<string, MutablePalette>();

	private readonly Dictionary<string, int> indices = new Dictionary<string, int>();

	private byte[] buffer = Array.Empty<byte>();

	private float[] colorShiftBuffer = Array.Empty<float>();

	public ITexture Texture { get; }

	public ITexture ColorShifts { get; }

	public int Height { get; private set; }

	public HardwarePalette()
	{
		Texture = Game.Renderer.Context.CreateTexture();
		ColorShifts = Game.Renderer.Context.CreateTexture();
	}

	public bool Contains(string name)
	{
		if (!mutablePalettes.ContainsKey(name))
		{
			return palettes.ContainsKey(name);
		}
		return true;
	}

	public IPalette GetPalette(string name)
	{
		if (mutablePalettes.TryGetValue(name, out var value))
		{
			return value.AsReadOnly();
		}
		if (palettes.TryGetValue(name, out var value2))
		{
			return value2;
		}
		throw new InvalidOperationException("Palette `" + name + "` does not exist");
	}

	public int GetPaletteIndex(string name)
	{
		if (!indices.TryGetValue(name, out var value))
		{
			throw new InvalidOperationException("Palette `" + name + "` does not exist");
		}
		return value;
	}

	public void AddPalette(string name, ImmutablePalette p, bool allowModifiers)
	{
		if (palettes.ContainsKey(name))
		{
			throw new InvalidOperationException("Palette " + name + " has already been defined");
		}
		int num = palettes.Count + 1;
		indices.Add(name, num);
		palettes.Add(name, p);
		if (num >= Height)
		{
			Height = Exts.NextPowerOf2(num + 1);
			Array.Resize(ref buffer, Height * 256 * 4);
			Array.Resize(ref colorShiftBuffer, Height * 8);
		}
		if (allowModifiers)
		{
			mutablePalettes.Add(name, new MutablePalette(p));
		}
		else
		{
			CopyPaletteToBuffer(num, p);
		}
	}

	public void ReplacePalette(string name, IPalette p)
	{
		if (mutablePalettes.ContainsKey(name))
		{
			palettes[name] = new ImmutablePalette(p);
			int index = indices[name];
			MutablePalette p2 = (mutablePalettes[name] = new MutablePalette(p));
			CopyPaletteToBuffer(index, p2);
		}
		else
		{
			if (!palettes.ContainsKey(name))
			{
				throw new InvalidOperationException("Palette `" + name + "` does not exist");
			}
			int index2 = indices[name];
			ImmutablePalette p3 = (palettes[name] = new ImmutablePalette(p));
			CopyPaletteToBuffer(index2, p3);
		}
		CopyBufferToTexture();
	}

	public void SetColorShift(string name, float hueOffset, float satOffset, float valueMultiplier, float minHue, float maxHue)
	{
		int paletteIndex = GetPaletteIndex(name);
		colorShiftBuffer[8 * paletteIndex] = minHue;
		colorShiftBuffer[8 * paletteIndex + 1] = maxHue;
		colorShiftBuffer[8 * paletteIndex + 4] = hueOffset;
		colorShiftBuffer[8 * paletteIndex + 5] = satOffset;
		colorShiftBuffer[8 * paletteIndex + 6] = valueMultiplier;
	}

	public bool HasColorShift(string name)
	{
		int paletteIndex = GetPaletteIndex(name);
		if (colorShiftBuffer[8 * paletteIndex] == 0f)
		{
			return colorShiftBuffer[8 * paletteIndex + 1] != 0f;
		}
		return true;
	}

	public void Initialize()
	{
		CopyModifiablePalettesToBuffer();
		CopyBufferToTexture();
	}

	private void CopyPaletteToBuffer(int index, IPalette p)
	{
		p.CopyToArray(buffer, index * 256);
	}

	private void CopyModifiablePalettesToBuffer()
	{
		foreach (KeyValuePair<string, MutablePalette> mutablePalette in mutablePalettes)
		{
			CopyPaletteToBuffer(indices[mutablePalette.Key], mutablePalette.Value);
		}
	}

	private void CopyBufferToTexture()
	{
		Texture.SetData(buffer, 256, Height);
		ColorShifts.SetFloatData(colorShiftBuffer, 2, Height);
	}

	public void ApplyModifiers(IEnumerable<IPaletteModifier> paletteMods)
	{
		foreach (IPaletteModifier paletteMod in paletteMods)
		{
			paletteMod.AdjustPalette(mutablePalettes);
		}
		CopyModifiablePalettesToBuffer();
		CopyBufferToTexture();
		foreach (KeyValuePair<string, MutablePalette> mutablePalette in mutablePalettes)
		{
			ImmutablePalette fromPalette = palettes[mutablePalette.Key];
			MutablePalette value = mutablePalette.Value;
			value.SetFromPalette(fromPalette);
		}
	}

	public void Dispose()
	{
		Texture.Dispose();
		ColorShifts.Dispose();
	}
}
