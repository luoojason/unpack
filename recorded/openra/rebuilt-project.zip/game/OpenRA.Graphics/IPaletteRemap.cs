using OpenRA.Primitives;

namespace OpenRA.Graphics;

public interface IPaletteRemap
{
	Color GetRemappedColor(Color original, int index);
}
