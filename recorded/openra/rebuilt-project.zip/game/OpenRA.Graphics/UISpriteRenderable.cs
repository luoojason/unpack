using OpenRA.Primitives;

namespace OpenRA.Graphics;

public class UISpriteRenderable : IRenderable, IPalettedRenderable, IFinalizedRenderable
{
	private readonly Sprite sprite;

	private readonly int2 screenPos;

	private readonly float scale;

	private readonly float alpha;

	private readonly float rotation;

	public WPos Pos { get; }

	public WVec Offset => WVec.Zero;

	public bool IsDecoration => true;

	public PaletteReference Palette { get; }

	public int ZOffset { get; }

	public UISpriteRenderable(Sprite sprite, WPos effectiveWorldPos, int2 screenPos, int zOffset, PaletteReference palette, float scale = 1f, float alpha = 1f, float rotation = 0f)
	{
		this.sprite = sprite;
		Pos = effectiveWorldPos;
		this.screenPos = screenPos;
		ZOffset = zOffset;
		Palette = palette;
		this.scale = scale;
		this.alpha = alpha;
		this.rotation = rotation;
		if (sprite.Channel == TextureChannel.RGBA && (palette == null || !palette.HasColorShift))
		{
			Palette = null;
		}
	}

	public IPalettedRenderable WithPalette(PaletteReference newPalette)
	{
		return new UISpriteRenderable(sprite, Pos, screenPos, ZOffset, newPalette, scale, alpha, rotation);
	}

	public IRenderable WithZOffset(int newOffset)
	{
		return this;
	}

	public IRenderable OffsetBy(in WVec vec)
	{
		return this;
	}

	public IRenderable AsDecoration()
	{
		return this;
	}

	public IFinalizedRenderable PrepareRender(WorldRenderer wr)
	{
		return this;
	}

	public void Render(WorldRenderer wr)
	{
		Game.Renderer.SpriteRenderer.DrawSprite(sprite, Palette, (float3)screenPos, scale, in float3.Ones, alpha, rotation);
	}

	public void RenderDebugGeometry(WorldRenderer wr)
	{
		float2 float4 = screenPos + sprite.Offset.XY;
		if (rotation == 0f)
		{
			Game.Renderer.RgbaColorRenderer.DrawRect((float3)float4, (float3)(float4 + sprite.Size.XY), 1f, Color.Red);
		}
		else
		{
			Game.Renderer.RgbaColorRenderer.DrawPolygon(Util.RotateQuad(float4, sprite.Size, rotation), 1f, Color.Red);
		}
	}

	public Rectangle ScreenBounds(WorldRenderer wr)
	{
		float3 offset = (float3)screenPos + sprite.Offset;
		return Util.BoundingRectangle(offset, sprite.Size, rotation);
	}

	IRenderable IRenderable.OffsetBy(in WVec offset)
	{
		return OffsetBy(in offset);
	}
}
