namespace OpenRA.Scripting;

public interface IScriptBindable
{
}
