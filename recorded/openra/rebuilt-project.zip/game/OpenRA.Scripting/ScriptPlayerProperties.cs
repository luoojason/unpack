namespace OpenRA.Scripting;

public abstract class ScriptPlayerProperties
{
	protected readonly Player Player;

	protected readonly ScriptContext Context;

	protected ScriptPlayerProperties(ScriptContext context, Player player)
	{
		Player = player;
		Context = context;
	}
}
