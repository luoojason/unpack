namespace OpenRA.Scripting;

public abstract class ScriptActorProperties
{
	protected readonly Actor Self;

	protected readonly ScriptContext Context;

	protected ScriptActorProperties(ScriptContext context, Actor self)
	{
		Self = self;
		Context = context;
	}
}
