using System;
using System.Linq;

namespace OpenRA.Scripting;

public class ScriptActorInterface : ScriptObjectWrapper
{
	private readonly Actor actor;

	protected override string DuplicateKeyError(string memberName)
	{
		return $"Actor '{actor.Info.Name}' defines the command '{memberName}' on multiple traits";
	}

	protected override string MemberNotFoundError(string memberName)
	{
		string text = actor.Info.Name;
		if (actor.IsDead)
		{
			text += " (dead)";
		}
		return $"Actor '{text}' does not define a property '{memberName}'";
	}

	public ScriptActorInterface(ScriptContext context, Actor actor)
		: base(context)
	{
		this.actor = actor;
		InitializeBindings();
	}

	private void InitializeBindings()
	{
		Type[] array = Context.ActorCommands[actor.Info];
		if (actor.Disposed)
		{
			array = array.Where((Type c) => c.HasAttribute<ExposedForDestroyedActors>()).ToArray();
		}
		Bind(ScriptObjectWrapper.CreateObjects(array, new object[2] { Context, actor }));
	}

	public void OnActorDestroyed()
	{
		Type[] array = Context.ActorCommands[actor.Info];
		foreach (Type type in array)
		{
			if (!type.HasAttribute<ExposedForDestroyedActors>())
			{
				Unbind(type);
			}
		}
	}
}
