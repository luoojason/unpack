using System;
using System.Collections.Generic;
using System.Reflection;
using Eluant;
using Eluant.ObjectBinding;

namespace OpenRA.Scripting;

public abstract class ScriptObjectWrapper : IScriptBindable, ILuaTableBinding
{
	protected readonly ScriptContext Context;

	private readonly Dictionary<string, ScriptMemberWrapper> members = new Dictionary<string, ScriptMemberWrapper>();

	public LuaValue this[LuaRuntime runtime, LuaValue keyValue]
	{
		get
		{
			string text = keyValue.ToString();
			if (!members.TryGetValue(text, out var value))
			{
				throw new LuaException(MemberNotFoundError(text));
			}
			return value.Get(runtime);
		}
		set
		{
			string text = keyValue.ToString();
			if (!members.TryGetValue(text, out var value2))
			{
				throw new LuaException(MemberNotFoundError(text));
			}
			value2.Set(value);
		}
	}

	protected abstract string DuplicateKeyError(string memberName);

	protected abstract string MemberNotFoundError(string memberName);

	protected ScriptObjectWrapper(ScriptContext context)
	{
		Context = context;
	}

	protected static object[] CreateObjects(Type[] types, object[] constructorArgs)
	{
		int num = 0;
		Type[] array = new Type[constructorArgs.Length];
		foreach (object obj in constructorArgs)
		{
			array[num++] = obj.GetType();
		}
		object[] array2 = new object[types.Length];
		num = 0;
		foreach (Type type in types)
		{
			array2[num++] = type.GetConstructor(array).Invoke(constructorArgs);
		}
		return array2;
	}

	protected void Bind(object[] clrObjects)
	{
		members.Clear();
		foreach (object obj in clrObjects)
		{
			IEnumerable<MemberInfo> enumerable = ScriptMemberWrapper.WrappableMembers(obj.GetType());
			foreach (MemberInfo item in enumerable)
			{
				if (members.ContainsKey(item.Name))
				{
					throw new LuaException(DuplicateKeyError(item.Name));
				}
				members.Add(item.Name, new ScriptMemberWrapper(Context, obj, item));
			}
		}
	}

	protected void Unbind(Type targetType)
	{
		foreach (KeyValuePair<string, ScriptMemberWrapper> member in members)
		{
			if (targetType == member.Value.Target.GetType())
			{
				members.Remove(member.Key);
			}
		}
	}

	public bool ContainsKey(string key)
	{
		return members.ContainsKey(key);
	}
}
