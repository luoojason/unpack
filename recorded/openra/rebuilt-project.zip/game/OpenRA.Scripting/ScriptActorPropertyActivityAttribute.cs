using System;

namespace OpenRA.Scripting;

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Property)]
public sealed class ScriptActorPropertyActivityAttribute : Attribute
{
}
