using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace OpenRA.Scripting;

public static class ScriptMemberExts
{
	private static readonly Dictionary<string, string> LuaTypeNameReplacements = new Dictionary<string, string>
	{
		{ "Void", "void" },
		{ "Int32", "int" },
		{ "String", "string" },
		{ "Boolean", "bool" }
	};

	public static string LuaDocString(this Type t)
	{
		if (!LuaTypeNameReplacements.TryGetValue(t.Name, out var value))
		{
			value = t.Name;
		}
		if (t.IsGenericType && t.GetGenericTypeDefinition() == typeof(Nullable<>))
		{
			value = t.GetGenericArguments()[0].LuaDocString() + "?";
		}
		return value;
	}

	public static string LuaDocString(this ParameterInfo pi)
	{
		string text = pi.ParameterType.LuaDocString() + " " + pi.Name;
		if (pi.IsOptional)
		{
			text += $" = {pi.DefaultValue ?? "nil"}";
		}
		return text;
	}

	public static string LuaDocString(this MemberInfo mi)
	{
		MethodInfo methodInfo = mi as MethodInfo;
		if (methodInfo != null)
		{
			IEnumerable<string> ts = from pi in methodInfo.GetParameters()
				select pi.LuaDocString();
			return $"{methodInfo.ReturnType.LuaDocString()} {mi.Name}({ts.JoinWith(", ")})";
		}
		PropertyInfo propertyInfo = mi as PropertyInfo;
		if (propertyInfo != null)
		{
			List<string> list = new List<string>();
			if (propertyInfo.GetGetMethod() != null)
			{
				list.Add("get;");
			}
			if (propertyInfo.GetSetMethod() != null)
			{
				list.Add("set;");
			}
			return $"{propertyInfo.PropertyType.LuaDocString()} {mi.Name} {{ {list.JoinWith(" ")} }}";
		}
		return "Unknown field: " + mi.Name;
	}
}
