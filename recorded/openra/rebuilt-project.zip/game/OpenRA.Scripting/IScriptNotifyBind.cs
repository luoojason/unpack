namespace OpenRA.Scripting;

public interface IScriptNotifyBind
{
	void OnScriptBind(ScriptContext context);
}
