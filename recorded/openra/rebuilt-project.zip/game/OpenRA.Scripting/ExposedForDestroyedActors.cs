using System;

namespace OpenRA.Scripting;

[AttributeUsage(AttributeTargets.Class)]
public sealed class ExposedForDestroyedActors : Attribute
{
}
