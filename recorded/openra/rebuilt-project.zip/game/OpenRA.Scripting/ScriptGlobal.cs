using System;
using System.Collections.Generic;
using System.Linq;
using Eluant;

namespace OpenRA.Scripting;

public abstract class ScriptGlobal : ScriptObjectWrapper
{
	public readonly string Name;

	protected override string DuplicateKeyError(string memberName)
	{
		return $"Table '{Name}' defines multiple members '{memberName}'";
	}

	protected override string MemberNotFoundError(string memberName)
	{
		return $"Table '{Name}' does not define a property '{memberName}'";
	}

	protected ScriptGlobal(ScriptContext context)
		: base(context)
	{
		Type type = GetType();
		ScriptGlobalAttribute[] customAttributes = type.GetCustomAttributes<ScriptGlobalAttribute>(inherit: true);
		if (customAttributes.Length != 1)
		{
			throw new InvalidOperationException($"[ScriptGlobal] attribute not found for global table '{type}'");
		}
		Name = customAttributes[0].Name;
		object[] clrObjects = new ScriptGlobal[1] { this };
		Bind(clrObjects);
	}

	protected IEnumerable<T> FilteredObjects<T>(IEnumerable<T> objects, LuaFunction filter)
	{
		if (filter != null)
		{
			objects = objects.Where((T a) =>
			{
				using LuaValue luaValue = a.ToLuaValue(Context);
				using LuaVararg luaVararg = filter.Call(luaValue);
				using LuaValue luaValue2 = luaVararg[0];
				return luaValue2.ToBoolean();
			});
		}
		return objects;
	}
}
