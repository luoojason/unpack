using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Eluant;
using OpenRA.Traits;

namespace OpenRA.Scripting;

public class ScriptMemberWrapper
{
	private readonly ScriptContext context;

	public readonly object Target;

	public readonly MemberInfo Member;

	public readonly bool IsMethod;

	public readonly bool IsGetProperty;

	public readonly bool IsSetProperty;

	public ScriptMemberWrapper(ScriptContext context, object target, MemberInfo mi)
	{
		this.context = context;
		Target = target;
		Member = mi;
		PropertyInfo propertyInfo = mi as PropertyInfo;
		if (propertyInfo != null)
		{
			IsGetProperty = propertyInfo.GetGetMethod() != null;
			IsSetProperty = propertyInfo.GetSetMethod() != null;
		}
		else
		{
			IsMethod = true;
		}
	}

	private LuaValue Invoke(LuaVararg args)
	{
		object[] array = null;
		try
		{
			if (!IsMethod)
			{
				throw new LuaException("Trying to invoke a ScriptMemberWrapper that isn't a method!");
			}
			MethodInfo methodInfo = (MethodInfo)Member;
			ParameterInfo[] parameters = methodInfo.GetParameters();
			array = new object[parameters.Length];
			int count = args.Count;
			for (int i = 0; i < parameters.Length; i++)
			{
				if (i >= count)
				{
					if (!parameters[i].IsOptional)
					{
						throw new LuaException($"Argument '{parameters[i].LuaDocString()}' of '{Member.LuaDocString()}' is not optional.");
					}
					array[i] = parameters[i].DefaultValue;
				}
				else if (!args[i].TryGetClrValue(parameters[i].ParameterType, out array[i]))
				{
					throw new LuaException($"Unable to convert parameter {i} to {parameters[i].ParameterType.Name}");
				}
			}
			return methodInfo.Invoke(Target, array).ToLuaValue(context);
		}
		finally
		{
			foreach (LuaValue arg in args)
			{
				arg.Dispose();
			}
			args.Dispose();
			if (array != null)
			{
				object[] array2 = array;
				foreach (object obj in array2)
				{
					if (obj is LuaValue[] array3)
					{
						LuaValue[] array4 = array3;
						foreach (LuaValue luaValue in array4)
						{
							luaValue.Dispose();
						}
					}
				}
			}
		}
	}

	public LuaValue Get(LuaRuntime runtime)
	{
		if (IsMethod)
		{
			return runtime.CreateFunctionFromDelegate(new Func<LuaVararg, LuaValue>(Invoke));
		}
		if (IsGetProperty)
		{
			return ((PropertyInfo)Member).GetValue(Target, null).ToLuaValue(context);
		}
		throw new LuaException("The property '" + Member.Name + "' is write-only");
	}

	public void Set(LuaValue value)
	{
		if (IsSetProperty)
		{
			PropertyInfo propertyInfo = (PropertyInfo)Member;
			if (!value.TryGetClrValue(propertyInfo.PropertyType, out var clrObject))
			{
				throw new LuaException($"Unable to convert '{value.WrappedClrType().Name}' to CLR type '{propertyInfo.PropertyType}'");
			}
			propertyInfo.SetValue(Target, clrObject, null);
			return;
		}
		throw new LuaException("The property '" + Member.Name + "' is read-only");
	}

	public static IEnumerable<MemberInfo> WrappableMembers(Type t)
	{
		MemberInfo[] members = t.GetMembers(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public);
		foreach (MemberInfo mi in members)
		{
			if (mi is PropertyInfo)
			{
				yield return mi;
			}
			MethodInfo methodInfo = mi as MethodInfo;
			if (methodInfo != null && !methodInfo.IsGenericMethodDefinition && !methodInfo.IsSpecialName)
			{
				yield return mi;
			}
		}
	}

	public static string[] RequiredTraitNames(Type t)
	{
		IEnumerable<Type> source = from i in t.GetInterfaces()
			where i.IsGenericType && i.GetGenericTypeDefinition() == typeof(Requires<>)
			select i;
		return (from g in source.SelectMany((Type i) => i.GetGenericArguments())
			select g.Name.Split('.', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() into s
			select (!s.EndsWith("Info", StringComparison.Ordinal)) ? s : s.Remove(s.Length - 4, 4)).ToArray();
	}
}
