namespace OpenRA.Scripting;

public class ScriptPlayerInterface : ScriptObjectWrapper
{
	private readonly Player player;

	protected override string DuplicateKeyError(string memberName)
	{
		return $"Player '{player.ResolvedPlayerName}' defines the command '{memberName}' on multiple traits";
	}

	protected override string MemberNotFoundError(string memberName)
	{
		return $"Player '{player.ResolvedPlayerName}' does not define a property '{memberName}'";
	}

	public ScriptPlayerInterface(ScriptContext context, Player player)
		: base(context)
	{
		this.player = player;
		Bind(ScriptObjectWrapper.CreateObjects(context.PlayerCommands, new object[2] { context, player }));
	}
}
