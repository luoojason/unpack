using System;

namespace OpenRA.Scripting;

[AttributeUsage(AttributeTargets.Class)]
public sealed class ScriptPropertyGroupAttribute : Attribute
{
	public readonly string Category;

	public ScriptPropertyGroupAttribute(string category)
	{
		Category = category;
	}
}
