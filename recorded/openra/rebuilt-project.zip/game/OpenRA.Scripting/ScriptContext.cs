using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using Eluant;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA.Scripting;

public sealed class ScriptContext : IDisposable
{
	private const int MaxUserScriptMemory = 52428800;

	private const int MaxUserScriptInstructions = 1000000;

	private readonly MemoryConstrainedLuaRuntime runtime;

	private readonly LuaFunction tick;

	private readonly Type[] knownActorCommands;

	public readonly Cache<ActorInfo, Type[]> ActorCommands;

	public readonly Type[] PlayerCommands;

	public string ErrorMessage;

	private bool disposed;

	private static readonly object[] NoArguments = Array.Empty<object>();

	public World World { get; }

	public WorldRenderer WorldRenderer { get; }

	public bool FatalErrorOccurred { get; private set; }

	public ScriptContext(World world, WorldRenderer worldRenderer, IEnumerable<string> scripts)
	{
		runtime = new MemoryConstrainedLuaRuntime();
		Log.AddChannel("lua", "lua.log");
		World = world;
		WorldRenderer = worldRenderer;
		knownActorCommands = Game.ModData.ObjectCreator.GetTypesImplementing<ScriptActorProperties>().ToArray();
		ActorCommands = new Cache<ActorInfo, Type[]>(FilterActorCommands);
		Type[] knownCommands = Game.ModData.ObjectCreator.GetTypesImplementing<ScriptPlayerProperties>().ToArray();
		PlayerCommands = FilterCommands(world.Map.Rules.Actors[SystemActors.Player], knownCommands);
		string[] source = new string[13]
		{
			"ipairs", "next", "pairs", "pcall", "select", "tonumber", "tostring", "type", "unpack", "xpcall",
			"math", "string", "table"
		};
		foreach (LuaValue key in runtime.Globals.Keys)
		{
			if (!Enumerable.Contains(source, key.ToString()))
			{
				runtime.Globals[key] = null;
			}
		}
		string[] source2 = new string[2] { "random", "randomseed" };
		LuaTable luaTable = (LuaTable)runtime.Globals["math"];
		foreach (LuaValue key2 in luaTable.Keys)
		{
			if (Enumerable.Contains(source2, key2.ToString()))
			{
				luaTable[key2] = null;
			}
		}
		runtime.Globals["EngineDir"] = Platform.EngineDir;
		using (LuaFunction value = runtime.CreateFunctionFromDelegate(new Action<string>(FatalError)))
		{
			runtime.Globals["FatalError"] = value;
		}
		runtime.Globals["MaxUserScriptInstructions"] = 1000000.0;
		using (LuaFunction value2 = runtime.CreateFunctionFromDelegate(new Action<string>(LogDebugMessage)))
		{
			runtime.Globals["print"] = value2;
		}
		IEnumerable<Type> typesImplementing = Game.ModData.ObjectCreator.GetTypesImplementing<ScriptGlobal>();
		foreach (Type item in typesImplementing)
		{
			ConstructorInfo constructorInfo = item.GetConstructors(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault((ConstructorInfo c) =>
			{
				ParameterInfo[] parameters2 = c.GetParameters();
				return parameters2.Length == 1 && parameters2[0].ParameterType == typeof(ScriptContext);
			});
			if (constructorInfo == null)
			{
				throw new InvalidOperationException(item.Name + " must define a constructor that takes a ScriptContext context parameter");
			}
			object[] parameters = new ScriptContext[1] { this };
			ScriptGlobal scriptGlobal = (ScriptGlobal)constructorInfo.Invoke(parameters);
			using LuaValue value3 = scriptGlobal.ToLuaValue(this);
			runtime.Globals.Add(scriptGlobal.Name, value3);
		}
		runtime.MaxMemoryUse = runtime.MemoryUse + 52428800;
		try
		{
			foreach (string script in scripts)
			{
				runtime.DoBuffer(world.Map.Open(script).ReadAllText(), script).Dispose();
			}
		}
		catch (Exception e)
		{
			FatalError(e);
			return;
		}
		tick = runtime.Globals["Tick"] as LuaFunction;
	}

	private void LogDebugMessage(string message)
	{
		Console.WriteLine("Lua debug: " + message);
		Log.Write("lua", message);
	}

	public void FatalError(Exception e)
	{
		ErrorMessage = e.Message;
		Console.WriteLine("Fatal Lua Error: " + e.Message);
		Console.WriteLine(e.StackTrace);
		Log.Write("lua", "Fatal Lua Error: " + e.Message);
		Log.Write("lua", e.StackTrace);
		FatalErrorOccurred = true;
		World.AddFrameEndTask((World w) =>
		{
			World.EndGame();
		});
	}

	private void FatalError(string message)
	{
		string value = new StackTrace().ToString();
		Console.WriteLine("Fatal Lua Error: " + message);
		Console.WriteLine(value);
		Log.Write("lua", message);
		Log.Write("lua", value);
		FatalErrorOccurred = true;
		World.AddFrameEndTask((World w) =>
		{
			World.EndGame();
		});
	}

	public void RegisterMapActor(string name, Actor a)
	{
		if (runtime.Globals.ContainsKey(name))
		{
			throw new LuaException("The global name '" + name + "' is reserved, and may not be used by a map actor");
		}
		using LuaValue value = a.ToLuaValue(this);
		runtime.Globals.Add(name, value);
	}

	public void WorldLoaded()
	{
		if (FatalErrorOccurred || !(runtime.Globals["WorldLoaded"] is LuaFunction luaFunction))
		{
			return;
		}
		try
		{
			luaFunction.Call().Dispose();
		}
		catch (LuaException e)
		{
			FatalError(e);
		}
		finally
		{
			luaFunction?.Dispose();
		}
	}

	public void Tick()
	{
		if (FatalErrorOccurred || disposed || tick == null)
		{
			return;
		}
		try
		{
			using (new PerfSample("tick_lua"))
			{
				tick.Call().Dispose();
			}
		}
		catch (LuaException e)
		{
			FatalError(e);
		}
	}

	public void Dispose()
	{
		if (!disposed)
		{
			disposed = true;
			runtime?.Dispose();
		}
	}

	private static IEnumerable<Type> ExtractRequiredTypes(Type t)
	{
		IEnumerable<Type> source = from i in t.GetInterfaces()
			where i.IsGenericType && i.GetGenericTypeDefinition() == typeof(Requires<>)
			select i;
		return source.SelectMany((Type i) => i.GetGenericArguments());
	}

	private Type[] FilterActorCommands(ActorInfo ai)
	{
		return FilterCommands(ai, knownActorCommands);
	}

	private Type[] FilterCommands(ActorInfo ai, Type[] knownCommands)
	{
		MethodInfo method = typeof(ActorInfo).GetMethod("HasTraitInfo");
		return knownCommands.Where((Type c) => ExtractRequiredTypes(c).All((Type t) => (bool)method.MakeGenericMethod(t).Invoke(ai, NoArguments))).ToArray();
	}

	public LuaTable CreateTable()
	{
		return runtime.CreateTable();
	}
}
