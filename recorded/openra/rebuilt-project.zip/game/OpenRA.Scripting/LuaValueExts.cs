using System;
using System.Collections.Generic;
using Eluant;

namespace OpenRA.Scripting;

public static class LuaValueExts
{
	public static Type WrappedClrType(this LuaValue value)
	{
		if (value.TryGetClrObject(out var obj))
		{
			return obj.GetType();
		}
		return value.GetType();
	}

	public static bool TryGetClrValue<T>(this LuaValue value, out T clrObject)
	{
		bool flag = value.TryGetClrValue(typeof(T), out var clrObject2);
		clrObject = (flag ? ((T)clrObject2) : default(T));
		return flag;
	}

	public static bool TryGetClrValue(this LuaValue value, Type t, out object clrObject)
	{
		Type underlyingType = Nullable.GetUnderlyingType(t);
		if (underlyingType != null)
		{
			t = underlyingType;
		}
		if (value.TryGetClrObject(out var obj) && obj.GetType() == t)
		{
			clrObject = obj;
			return true;
		}
		if (value is LuaNil && !t.IsValueType)
		{
			clrObject = null;
			return true;
		}
		if (value is LuaBoolean && t.IsAssignableFrom(typeof(bool)))
		{
			clrObject = value.ToBoolean();
			return true;
		}
		if (value is LuaNumber)
		{
			if (t.IsAssignableFrom(typeof(double)))
			{
				clrObject = value.ToNumber().Value;
				return true;
			}
			if (t.IsAssignableFrom(typeof(int)))
			{
				clrObject = (int)value.ToNumber().Value;
				return true;
			}
			if (t.IsAssignableFrom(typeof(short)))
			{
				clrObject = (short)value.ToNumber().Value;
				return true;
			}
			if (t.IsAssignableFrom(typeof(byte)))
			{
				clrObject = (byte)value.ToNumber().Value;
				return true;
			}
		}
		if (value is LuaString && t.IsAssignableFrom(typeof(string)))
		{
			clrObject = value.ToString();
			return true;
		}
		if (value is LuaFunction && t.IsAssignableFrom(typeof(LuaFunction)))
		{
			clrObject = value;
			return true;
		}
		if (value is LuaTable && t.IsAssignableFrom(typeof(LuaTable)))
		{
			clrObject = value;
			return true;
		}
		if (value is LuaTable luaTable && t.IsArray)
		{
			Type elementType = t.GetElementType();
			Array array = Array.CreateInstance(elementType, luaTable.Count);
			int num = 0;
			foreach (KeyValuePair<LuaValue, LuaValue> item in luaTable)
			{
				using (item.Key)
				{
					object clrObject2;
					if (elementType == typeof(LuaValue))
					{
						clrObject2 = item.Value;
					}
					else
					{
						bool flag = item.Value.TryGetClrValue(elementType, out clrObject2);
						if (!flag || !(clrObject2 is LuaValue))
						{
							item.Value.Dispose();
						}
						if (!flag)
						{
							throw new LuaException($"Unable to convert table value of type {item.Value.WrappedClrType()} to type {elementType}");
						}
					}
					array.SetValue(clrObject2, num++);
				}
			}
			clrObject = array;
			return true;
		}
		clrObject = (t.IsValueType ? Activator.CreateInstance(t) : null);
		return false;
	}

	public static LuaValue ToLuaValue(this object obj, ScriptContext context)
	{
		if (obj is LuaValue result)
		{
			return result;
		}
		if (obj == null)
		{
			return LuaNil.Instance;
		}
		if (obj is double value)
		{
			return value;
		}
		if (obj is int num)
		{
			return num;
		}
		if (obj is bool flag)
		{
			return flag;
		}
		if (obj is string text)
		{
			return text;
		}
		if (obj is IScriptBindable)
		{
			if (obj is IScriptNotifyBind scriptNotifyBind)
			{
				scriptNotifyBind.OnScriptBind(context);
			}
			return new LuaCustomClrObject(obj);
		}
		if (obj is Array array)
		{
			int num2 = 1;
			LuaTable luaTable = context.CreateTable();
			{
				foreach (object item in array)
				{
					using LuaValue key = num2++;
					using LuaValue value2 = item.ToLuaValue(context);
					luaTable.Add(key, value2);
				}
				return luaTable;
			}
		}
		throw new InvalidOperationException($"Cannot convert type '{obj.GetType()}' to Lua. Class must implement IScriptBindable.");
	}
}
