using System;

namespace OpenRA.Scripting;

[AttributeUsage(AttributeTargets.Class)]
public sealed class ScriptGlobalAttribute : Attribute
{
	public readonly string Name;

	public ScriptGlobalAttribute(string name)
	{
		Name = name;
	}
}
