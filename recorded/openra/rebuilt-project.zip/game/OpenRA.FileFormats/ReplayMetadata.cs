using System;
using System.IO;
using System.Text;

namespace OpenRA.FileFormats;

public class ReplayMetadata
{
	public const int MetaStartMarker = -1;

	public const int MetaEndMarker = -2;

	public const int MetaVersion = 1;

	public readonly GameInformation GameInfo;

	public string FilePath { get; private set; }

	public ReplayMetadata(GameInformation info)
	{
		if (info == null)
		{
			throw new ArgumentNullException("info");
		}
		GameInfo = info;
	}

	private ReplayMetadata(FileStream fs, string path)
	{
		FilePath = path;
		if (fs.ReadInt32() != -1)
		{
			throw new InvalidOperationException("Expected MetaStartMarker but found an invalid value.");
		}
		int num = fs.ReadInt32();
		if (num != 1)
		{
			throw new NotSupportedException($"Metadata version {num} is not supported");
		}
		string data = fs.ReadLengthPrefixedString(Encoding.UTF8, 102400);
		GameInfo = GameInformation.Deserialize(data, path);
	}

	public void Write(BinaryWriter writer)
	{
		writer.Write(-1);
		writer.Write(1);
		int num = 0;
		writer.Flush();
		num += writer.BaseStream.WriteLengthPrefixedString(Encoding.UTF8, GameInfo.Serialize());
		writer.Write(num);
		writer.Write(-2);
	}

	public void RenameFile(string newFilenameWithoutExtension)
	{
		string text = Path.Combine(Path.GetDirectoryName(FilePath), newFilenameWithoutExtension) + ".orarep";
		File.Move(FilePath, text);
		FilePath = text;
	}

	public static ReplayMetadata Read(string path)
	{
		try
		{
			using FileStream fileStream = new FileStream(path, FileMode.Open);
			if (!fileStream.CanSeek)
			{
				return null;
			}
			if (fileStream.Length < 20)
			{
				return null;
			}
			fileStream.Seek(-8L, SeekOrigin.End);
			int num = fileStream.ReadInt32();
			if (fileStream.ReadInt32() == -2)
			{
				fileStream.Seek(-(8 + num + 4 + 4), SeekOrigin.Current);
				return new ReplayMetadata(fileStream, path);
			}
		}
		catch (Exception ex)
		{
			Log.Write("debug", ex.ToString());
		}
		return null;
	}
}
