using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using ICSharpCode.SharpZipLib.Checksum;
using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;
using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.FileFormats;

public class Png
{
	[Flags]
	private enum PngColorType : byte
	{
		Indexed = 1,
		Color = 2,
		Alpha = 4
	}

	private enum PngFilter : byte
	{
		None,
		Sub,
		Up,
		Average,
		Paeth
	}

	private static readonly byte[] Signature = new byte[8] { 137, 80, 78, 71, 13, 10, 26, 10 };

	public Dictionary<string, string> EmbeddedData = new Dictionary<string, string>();

	public int Width { get; }

	public int Height { get; }

	public Color[] Palette { get; }

	public byte[] Data { get; }

	public SpriteFrameType Type { get; }

	public int PixelStride
	{
		get
		{
			if (Type != SpriteFrameType.Indexed8)
			{
				if (Type != SpriteFrameType.Rgb24)
				{
					return 4;
				}
				return 3;
			}
			return 1;
		}
	}

	public Png(Stream s)
	{
		if (!Verify(s))
		{
			throw new InvalidDataException("PNG Signature is bogus");
		}
		s.Position += 8L;
		bool flag = false;
		List<byte> list = new List<byte>();
		Type = SpriteFrameType.Rgba32;
		byte b = 8;
		while (true)
		{
			int num = IPAddress.NetworkToHostOrder(s.ReadInt32());
			string text = s.ReadASCII(4);
			byte[] array = s.ReadBytes(num);
			s.ReadInt32();
			if (!flag && text != "IHDR")
			{
				break;
			}
			using MemoryStream s2 = new MemoryStream(array);
			switch (text)
			{
			case "IHDR":
			{
				if (flag)
				{
					throw new InvalidDataException("Invalid PNG file - duplicate header.");
				}
				Width = IPAddress.NetworkToHostOrder(s2.ReadInt32());
				Height = IPAddress.NetworkToHostOrder(s2.ReadInt32());
				b = s2.ReadUInt8();
				PngColorType pngColorType = (PngColorType)s2.ReadUInt8();
				if (IsPaletted(b, pngColorType))
				{
					Type = SpriteFrameType.Indexed8;
				}
				else if (pngColorType == PngColorType.Color)
				{
					Type = SpriteFrameType.Rgb24;
				}
				Data = new byte[Width * Height * PixelStride];
				byte b3 = s2.ReadUInt8();
				s2.ReadUInt8();
				byte b4 = s2.ReadUInt8();
				if (b3 != 0)
				{
					throw new InvalidDataException("Compression method not supported");
				}
				if (b4 != 0)
				{
					throw new InvalidDataException("Interlacing not supported");
				}
				flag = true;
				break;
			}
			case "PLTE":
			{
				Palette = new Color[num / 3];
				for (int num11 = 0; num11 < Palette.Length; num11++)
				{
					byte red = s2.ReadUInt8();
					byte green = s2.ReadUInt8();
					byte blue = s2.ReadUInt8();
					Palette[num11] = Color.FromArgb(red, green, blue);
				}
				break;
			}
			case "tRNS":
			{
				if (Palette == null)
				{
					throw new InvalidDataException("Non-Palette indexed PNG are not supported.");
				}
				for (int num10 = 0; num10 < num; num10++)
				{
					Palette[num10] = Color.FromArgb(s2.ReadUInt8(), Palette[num10]);
				}
				break;
			}
			case "IDAT":
				list.AddRange(array);
				break;
			case "tEXt":
			{
				string text2 = s2.ReadASCIIZ();
				EmbeddedData.Add(text2, s2.ReadASCII(num - text2.Length - 1));
				break;
			}
			case "IEND":
			{
				using (MemoryStream baseInputStream = new MemoryStream(list.ToArray()))
				{
					using InflaterInputStream s3 = new InflaterInputStream(baseInputStream);
					int pixelStride = PixelStride;
					int num2 = Width * pixelStride;
					int num3 = 8 / b;
					int num4 = Exts.IntegerDivisionRoundingAwayFromZero(num2, num3);
					Span<byte> span = new byte[num2];
					for (int i = 0; i < Height; i++)
					{
						PngFilter pngFilter = (PngFilter)s3.ReadUInt8();
						s3.ReadBytes(Data, i * num2, num4);
						Span<byte> span2 = Data.AsSpan(i * num2, num2);
						if (b < 8)
						{
							int num5 = 255 >> 8 - b;
							for (int num6 = num4 - 1; num6 >= 0; num6--)
							{
								byte b2 = span2[num6];
								for (int j = 0; j < num3; j++)
								{
									int num7 = num6 * num3 + j;
									if (num7 < span2.Length)
									{
										span2[num7] = (byte)((b2 >> 8 - (j + 1) * b) & num5);
									}
								}
							}
						}
						switch (pngFilter)
						{
						case PngFilter.Sub:
						{
							for (int num8 = pixelStride; num8 < num2; num8++)
							{
								span2[num8] += span2[num8 - pixelStride];
							}
							break;
						}
						case PngFilter.Up:
						{
							for (int num9 = 0; num9 < num2; num9++)
							{
								span2[num9] += span[num9];
							}
							break;
						}
						case PngFilter.Average:
						{
							for (int m = 0; m < pixelStride; m++)
							{
								span2[m] += Average(0, span[m]);
							}
							for (int n = pixelStride; n < num2; n++)
							{
								span2[n] += Average(span2[n - pixelStride], span[n]);
							}
							break;
						}
						case PngFilter.Paeth:
						{
							for (int k = 0; k < pixelStride; k++)
							{
								span2[k] += Paeth(0, span[k], 0);
							}
							for (int l = pixelStride; l < num2; l++)
							{
								span2[l] += Paeth(span2[l - pixelStride], span[l], span[l - pixelStride]);
							}
							break;
						}
						default:
							throw new InvalidOperationException("Unsupported Filter");
						case PngFilter.None:
							break;
						}
						span = span2;
					}
				}
				if (Type == SpriteFrameType.Indexed8 && Palette == null)
				{
					throw new InvalidDataException("Non-Palette indexed PNG are not supported.");
				}
				return;
			}
			}
		}
		throw new InvalidDataException("Invalid PNG file - header does not appear first.");
	}

	public Png(byte[] data, SpriteFrameType type, int width, int height, Color[] palette = null, Dictionary<string, string> embeddedData = null)
	{
		int num = width * height;
		if (palette == null)
		{
			num *= 4;
		}
		if (data.Length != num)
		{
			throw new InvalidDataException("Input data does not match expected length");
		}
		Type = type;
		Width = width;
		Height = height;
		switch (type)
		{
		case SpriteFrameType.Indexed8:
		case SpriteFrameType.Rgba32:
		case SpriteFrameType.Rgb24:
			Data = data;
			if (type == SpriteFrameType.Indexed8)
			{
				Palette = palette;
			}
			break;
		case SpriteFrameType.Bgra32:
		case SpriteFrameType.Bgr24:
		{
			Data = new byte[data.Length];
			int pixelStride = PixelStride;
			for (int i = 0; i < width * height; i++)
			{
				Data[pixelStride * i] = data[pixelStride * i + 2];
				Data[pixelStride * i + 1] = data[pixelStride * i + 1];
				Data[pixelStride * i + 2] = data[pixelStride * i];
				if (type == SpriteFrameType.Bgra32)
				{
					Data[pixelStride * i + 3] = data[pixelStride * i + 3];
				}
			}
			break;
		}
		default:
			throw new InvalidDataException($"Unhandled SpriteFrameType {type}");
		}
		if (embeddedData != null)
		{
			EmbeddedData = embeddedData;
		}
	}

	public static bool Verify(Stream s)
	{
		long position = s.Position;
		bool result = Signature.Aggregate(seed: true, (bool current, byte t) => current && s.ReadUInt8() == t);
		s.Position = position;
		return result;
	}

	private static bool IsPaletted(byte bitDepth, PngColorType colorType)
	{
		if (bitDepth <= 8 && colorType == (PngColorType.Indexed | PngColorType.Color))
		{
			return true;
		}
		if (bitDepth == 8 && colorType == (PngColorType.Color | PngColorType.Alpha))
		{
			return false;
		}
		if (bitDepth == 8 && colorType == PngColorType.Color)
		{
			return false;
		}
		throw new InvalidDataException("Unknown pixel format");
	}

	private static void WritePngChunk(Stream output, string type, Stream input)
	{
		input.Position = 0L;
		byte[] bytes = Encoding.ASCII.GetBytes(type);
		output.Write(IPAddress.HostToNetworkOrder((int)input.Length));
		output.Write(bytes);
		byte[] array = input.ReadAllBytes();
		output.Write(array);
		Crc32 crc = new Crc32();
		crc.Update(bytes);
		crc.Update(array);
		output.Write(IPAddress.NetworkToHostOrder((int)crc.Value));
	}

	public byte[] Save()
	{
		using MemoryStream memoryStream = new MemoryStream();
		memoryStream.Write(Signature);
		using (MemoryStream memoryStream2 = new MemoryStream())
		{
			memoryStream2.Write(IPAddress.HostToNetworkOrder(Width));
			memoryStream2.Write(IPAddress.HostToNetworkOrder(Height));
			memoryStream2.WriteByte(8);
			PngColorType value;
			if (Type != SpriteFrameType.Indexed8)
			{
				value = ((Type == SpriteFrameType.Rgb24) ? PngColorType.Color : (PngColorType.Color | PngColorType.Alpha));
			}
			else
			{
				value = PngColorType.Indexed | PngColorType.Color;
			}
			memoryStream2.WriteByte((byte)value);
			memoryStream2.WriteByte(0);
			memoryStream2.WriteByte(0);
			memoryStream2.WriteByte(0);
			WritePngChunk(memoryStream, "IHDR", memoryStream2);
		}
		bool flag = false;
		if (Palette != null)
		{
			using MemoryStream memoryStream3 = new MemoryStream();
			Color[] palette = Palette;
			for (int i = 0; i < palette.Length; i++)
			{
				Color color = palette[i];
				memoryStream3.WriteByte(color.R);
				memoryStream3.WriteByte(color.G);
				memoryStream3.WriteByte(color.B);
				flag |= color.A > 0;
			}
			WritePngChunk(memoryStream, "PLTE", memoryStream3);
		}
		if (flag)
		{
			using MemoryStream memoryStream4 = new MemoryStream();
			Color[] palette2 = Palette;
			foreach (Color color2 in palette2)
			{
				memoryStream4.WriteByte(color2.A);
			}
			WritePngChunk(memoryStream, "tRNS", memoryStream4);
		}
		using (MemoryStream memoryStream5 = new MemoryStream())
		{
			using DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(memoryStream5, new Deflater(9));
			int num = Width * PixelStride;
			for (int k = 0; k < Height; k++)
			{
				deflaterOutputStream.WriteByte(0);
				deflaterOutputStream.Write(Data, k * num, num);
			}
			deflaterOutputStream.Flush();
			deflaterOutputStream.Finish();
			WritePngChunk(memoryStream, "IDAT", memoryStream5);
		}
		foreach (KeyValuePair<string, string> embeddedDatum in EmbeddedData)
		{
			using MemoryStream memoryStream6 = new MemoryStream();
			memoryStream6.Write(Encoding.ASCII.GetBytes(embeddedDatum.Key + "\0" + embeddedDatum.Value));
			WritePngChunk(memoryStream, "tEXt", memoryStream6);
		}
		WritePngChunk(memoryStream, "IEND", new MemoryStream());
		return memoryStream.ToArray();
	}

	public void Save(string path)
	{
		File.WriteAllBytes(path, Save());
	}

	private static byte Paeth(byte a, byte b, byte c)
	{
	    int p = a + b - c;
	    int pa = Math.Abs(p - a);
	    int pb = Math.Abs(p - b);
	    int pc = Math.Abs(p - c);
	    if (pa <= pb && pa <= pc)
	    {
	        return a;
	    }
	    if (pb <= pc)
	    {
	        return b;
	    }
	    return c;
	}

	private static byte Average(byte a, byte b)
	{
	    return (byte)((a + b) / 2);
	}
}
