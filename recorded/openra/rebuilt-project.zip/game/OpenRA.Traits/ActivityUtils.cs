using OpenRA.Activities;
using OpenRA.Support;

namespace OpenRA.Traits;

public static class ActivityUtils
{
	public static Activity RunActivity(Actor self, Activity act)
	{
		if (act == null)
		{
			return act;
		}
		long startTimestamp = PerfTickLogger.GetTimestamp();
		Activity activity;
		do
		{
			activity = act;
			act = act.TickOuter(self);
			startTimestamp = PerfTickLogger.LogLongTick(startTimestamp, "Activity", activity);
		}
		while (act != activity && act != null);
		return act;
	}
}
