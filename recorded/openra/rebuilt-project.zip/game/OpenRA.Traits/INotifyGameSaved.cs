namespace OpenRA.Traits;

public interface INotifyGameSaved
{
	void GameSaved(World w);
}
