using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public class FrozenActor
{
	public readonly PPos[] Footprint;

	public readonly WPos CenterPosition;

	private readonly Actor actor;

	private readonly ICreatesFrozenActors frozenTrait;

	private readonly Shroud shroud;

	private readonly List<WPos> targetablePositions = new List<WPos>();

	private readonly ITooltip[] tooltips;

	private readonly IHealth health;

	private readonly IVisibilityModifier[] visibilityModifiers;

	public IRenderable[] Renderables = NoRenderables;

	public Rectangle[] ScreenBounds = NoBounds;

	public Polygon MouseBounds = Polygon.Empty;

	private static readonly IRenderable[] NoRenderables = Array.Empty<IRenderable>();

	private static readonly Rectangle[] NoBounds = Array.Empty<Rectangle>();

	private int flashTicks;

	private TintModifiers flashModifiers;

	private float3 flashTint;

	private float? flashAlpha;

	public Player Viewer { get; }

	public Player Owner { get; private set; }

	public BitSet<TargetableType> TargetTypes { get; private set; }

	public IEnumerable<WPos> TargetablePositions => targetablePositions;

	public ITooltipInfo TooltipInfo { get; private set; }

	public Player TooltipOwner { get; private set; }

	public int HP { get; private set; }

	public DamageState DamageState { get; private set; }

	public bool Visible { get; private set; } = true;

	public bool Hidden { get; private set; }

	public bool Shrouded { get; private set; }

	public bool NeedRenderables { get; set; }

	public bool UpdateVisibilityNextTick { get; set; }

	public uint ID => actor.ActorID;

	public bool IsValid => Owner != null;

	public ActorInfo Info => actor.Info;

	public Actor Actor
	{
		get
		{
			if (actor.IsDead)
			{
				return null;
			}
			return actor;
		}
	}

	public bool HasRenderables
	{
		get
		{
			if (!Shrouded)
			{
				return Renderables.Length != 0;
			}
			return false;
		}
	}

	public FrozenActor(Actor actor, ICreatesFrozenActors frozenTrait, PPos[] footprint, Player viewer, bool startsRevealed)
	{
		this.actor = actor;
		this.frozenTrait = frozenTrait;
		Viewer = viewer;
		shroud = viewer.Shroud;
		NeedRenderables = startsRevealed;
		Footprint = footprint.Where((PPos m) => shroud.Contains(m)).ToArray();
		if (Footprint.Length == 0)
		{
			throw new ArgumentException("This frozen actor has no footprint.\nActor Name: " + actor.Info.Name + "\n" + $"Actor Location: {actor.Location}\n" + "Input footprint: [" + footprint.Select((PPos p) => p.ToString()).JoinWith("|") + "]\nInput footprint (after shroud.Contains): [" + footprint.Select((PPos p) => shroud.Contains(p).ToString()).JoinWith("|") + "]");
		}
		CenterPosition = actor.CenterPosition;
		tooltips = actor.TraitsImplementing<ITooltip>().ToArray();
		health = actor.TraitOrDefault<IHealth>();
		visibilityModifiers = actor.TraitsImplementing<IVisibilityModifier>().ToArray();
		UpdateVisibility();
	}

	public void RefreshState()
	{
		Owner = actor.Owner;
		TargetTypes = actor.GetEnabledTargetTypes();
		targetablePositions.Clear();
		targetablePositions.AddRange(actor.GetTargetablePositions());
		if (health != null)
		{
			HP = health.HP;
			DamageState = health.DamageState;
		}
		ITooltip tooltip = tooltips.FirstEnabledTraitOrDefault();
		if (tooltip != null)
		{
			TooltipInfo = tooltip.TooltipInfo;
			TooltipOwner = tooltip.Owner;
		}
	}

	public void RefreshHidden()
	{
		Hidden = false;
		IVisibilityModifier[] array = visibilityModifiers;
		foreach (IVisibilityModifier visibilityModifier in array)
		{
			if (!visibilityModifier.IsVisible(actor, Viewer))
			{
				Hidden = true;
				break;
			}
		}
	}

	public void Tick()
	{
		if (flashTicks > 0)
		{
			flashTicks--;
		}
		if (UpdateVisibilityNextTick)
		{
			UpdateVisibility();
		}
	}

	private void UpdateVisibility()
	{
		UpdateVisibilityNextTick = false;
		bool visible = Visible;
		Shrouded = true;
		Visible = true;
		PPos[] footprint = Footprint;
		foreach (PPos puv in footprint)
		{
			Shroud.CellVisibility visibility = shroud.GetVisibility(puv);
			if (visibility.HasFlag(Shroud.CellVisibility.Visible))
			{
				Visible = false;
				Shrouded = false;
				break;
			}
			if (Shrouded && visibility.HasFlag(Shroud.CellVisibility.Explored))
			{
				Shrouded = false;
			}
		}
		if (Visible != visible)
		{
			frozenTrait.OnVisibilityChanged(this);
		}
		NeedRenderables |= Visible && !visible;
	}

	public void Invalidate()
	{
		Owner = null;
	}

	public void Flash(Color color, float alpha)
	{
		flashTicks = 5;
		flashModifiers = TintModifiers.ReplaceColor;
		flashTint = new float3((int)color.R, (int)color.G, (int)color.B) / 255f;
		flashAlpha = alpha;
	}

	public void Flash(float3 tint)
	{
		flashTicks = 5;
		flashModifiers = TintModifiers.None;
		flashTint = tint;
		flashAlpha = null;
	}

	public IEnumerable<IRenderable> Render()
	{
		if (Shrouded)
		{
			return NoRenderables;
		}
		if (flashTicks > 0 && flashTicks % 2 == 0)
		{
			return Renderables.Concat(Renderables.Where((IRenderable r) => !r.IsDecoration && r is IModifyableRenderable).Select((IRenderable r) =>
			{
				IModifyableRenderable modifyableRenderable = (IModifyableRenderable)r;
				modifyableRenderable = modifyableRenderable.WithTint(in flashTint, modifyableRenderable.TintModifiers | flashModifiers);
				if (flashAlpha.HasValue)
				{
					modifyableRenderable = modifyableRenderable.WithAlpha(flashAlpha.Value);
				}
				return modifyableRenderable;
			}));
		}
		return Renderables;
	}

	public override string ToString()
	{
		return $"{Info.Name} {ID}{(IsValid ? "" : " (invalid)")}";
	}
}
