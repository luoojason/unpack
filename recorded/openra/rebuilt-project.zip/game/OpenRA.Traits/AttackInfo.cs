namespace OpenRA.Traits;

public class AttackInfo
{
	public Damage Damage;

	public Actor Attacker;

	public DamageState DamageState;

	public DamageState PreviousDamageState;
}
