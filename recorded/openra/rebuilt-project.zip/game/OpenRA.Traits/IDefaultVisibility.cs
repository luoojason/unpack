namespace OpenRA.Traits;

public interface IDefaultVisibility
{
	bool IsVisible(Actor self, Player byPlayer);
}
