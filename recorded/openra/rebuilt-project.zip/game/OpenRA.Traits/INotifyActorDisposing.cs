namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyActorDisposing
{
	void Disposing(Actor self);
}
