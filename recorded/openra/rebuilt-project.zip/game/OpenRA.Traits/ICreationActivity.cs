using OpenRA.Activities;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface ICreationActivity
{
	Activity GetCreationActivity();
}
