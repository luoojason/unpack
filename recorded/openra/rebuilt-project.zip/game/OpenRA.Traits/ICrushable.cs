using OpenRA.Primitives;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface ICrushable
{
	bool CrushableBy(Actor self, Actor crusher, BitSet<CrushClass> crushClasses);

	LongBitSet<PlayerBitMask> CrushableBy(Actor self, BitSet<CrushClass> crushClasses);
}
