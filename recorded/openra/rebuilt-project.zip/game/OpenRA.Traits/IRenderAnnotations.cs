using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface IRenderAnnotations
{
	bool SpatiallyPartitionable { get; }

	IEnumerable<IRenderable> RenderAnnotations(Actor self, WorldRenderer wr);
}
