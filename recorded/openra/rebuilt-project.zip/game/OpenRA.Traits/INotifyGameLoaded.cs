namespace OpenRA.Traits;

public interface INotifyGameLoaded
{
	void GameLoaded(World w);
}
