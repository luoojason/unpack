namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface IObservesVariablesInfo : ITraitInfoInterface
{
}
