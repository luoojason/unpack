using OpenRA.Primitives;

namespace OpenRA.Traits;

public class Damage
{
	public readonly int Value;

	public readonly BitSet<DamageType> DamageTypes;

	public Damage(int damage, BitSet<DamageType> damageTypes)
	{
		Value = damage;
		DamageTypes = damageTypes;
	}

	public Damage(int damage)
	{
		Value = damage;
		DamageTypes = default;
	}
}
