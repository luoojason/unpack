namespace OpenRA.Traits;

public interface INotifyOwnerLost
{
	void OnOwnerLost(Actor self);
}
