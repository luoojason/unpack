namespace OpenRA.Traits;

public interface IBot
{
	IBotInfo Info { get; }

	Player Player { get; }

	void Activate(Player p);

	void QueueOrder(Order order);
}
