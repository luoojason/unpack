using System.Collections.Generic;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface IMapPreviewSignatureInfo : ITraitInfoInterface
{
	void PopulateMapPreviewSignatureCells(Map map, ActorInfo ai, ActorReference s, List<(MPos Uv, Color Color)> destinationBuffer);
}
