using System;

namespace OpenRA.Traits;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class ConsumedConditionReferenceAttribute : Attribute
{
}
