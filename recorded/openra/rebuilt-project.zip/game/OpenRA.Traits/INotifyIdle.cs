namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyIdle
{
	void TickIdle(Actor self);
}
