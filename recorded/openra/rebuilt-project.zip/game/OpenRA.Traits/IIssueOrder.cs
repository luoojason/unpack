using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IIssueOrder
{
	IEnumerable<IOrderTargeter> Orders { get; }

	Order IssueOrder(Actor self, IOrderTargeter order, in Target target, bool queued);
}
