using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface ILoadsPlayerPalettes
{
	void LoadPlayerPalettes(WorldRenderer wr, string playerName, Color playerColor, bool replaceExisting);
}
