namespace OpenRA.Traits;

public interface IHealthInfo : ITraitInfoInterface
{
	int MaxHP { get; }
}
