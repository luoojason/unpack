namespace OpenRA.Traits;

public interface IOccupySpace
{
	WPos CenterPosition { get; }

	CPos TopLeft { get; }

	(CPos Cell, SubCell SubCell)[] OccupiedCells();
}
