namespace OpenRA.Traits;

public interface IMouseBoundsInfo : ITraitInfoInterface
{
}
