using System;

namespace OpenRA.Traits;

[Flags]
public enum DamageState
{
	Undamaged = 1,
	Light = 2,
	Medium = 4,
	Heavy = 8,
	Critical = 0x10,
	Dead = 0x20
}
