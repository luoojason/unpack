using OpenRA.Network;
using OpenRA.Support;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface IAssignSpawnPoints
{
	CPos AssignHomeLocation(World world, Session.Client client, MersenneTwister playerRandom);

	int SpawnPointForPlayer(Player player);
}
