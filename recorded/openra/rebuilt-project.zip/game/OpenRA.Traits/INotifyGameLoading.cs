namespace OpenRA.Traits;

public interface INotifyGameLoading
{
	void GameLoading(World w);
}
