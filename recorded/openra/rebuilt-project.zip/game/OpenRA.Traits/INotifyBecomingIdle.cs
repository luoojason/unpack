namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyBecomingIdle
{
	void OnBecomingIdle(Actor self);
}
