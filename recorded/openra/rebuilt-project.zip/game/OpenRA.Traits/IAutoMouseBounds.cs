using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface IAutoMouseBounds
{
	Rectangle AutoMouseoverBounds(Actor self, WorldRenderer wr);
}
