using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IOrderTargeter
{
	string OrderID { get; }

	int OrderPriority { get; }

	bool IsQueued { get; }

	bool CanTarget(Actor self, in Target target, ref TargetModifiers modifiers, ref string cursor);

	bool TargetOverridesSelection(Actor self, in Target target, List<Actor> actorsAt, CPos xy, TargetModifiers modifiers);
}
