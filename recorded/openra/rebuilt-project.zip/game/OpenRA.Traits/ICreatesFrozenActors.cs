namespace OpenRA.Traits;

public interface ICreatesFrozenActors
{
	void OnVisibilityChanged(FrozenActor frozen);
}
