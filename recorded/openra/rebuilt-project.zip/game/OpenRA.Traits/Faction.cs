namespace OpenRA.Traits;

public class Faction
{
}
