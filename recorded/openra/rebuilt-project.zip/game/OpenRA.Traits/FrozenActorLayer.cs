using System.Collections.Generic;
using System.Linq;
using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public class FrozenActorLayer : IRender, ITick, ISync
{
	[Sync]
	public int VisibilityHash;

	[Sync]
	public int FrozenHash;

	private readonly int binSize;

	private readonly World world;

	private readonly Player owner;

	private readonly Dictionary<uint, FrozenActor> frozenActorsById;

	private readonly SpatiallyPartitioned<FrozenActor> partitionedFrozenActors;

	public FrozenActorLayer(Actor self, FrozenActorLayerInfo info)
	{
		binSize = info.BinSize;
		world = self.World;
		owner = self.Owner;
		frozenActorsById = new Dictionary<uint, FrozenActor>();
		partitionedFrozenActors = new SpatiallyPartitioned<FrozenActor>(world.Map.MapSize.X, world.Map.MapSize.Y, binSize);
		self.Trait<Shroud>().OnShroudChanged += (PPos uv) =>
		{
			foreach (FrozenActor item in partitionedFrozenActors.At(new int2(uv.U, uv.V)))
			{
				item.UpdateVisibilityNextTick = true;
			}
		};
	}

	public void Add(FrozenActor fa)
	{
		frozenActorsById.Add(fa.ID, fa);
		world.ScreenMap.AddOrUpdate(owner, fa);
		partitionedFrozenActors.Add(fa, FootprintBounds(fa));
	}

	public void Remove(FrozenActor fa)
	{
		partitionedFrozenActors.Remove(fa);
		world.ScreenMap.Remove(owner, fa);
		frozenActorsById.Remove(fa.ID);
	}

	private static Rectangle FootprintBounds(FrozenActor fa)
	{
		PPos pPos = fa.Footprint[0];
		int u = pPos.U;
		int u2 = pPos.U;
		int v = pPos.V;
		int v2 = pPos.V;
		PPos[] footprint = fa.Footprint;
		for (int i = 0; i < footprint.Length; i++)
		{
			PPos pPos2 = footprint[i];
			if (u > pPos2.U)
			{
				u = pPos2.U;
			}
			else if (u2 < pPos2.U)
			{
				u2 = pPos2.U;
			}
			if (v > pPos2.V)
			{
				v = pPos2.V;
			}
			else if (v2 < pPos2.V)
			{
				v2 = pPos2.V;
			}
		}
		return Rectangle.FromLTRB(u, v, u2 + 1, v2 + 1);
	}

	void ITick.Tick(Actor self)
	{
		List<FrozenActor> list = null;
		VisibilityHash = 0;
		FrozenHash = 0;
		foreach (KeyValuePair<uint, FrozenActor> item in frozenActorsById)
		{
			uint key = item.Key;
			int num = (int)key;
			FrozenHash += num;
			FrozenActor value = item.Value;
			value.Tick();
			if (value.Visible)
			{
				VisibilityHash += num;
			}
			else if (value.Actor == null)
			{
				if (list == null)
				{
					list = new List<FrozenActor>();
				}
				list.Add(value);
			}
		}
		if (list == null)
		{
			return;
		}
		foreach (FrozenActor item2 in list)
		{
			Remove(item2);
		}
	}

	public virtual IEnumerable<IRenderable> Render(Actor self, WorldRenderer wr)
	{
		return (from f in world.ScreenMap.RenderableFrozenActorsInBox(owner, wr.Viewport.TopLeft, wr.Viewport.BottomRight)
			where f.Visible
			select f).SelectMany((FrozenActor ff) => ff.Render());
	}

	public IEnumerable<Rectangle> ScreenBounds(Actor self, WorldRenderer wr)
	{
		yield break;
	}

	public FrozenActor FromID(uint id)
	{
		if (!frozenActorsById.TryGetValue(id, out var value))
		{
			return null;
		}
		return value;
	}

	public IEnumerable<FrozenActor> FrozenActorsInRegion(CellRegion region, bool onlyVisible = true)
	{
		CPos topLeft = region.TopLeft;
		CPos bottomRight = region.BottomRight;
		return from fa in partitionedFrozenActors.InBox(Rectangle.FromLTRB(topLeft.X, topLeft.Y, bottomRight.X, bottomRight.Y))
			where fa.IsValid && (!onlyVisible || fa.Visible)
			select fa;
	}

	public IEnumerable<FrozenActor> FrozenActorsInCircle(World world, WPos origin, WDist r, bool onlyVisible = true)
	{
		CPos cPos = world.Map.CellContaining(origin);
		int num = (r.Length + 1023) / 1024;
		CPos cPos2 = cPos - new CVec(num, num);
		CPos cPos3 = cPos + new CVec(num, num);
		return from fa in partitionedFrozenActors.InBox(Rectangle.FromLTRB(cPos2.X, cPos2.Y, cPos3.X, cPos3.Y))
			where fa.IsValid && (!onlyVisible || fa.Visible) && (fa.CenterPosition - origin).HorizontalLengthSquared <= r.LengthSquared
			select fa;
	}
}
