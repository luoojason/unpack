using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface IPostWorldLoaded
{
	void PostWorldLoaded(World w, WorldRenderer wr);
}
