namespace OpenRA.Traits;

[TraitLocation(SystemActors.Player)]
[Desc(new string[] { "Required for FrozenUnderFog to work. Attach this to the player actor." })]
public class FrozenActorLayerInfo : TraitInfo, Requires<ShroudInfo>
{
	[Desc(new string[] { "Size of partition bins (cells)" })]
	public readonly int BinSize = 10;

	public override object Create(ActorInitializer init)
	{
		return new FrozenActorLayer(init.Self, this);
	}
}
