using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface IHealth
{
	DamageState DamageState { get; }

	int HP { get; }

	int MaxHP { get; }

	int DisplayHP { get; }

	bool IsDead { get; }

	void InflictDamage(Actor self, Actor attacker, Damage damage, bool ignoreModifiers);

	void Kill(Actor self, Actor attacker, BitSet<DamageType> damageTypes);
}
