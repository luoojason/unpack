namespace OpenRA.Traits;

public interface IControlGroupsInfo : ITraitInfoInterface
{
	string[] Groups { get; }
}
