namespace OpenRA.Traits;

public interface IProvideTooltipInfo
{
	string TooltipText { get; }

	bool IsTooltipVisible(Player forPlayer);
}
