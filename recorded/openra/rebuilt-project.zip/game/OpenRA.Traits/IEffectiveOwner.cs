namespace OpenRA.Traits;

public interface IEffectiveOwner
{
	bool Disguised { get; }

	Player Owner { get; }
}
