namespace OpenRA.Traits;

public interface IOrderVoice
{
	string VoicePhraseForOrder(Actor self, Order order);
}
