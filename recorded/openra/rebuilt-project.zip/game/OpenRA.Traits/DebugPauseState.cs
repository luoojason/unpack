namespace OpenRA.Traits;

public class DebugPauseState : ISync
{
	private readonly World world;

	[Sync]
	public bool Paused => world.Paused;

	public DebugPauseState(World world)
	{
		this.world = world;
	}
}
