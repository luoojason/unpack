namespace OpenRA.Traits;

public interface INotifyEffectiveOwnerChanged
{
	void OnEffectiveOwnerChanged(Actor self, Player oldEffectiveOwner, Player newEffectiveOwner);
}
