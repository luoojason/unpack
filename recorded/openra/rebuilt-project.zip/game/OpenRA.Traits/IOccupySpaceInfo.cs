using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IOccupySpaceInfo : ITraitInfoInterface
{
	bool SharesCell { get; }

	IReadOnlyDictionary<CPos, SubCell> OccupiedCells(ActorInfo info, CPos location, SubCell subCell = SubCell.Any);
}
