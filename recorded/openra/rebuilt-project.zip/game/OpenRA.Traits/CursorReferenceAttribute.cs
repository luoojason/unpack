using System;

namespace OpenRA.Traits;

[AttributeUsage(AttributeTargets.Field)]
public sealed class CursorReferenceAttribute : Attribute
{
	public readonly LintDictionaryReference DictionaryReference;

	public CursorReferenceAttribute(LintDictionaryReference dictionaryReference = LintDictionaryReference.None)
	{
		DictionaryReference = dictionaryReference;
	}
}
