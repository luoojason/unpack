using OpenRA.Support;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface ICreatePlayers
{
	void CreatePlayers(World w, MersenneTwister playerRandom);
}
