namespace OpenRA.Traits;

public interface IEditorPasteLayer : ITraitInfoInterface
{
}
