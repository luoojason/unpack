namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyPlayerDisconnected
{
	void PlayerDisconnected(Actor self, Player p);
}
