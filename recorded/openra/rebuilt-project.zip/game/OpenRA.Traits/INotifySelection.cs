namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifySelection
{
	void SelectionChanged();
}
