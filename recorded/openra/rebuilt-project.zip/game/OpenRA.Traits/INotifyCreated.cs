namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyCreated
{
	void Created(Actor self);
}
