using System;

namespace OpenRA.Traits;

[AttributeUsage(AttributeTargets.Field)]
public sealed class ActorReferenceAttribute : Attribute
{
	public readonly Type[] RequiredTraits;

	public readonly LintDictionaryReference DictionaryReference;

	public ActorReferenceAttribute(Type[] requiredTraits, LintDictionaryReference dictionaryReference = LintDictionaryReference.None)
	{
		RequiredTraits = requiredTraits;
		DictionaryReference = dictionaryReference;
	}

	public ActorReferenceAttribute(Type requiredTrait = null, LintDictionaryReference dictionaryReference = LintDictionaryReference.None)
	{
		RequiredTraits = ((!(requiredTrait != null)) ? Array.Empty<Type>() : new Type[1] { requiredTrait });
		DictionaryReference = dictionaryReference;
	}
}
