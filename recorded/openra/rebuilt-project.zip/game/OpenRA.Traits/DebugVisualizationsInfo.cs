namespace OpenRA.Traits;

[TraitLocation(SystemActors.World | SystemActors.EditorWorld)]
[Desc(new string[] { "Enables visualization commands. Attach this to the world actor." })]
public class DebugVisualizationsInfo : TraitInfo<DebugVisualizations>
{
}
