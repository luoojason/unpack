namespace OpenRA.Traits;

public interface IDisabledTrait
{
	bool IsTraitDisabled { get; }
}
