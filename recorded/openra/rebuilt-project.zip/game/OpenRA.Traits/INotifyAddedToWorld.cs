namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyAddedToWorld
{
	void AddedToWorld(Actor self);
}
