using System.Collections.Generic;
using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface IRender
{
	IEnumerable<IRenderable> Render(Actor self, WorldRenderer wr);

	IEnumerable<Rectangle> ScreenBounds(Actor self, WorldRenderer wr);
}
