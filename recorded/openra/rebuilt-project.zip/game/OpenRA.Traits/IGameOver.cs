namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface IGameOver
{
	void GameOver(World world);
}
