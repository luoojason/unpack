using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface IMoveInfo : ITraitInfoInterface
{
	Color GetTargetLineColor();
}
