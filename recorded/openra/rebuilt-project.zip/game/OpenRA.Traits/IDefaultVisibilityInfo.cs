namespace OpenRA.Traits;

public interface IDefaultVisibilityInfo : ITraitInfoInterface
{
}
