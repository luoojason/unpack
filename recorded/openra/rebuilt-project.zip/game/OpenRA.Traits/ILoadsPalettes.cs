using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface ILoadsPalettes
{
	void LoadPalettes(WorldRenderer wr);
}
