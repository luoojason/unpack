using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface IRenderAboveWorld
{
	void RenderAboveWorld(Actor self, WorldRenderer wr);
}
