using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface IRenderAnnotationsWhenSelected
{
	bool SpatiallyPartitionable { get; }

	IEnumerable<IRenderable> RenderAnnotations(Actor self, WorldRenderer wr);
}
