using System.Collections.Generic;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface ILobbyOptions : ITraitInfoInterface
{
	IEnumerable<LobbyOption> LobbyOptions(MapPreview map);
}
