namespace OpenRA.Traits;

public interface IFacingInfo : ITraitInfoInterface
{
	WAngle GetInitialFacing();
}
