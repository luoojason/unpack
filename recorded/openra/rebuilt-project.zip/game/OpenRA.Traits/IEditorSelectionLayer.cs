namespace OpenRA.Traits;

public interface IEditorSelectionLayer : ITraitInfoInterface
{
}
