using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface IPaletteModifier
{
	void AdjustPalette(IReadOnlyDictionary<string, MutablePalette> b);
}
