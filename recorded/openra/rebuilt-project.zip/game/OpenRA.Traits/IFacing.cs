namespace OpenRA.Traits;

public interface IFacing
{
	WAngle TurnSpeed { get; }

	WAngle Facing { get; set; }

	WRot Orientation { get; }
}
