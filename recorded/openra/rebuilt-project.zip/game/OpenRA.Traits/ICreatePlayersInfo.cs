using System.Collections.Generic;
using OpenRA.Network;
using OpenRA.Support;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface ICreatePlayersInfo : ITraitInfoInterface
{
	void CreateServerPlayers(MapPreview map, Session lobbyInfo, List<GameInformation.Player> players, MersenneTwister playerRandom);
}
