using OpenRA.FileSystem;
using OpenRA.Graphics;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface IProvidesCursorPaletteInfo : ITraitInfoInterface
{
	string Palette { get; }

	ImmutablePalette ReadPalette(IReadOnlyFileSystem fileSystem);
}
