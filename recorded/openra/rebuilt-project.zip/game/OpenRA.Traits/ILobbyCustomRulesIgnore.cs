namespace OpenRA.Traits;

public interface ILobbyCustomRulesIgnore
{
}
