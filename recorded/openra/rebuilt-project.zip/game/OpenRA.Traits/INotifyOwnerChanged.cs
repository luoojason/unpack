namespace OpenRA.Traits;

public interface INotifyOwnerChanged
{
	void OnOwnerChanged(Actor self, Player oldOwner, Player newOwner);
}
