namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifySelected
{
	void Selected(Actor self);
}
