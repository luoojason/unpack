using System.Collections.Generic;
using OpenRA.Graphics;

namespace OpenRA.Traits;

public interface IRenderAboveShroud
{
	bool SpatiallyPartitionable { get; }

	IEnumerable<IRenderable> RenderAboveShroud(Actor self, WorldRenderer wr);
}
