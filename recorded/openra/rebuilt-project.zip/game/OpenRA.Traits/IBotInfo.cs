namespace OpenRA.Traits;

public interface IBotInfo : ITraitInfoInterface
{
	string Type { get; }

	string Name { get; }
}
