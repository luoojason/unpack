namespace OpenRA.Traits;

public class DebugVisualizations
{
	public bool CombatGeometry;

	public bool RenderGeometry;

	public bool ScreenMap;

	public bool ActorTags;

	private bool depthBufferDirty = true;

	private bool depthBuffer;

	private float depthBufferContrast = 1f;

	private float depthBufferOffset;

	public bool DepthBuffer
	{
		get
		{
			return depthBuffer;
		}
		set
		{
			depthBuffer = value;
			depthBufferDirty = true;
		}
	}

	public float DepthBufferContrast
	{
		get
		{
			return depthBufferContrast;
		}
		set
		{
			depthBufferContrast = value;
			depthBufferDirty = true;
		}
	}

	public float DepthBufferOffset
	{
		get
		{
			return depthBufferOffset;
		}
		set
		{
			depthBufferOffset = value;
			depthBufferDirty = true;
		}
	}

	public void UpdateDepthBuffer()
	{
		if (depthBufferDirty)
		{
			Game.Renderer.WorldSpriteRenderer.SetDepthPreview(DepthBuffer, DepthBufferContrast, DepthBufferOffset);
			depthBufferDirty = false;
		}
	}
}
