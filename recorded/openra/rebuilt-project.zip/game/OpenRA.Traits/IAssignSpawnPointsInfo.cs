using OpenRA.Network;
using OpenRA.Support;

namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface IAssignSpawnPointsInfo : ITraitInfoInterface
{
	object InitializeState(MapPreview map, Session lobbyInfo);

	int AssignSpawnPoint(object state, Session lobbyInfo, Session.Client client, MersenneTwister playerRandom);
}
