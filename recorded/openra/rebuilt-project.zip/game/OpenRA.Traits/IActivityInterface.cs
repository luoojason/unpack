namespace OpenRA.Traits;

public interface IActivityInterface
{
}
