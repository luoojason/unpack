using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IObservesVariables
{
	IEnumerable<VariableObserver> GetVariableObservers();
}
