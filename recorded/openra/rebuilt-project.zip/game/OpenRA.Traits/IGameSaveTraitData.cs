using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IGameSaveTraitData
{
	List<MiniYamlNode> IssueTraitData(Actor self);

	void ResolveTraitData(Actor self, MiniYaml data);
}
