namespace OpenRA.Traits;

public sealed class DamageType
{
	private DamageType()
	{
	}
}
