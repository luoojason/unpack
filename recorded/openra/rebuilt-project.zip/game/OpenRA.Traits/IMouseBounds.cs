using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA.Traits;

public interface IMouseBounds
{
	Polygon MouseoverBounds(Actor self, WorldRenderer wr);
}
