using OpenRA.Primitives;

namespace OpenRA.Traits;

public readonly struct ActorBoundsPair(Actor actor, Polygon bounds)
{
	public readonly Actor Actor = actor;

	public readonly Polygon Bounds = bounds;

	public override int GetHashCode()
	{
		return Actor.GetHashCode() ^ Bounds.GetHashCode();
	}

	public override string ToString()
	{
		return Actor.Info.Name + "->" + Bounds.GetType().Name;
	}
}
