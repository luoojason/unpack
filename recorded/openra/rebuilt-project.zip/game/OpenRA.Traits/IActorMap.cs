using System;
using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IActorMap
{
	WDist LargestActorRadius { get; }

	WDist LargestBlockingActorRadius { get; }

	event Action<CPos> CellUpdated;

	IEnumerable<Actor> GetActorsAt(CPos a);

	IEnumerable<Actor> GetActorsAt(CPos a, SubCell sub);

	bool HasFreeSubCell(CPos cell, bool checkTransient = true);

	SubCell FreeSubCell(CPos cell, SubCell preferredSubCell = SubCell.Any, bool checkTransient = true);

	SubCell FreeSubCell(CPos cell, SubCell preferredSubCell, Func<Actor, bool> checkIfBlocker);

	bool AnyActorsAt(CPos a);

	bool AnyActorsAt(CPos a, SubCell sub, bool checkTransient = true);

	bool AnyActorsAt(CPos a, SubCell sub, Func<Actor, bool> withCondition);

	IEnumerable<Actor> AllActors();

	void AddInfluence(Actor self, IOccupySpace ios);

	void RemoveInfluence(Actor self, IOccupySpace ios);

	int AddCellTrigger(CPos[] cells, Action<Actor> onEntry, Action<Actor> onExit);

	IEnumerable<CPos> TriggerPositions();

	void RemoveCellTrigger(int id);

	int AddProximityTrigger(WPos pos, WDist range, WDist vRange, Action<Actor> onEntry, Action<Actor> onExit);

	void RemoveProximityTrigger(int id);

	void UpdateProximityTrigger(int id, WPos newPos, WDist newRange, WDist newVRange);

	void AddPosition(Actor a, IOccupySpace ios);

	void RemovePosition(Actor a, IOccupySpace ios);

	void UpdatePosition(Actor a, IOccupySpace ios);

	IEnumerable<Actor> ActorsInBox(WPos a, WPos b);

	void UpdateOccupiedCells(IOccupySpace ios);
}
