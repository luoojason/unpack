using System.Collections.Generic;

namespace OpenRA.Traits;

[Desc(new string[] { "Attach this to the `World` actor." })]
[TraitLocation(SystemActors.World | SystemActors.EditorWorld)]
public class FactionInfo : TraitInfo<Faction>
{
	[FluentReference]
	[Desc(new string[] { "This is the name exposed to the players." })]
	public readonly string Name;

	[Desc(new string[] { "This is the internal name for owner checks." })]
	public readonly string InternalName;

	[Desc(new string[] { "Pick a random faction as the player's faction out of this list." })]
	public readonly HashSet<string> RandomFactionMembers = new HashSet<string>();

	[Desc(new string[] { "The side that the faction belongs to. For example, England belongs to the 'Allies' side." })]
	public readonly string Side;

	[FluentReference(true)]
	[Desc(new string[] { "This is shown in the lobby as a tooltip." })]
	public readonly string Description;

	public readonly bool Selectable = true;
}
