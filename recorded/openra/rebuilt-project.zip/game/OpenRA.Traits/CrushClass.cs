namespace OpenRA.Traits;

public class CrushClass
{
}
