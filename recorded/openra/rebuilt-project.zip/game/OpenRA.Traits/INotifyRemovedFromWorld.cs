namespace OpenRA.Traits;

[RequireExplicitImplementation]
public interface INotifyRemovedFromWorld
{
	void RemovedFromWorld(Actor self);
}
