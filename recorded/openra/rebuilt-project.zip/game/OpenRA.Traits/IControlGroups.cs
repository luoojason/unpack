using System.Collections.Generic;

namespace OpenRA.Traits;

public interface IControlGroups
{
	string[] Groups { get; }

	void SelectControlGroup(int group);

	void CreateControlGroup(int group);

	void AddSelectionToControlGroup(int group);

	void CombineSelectionWithControlGroup(int group);

	void AddToControlGroup(Actor a, int group);

	void RemoveFromControlGroup(Actor a);

	int? GetControlGroupForActor(Actor a);

	IEnumerable<Actor> GetActorsInControlGroup(int group);
}
