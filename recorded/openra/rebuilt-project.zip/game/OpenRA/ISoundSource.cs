using System;

namespace OpenRA;

public interface ISoundSource : IDisposable
{
}
