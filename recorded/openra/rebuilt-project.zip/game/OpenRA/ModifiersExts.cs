using System.Collections.Generic;
using OpenRA.Traits;

namespace OpenRA;

public static class ModifiersExts
{
	[FluentReference]
	public const string Cmd = "keycode-modifier.cmd";

	[FluentReference(LintDictionaryReference.Values)]
	public static readonly IReadOnlyDictionary<Modifiers, string> ModifierFluentKeys = new Dictionary<Modifiers, string>
	{
		{
			Modifiers.None,
			"keycode-modifier.none"
		},
		{
			Modifiers.Shift,
			"keycode-modifier.shift"
		},
		{
			Modifiers.Alt,
			"keycode-modifier.alt"
		},
		{
			Modifiers.Ctrl,
			"keycode-modifier.ctrl"
		},
		{
			Modifiers.Meta,
			"keycode-modifier.meta"
		}
	};

	public static string DisplayString(Modifiers m)
	{
		if (m == Modifiers.Meta && Platform.CurrentPlatform == PlatformType.OSX)
		{
			return FluentProvider.GetMessage("keycode-modifier.cmd");
		}
		if (!ModifierFluentKeys.TryGetValue(m, out var value))
		{
			return m.ToString();
		}
		return FluentProvider.GetMessage(value);
	}
}
