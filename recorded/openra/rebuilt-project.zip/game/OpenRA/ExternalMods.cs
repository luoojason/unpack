using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.FileFormats;
using OpenRA.Graphics;
using OpenRA.Primitives;

namespace OpenRA;

public class ExternalMods : IReadOnlyDictionary<string, ExternalMod>, IEnumerable<KeyValuePair<string, ExternalMod>>, IEnumerable, IReadOnlyCollection<KeyValuePair<string, ExternalMod>>
{
	private readonly Dictionary<string, ExternalMod> mods = new Dictionary<string, ExternalMod>();

	private readonly SheetBuilder sheetBuilder;

	public ExternalMod this[string key] => mods[key];

	public int Count => mods.Count;

	public ICollection<string> Keys => mods.Keys;

	public ICollection<ExternalMod> Values => mods.Values;

	IEnumerable<string> IReadOnlyDictionary<string, ExternalMod>.Keys => ((IReadOnlyDictionary<string, ExternalMod>)mods).Keys;

	IEnumerable<ExternalMod> IReadOnlyDictionary<string, ExternalMod>.Values => ((IReadOnlyDictionary<string, ExternalMod>)mods).Values;

	private Sheet CreateSheet()
	{
		Sheet sheet = new Sheet(SheetType.BGRA, new Size(512, 512));
		sheet.CreateBuffer();
		sheet.GetTexture().ScaleFilter = TextureScaleFilter.Linear;
		return sheet;
	}

	public ExternalMods()
	{
		if (Game.Renderer != null)
		{
			sheetBuilder = new SheetBuilder(SheetType.BGRA, CreateSheet);
		}
		HashSet<string> stringPool = new HashSet<string>();
		foreach (string supportDir in GetSupportDirs(ModRegistration.User | ModRegistration.System))
		{
			string path = Path.Combine(supportDir, "ModMetadata");
			if (!Directory.Exists(path))
			{
				continue;
			}
			string[] files = Directory.GetFiles(path, "*.yaml");
			foreach (string text in files)
			{
				try
				{
					MiniYaml value = MiniYaml.FromFile(text, discardCommentsAndWhitespace: true, stringPool).First().Value;
					LoadMod(value, text);
				}
				catch (Exception e)
				{
					Log.Write("debug", "Failed to parse mod metadata file '" + text + "'");
					Log.Write("debug", e);
				}
			}
		}
	}

	private void LoadMod(MiniYaml yaml, string path = null, bool forceRegistration = false)
	{
		ExternalMod externalMod = FieldLoader.Load<ExternalMod>(yaml);
		if (sheetBuilder != null)
		{
			MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault("Icon");
			if (miniYamlNode != null && !string.IsNullOrEmpty(miniYamlNode.Value.Value))
			{
				using MemoryStream s = new MemoryStream(Convert.FromBase64String(miniYamlNode.Value.Value));
				externalMod.Icon = sheetBuilder.Add(new Png(s));
			}
			MiniYamlNode miniYamlNode2 = yaml.NodeWithKeyOrDefault("Icon2x");
			if (miniYamlNode2 != null && !string.IsNullOrEmpty(miniYamlNode2.Value.Value))
			{
				using MemoryStream s2 = new MemoryStream(Convert.FromBase64String(miniYamlNode2.Value.Value));
				externalMod.Icon2x = sheetBuilder.Add(new Png(s2), 0.5f);
			}
			MiniYamlNode miniYamlNode3 = yaml.NodeWithKeyOrDefault("Icon3x");
			if (miniYamlNode3 != null && !string.IsNullOrEmpty(miniYamlNode3.Value.Value))
			{
				using MemoryStream s3 = new MemoryStream(Convert.FromBase64String(miniYamlNode3.Value.Value));
				externalMod.Icon3x = sheetBuilder.Add(new Png(s3), 1f / 3f);
			}
		}
		string text = ExternalMod.MakeKey(externalMod);
		if ((forceRegistration || File.Exists(externalMod.LaunchPath)) && (path == null || Path.GetFileNameWithoutExtension(path) == text))
		{
			mods[text] = externalMod;
		}
	}

	internal void Register(Manifest mod, string launchPath, IEnumerable<string> launchArgs, ModRegistration registration)
	{
		if (mod.Metadata.Hidden)
		{
			return;
		}
		string text = ExternalMod.MakeKey(mod);
		MiniYamlNode miniYamlNode = new MiniYamlNode("Registration", new MiniYaml("", new MiniYamlNode[4]
		{
			new MiniYamlNode("Id", mod.Id),
			new MiniYamlNode("Version", mod.Metadata.Version),
			new MiniYamlNode("LaunchPath", launchPath),
			new MiniYamlNode("LaunchArgs", new string[1] { "Game.Mod=" + mod.Id }.Concat(launchArgs).JoinWith(", "))
		}));
		List<MiniYamlNode> list = new List<MiniYamlNode>();
		using (Stream stream = mod.Package.GetStream("icon.png"))
		{
			if (stream != null)
			{
				list.Add(new MiniYamlNode("Icon", Convert.ToBase64String(stream.ReadAllBytes())));
			}
		}
		using (Stream stream2 = mod.Package.GetStream("icon-2x.png"))
		{
			if (stream2 != null)
			{
				list.Add(new MiniYamlNode("Icon2x", Convert.ToBase64String(stream2.ReadAllBytes())));
			}
		}
		using (Stream stream3 = mod.Package.GetStream("icon-3x.png"))
		{
			if (stream3 != null)
			{
				list.Add(new MiniYamlNode("Icon3x", Convert.ToBase64String(stream3.ReadAllBytes())));
			}
		}
		miniYamlNode = miniYamlNode.WithValue(miniYamlNode.Value.WithNodesAppended(list));
		HashSet<string> hashSet = new HashSet<string>();
		if (registration.HasFlag(ModRegistration.System))
		{
			hashSet.Add(Platform.GetSupportDir(SupportDirType.System));
		}
		if (registration.HasFlag(ModRegistration.User))
		{
			hashSet.Add(Platform.GetSupportDir(SupportDirType.User));
			string supportDir = Platform.GetSupportDir(SupportDirType.LegacyUser);
			if (Directory.Exists(supportDir))
			{
				hashSet.Add(supportDir);
			}
		}
		LoadMod(miniYamlNode.Value, null, forceRegistration: true);
		string[] contents = new List<MiniYamlNode> { miniYamlNode }.ToLines().ToArray();
		foreach (string item in hashSet)
		{
			string text2 = Path.Combine(item, "ModMetadata");
			try
			{
				Directory.CreateDirectory(text2);
				File.WriteAllLines(Path.Combine(text2, text + ".yaml"), contents);
			}
			catch (Exception e)
			{
				Log.Write("debug", "Failed to register current mod metadata");
				Log.Write("debug", e);
			}
		}
	}

	internal void ClearInvalidRegistrations(ModRegistration registration)
	{
		foreach (string supportDir in GetSupportDirs(registration))
		{
			string path = Path.Combine(supportDir, "ModMetadata");
			if (!Directory.Exists(path))
			{
				continue;
			}
			string[] files = Directory.GetFiles(path, "*.yaml");
			foreach (string text in files)
			{
				string text2 = null;
				try
				{
					MiniYaml value = MiniYaml.FromFile(text).First().Value;
					ExternalMod externalMod = FieldLoader.Load<ExternalMod>(value);
					text2 = ExternalMod.MakeKey(externalMod);
					if (File.Exists(externalMod.LaunchPath) && Path.GetFileNameWithoutExtension(text) == text2 && Path.GetExtension(externalMod.LaunchPath) != ".dll")
					{
						continue;
					}
				}
				catch (Exception e)
				{
					Log.Write("debug", "Failed to parse mod metadata file '" + text + "'");
					Log.Write("debug", e);
				}
				if (Path.GetFileNameWithoutExtension(text) == text2)
				{
					mods.Remove(text2);
				}
				try
				{
					File.Delete(text);
					Log.Write("debug", "Removed invalid mod metadata file '" + text + "'");
				}
				catch (Exception e2)
				{
					Log.Write("debug", "Failed to remove mod metadata file '" + text + "'");
					Log.Write("debug", e2);
				}
			}
		}
	}

	internal void Unregister(Manifest mod, ModRegistration registration)
	{
		string text = ExternalMod.MakeKey(mod);
		mods.Remove(text);
		foreach (string supportDir in GetSupportDirs(registration))
		{
			string text2 = Path.Combine(supportDir, "ModMetadata", text + ".yaml");
			try
			{
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
			}
			catch (Exception e)
			{
				Log.Write("debug", "Failed to remove mod metadata file '" + text2 + "'");
				Log.Write("debug", e);
			}
		}
	}

	private static IEnumerable<string> GetSupportDirs(ModRegistration registration)
	{
		HashSet<string> hashSet = new HashSet<string>(4);
		if (registration.HasFlag(ModRegistration.System))
		{
			hashSet.Add(Platform.GetSupportDir(SupportDirType.System));
		}
		if (registration.HasFlag(ModRegistration.User))
		{
			hashSet.Add(Platform.GetSupportDir(SupportDirType.User));
			hashSet.Add(Platform.GetSupportDir(SupportDirType.ModernUser));
			hashSet.Add(Platform.GetSupportDir(SupportDirType.LegacyUser));
		}
		return hashSet;
	}

	public bool ContainsKey(string key)
	{
		return mods.ContainsKey(key);
	}

	public IEnumerator<KeyValuePair<string, ExternalMod>> GetEnumerator()
	{
		return mods.GetEnumerator();
	}

	public bool TryGetValue(string key, out ExternalMod value)
	{
		return mods.TryGetValue(key, out value);
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return mods.GetEnumerator();
	}
}
