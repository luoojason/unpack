namespace OpenRA;

public class ModMetadata
{
	[FluentReference]
	private readonly string Title;

	public readonly string Version;

	public readonly string Website;

	public readonly string WebIcon32;

	[FluentReference]
	private readonly string WindowTitle;

	public readonly bool Hidden;

	public string TitleTranslated => FluentProvider.GetMessage(Title);

	public string WindowTitleTranslated
	{
		get
		{
			if (WindowTitle == null)
			{
				return null;
			}
			return FluentProvider.GetMessage(WindowTitle);
		}
	}
}
