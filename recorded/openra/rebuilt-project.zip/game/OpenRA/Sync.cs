using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA;

public static class Sync
{
	private static readonly ConcurrentCache<Type, Func<object, int>> HashFunctions = new ConcurrentCache<Type, Func<object, int>>(GenerateHashFunc);

	private static readonly Dictionary<Type, MethodInfo> CustomHashFunctions = new Dictionary<Type, MethodInfo>
	{
		{
			typeof(int2),
			new Func<int2, int>(HashInt2).Method
		},
		{
			typeof(CPos),
			new Func<CPos, int>(HashCPos).Method
		},
		{
			typeof(CVec),
			new Func<CVec, int>(HashCVec).Method
		},
		{
			typeof(WDist),
			new Func<WDist, int>(HashUsingHashCode).Method
		},
		{
			typeof(WPos),
			new Func<WPos, int>(HashUsingHashCode).Method
		},
		{
			typeof(WVec),
			new Func<WVec, int>(HashUsingHashCode).Method
		},
		{
			typeof(WAngle),
			new Func<WAngle, int>(HashUsingHashCode).Method
		},
		{
			typeof(WRot),
			new Func<WRot, int>(HashUsingHashCode).Method
		},
		{
			typeof(Actor),
			new Func<Actor, int>(HashActor).Method
		},
		{
			typeof(Player),
			new Func<Player, int>(HashPlayer).Method
		},
		{
			typeof(Target),
			new Func<Target, int>(HashTarget).Method
		}
	};

	private static int unsyncCount = 0;

	internal static Func<object, int> GetHashFunction(ISync sync)
	{
		return HashFunctions[sync.GetType()];
	}

	internal static int Hash(ISync sync)
	{
		return GetHashFunction(sync)(sync);
	}

	private static void EmitSyncOpcodes(Type type, ILGenerator il)
	{
		if (CustomHashFunctions.TryGetValue(type, out var value))
		{
			il.EmitCall(OpCodes.Call, value, null);
		}
		else if (type == typeof(bool))
		{
			Label label = il.DefineLabel();
			il.Emit(OpCodes.Ldc_I4, 2730);
			il.Emit(OpCodes.Brtrue, label);
			il.Emit(OpCodes.Pop);
			il.Emit(OpCodes.Ldc_I4, 1365);
			il.MarkLabel(label);
		}
		else if (type != typeof(int))
		{
			throw new NotImplementedException("SyncAttribute on member of unhashable type: " + type.FullName);
		}
		il.Emit(OpCodes.Xor);
	}

	private static Func<object, int> GenerateHashFunc(Type t)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("hash_" + t.Name, typeof(int), new Type[1] { typeof(object) }, t);
		ILGenerator iLGenerator = dynamicMethod.GetILGenerator();
		int localIndex = iLGenerator.DeclareLocal(t).LocalIndex;
		iLGenerator.Emit(OpCodes.Ldarg_0);
		iLGenerator.Emit(OpCodes.Castclass, t);
		iLGenerator.Emit(OpCodes.Stloc, localIndex);
		iLGenerator.Emit(OpCodes.Ldc_I4_0);
		foreach (FieldInfo item in from x in t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
			where x.HasAttribute<SyncAttribute>()
			select x)
		{
			iLGenerator.Emit(OpCodes.Ldloc, localIndex);
			iLGenerator.Emit(OpCodes.Ldfld, item);
			EmitSyncOpcodes(item.FieldType, iLGenerator);
		}
		foreach (PropertyInfo item2 in from x in t.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
			where x.HasAttribute<SyncAttribute>()
			select x)
		{
			iLGenerator.Emit(OpCodes.Ldloc, localIndex);
			iLGenerator.EmitCall(OpCodes.Call, item2.GetGetMethod(nonPublic: true), null);
			EmitSyncOpcodes(item2.PropertyType, iLGenerator);
		}
		iLGenerator.Emit(OpCodes.Ret);
		return (Func<object, int>)dynamicMethod.CreateDelegate(typeof(Func<object, int>));
	}

	public static int HashInt2(int2 i2)
	{
		return ((i2.X * 5) ^ (i2.Y * 3)) / 4;
	}

	public static int HashCPos(CPos i2)
	{
		return i2.Bits;
	}

	public static int HashCVec(CVec i2)
	{
		return ((i2.X * 5) ^ (i2.Y * 3)) / 4;
	}

	public static int HashActor(Actor a)
	{
		if (a != null)
		{
			return (int)(a.ActorID << 16);
		}
		return 0;
	}

	public static int HashPlayer(Player p)
	{
		if (p != null)
		{
			return (int)((p.PlayerActor.ActorID << 16) * 1383);
		}
		return 0;
	}

	public static int HashTarget(Target t)
	{
		switch (t.Type)
		{
		case TargetType.Actor:
			return (int)((t.Actor.ActorID << 16) * 1383);
		case TargetType.FrozenActor:
		{
			Actor actor = t.FrozenActor.Actor;
			if (actor == null)
			{
				return 0;
			}
			return (int)((actor.ActorID << 16) * 1383);
		}
		case TargetType.Terrain:
			return HashUsingHashCode(t.CenterPosition);
		default:
			return 0;
		}
	}

	public static int HashUsingHashCode<T>(T t)
	{
		return t.GetHashCode();
	}

	public static void RunUnsynced(World world, Action fn)
	{
		RunUnsynced(Game.Settings.Debug.SyncCheckUnsyncedCode, world, () =>
		{
			fn();
			return true;
		});
	}

	public static void RunUnsynced(bool checkSyncHash, World world, Action fn)
	{
		RunUnsynced(checkSyncHash, world, () =>
		{
			fn();
			return true;
		});
	}

	public static T RunUnsynced<T>(World world, Func<T> fn)
	{
		return RunUnsynced(Game.Settings.Debug.SyncCheckUnsyncedCode, world, fn);
	}

	public static T RunUnsynced<T>(bool checkSyncHash, World world, Func<T> fn)
	{
		unsyncCount++;
		int num = ((((unsyncCount == 1) & checkSyncHash) && world != null) ? world.SyncHash() : 0);
		try
		{
			return fn();
		}
		finally
		{
			unsyncCount--;
			if (((unsyncCount == 0) & checkSyncHash) && world != null && !world.Disposing && num != world.SyncHash())
			{
				throw new InvalidOperationException("RunUnsynced: sync-changing code may not run here");
			}
		}
	}

	public static void AssertUnsynced(string message)
	{
		if (unsyncCount == 0)
		{
			throw new InvalidOperationException(message);
		}
	}
}
