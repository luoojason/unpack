using System;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Scripting;
using OpenRA.Support;

namespace OpenRA;

public readonly struct WVec : IEquatable<WVec>, IScriptBindable, ILuaAdditionBinding, ILuaSubtractionBinding, ILuaEqualityBinding, ILuaUnaryMinusBinding, ILuaMultiplicationBinding, ILuaDivisionBinding, ILuaTableBinding, ILuaToStringBinding
{
	public readonly int X;

	public readonly int Y;

	public readonly int Z;

	public static readonly WVec Zero = new WVec(0, 0, 0);

	public long LengthSquared => (long)X * (long)X + (long)Y * (long)Y + (long)Z * (long)Z;

	public int Length => (int)Exts.ISqrt(LengthSquared);

	public long HorizontalLengthSquared => (long)X * (long)X + (long)Y * (long)Y;

	public int HorizontalLength => (int)Exts.ISqrt(HorizontalLengthSquared);

	public long VerticalLengthSquared => (long)Z * (long)Z;

	public int VerticalLength => (int)Exts.ISqrt(VerticalLengthSquared);

	public WAngle Yaw
	{
		get
		{
			if (LengthSquared == 0L)
			{
				return WAngle.Zero;
			}
			return WAngle.ArcTan(-Y, X) - new WAngle(256);
		}
	}

	public LuaValue this[LuaRuntime runtime, LuaValue key]
	{
		get
		{
			return key.ToString() switch
			{
				"X" => (LuaValue)X, 
				"Y" => Y, 
				"Z" => Z, 
				"Facing" => new LuaCustomClrObject(Yaw), 
				_ => throw new LuaException($"WVec does not define a member '{key}'"), 
			};
		}
		set
		{
			throw new LuaException("WVec is read-only. Use WVec.New to create a new value");
		}
	}

	public WVec(int x, int y, int z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	public WVec(WDist x, WDist y, WDist z)
	{
		X = x.Length;
		Y = y.Length;
		Z = z.Length;
	}

	public static WVec operator +(in WVec a, in WVec b)
	{
		return new WVec(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
	}

	public static WVec operator -(in WVec a, in WVec b)
	{
		return new WVec(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
	}

	public static WVec operator -(in WVec a)
	{
		return new WVec(-a.X, -a.Y, -a.Z);
	}

	public static WVec operator /(in WVec a, int b)
	{
		return new WVec(a.X / b, a.Y / b, a.Z / b);
	}

	public static WVec operator *(int a, in WVec b)
	{
		return new WVec(a * b.X, a * b.Y, a * b.Z);
	}

	public static WVec operator *(in WVec a, int b)
	{
		return b * a;
	}

	public static bool operator ==(in WVec me, in WVec other)
	{
		if (me.X == other.X && me.Y == other.Y)
		{
			return me.Z == other.Z;
		}
		return false;
	}

	public static bool operator !=(in WVec me, in WVec other)
	{
		return !(me == other);
	}

	public static int Dot(in WVec a, in WVec b)
	{
		return a.X * b.X + a.Y * b.Y + a.Z * b.Z;
	}

	public WVec Rotate(in WRot rot)
	{
		rot.AsMatrix(out var mtx);
		return Rotate(ref mtx);
	}

	public WVec Rotate(ref Int32Matrix4x4 mtx)
	{
		long num = X;
		long num2 = Y;
		long num3 = Z;
		return new WVec((int)((num * mtx.M11 + num2 * mtx.M21 + num3 * mtx.M31) / mtx.M44), (int)((num * mtx.M12 + num2 * mtx.M22 + num3 * mtx.M32) / mtx.M44), (int)((num * mtx.M13 + num2 * mtx.M23 + num3 * mtx.M33) / mtx.M44));
	}

	public static WVec Lerp(in WVec a, in WVec b, int mul, int div)
	{
		return a + (b - a) * mul / div;
	}

	public static WVec LerpQuadratic(in WVec a, in WVec b, WAngle pitch, int mul, int div)
	{
		WVec result = Lerp(in a, in b, mul, div);
		if (pitch.Angle == 0)
		{
			return result;
		}
		int num = (int)((decimal)(b - a).Length * (decimal)pitch.Tan() * (decimal)mul * (decimal)(div - mul) / (decimal)(1024 * div * div));
		return new WVec(result.X, result.Y, result.Z + num);
	}

	public static WVec FromPDF(MersenneTwister r, int samples)
	{
		return new WVec(WDist.FromPDF(r, samples), WDist.FromPDF(r, samples), WDist.Zero);
	}

	public override int GetHashCode()
	{
		return X.GetHashCode() ^ Y.GetHashCode() ^ Z.GetHashCode();
	}

	public bool Equals(WVec other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is WVec other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return X + "," + Y + "," + Z;
	}

	public LuaValue Add(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WVec>(out var clrObject) || !right.TryGetClrValue<WVec>(out var b))
		{
			throw new LuaException("Attempted to call WVec.Add(WVec, WVec) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject + b);
	}

	public LuaValue Subtract(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WVec>(out var clrObject) || !right.TryGetClrValue<WVec>(out var b))
		{
			throw new LuaException("Attempted to call WVec.Subtract(WVec, WVec) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject - b);
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WVec>(out var clrObject) || !right.TryGetClrValue<WVec>(out var other))
		{
			return false;
		}
		return clrObject == other;
	}

	public LuaValue Minus(LuaRuntime runtime)
	{
		return new LuaCustomClrObject(-this);
	}

	public LuaValue Multiply(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WVec>(out var clrObject) || !right.TryGetClrValue<int>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WVec.Multiply(WVec, integer) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject * clrObject2);
	}

	public LuaValue Divide(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WVec>(out var clrObject) || !right.TryGetClrValue<int>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WVec.Divide(WVec, integer) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject / clrObject2);
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return ToString();
	}
}
