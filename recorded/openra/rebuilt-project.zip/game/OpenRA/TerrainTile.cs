namespace OpenRA;

public readonly struct TerrainTile(ushort type, byte index)
{
	public readonly ushort Type = type;

	public readonly byte Index = index;

	public override int GetHashCode()
	{
		return Type.GetHashCode() ^ Index.GetHashCode();
	}

	public override string ToString()
	{
		return Type + "," + Index;
	}
}
