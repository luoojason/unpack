using System;

namespace OpenRA;

public interface IFont : IDisposable
{
	FontGlyph CreateGlyph(char c, int size, float deviceScale);
}
