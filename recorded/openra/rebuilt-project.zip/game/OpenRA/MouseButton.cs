using System;

namespace OpenRA;

[Flags]
public enum MouseButton
{
	None = 0,
	Left = 1,
	Right = 2,
	Middle = 4
}
