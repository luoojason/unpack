using System;
using System.Text;
using OpenRA.FileSystem;

namespace OpenRA;

public static class FluentProvider
{
	private static readonly object SyncObject = new object();

	private static FluentBundle modFluentBundle;

	private static FluentBundle mapFluentBundle;

	public static void Initialize(ModData modData, IReadOnlyFileSystem fileSystem)
	{
		lock (SyncObject)
		{
			modFluentBundle = new FluentBundle(modData.Manifest.FluentCulture, modData.Manifest.FluentMessages, fileSystem);
			if (!(fileSystem is Map { FluentMessageDefinitions: not null } map))
			{
				return;
			}
			string[] paths = Array.Empty<string>();
			if (map.FluentMessageDefinitions.Value != null)
			{
				paths = FieldLoader.GetValue<string[]>("value", map.FluentMessageDefinitions.Value);
			}
			string text = null;
			if (map.FluentMessageDefinitions.Nodes.Length > 0)
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (MiniYamlNode node in map.FluentMessageDefinitions.Nodes)
				{
					if (node.Key == "base64")
					{
						stringBuilder.Append(Encoding.UTF8.GetString(Convert.FromBase64String(node.Value.Value)));
					}
				}
				text = stringBuilder.ToString();
			}
			mapFluentBundle = new FluentBundle(modData.Manifest.FluentCulture, paths, fileSystem, text);
		}
	}

	public static string GetMessage(string key, params object[] args)
	{
		lock (SyncObject)
		{
			if (modFluentBundle.TryGetMessage(key, out var value, args))
			{
				return value;
			}
			if (mapFluentBundle != null)
			{
				return mapFluentBundle.GetMessage(key, args);
			}
			return key;
		}
	}

	public static bool TryGetMessage(string key, out string message, params object[] args)
	{
		lock (SyncObject)
		{
			if (modFluentBundle.TryGetMessage(key, out message, args))
			{
				return true;
			}
			if (mapFluentBundle != null && mapFluentBundle.TryGetMessage(key, out message, args))
			{
				return true;
			}
			return false;
		}
	}

	internal static bool TryGetModMessage(string key, out string message, params object[] args)
	{
		lock (SyncObject)
		{
			return modFluentBundle.TryGetMessage(key, out message, args);
		}
	}
}
