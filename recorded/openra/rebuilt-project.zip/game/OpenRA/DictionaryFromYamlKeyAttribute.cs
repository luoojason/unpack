using System;

namespace OpenRA;

[AttributeUsage(AttributeTargets.Field)]
public sealed class DictionaryFromYamlKeyAttribute : FieldLoader.SerializeAttribute
{
	public DictionaryFromYamlKeyAttribute()
	{
		FromYamlKey = true;
		DictionaryFromYamlKey = true;
	}
}
