using System;
using System.Collections.Generic;
using System.IO;
using OpenRA.FileSystem;
using OpenRA.GameRules;
using OpenRA.Primitives;

namespace OpenRA;

public sealed class Sound : IDisposable
{
	private readonly ISoundEngine soundEngine;

	private ISoundLoader[] loaders;

	private IReadOnlyFileSystem fileSystem;

	private Cache<string, ISoundSource> sounds;

	private ISoundSource videoSource;

	private ISound music;

	private ISound video;

	private readonly Dictionary<uint, ISound> currentSounds = new Dictionary<uint, ISound>();

	private readonly Dictionary<string, ISound> currentNotifications = new Dictionary<string, ISound>();

	private Action onMusicComplete;

	private float soundVolumeModifier = 1f;

	public bool DummyEngine { get; }

	public bool DisableAllSounds { get; set; }

	public bool DisableWorldSounds { get; set; }

	public bool MusicPlaying { get; private set; }

	public MusicInfo CurrentMusic { get; private set; }

	public float SoundVolumeModifier
	{
		get
		{
			return soundVolumeModifier;
		}
		set
		{
			soundVolumeModifier = value;
			soundEngine.SetSoundVolume(InternalSoundVolume, music, video);
		}
	}

	private float InternalSoundVolume => SoundVolume * soundVolumeModifier;

	public float SoundVolume
	{
		get
		{
			return Game.Settings.Sound.SoundVolume;
		}
		set
		{
			Game.Settings.Sound.SoundVolume = value;
			soundEngine.SetSoundVolume(InternalSoundVolume, music, video);
		}
	}

	public float MusicVolume
	{
		get
		{
			return Game.Settings.Sound.MusicVolume;
		}
		set
		{
			Game.Settings.Sound.MusicVolume = value;
			if (music != null)
			{
				music.Volume = value;
			}
		}
	}

	public float VideoVolume
	{
		get
		{
			return Game.Settings.Sound.VideoVolume;
		}
		set
		{
			Game.Settings.Sound.VideoVolume = value;
			if (video != null)
			{
				video.Volume = value;
			}
		}
	}

	public float MusicSeekPosition => music?.SeekPosition ?? 0f;

	public float VideoSeekPosition => video?.SeekPosition ?? 0f;

	public Sound(IPlatform platform, SoundSettings soundSettings)
	{
		soundEngine = platform.CreateSound(soundSettings.Device);
		DummyEngine = soundEngine.Dummy;
		if (soundSettings.Mute)
		{
			MuteAudio();
		}
	}

	private T LoadSound<T>(string filename, Func<ISoundFormat, T> loadFormat)
	{
		if (!fileSystem.Exists(filename))
		{
			Log.Write("sound", "LoadSound, file does not exist: " + filename);
			return default;
		}
		using (Stream stream = fileSystem.Open(filename))
		{
			ISoundLoader[] array = loaders;
			foreach (ISoundLoader soundLoader in array)
			{
				stream.Position = 0L;
				if (soundLoader.TryParseSound(stream, out var sound))
				{
					T result = loadFormat(sound);
					sound.Dispose();
					return result;
				}
			}
		}
		throw new InvalidDataException(filename + " is not a valid sound file!");
	}

	public void Initialize(ISoundLoader[] loaders, IReadOnlyFileSystem fileSystem)
	{
		StopMusic();
		soundEngine.StopAllSounds();
		if (sounds != null)
		{
			foreach (ISoundSource value in sounds.Values)
			{
				value?.Dispose();
			}
		}
		this.loaders = loaders;
		this.fileSystem = fileSystem;
		sounds = new Cache<string, ISoundSource>((string filename) => LoadSound(filename, LoadIntoMemory));
		currentSounds.Clear();
		currentNotifications.Clear();
		video = null;
		ISoundSource LoadIntoMemory(ISoundFormat soundFormat)
		{
			return soundEngine.AddSoundSourceFromMemory(soundFormat.GetPCMInputStream().ReadAllBytes(), soundFormat.Channels, soundFormat.SampleBits, soundFormat.SampleRate);
		}
	}

	public SoundDevice[] AvailableDevices()
	{
		return soundEngine.AvailableDevices();
	}

	public void SetListenerPosition(WPos position)
	{
		soundEngine.SetListenerPosition(position);
	}

	private ISound Play(SoundType type, Player player, string name, bool headRelative, WPos pos, float volumeModifier = 1f, bool loop = false)
	{
		if (string.IsNullOrEmpty(name) || DisableAllSounds || (DisableWorldSounds && type == SoundType.World))
		{
			return null;
		}
		if (player != null && player != player.World.LocalPlayer)
		{
			return null;
		}
		return soundEngine.Play2D(sounds[name], loop, headRelative, pos, InternalSoundVolume * volumeModifier, attenuateVolume: true);
	}

	public void StopAudio()
	{
		soundEngine.StopAllSounds();
	}

	public void SetLooped(ISound sound, bool looped)
	{
		soundEngine.SetSoundLooping(looped, sound);
	}

	public void SetPosition(ISound sound, WPos position)
	{
		soundEngine.SetSoundPosition(sound, position);
	}

	public void MuteAudio()
	{
		soundEngine.Volume = 0f;
	}

	public void UnmuteAudio()
	{
		soundEngine.Volume = 1f;
	}

	public void SetMusicLooped(bool loop)
	{
		Game.Settings.Sound.Repeat = loop;
		soundEngine.SetSoundLooping(loop, music);
	}

	public ISound Play(SoundType type, string name)
	{
		return Play(type, null, name, headRelative: true, WPos.Zero);
	}

	public ISound Play(SoundType type, string name, WPos pos)
	{
		return Play(type, null, name, headRelative: false, pos);
	}

	public ISound Play(SoundType type, string name, float volumeModifier)
	{
		return Play(type, null, name, headRelative: true, WPos.Zero, volumeModifier);
	}

	public ISound Play(SoundType type, string name, WPos pos, float volumeModifier)
	{
		return Play(type, null, name, headRelative: false, pos, volumeModifier);
	}

	public ISound PlayToPlayer(SoundType type, Player player, string name)
	{
		return Play(type, player, name, headRelative: true, WPos.Zero);
	}

	public ISound PlayToPlayer(SoundType type, Player player, string name, WPos pos)
	{
		return Play(type, player, name, headRelative: false, pos);
	}

	public ISound PlayLooped(SoundType type, string name)
	{
		return Play(type, null, name, headRelative: true, WPos.Zero, 1f, loop: true);
	}

	public ISound PlayLooped(SoundType type, string name, WPos pos)
	{
		return Play(type, null, name, headRelative: false, pos, 1f, loop: true);
	}

	public ISound Play(SoundType type, string[] names, World world, Player player = null, float volumeModifier = 1f)
	{
		return Play(type, player, names.Random(world.LocalRandom), headRelative: true, WPos.Zero, volumeModifier);
	}

	public ISound Play(SoundType type, string[] names, World world, WPos pos, Player player = null, float volumeModifier = 1f)
	{
		return Play(type, player, names.Random(world.LocalRandom), headRelative: false, pos, volumeModifier);
	}

	public ISound Play(ISoundFormat soundFormat)
	{
		return Play(soundFormat, MusicVolume);
	}

	public ISound Play(ISoundFormat soundFormat, float volume)
	{
		return soundEngine.Play2DStream(soundFormat.GetPCMInputStream(), soundFormat.Channels, soundFormat.SampleBits, soundFormat.SampleRate, loop: false, relative: true, WPos.Zero, volume);
	}

	public void PlayVideo(byte[] raw, int channels, int sampleBits, int sampleRate)
	{
		StopVideo();
		videoSource = soundEngine.AddSoundSourceFromMemory(raw, channels, sampleBits, sampleRate);
		video = soundEngine.Play2D(videoSource, loop: false, relative: true, WPos.Zero, InternalSoundVolume, attenuateVolume: false);
	}

	public void PlayVideo()
	{
		if (video != null)
		{
			soundEngine.PauseSound(video, paused: false);
		}
	}

	public void PauseVideo()
	{
		if (video != null)
		{
			soundEngine.PauseSound(video, paused: true);
		}
	}

	public void StopVideo()
	{
		if (video != null)
		{
			soundEngine.StopSound(video);
			videoSource.Dispose();
			videoSource = null;
			video = null;
		}
	}

	public void Tick()
	{
		if (MusicPlaying && music.Complete)
		{
			StopMusic();
			onMusicComplete();
		}
	}

	public void PlayMusicThen(MusicInfo m, Action then)
	{
		if (m != null && m.Exists)
		{
			onMusicComplete = then;
			if (m == CurrentMusic && music != null)
			{
				soundEngine.PauseSound(music, paused: false);
				MusicPlaying = true;
			}
			else
			{
				PlayMusic(m, Game.Settings.Sound.Repeat);
			}
		}
	}

	public void PlayMusic(MusicInfo m, bool looped = false)
	{
		if (m != null && m.Exists)
		{
			StopMusic();
			music = LoadSound(m.Filename, Stream);
			if (music == null)
			{
				onMusicComplete = null;
				return;
			}
			CurrentMusic = m;
			MusicPlaying = true;
		}
		ISound Stream(ISoundFormat soundFormat)
		{
			return soundEngine.Play2DStream(soundFormat.GetPCMInputStream(), soundFormat.Channels, soundFormat.SampleBits, soundFormat.SampleRate, looped, relative: true, WPos.Zero, MusicVolume * m.VolumeModifier);
		}
	}

	public void PlayMusic()
	{
		if (music != null)
		{
			MusicPlaying = true;
			soundEngine.PauseSound(music, paused: false);
		}
	}

	public void StopSound(ISound sound)
	{
		if (sound != null)
		{
			soundEngine.StopSound(sound);
		}
	}

	public void StopMusic()
	{
		if (music != null)
		{
			soundEngine.StopSound(music);
			music = null;
		}
		CurrentMusic = null;
		MusicPlaying = false;
	}

	public void PauseMusic()
	{
		if (music != null)
		{
			MusicPlaying = false;
			soundEngine.PauseSound(music, paused: true);
		}
	}

	public bool PlayPredefined(SoundType soundType, Ruleset ruleset, Player player, Actor voicedActor, string type, string definition, string variant, bool relative, WPos pos, float volumeModifier, bool attenuateVolume)
	{
		if (ruleset == null)
		{
			throw new ArgumentNullException("ruleset");
		}
		if (definition == null || DisableAllSounds || (DisableWorldSounds && soundType == SoundType.World))
		{
			return false;
		}
		if (ruleset.Voices == null || ruleset.Notifications == null)
		{
			return false;
		}
		SoundInfo soundInfo = ((voicedActor != null) ? ruleset.Voices[type] : ruleset.Notifications[type]);
		if (soundInfo == null)
		{
			return false;
		}
		uint num = voicedActor?.ActorID ?? 0;
		string text = soundInfo.DefaultVariant;
		string text2 = soundInfo.DefaultPrefix;
		SoundPool pool;
		if (voicedActor != null)
		{
			if (!soundInfo.VoicePools.Value.TryGetValue(definition, out var value))
			{
				throw new InvalidOperationException("Can't find " + definition + " in voice pool.");
			}
			pool = value;
		}
		else
		{
			if (!soundInfo.NotificationsPools.Value.TryGetValue(definition, out var value2))
			{
				throw new InvalidOperationException("Can't find " + definition + " in notification pool.");
			}
			pool = value2;
		}
		string next = pool.GetNext();
		if (string.IsNullOrEmpty(next))
		{
			return false;
		}
		if (variant != null)
		{
			if (soundInfo.Variants.TryGetValue(variant, out var value3) && !soundInfo.DisableVariants.Contains(definition))
			{
				text = value3[num % value3.Length];
			}
			if (soundInfo.Prefixes.TryGetValue(variant, out var value4) && !soundInfo.DisablePrefixes.Contains(definition))
			{
				text2 = value4[num % value4.Length];
			}
		}
		string name = text2 + next + text;
		uint key = ((voicedActor == null || !voicedActor.World.Selection.Contains(voicedActor)) ? num : 0u);
		if (!string.IsNullOrEmpty(name) && (player == null || player == player.World.LocalPlayer))
		{
			if (pool.Type == SoundPool.InterruptType.Overlap)
			{
				if (PlaySound() == null)
				{
					return false;
				}
			}
			else if (voicedActor == null)
			{
				if (currentNotifications.TryGetValue(name, out var value5) && !value5.Complete)
				{
					if (pool.Type == SoundPool.InterruptType.Interrupt)
					{
						soundEngine.StopSound(value5);
					}
					else if (pool.Type == SoundPool.InterruptType.DoNotPlay)
					{
						return false;
					}
				}
				ISound sound = PlaySound();
				if (sound == null)
				{
					return false;
				}
				currentNotifications[name] = sound;
			}
			else
			{
				if (currentSounds.TryGetValue(key, out var value6) && !value6.Complete)
				{
					if (pool.Type == SoundPool.InterruptType.Interrupt)
					{
						soundEngine.StopSound(value6);
					}
					else if (pool.Type == SoundPool.InterruptType.DoNotPlay)
					{
						return false;
					}
				}
				ISound sound2 = PlaySound();
				if (sound2 == null)
				{
					return false;
				}
				currentSounds[key] = sound2;
			}
		}
		return true;
		ISound PlaySound()
		{
			float volume = InternalSoundVolume * volumeModifier * pool.VolumeModifier;
			return soundEngine.Play2D(sounds[name], loop: false, relative, pos, volume, attenuateVolume);
		}
	}

	public bool PlayNotification(Ruleset rules, Player player, string type, string notification, string variant)
	{
		if (rules == null)
		{
			throw new ArgumentNullException("rules");
		}
		if (type == null || notification == null)
		{
			return false;
		}
		return PlayPredefined(SoundType.UI, rules, player, null, type.ToLowerInvariant(), notification, variant, relative: true, WPos.Zero, 1f, attenuateVolume: false);
	}

	public void Dispose()
	{
		StopAudio();
		if (sounds != null)
		{
			foreach (ISoundSource value in sounds.Values)
			{
				value?.Dispose();
			}
		}
		soundEngine.Dispose();
	}
}
