namespace OpenRA;

public enum PlatformType
{
	Unknown,
	Windows,
	OSX,
	Linux
}
