using System;

namespace OpenRA;

public interface IIndexBuffer : IDisposable
{
	void Bind();
}
