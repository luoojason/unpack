using System;

namespace OpenRA;

public readonly struct Hotkey : IEquatable<Hotkey>
{
	public static Hotkey Invalid = new Hotkey(Keycode.UNKNOWN, Modifiers.None);

	public readonly Keycode Key;

	public readonly Modifiers Modifiers;

	public bool IsValid()
	{
		return Key != Keycode.UNKNOWN;
	}

	public static bool TryParse(string s, out Hotkey result)
	{
		result = Invalid;
		if (string.IsNullOrWhiteSpace(s))
		{
			return false;
		}
		string[] array = s.Split(' ');
		if (!Enum<Keycode>.TryParse(array[0], ignoreCase: true, out var value))
		{
			if (!int.TryParse(array[0], out var result2))
			{
				return false;
			}
			value = (Keycode)result2;
		}
		Modifiers value2 = Modifiers.None;
		if (array.Length >= 2)
		{
			string s2 = s.Substring(s.IndexOf(' '));
			if (!Enum<Modifiers>.TryParse(s2, ignoreCase: true, out value2))
			{
				return false;
			}
		}
		result = new Hotkey(value, value2);
		return true;
	}

	public static Hotkey FromKeyInput(KeyInput ki)
	{
		return new Hotkey(ki.Key, ki.Modifiers);
	}

	public Hotkey(Keycode virtKey, Modifiers mod)
	{
		Key = virtKey;
		Modifiers = mod;
	}

	public static bool operator !=(Hotkey a, Hotkey b)
	{
		return !(a == b);
	}

	public static bool operator ==(Hotkey a, Hotkey b)
	{
		if (a.Key == Keycode.UNKNOWN)
		{
			return false;
		}
		if (a.Key == b.Key)
		{
			return a.Modifiers == b.Modifiers;
		}
		return false;
	}

	public override int GetHashCode()
	{
		return Key.GetHashCode() ^ Modifiers.GetHashCode();
	}

	public bool Equals(Hotkey other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is Hotkey hotkey)
		{
			return hotkey == this;
		}
		return false;
	}

	public override string ToString()
	{
		return $"{Key} {Modifiers:F}";
	}

	public string DisplayString()
	{
		string text = KeycodeExts.DisplayString(Key);
		if (Modifiers.HasModifier(Modifiers.Shift))
		{
			text = ModifiersExts.DisplayString(Modifiers.Shift) + " + " + text;
		}
		if (Modifiers.HasModifier(Modifiers.Alt))
		{
			text = ModifiersExts.DisplayString(Modifiers.Alt) + " + " + text;
		}
		if (Modifiers.HasModifier(Modifiers.Ctrl))
		{
			text = ModifiersExts.DisplayString(Modifiers.Ctrl) + " + " + text;
		}
		if (Modifiers.HasModifier(Modifiers.Meta))
		{
			text = ModifiersExts.DisplayString(Modifiers.Meta) + " + " + text;
		}
		return text;
	}
}
