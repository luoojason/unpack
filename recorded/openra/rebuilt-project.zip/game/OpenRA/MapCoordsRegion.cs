using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA;

public readonly struct MapCoordsRegion(MPos mapTopLeft, MPos mapBottomRight) : IEnumerable<MPos>, IEnumerable
{
	public struct MapCoordsEnumerator : IEnumerator<MPos>, IEnumerator, IDisposable
	{
		private readonly MapCoordsRegion r;

		public MPos Current { get; private set; }

		readonly object IEnumerator.Current => Current;

		public MapCoordsEnumerator(MapCoordsRegion region)
		{
			this = default;
			r = region;
			Reset();
		}

		public bool MoveNext()
		{
			int num = Current.U + 1;
			int num2 = Current.V;
			if (num > r.BottomRight.U)
			{
				num2++;
				num = r.TopLeft.U;
				if (num2 > r.BottomRight.V)
				{
					return false;
				}
			}
			Current = new MPos(num, num2);
			return true;
		}

		public void Reset()
		{
			Current = new MPos(r.TopLeft.U - 1, r.TopLeft.V);
		}

		public readonly void Dispose()
		{
		}
	}

	public MPos TopLeft { get; } = mapTopLeft;

	public MPos BottomRight { get; } = mapBottomRight;

	public override string ToString()
	{
		return $"{TopLeft}->{BottomRight}";
	}

	public MapCoordsEnumerator GetEnumerator()
	{
		return new MapCoordsEnumerator(this);
	}

	IEnumerator<MPos> IEnumerable<MPos>.GetEnumerator()
	{
		return GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
