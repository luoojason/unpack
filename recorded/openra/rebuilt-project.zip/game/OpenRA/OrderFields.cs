using System;

namespace OpenRA;

[Flags]
internal enum OrderFields : short
{
	None = 0,
	Target = 1,
	ExtraActors = 2,
	TargetString = 4,
	Queued = 8,
	ExtraLocation = 0x10,
	ExtraData = 0x20,
	TargetIsCell = 0x40,
	Subject = 0x80,
	Grouped = 0x100
}
