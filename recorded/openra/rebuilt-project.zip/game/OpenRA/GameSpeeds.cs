using System.Collections.Generic;

namespace OpenRA;

public class GameSpeeds : IGlobalModData
{
	[FieldLoader.Require]
	public readonly string DefaultSpeed;

	[FieldLoader.LoadUsing("LoadSpeeds", false)]
	public readonly Dictionary<string, GameSpeed> Speeds;

	private static object LoadSpeeds(MiniYaml y)
	{
		Dictionary<string, GameSpeed> dictionary = new Dictionary<string, GameSpeed>();
		MiniYamlNode miniYamlNode = y.NodeWithKeyOrDefault("Speeds");
		if (miniYamlNode == null)
		{
			throw new YamlException("Error parsing GameSpeeds: Missing Speeds node!");
		}
		foreach (MiniYamlNode node in miniYamlNode.Value.Nodes)
		{
			try
			{
				dictionary.Add(node.Key, FieldLoader.Load<GameSpeed>(node.Value));
			}
			catch (FieldLoader.MissingFieldsException ex)
			{
				string value = ((ex.Missing.Length > 1) ? "Required properties missing" : "Required property missing");
				throw new YamlException($"Error parsing GameSpeed {node.Key}: {value}: {ex.Missing.JoinWith(", ")}");
			}
		}
		return dictionary;
	}
}
