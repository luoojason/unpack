using System.Collections.Generic;

namespace OpenRA;

public sealed class MiniYamlNodeBuilder
{
	public MiniYamlNode.SourceLocation Location;

	public string Key;

	public MiniYamlBuilder Value;

	public string Comment;

	public MiniYamlNodeBuilder(MiniYamlNode node)
	{
		Location = node.Location;
		Key = node.Key;
		Value = new MiniYamlBuilder(node.Value);
		Comment = node.Comment;
	}

	public MiniYamlNodeBuilder(string k, MiniYamlBuilder v, string c = null)
	{
		Key = k;
		Value = v;
		Comment = c;
	}

	public MiniYamlNodeBuilder(string k, MiniYamlBuilder v, string c, MiniYamlNode.SourceLocation loc)
		: this(k, v, c)
	{
		Location = loc;
	}

	public MiniYamlNodeBuilder(string k, string v, string c = null)
		: this(k, new MiniYamlBuilder(v, null), c)
	{
	}

	public MiniYamlNodeBuilder(string k, string v, List<MiniYamlNode> n)
		: this(k, new MiniYamlBuilder(v, n))
	{
	}

	public MiniYamlNode Build()
	{
		return new MiniYamlNode(Key, Value.Build(), Comment, Location);
	}
}
