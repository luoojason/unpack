using System;

namespace OpenRA;

public ref struct LineSplitEnumerator(ReadOnlySpan<char> str, char separator)
{
	private ReadOnlySpan<char> str = str;

	private readonly char separator = separator;

	public ReadOnlySpan<char> Current { get; private set; } = default;

	public readonly LineSplitEnumerator GetEnumerator()
	{
		return this;
	}

	public bool MoveNext()
	{
		ReadOnlySpan<char> readOnlySpan = str;
		if (readOnlySpan.Length == 0)
		{
			return false;
		}
		int num = readOnlySpan.IndexOf(separator);
		if (num == -1)
		{
			str = ReadOnlySpan<char>.Empty;
			Current = readOnlySpan;
			return true;
		}
		Current = readOnlySpan.Slice(0, num);
		str = readOnlySpan.Slice(num + 1);
		return true;
	}
}
