using System;
using System.IO;

namespace OpenRA;

public interface ISoundFormat : IDisposable
{
	int Channels { get; }

	int SampleBits { get; }

	int SampleRate { get; }

	float LengthInSeconds { get; }

	Stream GetPCMInputStream();
}
