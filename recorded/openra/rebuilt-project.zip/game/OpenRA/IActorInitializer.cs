using OpenRA.Traits;

namespace OpenRA;

public interface IActorInitializer
{
	World World { get; }

	T GetOrDefault<T>(TraitInfo info) where T : ActorInit;

	T Get<T>(TraitInfo info) where T : ActorInit;

	U GetValue<T, U>(TraitInfo info) where T : ValueActorInit<U>;

	U GetValue<T, U>(TraitInfo info, U fallback) where T : ValueActorInit<U>;

	bool Contains<T>(TraitInfo info) where T : ActorInit;

	T GetOrDefault<T>() where T : ActorInit, ISingleInstanceInit;

	T Get<T>() where T : ActorInit, ISingleInstanceInit;

	U GetValue<T, U>() where T : ValueActorInit<U>, ISingleInstanceInit;

	U GetValue<T, U>(U fallback) where T : ValueActorInit<U>, ISingleInstanceInit;

	bool Contains<T>() where T : ActorInit, ISingleInstanceInit;
}
