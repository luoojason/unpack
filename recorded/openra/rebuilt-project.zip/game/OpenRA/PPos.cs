using System;
using OpenRA.Primitives;

namespace OpenRA;

public readonly struct PPos(int u, int v) : IEquatable<PPos>
{
	public readonly int U = u;

	public readonly int V = v;

	public static readonly PPos Zero = new PPos(0, 0);

	public static bool operator ==(PPos me, PPos other)
	{
		if (me.U == other.U)
		{
			return me.V == other.V;
		}
		return false;
	}

	public static bool operator !=(PPos me, PPos other)
	{
		return !(me == other);
	}

	public static explicit operator MPos(PPos puv)
	{
		return new MPos(puv.U, puv.V);
	}

	public static explicit operator PPos(MPos uv)
	{
		return new PPos(uv.U, uv.V);
	}

	public PPos Clamp(Rectangle r)
	{
		return new PPos(Math.Min(r.Right, Math.Max(U, r.Left)), Math.Min(r.Bottom, Math.Max(V, r.Top)));
	}

	public override int GetHashCode()
	{
		return U.GetHashCode() ^ V.GetHashCode();
	}

	public bool Equals(PPos other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is PPos other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return U + "," + V;
	}
}
