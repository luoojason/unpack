using System;
using OpenRA.Primitives;

namespace OpenRA;

public interface IGraphicsContext : IDisposable
{
	string GLVersion { get; }

	IVertexBuffer<T> CreateVertexBuffer<T>(int size) where T : struct;

	T[] CreateVertices<T>(int size) where T : struct;

	IIndexBuffer CreateIndexBuffer(uint[] indices);

	ITexture CreateTexture();

	IFrameBuffer CreateFrameBuffer(Size s);

	IFrameBuffer CreateFrameBuffer(Size s, Color clearColor);

	IShader CreateShader(IShaderBindings shaderBindings);

	void EnableScissor(int x, int y, int width, int height);

	void DisableScissor();

	void Present();

	void DrawPrimitives(PrimitiveType pt, int firstVertex, int numVertices);

	void DrawElements(int numIndices, int offset);

	void Clear();

	void EnableDepthBuffer();

	void DisableDepthBuffer();

	void ClearDepthBuffer();

	void SetBlendMode(BlendMode mode);

	void SetVSyncEnabled(bool enabled);
}
