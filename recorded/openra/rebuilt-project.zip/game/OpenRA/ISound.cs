namespace OpenRA;

public interface ISound
{
	float Volume { get; set; }

	float SeekPosition { get; }

	bool Complete { get; }

	void SetPosition(WPos pos);
}
