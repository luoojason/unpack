using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.Effects;
using OpenRA.FileFormats;
using OpenRA.Graphics;
using OpenRA.Network;
using OpenRA.Orders;
using OpenRA.Primitives;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA;

public sealed class World : IDisposable
{
	internal readonly TraitDictionary TraitDict = new TraitDictionary();

	private readonly SortedDictionary<uint, Actor> actors = new SortedDictionary<uint, Actor>();

	private readonly List<IEffect> effects = new List<IEffect>();

	private readonly List<IEffect> unpartitionedEffects = new List<IEffect>();

	private readonly List<ISync> syncedEffects = new List<ISync>();

	private readonly GameSettings gameSettings;

	private readonly ModData modData;

	private readonly Queue<Action<World>> frameEndActions = new Queue<Action<World>>();

	public readonly GameSpeed GameSpeed;

	public readonly int Timestep;

	public int ReplayTimestep;

	internal readonly OrderManager OrderManager;

	public readonly MersenneTwister SharedRandom;

	public readonly MersenneTwister LocalRandom;

	public LongBitSet<PlayerBitMask> AllPlayersMask;

	public readonly LongBitSet<PlayerBitMask> NoPlayersMask;

	public Player[] Players = Array.Empty<Player>();

	private Player renderPlayer;

	public readonly Actor WorldActor;

	public readonly Map Map;

	public readonly IActorMap ActorMap;

	public readonly ScreenMap ScreenMap;

	public readonly WorldType Type;

	public readonly IValidateOrder[] OrderValidators;

	private readonly INotifyPlayerDisconnected[] notifyDisconnected;

	private readonly GameInformation gameInfo;

	private readonly Type defaultOrderGeneratorType;

	private IOrderGenerator orderGenerator;

	public readonly ISelection Selection;

	public readonly IControlGroups ControlGroups;

	private bool wasLoadingGameSave;

	private readonly Dictionary<int, MiniYaml> gameSaveTraitData = new Dictionary<int, MiniYaml>();

	private uint nextAID;

	public bool Disposing;

	public Session LobbyInfo => OrderManager.LobbyInfo;

	public Player LocalPlayer { get; private set; }

	public bool IsGameOver { get; private set; }

	public Player RenderPlayer
	{
		get
		{
			return renderPlayer;
		}
		set
		{
			if (LocalPlayer == null || LocalPlayer.UnlockedRenderPlayer)
			{
				renderPlayer = value;
				RenderPlayerChanged?.Invoke(value);
			}
		}
	}

	public bool IsReplay => OrderManager.Connection is ReplayConnection;

	public bool IsLoadingGameSave => OrderManager.NetFrameNumber <= OrderManager.GameSaveLastFrame;

	public int GameSaveLoadingPercentage => OrderManager.NetFrameNumber * 100 / OrderManager.GameSaveLastFrame;

	public IOrderGenerator OrderGenerator
	{
		get
		{
			return orderGenerator;
		}
		set
		{
			Sync.AssertUnsynced("The current order generator may not be changed from synced code");
			orderGenerator?.Deactivate();
			orderGenerator = value;
		}
	}

	public bool RulesContainTemporaryBlocker { get; }

	public bool Paused { get; internal set; }

	public bool PredictedPaused { get; internal set; }

	public int WorldTick { get; private set; }

	public IEnumerable<Actor> Actors => actors.Values;

	public IEnumerable<IEffect> Effects => effects;

	public IEnumerable<IEffect> UnpartitionedEffects => unpartitionedEffects;

	public IEnumerable<ISync> SyncedEffects => syncedEffects;

	public event Action<Player> RenderPlayerChanged;

	public event Action GameOver = () =>
	{
	};

	public event Action<Actor> ActorAdded = (Actor _) =>
	{
	};

	public event Action<Actor> ActorRemoved = (Actor _) =>
	{
	};

	public void SetPlayers(IEnumerable<Player> players, Player localPlayer)
	{
		if (Players.Length != 0)
		{
			throw new InvalidOperationException("Players are fixed once they have been set.");
		}
		Players = players.ToArray();
		SetLocalPlayer(localPlayer);
	}

	public void EndGame()
	{
		if (IsGameOver)
		{
			return;
		}
		SetPauseState(paused: true);
		IsGameOver = true;
		foreach (IGameOver item in WorldActor.TraitsImplementing<IGameOver>())
		{
			item.GameOver(this);
		}
		gameInfo.FinalGameTick = WorldTick;
		GameOver();
	}

	public bool FogObscures(Actor a)
	{
		if (RenderPlayer != null)
		{
			return !a.CanBeViewedByPlayer(RenderPlayer);
		}
		return false;
	}

	public bool FogObscures(CPos p)
	{
		if (RenderPlayer != null)
		{
			return !RenderPlayer.Shroud.IsVisible(p);
		}
		return false;
	}

	public bool FogObscures(WPos pos)
	{
		if (RenderPlayer != null)
		{
			return !RenderPlayer.Shroud.IsVisible(pos);
		}
		return false;
	}

	public bool ShroudObscures(CPos p)
	{
		if (RenderPlayer != null)
		{
			return !RenderPlayer.Shroud.IsExplored(p);
		}
		return false;
	}

	public bool ShroudObscures(MPos uv)
	{
		if (RenderPlayer != null)
		{
			return !RenderPlayer.Shroud.IsExplored(uv);
		}
		return false;
	}

	public bool ShroudObscures(WPos pos)
	{
		if (RenderPlayer != null)
		{
			return !RenderPlayer.Shroud.IsExplored(pos);
		}
		return false;
	}

	public bool ShroudObscures(PPos uv)
	{
		if (RenderPlayer != null)
		{
			return !RenderPlayer.Shroud.IsExplored(uv);
		}
		return false;
	}

	private void SetLocalPlayer(Player localPlayer)
	{
		if (localPlayer != null)
		{
			if (!Enumerable.Contains(Players, localPlayer))
			{
				throw new ArgumentException("The local player must be one of the players in the world.", "localPlayer");
			}
			if (!IsReplay)
			{
				LocalPlayer = localPlayer;
				renderPlayer = LocalPlayer;
			}
		}
	}

	public void IssueOrder(Order o)
	{
		OrderManager.IssueOrder(o);
	}

	public void CancelInputMode()
	{
		OrderGenerator = (IOrderGenerator)modData.ObjectCreator.CreateBasic(defaultOrderGeneratorType);
	}

	public bool ToggleInputMode<T>() where T : IOrderGenerator, new()
	{
		if (OrderGenerator is T)
		{
			CancelInputMode();
			return false;
		}
		OrderGenerator = new T();
		return true;
	}

	internal World(string mapUID, ModData modData, OrderManager orderManager, WorldType type)
	{
		this.modData = modData;
		Type = type;
		OrderManager = orderManager;
		using (new PerfTimer("PrepareMap"))
		{
			Map = modData.PrepareMap(mapUID);
		}
		if (string.IsNullOrEmpty(modData.Manifest.DefaultOrderGenerator))
		{
			throw new InvalidDataException("mod.yaml must define a DefaultOrderGenerator");
		}
		defaultOrderGeneratorType = modData.ObjectCreator.FindType(modData.Manifest.DefaultOrderGenerator);
		if (defaultOrderGeneratorType == null)
		{
			throw new InvalidDataException(modData.Manifest.DefaultOrderGenerator + " is not a valid DefaultOrderGenerator");
		}
		orderGenerator = (IOrderGenerator)modData.ObjectCreator.CreateBasic(defaultOrderGeneratorType);
		GameSpeeds gameSpeeds = modData.Manifest.Get<GameSpeeds>();
		string key = orderManager.LobbyInfo.GlobalSettings.OptionOrDefault("gamespeed", gameSpeeds.DefaultSpeed);
		GameSpeed = gameSpeeds.Speeds[key];
		Timestep = (ReplayTimestep = GameSpeed.Timestep);
		SharedRandom = new MersenneTwister(orderManager.LobbyInfo.GlobalSettings.RandomSeed);
		LocalRandom = new MersenneTwister();
		WorldActor = CreateActor(((type == WorldType.Editor) ? SystemActors.EditorWorld : SystemActors.World).ToString(), new TypeDictionary());
		ActorMap = WorldActor.Trait<IActorMap>();
		ScreenMap = WorldActor.Trait<ScreenMap>();
		Selection = WorldActor.Trait<ISelection>();
		ControlGroups = WorldActor.Trait<IControlGroups>();
		OrderValidators = WorldActor.TraitsImplementing<IValidateOrder>().ToArray();
		notifyDisconnected = WorldActor.TraitsImplementing<INotifyPlayerDisconnected>().ToArray();
		LongBitSet<PlayerBitMask>.Reset();
		MersenneTwister playerRandom = new MersenneTwister(orderManager.LobbyInfo.GlobalSettings.RandomSeed);
		foreach (ICreatePlayers item in WorldActor.TraitsImplementing<ICreatePlayers>())
		{
			item.CreatePlayers(this, playerRandom);
		}
		Game.Sound.SoundVolumeModifier = 1f;
		gameInfo = new GameInformation
		{
			Mod = Game.ModData.Manifest.Id,
			Version = Game.ModData.Manifest.Metadata.Version,
			MapUid = Map.Uid,
			MapTitle = Map.Title
		};
		RulesContainTemporaryBlocker = Map.Rules.Actors.Any((KeyValuePair<string, ActorInfo> a) => a.Value.HasTraitInfo<ITemporaryBlockerInfo>());
		gameSettings = Game.Settings.Game;
	}

	public void AddToMaps(Actor self, IOccupySpace ios)
	{
		ActorMap.AddInfluence(self, ios);
		ActorMap.AddPosition(self, ios);
		ScreenMap.AddOrUpdate(self);
	}

	public void UpdateMaps(Actor self, IOccupySpace ios)
	{
		if (self.IsInWorld)
		{
			ScreenMap.AddOrUpdate(self);
			ActorMap.UpdatePosition(self, ios);
		}
	}

	public void RemoveFromMaps(Actor self, IOccupySpace ios)
	{
		ActorMap.RemoveInfluence(self, ios);
		ActorMap.RemovePosition(self, ios);
		ScreenMap.Remove(self);
	}

	public void LoadComplete(WorldRenderer wr)
	{
		if (IsLoadingGameSave)
		{
			wasLoadingGameSave = true;
			Game.Sound.DisableAllSounds = true;
			foreach (INotifyGameLoading item in WorldActor.TraitsImplementing<INotifyGameLoading>())
			{
				item.GameLoading(this);
			}
		}
		using (new PerfTimer("ScreenMap.WorldLoaded"))
		{
			ScreenMap.WorldLoaded(this, wr);
		}
		foreach (IWorldLoaded item2 in WorldActor.TraitsImplementing<IWorldLoaded>())
		{
			if (item2 != ScreenMap)
			{
				using (new PerfTimer(item2.GetType().Name + ".WorldLoaded"))
				{
					item2.WorldLoaded(this, wr);
				}
			}
		}
		Player[] players = Players;
		foreach (Player player in players)
		{
			foreach (IWorldLoaded item3 in player.PlayerActor.TraitsImplementing<IWorldLoaded>())
			{
				using (new PerfTimer(item3.GetType().Name + ".WorldLoaded"))
				{
					item3.WorldLoaded(this, wr);
				}
			}
		}
		Player[] players2 = Players;
		foreach (Player runtimePlayer in players2)
		{
			gameInfo.AddPlayer(runtimePlayer, OrderManager.LobbyInfo);
		}
		gameInfo.DisabledSpawnPoints = OrderManager.LobbyInfo.DisabledSpawnPoints;
		gameInfo.StartTimeUtc = DateTime.UtcNow;
		if (OrderManager.Connection is NetworkConnection { Recorder: not null } networkConnection)
		{
			networkConnection.Recorder.Metadata = new ReplayMetadata(gameInfo);
		}
	}

	public void PostLoadComplete(WorldRenderer wr)
	{
		foreach (IPostWorldLoaded item in WorldActor.TraitsImplementing<IPostWorldLoaded>())
		{
			using (new PerfTimer(item.GetType().Name + ".PostWorldLoaded"))
			{
				item.PostWorldLoaded(this, wr);
			}
		}
		Player[] players = Players;
		foreach (Player player in players)
		{
			foreach (IPostWorldLoaded item2 in player.PlayerActor.TraitsImplementing<IPostWorldLoaded>())
			{
				using (new PerfTimer(item2.GetType().Name + ".PostWorldLoaded"))
				{
					item2.PostWorldLoaded(this, wr);
				}
			}
		}
	}

	public void SetWorldOwner(Player p)
	{
		WorldActor.Owner = p;
	}

	public Actor CreateActor(string name, TypeDictionary initDict)
	{
		return CreateActor(addToWorld: true, name, initDict);
	}

	public Actor CreateActor(bool addToWorld, ActorReference reference)
	{
		return CreateActor(addToWorld, reference.Type, reference.InitDict);
	}

	public Actor CreateActor(bool addToWorld, string name, TypeDictionary initDict)
	{
		Actor actor = new Actor(this, name, initDict);
		actor.Initialize(addToWorld);
		return actor;
	}

	public void Add(Actor a)
	{
		a.IsInWorld = true;
		actors.Add(a.ActorID, a);
		ActorAdded(a);
		foreach (INotifyAddedToWorld item in a.TraitsImplementing<INotifyAddedToWorld>())
		{
			item.AddedToWorld(a);
		}
	}

	public void Remove(Actor a)
	{
		a.IsInWorld = false;
		actors.Remove(a.ActorID);
		ActorRemoved(a);
		foreach (INotifyRemovedFromWorld item in a.TraitsImplementing<INotifyRemovedFromWorld>())
		{
			item.RemovedFromWorld(a);
		}
	}

	public void Add(IEffect e)
	{
		effects.Add(e);
		if (!(e is ISpatiallyPartitionable))
		{
			unpartitionedEffects.Add(e);
		}
		if (e is ISync item)
		{
			syncedEffects.Add(item);
		}
	}

	public void Remove(IEffect e)
	{
		effects.Remove(e);
		if (!(e is ISpatiallyPartitionable))
		{
			unpartitionedEffects.Remove(e);
		}
		if (e is ISync item)
		{
			syncedEffects.Remove(item);
		}
	}

	public void RemoveAll(Predicate<IEffect> predicate)
	{
		effects.RemoveAll(predicate);
		unpartitionedEffects.RemoveAll((IEffect e) => predicate(e));
		syncedEffects.RemoveAll((ISync e) => predicate((IEffect)e));
	}

	public void AddFrameEndTask(Action<World> a)
	{
		frameEndActions.Enqueue(a);
	}

	internal void AddGameSaveTraitData(int traitIndex, MiniYaml yaml)
	{
		gameSaveTraitData[traitIndex] = yaml;
	}

	public void SetPauseState(bool paused)
	{
		if (!IsGameOver)
		{
			IssueOrder(Order.FromTargetString("PauseGame", paused ? "Pause" : "UnPause", isImmediate: false));
			PredictedPaused = paused;
		}
	}

	public void SetLocalPauseState(bool paused)
	{
		bool paused2 = (PredictedPaused = paused);
		Paused = paused2;
	}

	public void Tick()
	{
		if (wasLoadingGameSave && !IsLoadingGameSave)
		{
			foreach (KeyValuePair<int, MiniYaml> gameSaveTraitDatum in gameSaveTraitData)
			{
				TraitPair<IGameSaveTraitData> traitPair = TraitDict.ActorsWithTrait<IGameSaveTraitData>().Skip(gameSaveTraitDatum.Key).FirstOrDefault();
				if (traitPair.Actor == null)
				{
					break;
				}
				traitPair.Trait.ResolveTraitData(traitPair.Actor, gameSaveTraitDatum.Value);
			}
			gameSaveTraitData.Clear();
			Game.Sound.DisableAllSounds = false;
			foreach (INotifyGameLoaded item in WorldActor.TraitsImplementing<INotifyGameLoaded>())
			{
				item.GameLoaded(this);
			}
			wasLoadingGameSave = false;
		}
		if (!Paused && (Type != WorldType.Shellmap || !gameSettings.PauseShellmap || WorldTick == 0))
		{
			WorldTick++;
			using (new PerfSample("tick_actors"))
			{
				foreach (Actor value in actors.Values)
				{
					value.Tick();
				}
			}
			ApplyToActorsWithTraitTimed((Actor actor, ITick trait) =>
			{
				trait.Tick(actor);
			}, "Trait");
			effects.DoTimed((IEffect e) =>
			{
				e.Tick(this);
			}, "Effect");
		}
		while (frameEndActions.Count != 0)
		{
			frameEndActions.Dequeue()(this);
		}
	}

	public void TickRender(WorldRenderer wr)
	{
		ApplyToActorsWithTraitTimed((Actor actor, ITickRender trait) =>
		{
			trait.TickRender(wr, actor);
		}, "Render");
		ScreenMap.TickRender();
	}

	public Actor GetActorById(uint actorId)
	{
		if (actors.TryGetValue(actorId, out var value))
		{
			return value;
		}
		return null;
	}

	internal uint NextAID()
	{
		return nextAID++;
	}

	public int SyncHash()
	{
		int num = 0;
		int num2 = 0;
		foreach (Actor actor in Actors)
		{
			num2 += num++ * (int)(1 + actor.ActorID) * Sync.HashActor(actor);
		}
		foreach (Actor item in ActorsHavingTrait<ISync>())
		{
			Actor.SyncHash[] syncHashes = item.SyncHashes;
			foreach (Actor.SyncHash syncHash in syncHashes)
			{
				num2 += num++ * (int)(1 + item.ActorID) * syncHash.Hash();
			}
		}
		foreach (ISync syncedEffect in SyncedEffects)
		{
			num2 += num++ * Sync.Hash(syncedEffect);
		}
		num2 += SharedRandom.Last;
		Player[] players = Players;
		foreach (Player player in players)
		{
			if (player.UnlockedRenderPlayer)
			{
				num2 += Sync.HashPlayer(player);
			}
		}
		return num2;
	}

	public IEnumerable<TraitPair<T>> ActorsWithTrait<T>()
	{
		return TraitDict.ActorsWithTrait<T>();
	}

	public void ApplyToActorsWithTraitTimed<T>(Action<Actor, T> action, string text)
	{
		TraitDict.ApplyToActorsWithTraitTimed(action, text);
	}

	public void ApplyToActorsWithTrait<T>(Action<Actor, T> action)
	{
		TraitDict.ApplyToActorsWithTrait(action);
	}

	public IEnumerable<Actor> ActorsHavingTrait<T>()
	{
		return TraitDict.ActorsHavingTrait<T>();
	}

	public IEnumerable<Actor> ActorsHavingTrait<T>(Func<T, bool> predicate)
	{
		return TraitDict.ActorsHavingTrait(predicate);
	}

	public void OnPlayerWinStateChanged(Player player)
	{
		GameInformation.Player player2 = gameInfo.GetPlayer(player);
		if (player2 != null)
		{
			player2.Outcome = player.WinState;
			player2.OutcomeTimestampUtc = DateTime.UtcNow;
		}
	}

	internal void OnClientDisconnected(int clientId)
	{
		foreach (Player item in Players.Where((Player p) => p.ClientIndex == clientId && p.PlayerReference.Playable))
		{
			INotifyPlayerDisconnected[] array = notifyDisconnected;
			foreach (INotifyPlayerDisconnected notifyPlayerDisconnected in array)
			{
				notifyPlayerDisconnected.PlayerDisconnected(WorldActor, item);
			}
			Player[] players = Players;
			foreach (Player player in players)
			{
				player.PlayerDisconnected(item);
			}
			GameInformation.Player player2 = gameInfo.GetPlayer(item);
			if (player2 != null)
			{
				player2.DisconnectFrame = OrderManager.NetFrameNumber;
			}
		}
	}

	public void RequestGameSave(string filename)
	{
		int num = 0;
		foreach (TraitPair<IGameSaveTraitData> item in TraitDict.ActorsWithTrait<IGameSaveTraitData>())
		{
			List<MiniYamlNode> list = item.Trait.IssueTraitData(item.Actor);
			if (list != null)
			{
				List<MiniYamlNode> y = new List<MiniYamlNode>
				{
					new MiniYamlNode(num.ToStringInvariant(), new MiniYaml("", list))
				};
				IssueOrder(Order.FromTargetString("GameSaveTraitData", y.WriteToString(), isImmediate: true));
			}
			num++;
		}
		IssueOrder(Order.FromTargetString("CreateGameSave", filename, isImmediate: true));
	}

	public void Dispose()
	{
		Disposing = true;
		OrderGenerator?.Deactivate();
		frameEndActions.Clear();
		Game.Sound.StopAudio();
		Game.Sound.StopVideo();
		if (IsLoadingGameSave)
		{
			Game.Sound.DisableAllSounds = false;
		}
		foreach (Actor item in actors.Values.Reverse())
		{
			item.Dispose();
		}
		while (frameEndActions.Count != 0)
		{
			frameEndActions.Dequeue()(this);
		}
		if (Type == WorldType.Shellmap)
		{
			OrderManager.Dispose();
		}
		Map.Dispose();
		Game.FinishBenchmark();
	}

	public void OutOfSync()
	{
		EndGame();
		ReplayTimestep = 0;
	}
}
