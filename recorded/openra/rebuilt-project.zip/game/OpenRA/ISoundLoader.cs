using System.IO;

namespace OpenRA;

public interface ISoundLoader
{
	bool TryParseSound(Stream stream, out ISoundFormat sound);
}
