using System;

namespace OpenRA;

[Flags]
public enum MapClassification
{
	Unknown = 0,
	System = 1,
	User = 2,
	Remote = 4
}
