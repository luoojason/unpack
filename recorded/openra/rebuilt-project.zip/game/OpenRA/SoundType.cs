namespace OpenRA;

public enum SoundType
{
	World,
	UI
}
