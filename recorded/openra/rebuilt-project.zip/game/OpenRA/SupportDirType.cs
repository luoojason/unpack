namespace OpenRA;

public enum SupportDirType
{
	System,
	ModernUser,
	LegacyUser,
	User
}
