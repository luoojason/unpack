using System;

namespace OpenRA;

public readonly struct WRot : IEquatable<WRot>
{
	public readonly WAngle Roll;

	public readonly WAngle Pitch;

	public readonly WAngle Yaw;

	private readonly int x;

	private readonly int y;

	private readonly int z;

	private readonly int w;

	public static readonly WRot None = new WRot(WAngle.Zero, WAngle.Zero, WAngle.Zero);

	public WRot(WAngle roll, WAngle pitch, WAngle yaw)
	{
		Roll = roll;
		Pitch = pitch;
		Yaw = yaw;
		WAngle wAngle = new WAngle(-Roll.Angle / 2);
		WAngle wAngle2 = new WAngle(-Pitch.Angle / 2);
		WAngle wAngle3 = new WAngle(-Yaw.Angle / 2);
		long num = wAngle.Cos();
		long num2 = wAngle.Sin();
		long num3 = wAngle2.Cos();
		long num4 = wAngle2.Sin();
		long num5 = wAngle3.Cos();
		long num6 = wAngle3.Sin();
		x = (int)((num2 * num3 * num5 - num * num4 * num6) / 1048576);
		y = (int)((num * num4 * num5 + num2 * num3 * num6) / 1048576);
		z = (int)((num * num3 * num6 - num2 * num4 * num5) / 1048576);
		w = (int)((num * num3 * num5 + num2 * num4 * num6) / 1048576);
	}

	public WRot(WVec axis, WAngle angle)
	{
		x = axis.X * new WAngle(-angle.Angle / 2).Sin() / 1024;
		y = axis.Y * new WAngle(-angle.Angle / 2).Sin() / 1024;
		z = axis.Z * new WAngle(-angle.Angle / 2).Sin() / 1024;
		w = new WAngle(-angle.Angle / 2).Cos();
		(Roll, Pitch, Yaw) = QuaternionToEuler(x, y, z, w);
	}

	private WRot(int x, int y, int z, int w)
	{
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
		(Roll, Pitch, Yaw) = QuaternionToEuler(x, y, z, w);
	}

	private static (WAngle Roll, WAngle Pitch, WAngle Yaw) QuaternionToEuler(int x, int y, int z, int w)
	{
		int num = x * x + y * y + z * z + w * w;
		int num2 = 2 * (w * x + y * z);
		int num3 = num - 2 * (x * x + y * y);
		int num4 = (w * y - z * x) / 512;
		int num5 = 2 * (w * z + x * y);
		int num6 = num - 2 * (y * y + z * z);
		WAngle item = -WAngle.ArcTan(num2, num3);
		WAngle item2 = -((Math.Abs(num4) >= 1024) ? new WAngle(Math.Sign(num4) * 256) : WAngle.ArcSin(num4));
		WAngle item3 = -WAngle.ArcTan(num5, num6);
		return (Roll: item, Pitch: item2, Yaw: item3);
	}

	private WRot(int x, int y, int z, int w, WAngle roll, WAngle pitch, WAngle yaw)
	{
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
		Roll = roll;
		Pitch = pitch;
		Yaw = yaw;
	}

	public static WRot FromFacing(int facing)
	{
		return new WRot(WAngle.Zero, WAngle.Zero, WAngle.FromFacing(facing));
	}

	public static WRot FromYaw(WAngle yaw)
	{
		return new WRot(WAngle.Zero, WAngle.Zero, yaw);
	}

	public static WRot operator +(in WRot a, in WRot b)
	{
		return new WRot(a.Roll + b.Roll, a.Pitch + b.Pitch, a.Yaw + b.Yaw);
	}

	public static WRot operator -(in WRot a, in WRot b)
	{
		return new WRot(a.Roll - b.Roll, a.Pitch - b.Pitch, a.Yaw - b.Yaw);
	}

	public static WRot operator -(in WRot a)
	{
		return new WRot(-a.x, -a.y, -a.z, a.w, -a.Roll, -a.Pitch, -a.Yaw);
	}

	public WRot Rotate(in WRot rot)
	{
		if (this == None)
		{
			return rot;
		}
		if (rot == None)
		{
			return this;
		}
		long num = ((long)rot.w * (long)x + (long)rot.x * (long)w + (long)rot.y * (long)z - (long)rot.z * (long)y) / 1024;
		long num2 = ((long)rot.w * (long)y - (long)rot.x * (long)z + (long)rot.y * (long)w + (long)rot.z * (long)x) / 1024;
		long num3 = ((long)rot.w * (long)z + (long)rot.x * (long)y - (long)rot.y * (long)x + (long)rot.z * (long)w) / 1024;
		long num4 = ((long)rot.w * (long)w - (long)rot.x * (long)x - (long)rot.y * (long)y - (long)rot.z * (long)z) / 1024;
		return new WRot((int)num, (int)num2, (int)num3, (int)num4);
	}

	public static bool operator ==(in WRot me, in WRot other)
	{
		if (me.Roll == other.Roll && me.Pitch == other.Pitch)
		{
			return me.Yaw == other.Yaw;
		}
		return false;
	}

	public static bool operator !=(in WRot me, in WRot other)
	{
		return !(me == other);
	}

	public WRot WithRoll(WAngle roll)
	{
		return new WRot(roll, Pitch, Yaw);
	}

	public WRot WithPitch(WAngle pitch)
	{
		return new WRot(Roll, pitch, Yaw);
	}

	public WRot WithYaw(WAngle yaw)
	{
		return new WRot(Roll, Pitch, yaw);
	}

	public void AsMatrix(out Int32Matrix4x4 mtx)
	{
		int num = x * x + y * y + z * z + w * w;
		mtx = new Int32Matrix4x4(num - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0, 2 * (x * y - z * w), num - 2 * (x * x + z * z), 2 * (y * z + x * w), 0, 2 * (x * z + y * w), 2 * (y * z - x * w), num - 2 * (x * x + y * y), 0, 0, 0, 0, num);
	}

	public Int32Matrix4x4 AsMatrix()
	{
		AsMatrix(out var mtx);
		return mtx;
	}

	public override int GetHashCode()
	{
		return Roll.GetHashCode() ^ Pitch.GetHashCode() ^ Yaw.GetHashCode();
	}

	public bool Equals(WRot other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is WRot other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return Roll.ToString() + "," + Pitch.ToString() + "," + Yaw;
	}

	public static WRot SLerp(in WRot a, in WRot b, int mul, int div)
	{
		int num = a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
		int num2 = ((num >= 0) ? 1 : (-1));
		if (num2 * num >= 1048576)
		{
			return a;
		}
		WAngle wAngle = WAngle.ArcCos(num / 1024);
		int num3 = new WAngle((div - mul) * wAngle.Angle / div).Sin();
		int num4 = new WAngle(mul * wAngle.Angle / div).Sin();
		int num5 = wAngle.Sin();
		long num6 = ((long)a.x * (long)num3 + num2 * b.x * num4) / num5;
		long num7 = ((long)a.y * (long)num3 + num2 * b.y * num4) / num5;
		long num8 = ((long)a.z * (long)num3 + num2 * b.z * num4) / num5;
		long num9 = ((long)a.w * (long)num3 + num2 * b.w * num4) / num5;
		long num10 = Exts.ISqrt(num6 * num6 + num7 * num7 + num8 * num8 + num9 * num9);
		return new WRot((int)(1024 * num6 / num10), (int)(1024 * num7 / num10), (int)(1024 * num8 / num10), (int)(1024 * num9 / num10));
	}
}
