using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA;

public class ActorInfo
{
	public const char AbstractActorPrefix = '^';

	public const char TraitInstanceSeparator = '@';

	public readonly string Name;

	private readonly TypeDictionary traits = new TypeDictionary();

	private TraitInfo[] constructOrderCache;

	public ActorInfo(ObjectCreator creator, string name, MiniYaml node)
	{
		try
		{
			Name = name;
			foreach (MiniYamlNode node2 in node.Nodes)
			{
				try
				{
					TraitInfo traitInfo = LoadTraitInfo(creator, node2.Key, node2.Value);
					if (traitInfo != null)
					{
						traits.Add(traitInfo);
					}
				}
				catch (FieldLoader.MissingFieldsException ex)
				{
					throw new YamlException(ex.Message);
				}
			}
			traits.TrimExcess();
		}
		catch (YamlException ex2)
		{
			throw new YamlException("Actor type " + name + ": " + ex2.Message);
		}
	}

	public ActorInfo(string name, params TraitInfo[] traitInfos)
	{
		Name = name;
		foreach (TraitInfo val in traitInfos)
		{
			traits.Add(val);
		}
		traits.TrimExcess();
	}

	private static TraitInfo LoadTraitInfo(ObjectCreator creator, string traitName, MiniYaml my)
	{
		if (!string.IsNullOrEmpty(my.Value))
		{
			throw new YamlException("Junk value `" + my.Value + "` on trait node " + traitName);
		}
		string[] array = traitName.Split('@');
		TraitInfo traitInfo = creator.CreateObject<TraitInfo>(array[0] + "Info");
		if (traitInfo == null)
		{
			return null;
		}
		try
		{
			if (array.Length > 1)
			{
				traitInfo.GetType().GetField("InstanceName").SetValue(traitInfo, array[1]);
			}
			FieldLoader.Load(traitInfo, my);
			return traitInfo;
		}
		catch (FieldLoader.MissingFieldsException ex)
		{
			string header = "Trait name " + traitName + ": " + ((ex.Missing.Length > 1) ? "Required properties missing" : "Required property missing");
			throw new FieldLoader.MissingFieldsException(ex.Missing, header);
		}
	}

	public IEnumerable<TraitInfo> TraitsInConstructOrder()
	{
		if (constructOrderCache != null)
		{
			return constructOrderCache;
		}
		var source = (from i in traits.WithInterface<TraitInfo>()
			select new
			{
				Trait = i,
				Type = i.GetType(),
				Dependencies = PrerequisitesOf(i).ToList(),
				OptionalDependencies = OptionalPrerequisitesOf(i).ToList()
			}).ToList();
		var resolved = source.Where(s => s.Dependencies.Count == 0 && s.OptionalDependencies.Count == 0).ToList();
		var unresolved = source.ToHashSet();
		unresolved.ExceptWith(resolved);
		var enumerable = unresolved.Where(u => u.Dependencies.All((Type d) => resolved.Exists(r => AreResolvable(d, r.Type)) && !unresolved.Any(anon => AreResolvable(d, anon.Type))) && u.OptionalDependencies.All((Type d) => !unresolved.Any(anon => AreResolvable(d, anon.Type))));
		var list = enumerable.ToList();
		while (list.Count != 0)
		{
			resolved.AddRange(list);
			unresolved.ExceptWith(list);
			list.Clear();
			list.AddRange(enumerable);
		}
		if (unresolved.Count != 0)
		{
			string text = "ActorInfo(\"" + Name + "\") failed to initialize because of the following:\n";
			IEnumerable<Type> enumerable2 = unresolved.SelectMany(u => u.Dependencies.Where((Type d) => !source.Any(s => AreResolvable(d, s.Type)))).Distinct();
			text += "Missing:\n";
			foreach (Type item in enumerable2)
			{
				text = text + item?.ToString() + " \n";
			}
			text += "Unresolved:\n";
			foreach (var item2 in unresolved)
			{
				IEnumerable<Type> source2 = item2.Dependencies.Where((Type d) => !resolved.Exists(r => r.Type == d));
				IEnumerable<Type> source3 = item2.OptionalDependencies.Where((Type d) => !resolved.Exists(r => r.Type == d));
				string value = string.Join(", ", source2.Select((Type o) => o.ToString()).Concat(source3.Select((Type o) => $"[{o}]")));
				text += $"{item2.Type}: {{ {value} }}\n";
			}
			throw new YamlException(text);
		}
		constructOrderCache = resolved.Select(r => r.Trait).ToArray();
		return constructOrderCache;
		static bool AreResolvable(Type a, Type b)
		{
			return a.IsAssignableFrom(b);
		}
	}

	public static IEnumerable<Type> PrerequisitesOf(TraitInfo info)
	{
		return from t in info.GetType().GetInterfaces()
			where t.IsGenericType && t.GetGenericTypeDefinition() == typeof(Requires<>)
			select t.GetGenericArguments()[0];
	}

	public static IEnumerable<Type> OptionalPrerequisitesOf(TraitInfo info)
	{
		return from t in info.GetType().GetInterfaces()
			where t.IsGenericType && t.GetGenericTypeDefinition() == typeof(NotBefore<>)
			select t.GetGenericArguments()[0];
	}

	public bool HasTraitInfo<T>() where T : ITraitInfoInterface
	{
		return traits.Contains<T>();
	}

	public T TraitInfo<T>() where T : ITraitInfoInterface
	{
		return traits.Get<T>();
	}

	public T TraitInfoOrDefault<T>() where T : ITraitInfoInterface
	{
		return traits.GetOrDefault<T>();
	}

	public IReadOnlyCollection<T> TraitInfos<T>() where T : ITraitInfoInterface
	{
		return traits.WithInterface<T>();
	}

	public BitSet<TargetableType> GetAllTargetTypes()
	{
		BitSet<TargetableType> result = default;
		foreach (ITargetableInfo item in TraitInfos<ITargetableInfo>())
		{
			result = result.Union(item.GetTargetTypes());
		}
		return result;
	}
}
