using OpenRA.Graphics;

namespace OpenRA;

public class ExternalMod
{
	public readonly string Id;

	public readonly string Version;

	public readonly string LaunchPath;

	public readonly string[] LaunchArgs;

	public Sprite Icon { get; internal set; }

	public Sprite Icon2x { get; internal set; }

	public Sprite Icon3x { get; internal set; }

	public static string MakeKey(Manifest mod)
	{
		return MakeKey(mod.Id, mod.Metadata.Version);
	}

	public static string MakeKey(ExternalMod mod)
	{
		return MakeKey(mod.Id, mod.Version);
	}

	public static string MakeKey(string modId, string modVersion)
	{
		return modId + "-" + modVersion;
	}
}
