using System.Net.Http;
using System.Threading.Tasks;
using OpenRA.FileFormats;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public class PlayerDatabase : IGlobalModData
{
	public readonly string Profile = "https://forum.openra.net/openra/info/";

	public readonly int IconSize = 24;

	[FieldLoader.Ignore]
	private SheetBuilder sheetBuilder;

	[FieldLoader.Ignore]
	private Cache<(PlayerBadge, int), Sprite> iconCache;

	private Sprite LoadSprite(string url, int density)
	{
		int spriteSize = IconSize * density;
		Sprite sprite = sheetBuilder.Allocate(new Size(spriteSize, spriteSize), 1f / (float)density);
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				HttpClient httpClient = HttpClientFactory.Create();
				Png icon = new Png(await (await httpClient.GetAsync(url)).Content.ReadAsStreamAsync());
				if (icon.Width == spriteSize && icon.Height == spriteSize)
				{
					Game.RunAfterTick(() =>
					{
						Util.FastCopyIntoSprite(sprite, icon);
						sprite.Sheet.CommitBufferedData();
					});
				}
			}
			catch
			{
			}
		});
		return sprite;
	}

	private Sheet CreateSheet()
	{
		Sheet sheet = new Sheet(SheetType.BGRA, new Size(512, 512));
		sheet.CreateBuffer();
		sheet.GetTexture().ScaleFilter = TextureScaleFilter.Linear;
		return sheet;
	}

	public PlayerBadge LoadBadge(MiniYaml yaml)
	{
		if (sheetBuilder == null)
		{
			sheetBuilder = new SheetBuilder(SheetType.BGRA, CreateSheet);
			iconCache = new Cache<(PlayerBadge, int), Sprite>(((PlayerBadge Badge, int Density) p) =>
			{
				if (p.Density > 2 && !string.IsNullOrEmpty(p.Badge.Icon3x))
				{
					return LoadSprite(p.Badge.Icon3x, 3);
				}
				return (p.Density > 1 && !string.IsNullOrEmpty(p.Badge.Icon2x)) ? LoadSprite(p.Badge.Icon2x, 2) : LoadSprite(p.Badge.Icon, 1);
			});
		}
		MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault("Label");
		MiniYamlNode miniYamlNode2 = yaml.NodeWithKeyOrDefault("Icon24");
		MiniYamlNode miniYamlNode3 = yaml.NodeWithKeyOrDefault("Icon48");
		MiniYamlNode miniYamlNode4 = yaml.NodeWithKeyOrDefault("Icon72");
		if (miniYamlNode == null)
		{
			return null;
		}
		return new PlayerBadge(miniYamlNode.Value.Value, miniYamlNode2?.Value.Value, miniYamlNode3?.Value.Value, miniYamlNode4?.Value.Value);
	}

	public Sprite GetIcon(PlayerBadge badge)
	{
		float windowScale = Game.Renderer.WindowScale;
		int item = ((windowScale > 2f) ? 3 : ((!(windowScale > 1f)) ? 1 : 2));
		return iconCache[(badge, item)];
	}
}
