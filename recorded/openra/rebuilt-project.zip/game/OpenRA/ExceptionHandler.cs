using System;
using System.Diagnostics;
using System.Globalization;
using System.Text;

namespace OpenRA;

public static class ExceptionHandler
{
	public static void HandleFatalError(Exception ex)
	{
		string baseFilename = "exception-" + DateTime.UtcNow.ToString("yyyy-MM-ddTHHmmssZ", CultureInfo.InvariantCulture) + ".log";
		Log.AddChannel("exception", baseFilename);
		if (Game.EngineVersion != null)
		{
			Log.Write("exception", "OpenRA engine version " + Game.EngineVersion);
		}
		if (Game.ModData != null)
		{
			Manifest manifest = Game.ModData.Manifest;
			Log.Write("exception", manifest.Id + " mod version " + manifest.Metadata.Version);
		}
		if (Game.OrderManager != null && Game.OrderManager.World != null && Game.OrderManager.World.Map != null)
		{
			Map map = Game.OrderManager.World.Map;
			Log.Write("exception", $"on map {map.Uid} ({map.Title} by {map.Author}).");
		}
		Log.Write("exception", $"Date: {DateTime.UtcNow:u}");
		Log.Write("exception", $"Operating System: {Platform.CurrentPlatform} ({Platform.CurrentArchitecture}, {Environment.OSVersion})");
		Log.Write("exception", "Runtime Version: " + Platform.RuntimeVersion);
		Log.Write("exception", "Installed Language: " + CultureInfo.InstalledUICulture.TwoLetterISOLanguageName + " (Installed) " + CultureInfo.CurrentCulture.TwoLetterISOLanguageName + " (Current) " + CultureInfo.CurrentUICulture.TwoLetterISOLanguageName + " (Current UI)");
		string value = BuildExceptionReport(ex).ToString();
		Log.Write("exception", value);
		Console.Error.WriteLine(value);
	}

	private static StringBuilder BuildExceptionReport(Exception ex)
	{
		return BuildExceptionReport(ex, new StringBuilder(), 0);
	}

	private static StringBuilder AppendIndentedLine(this StringBuilder sb, int indent, string message)
	{
		return sb.Append(new string(' ', indent * 2)).Append(message).AppendLine();
	}

	private static StringBuilder BuildExceptionReport(Exception ex, StringBuilder sb, int indent)
	{
		if (ex == null)
		{
			return sb;
		}
		sb.AppendIndentedLine(indent, "Exception of type `" + ex.GetType().FullName + "`: " + ex.Message);
		if (ex is TypeLoadException ex2)
		{
			sb.AppendIndentedLine(indent, "TypeName=`" + ex2.TypeName + "`");
		}
		else if (ex is OutOfMemoryException)
		{
			long totalMemory = GC.GetTotalMemory(forceFullCollection: false);
			GC.Collect();
			GC.WaitForPendingFinalizers();
			GC.Collect();
			sb.AppendIndentedLine(indent, $"GC Memory (post-collect)={GC.GetTotalMemory(forceFullCollection: false):N0}");
			sb.AppendIndentedLine(indent, $"GC Memory (pre-collect)={totalMemory:N0}");
			using Process process = Process.GetCurrentProcess();
			sb.AppendIndentedLine(indent, $"Working Set={process.WorkingSet64:N0}");
			sb.AppendIndentedLine(indent, $"Private Memory={process.PrivateMemorySize64:N0}");
			sb.AppendIndentedLine(indent, $"Virtual Memory={process.VirtualMemorySize64:N0}");
		}
		if (ex.InnerException != null)
		{
			sb.AppendIndentedLine(indent, "Inner");
			BuildExceptionReport(ex.InnerException, sb, indent + 1);
		}
		sb.AppendIndentedLine(indent, ex.StackTrace);
		return sb;
	}
}
