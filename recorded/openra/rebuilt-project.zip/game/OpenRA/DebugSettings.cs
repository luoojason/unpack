using System;

namespace OpenRA;

public class DebugSettings
{
	[Desc(new string[] { "Display average FPS and tick/render times" })]
	public bool PerfText;

	[Desc(new string[] { "Display a graph with various profiling traces" })]
	public bool PerfGraph;

	[Desc(new string[] { "Number of samples to average over when calculating tick and render times." })]
	public int Samples = 25;

	[Desc(new string[] { "Check whether a newer version is available online." })]
	public bool CheckVersion = true;

	[Desc(new string[] { "Allow the collection of anonymous data such as Operating System, .NET runtime, OpenGL version and language settings." })]
	public bool SendSystemInformation = true;

	[Desc(new string[] { "Version of sysinfo that the player last opted in or out of." })]
	public int SystemInformationVersionPrompt;

	[Desc(new string[] { "Sysinfo anonymous user identifier." })]
	public string UUID = Guid.NewGuid().ToString();

	[Desc(new string[] { "Enable hidden developer settings in the Advanced settings tab." })]
	public bool DisplayDeveloperSettings;

	[Desc(new string[] { "Display bot debug messages in the game chat." })]
	public bool BotDebug;

	[Desc(new string[] { "Display Lua debug messages in the game chat." })]
	public bool LuaDebug;

	[Desc(new string[] { "Enable the chat field during replays to allow use of console commands." })]
	public bool EnableDebugCommandsInReplays;

	[Desc(new string[] { "Enable perf.log output for traits, activities and effects." })]
	public bool EnableSimulationPerfLogging;

	[Desc(new string[] { "Amount of time required for triggering perf.log output." })]
	public float LongTickThresholdMs = 1f;

	[Desc(new string[] { "Throw an exception if the world sync hash changes while evaluating user input." })]
	public bool SyncCheckUnsyncedCode;

	[Desc(new string[] { "Throw an exception if the world sync hash changes while evaluating BotModules." })]
	public bool SyncCheckBotModuleCode;
}
