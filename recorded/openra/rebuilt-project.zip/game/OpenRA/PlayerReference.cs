using System;
using OpenRA.Primitives;

namespace OpenRA;

public class PlayerReference
{
	public string Name;

	public string Palette;

	public string Bot;

	public string StartingUnitsClass;

	public bool AllowBots = true;

	public bool Playable;

	public bool Required;

	public bool OwnsWorld;

	public bool Spectating;

	public bool NonCombatant;

	public bool LockFaction;

	public string Faction;

	public bool LockColor;

	public Color Color = Game.ModData.Manifest.Get<DefaultPlayer>().Color;

	public CPos HomeLocation = CPos.Zero;

	public bool LockSpawn;

	public int Spawn;

	public bool LockTeam;

	public int Team;

	public bool LockHandicap;

	public int Handicap;

	public string[] Allies = Array.Empty<string>();

	public string[] Enemies = Array.Empty<string>();

	public PlayerReference()
	{
	}

	public PlayerReference(MiniYaml my)
	{
		FieldLoader.Load(this, my);
	}

	public override string ToString()
	{
		return Name;
	}
}
