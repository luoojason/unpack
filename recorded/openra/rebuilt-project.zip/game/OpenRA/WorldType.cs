namespace OpenRA;

public enum WorldType
{
	Regular,
	Shellmap,
	Editor
}
