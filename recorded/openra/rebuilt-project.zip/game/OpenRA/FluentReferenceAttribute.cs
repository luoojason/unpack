using System;
using OpenRA.Traits;

namespace OpenRA;

[AttributeUsage(AttributeTargets.Field)]
public sealed class FluentReferenceAttribute : Attribute
{
	public readonly bool Optional;

	public readonly string[] RequiredVariableNames;

	public readonly LintDictionaryReference DictionaryReference;

	public FluentReferenceAttribute()
	{
	}

	public FluentReferenceAttribute(params string[] requiredVariableNames)
	{
		RequiredVariableNames = requiredVariableNames;
	}

	public FluentReferenceAttribute(LintDictionaryReference dictionaryReference = LintDictionaryReference.None)
	{
		DictionaryReference = dictionaryReference;
	}

	public FluentReferenceAttribute(bool optional)
	{
		Optional = optional;
	}
}
