namespace OpenRA;

public class GameSettings
{
	public string Platform = "Default";

	public bool ViewportEdgeScroll = true;

	public int ViewportEdgeScrollMargin = 5;

	public bool LockMouseWindow;

	public MouseScrollType MouseScroll = MouseScrollType.Joystick;

	public MouseButtonPreference MouseButtonPreference = new MouseButtonPreference();

	public float ViewportEdgeScrollStep = 30f;

	public float UIScrollSpeed = 50f;

	public float ZoomSpeed = 0.04f;

	public int SelectionDeadzone = 24;

	public int MouseScrollDeadzone = 8;

	public bool UseClassicMouseStyle;

	public bool UseAlternateScrollButton;

	public bool HideReplayChat;

	public StatusBarsType StatusBars;

	public TargetLinesType TargetLines = TargetLinesType.Manual;

	public bool UsePlayerStanceColors;

	public bool AllowDownloading = true;

	[Desc(new string[] { "Filename of the authentication profile to use." })]
	public string AuthProfile = "player.oraid";

	public Modifiers ZoomModifier;

	public bool FetchNews = true;

	[Desc(new string[] { "Version of introduction prompt that the player last viewed." })]
	public int IntroductionPromptVersion;

	public MPGameFilters MPGameFilters = MPGameFilters.Waiting | MPGameFilters.Empty | MPGameFilters.Protected | MPGameFilters.Started;

	public bool PauseShellmap;

	[Desc(new string[] { "Allow mods to enable the Discord service that can interact with a local Discord client." })]
	public bool EnableDiscordService = true;

	public TextNotificationPoolFilters TextNotificationPoolFilters = TextNotificationPoolFilters.Feedback | TextNotificationPoolFilters.Transients;
}
