using System.Collections.Generic;

namespace OpenRA;

internal static class ListExts
{
	public static int BinarySearchMany(this List<Actor> list, uint searchFor)
	{
		int num = 0;
		int num2 = list.Count;
		while (num != num2)
		{
			int num3 = (num + num2) / 2;
			if (list[num3].ActorID < searchFor)
			{
				num = num3 + 1;
			}
			else
			{
				num2 = num3;
			}
		}
		return num;
	}
}
