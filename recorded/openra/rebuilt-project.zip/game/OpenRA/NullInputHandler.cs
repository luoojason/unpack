namespace OpenRA;

public class NullInputHandler : IInputHandler
{
	public void ModifierKeys(Modifiers mods)
	{
	}

	public void OnKeyInput(KeyInput input)
	{
	}

	public void OnTextInput(string text)
	{
	}

	public void OnMouseInput(MouseInput input)
	{
	}
}
