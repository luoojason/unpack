using System;
using OpenRA.Primitives;

namespace OpenRA;

public interface IPlatformWindow : IDisposable
{
	IGraphicsContext Context { get; }

	Size NativeWindowSize { get; }

	Size EffectiveWindowSize { get; }

	float NativeWindowScale { get; }

	float EffectiveWindowScale { get; }

	Size SurfaceSize { get; }

	int DisplayCount { get; }

	int CurrentDisplay { get; }

	bool HasInputFocus { get; }

	bool IsSuspended { get; }

	GLProfile GLProfile { get; }

	GLProfile[] SupportedGLProfiles { get; }

	event Action<float, float, float, float> OnWindowScaleChanged;

	void PumpInput(IInputHandler inputHandler);

	string GetClipboardText();

	bool SetClipboardText(string text);

	void GrabWindowMouseFocus();

	void ReleaseWindowMouseFocus();

	IHardwareCursor CreateHardwareCursor(string name, Size size, byte[] data, int2 hotspot, bool pixelDouble);

	void SetHardwareCursor(IHardwareCursor cursor);

	void SetWindowTitle(string title);

	void SetRelativeMouseMode(bool mode);

	void SetScaleModifier(float scale);
}
