using System;
using OpenRA.Primitives;

namespace OpenRA;

public readonly struct MPos(int u, int v) : IEquatable<MPos>
{
	public readonly int U = u;

	public readonly int V = v;

	public static readonly MPos Zero = new MPos(0, 0);

	public static bool operator ==(MPos me, MPos other)
	{
		if (me.U == other.U)
		{
			return me.V == other.V;
		}
		return false;
	}

	public static bool operator !=(MPos me, MPos other)
	{
		return !(me == other);
	}

	public override int GetHashCode()
	{
		return U.GetHashCode() ^ V.GetHashCode();
	}

	public bool Equals(MPos other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is MPos other)
		{
			return Equals(other);
		}
		return false;
	}

	public MPos Clamp(Rectangle r)
	{
		return new MPos(Math.Min(r.Right, Math.Max(U, r.Left)), Math.Min(r.Bottom, Math.Max(V, r.Top)));
	}

	public override string ToString()
	{
		return U + "," + V;
	}

	public CPos ToCPos(Map map)
	{
		return ToCPos(map.Grid.Type);
	}

	public CPos ToCPos(MapGridType gridType)
	{
		if (gridType == MapGridType.Rectangular)
		{
			return new CPos(U, V);
		}
		int num = (((V & 1) == 1) ? 1 : 0);
		int num2 = (V - num) / 2 - U;
		int x = V - num2;
		return new CPos(x, num2);
	}
}
