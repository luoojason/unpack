namespace OpenRA;

public class SoundDevice
{
	public readonly string Device;

	public readonly string Label;

	public SoundDevice(string device, string label)
	{
		Device = device;
		Label = label;
	}
}
