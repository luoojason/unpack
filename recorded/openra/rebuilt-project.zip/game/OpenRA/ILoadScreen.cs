using System;
using System.Collections.Generic;

namespace OpenRA;

public interface ILoadScreen : IDisposable
{
	void Init(ModData m, Dictionary<string, string> info);

	void Display();

	bool BeforeLoad();

	void StartGame(Arguments args);
}
