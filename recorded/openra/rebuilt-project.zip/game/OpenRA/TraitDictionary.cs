using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

internal sealed class TraitDictionary
{
	private interface ITraitContainer
	{
		int Queries { get; }

		void Add(Actor actor, object trait);

		void RemoveActor(uint actor);
	}

	private sealed class TraitContainer<T> : ITraitContainer
	{
		private sealed class MultipleEnumerable : IEnumerable<T>, IEnumerable
		{
			private readonly TraitContainer<T> container;

			private readonly uint actor;

			public MultipleEnumerable(TraitContainer<T> container, uint actor)
			{
				this.container = container;
				this.actor = actor;
			}

			public IEnumerator<T> GetEnumerator()
			{
				return new MultipleEnumerator(container, actor);
			}

			IEnumerator IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}
		}

		private struct MultipleEnumerator : IEnumerator<T>, IEnumerator, IDisposable
		{
			private readonly List<Actor> actors;

			private readonly List<T> traits;

			private readonly uint actor;

			private int index;

			public readonly T Current => traits[index];

			readonly object IEnumerator.Current => Current;

			public MultipleEnumerator(TraitContainer<T> container, uint actor)
			{
				this = default;
				actors = container.actors;
				traits = container.traits;
				this.actor = actor;
				Reset();
			}

			public void Reset()
			{
				index = actors.BinarySearchMany(actor) - 1;
			}

			public bool MoveNext()
			{
				if (++index < actors.Count)
				{
					return actors[index].ActorID == actor;
				}
				return false;
			}

			public readonly void Dispose()
			{
			}
		}

		private readonly struct AllEnumerable(TraitContainer<T> container) : IEnumerable<TraitPair<T>>, IEnumerable
		{
			private readonly TraitContainer<T> container = container;

			public IEnumerator<TraitPair<T>> GetEnumerator()
			{
				return new AllEnumerator(container);
			}

			IEnumerator IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}
		}

		private struct AllEnumerator : IEnumerator<TraitPair<T>>, IEnumerator, IDisposable
		{
			private readonly List<Actor> actors;

			private readonly List<T> traits;

			private int index;

			public readonly TraitPair<T> Current => new TraitPair<T>(actors[index], traits[index]);

			readonly object IEnumerator.Current => Current;

			public AllEnumerator(TraitContainer<T> container)
			{
				this = default;
				actors = container.actors;
				traits = container.traits;
				Reset();
			}

			public void Reset()
			{
				index = -1;
			}

			public bool MoveNext()
			{
				return ++index < actors.Count;
			}

			public readonly void Dispose()
			{
			}
		}

		private readonly List<Actor> actors = new List<Actor>();

		private readonly List<T> traits = new List<T>();

		public int Queries { get; private set; }

		public void Add(Actor actor, object trait)
		{
			int index = actors.BinarySearchMany(actor.ActorID + 1);
			actors.Insert(index, actor);
			traits.Insert(index, (T)trait);
		}

		public T Get(Actor actor)
		{
			T orDefault = GetOrDefault(actor);
			if (orDefault == null)
			{
				throw new InvalidOperationException($"Actor {actor.Info.Name} does not have trait of type `{typeof(T)}`");
			}
			return orDefault;
		}

		public T GetOrDefault(Actor actor)
		{
			int queries = Queries + 1;
			Queries = queries;
			int num = actors.BinarySearchMany(actor.ActorID);
			if (num >= actors.Count || actors[num] != actor)
			{
				return default;
			}
			if (num + 1 < actors.Count && actors[num + 1] == actor)
			{
				throw new InvalidOperationException($"Actor {actor.Info.Name} has multiple traits of type `{typeof(T)}`");
			}
			return traits[num];
		}

		public IEnumerable<T> GetMultiple(uint actor)
		{
			int queries = Queries + 1;
			Queries = queries;
			return new MultipleEnumerable(this, actor);
		}

		public IEnumerable<TraitPair<T>> All()
		{
			int queries = Queries + 1;
			Queries = queries;
			return new AllEnumerable(this);
		}

		public IEnumerable<Actor> Actors()
		{
			int queries = Queries + 1;
			Queries = queries;
			Actor actor = null;
			for (int i = 0; i < actors.Count; i++)
			{
				Actor current = actors[i];
				if (current != actor)
				{
					yield return current;
					actor = current;
				}
			}
		}

		public IEnumerable<Actor> Actors(Func<T, bool> predicate)
		{
			int queries = Queries + 1;
			Queries = queries;
			Actor actor = null;
			for (int i = 0; i < actors.Count; i++)
			{
				Actor current = actors[i];
				if (current != actor && predicate(traits[i]))
				{
					yield return current;
					actor = current;
				}
			}
		}

		public void RemoveActor(uint actor)
		{
			int num = actors.BinarySearchMany(actor);
			if (num < actors.Count && actors[num].ActorID == actor)
			{
				int i;
				for (i = num + 1; i < actors.Count && actors[i].ActorID == actor; i++)
				{
				}
				int count = i - num;
				actors.RemoveRange(num, count);
				traits.RemoveRange(num, count);
			}
		}

		public void ApplyToAll(Action<Actor, T> action)
		{
			for (int i = 0; i < actors.Count; i++)
			{
				action(actors[i], traits[i]);
			}
		}

		public void ApplyToAllTimed(Action<Actor, T> action, string text)
		{
			long startTimestamp = PerfTickLogger.GetTimestamp();
			for (int i = 0; i < actors.Count; i++)
			{
				Actor arg = actors[i];
				T val = traits[i];
				action(arg, val);
				startTimestamp = PerfTickLogger.LogLongTick(startTimestamp, text, val);
			}
		}
	}

	private static readonly Func<Type, ITraitContainer> CreateTraitContainer = (Type t) => (ITraitContainer)typeof(TraitContainer<>).MakeGenericType(t).GetConstructor(Type.EmptyTypes).Invoke(null);

	private readonly Dictionary<Type, ITraitContainer> traits = new Dictionary<Type, ITraitContainer>();

	private ITraitContainer InnerGet(Type t)
	{
		return traits.GetOrAdd(t, CreateTraitContainer);
	}

	private TraitContainer<T> InnerGet<T>()
	{
		return (TraitContainer<T>)InnerGet(typeof(T));
	}

	public void PrintReport()
	{
		Log.AddChannel("traitreport", "traitreport.log");
		foreach (KeyValuePair<Type, ITraitContainer> item in traits.OrderByDescending((KeyValuePair<Type, ITraitContainer> t) => t.Value.Queries).TakeWhile((KeyValuePair<Type, ITraitContainer> t) => t.Value.Queries > 0))
		{
			Log.Write("traitreport", $"{item.Key.Name}: {item.Value.Queries}");
		}
	}

	public void AddTrait(Actor actor, object val)
	{
		Type type = val.GetType();
		Type[] interfaces = type.GetInterfaces();
		foreach (Type t in interfaces)
		{
			InnerAdd(actor, t, val);
		}
		foreach (Type item in type.BaseTypes())
		{
			InnerAdd(actor, item, val);
		}
	}

	private void InnerAdd(Actor actor, Type t, object val)
	{
		InnerGet(t).Add(actor, val);
	}

	private static void CheckDestroyed(Actor actor)
	{
		if (actor.Disposed)
		{
			throw new InvalidOperationException($"Attempted to get trait from destroyed object ({actor})");
		}
	}

	public T Get<T>(Actor actor)
	{
		CheckDestroyed(actor);
		return InnerGet<T>().Get(actor);
	}

	public T GetOrDefault<T>(Actor actor)
	{
		CheckDestroyed(actor);
		return InnerGet<T>().GetOrDefault(actor);
	}

	public IEnumerable<T> WithInterface<T>(Actor actor)
	{
		CheckDestroyed(actor);
		return InnerGet<T>().GetMultiple(actor.ActorID);
	}

	public IEnumerable<TraitPair<T>> ActorsWithTrait<T>()
	{
		return InnerGet<T>().All();
	}

	public IEnumerable<Actor> ActorsHavingTrait<T>()
	{
		return InnerGet<T>().Actors();
	}

	public IEnumerable<Actor> ActorsHavingTrait<T>(Func<T, bool> predicate)
	{
		return InnerGet<T>().Actors(predicate);
	}

	public void RemoveActor(Actor a)
	{
		foreach (KeyValuePair<Type, ITraitContainer> trait in traits)
		{
			trait.Value.RemoveActor(a.ActorID);
		}
	}

	public void ApplyToActorsWithTrait<T>(Action<Actor, T> action)
	{
		InnerGet<T>().ApplyToAll(action);
	}

	public void ApplyToActorsWithTraitTimed<T>(Action<Actor, T> action, string text)
	{
		InnerGet<T>().ApplyToAllTimed(action, text);
	}
}
