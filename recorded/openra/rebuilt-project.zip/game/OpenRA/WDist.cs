using System;
using System.Linq;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Scripting;
using OpenRA.Support;

namespace OpenRA;

public readonly struct WDist : IComparable, IComparable<WDist>, IEquatable<WDist>, IScriptBindable, ILuaAdditionBinding, ILuaSubtractionBinding, ILuaEqualityBinding, ILuaUnaryMinusBinding, ILuaMultiplicationBinding, ILuaDivisionBinding, ILuaLessThanBinding, ILuaLessThanOrEqualToBinding, ILuaTableBinding, ILuaToStringBinding
{
	public readonly int Length;

	public static readonly WDist Zero = new WDist(0);

	public static readonly WDist MaxValue = new WDist(int.MaxValue);

	public long LengthSquared => (long)Length * (long)Length;

	public LuaValue this[LuaRuntime runtime, LuaValue key]
	{
		get
		{
			string text = key.ToString();
			if (text == "Length")
			{
				return Length;
			}
			throw new LuaException($"WDist does not define a member '{key}'");
		}
		set
		{
			throw new LuaException("WDist is read-only. Use WDist.New to create a new value");
		}
	}

	public WDist(int r)
	{
		Length = r;
	}

	public static WDist FromCells(int cells)
	{
		return new WDist(1024 * cells);
	}

	public static WDist operator +(WDist a, WDist b)
	{
		return new WDist(a.Length + b.Length);
	}

	public static WDist operator -(WDist a, WDist b)
	{
		return new WDist(a.Length - b.Length);
	}

	public static WDist operator -(WDist a)
	{
		return new WDist(-a.Length);
	}

	public static WDist operator /(WDist a, int b)
	{
		return new WDist(a.Length / b);
	}

	public static WDist operator *(WDist a, int b)
	{
		return new WDist(a.Length * b);
	}

	public static WDist operator *(int a, WDist b)
	{
		return new WDist(a * b.Length);
	}

	public static bool operator <(WDist a, WDist b)
	{
		return a.Length < b.Length;
	}

	public static bool operator >(WDist a, WDist b)
	{
		return a.Length > b.Length;
	}

	public static bool operator <=(WDist a, WDist b)
	{
		return a.Length <= b.Length;
	}

	public static bool operator >=(WDist a, WDist b)
	{
		return a.Length >= b.Length;
	}

	public static bool operator ==(WDist me, WDist other)
	{
		return me.Length == other.Length;
	}

	public static bool operator !=(WDist me, WDist other)
	{
		return !(me == other);
	}

	public static WDist FromPDF(MersenneTwister r, int samples)
	{
		return new WDist(Exts.MakeArray(samples, (int _) => r.Next(-1024, 1024)).Sum() / samples);
	}

	public static bool TryParse(string s, out WDist result)
	{
		result = Zero;
		if (string.IsNullOrEmpty(s))
		{
			return false;
		}
		s = s.ToLowerInvariant();
		string[] array = s.Split('c');
		int i = 0;
		int i2;
		switch (array.Length)
		{
		case 2:
			if (!Exts.TryParseInt32Invariant(array[0], out i) || !Exts.TryParseInt32Invariant(array[1], out i2))
			{
				return false;
			}
			break;
		case 1:
			if (!Exts.TryParseInt32Invariant(array[0], out i2))
			{
				return false;
			}
			break;
		default:
			return false;
		}
		if (i < 0)
		{
			i2 = -i2;
		}
		result = new WDist(1024 * i + i2);
		return true;
	}

	public override int GetHashCode()
	{
		return Length.GetHashCode();
	}

	public bool Equals(WDist other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is WDist other)
		{
			return Equals(other);
		}
		return false;
	}

	public int CompareTo(object obj)
	{
		if (!(obj is WDist))
		{
			return 1;
		}
		return Length.CompareTo(((WDist)obj).Length);
	}

	public int CompareTo(WDist other)
	{
		return Length.CompareTo(other.Length);
	}

	public override string ToString()
	{
		int num = Math.Abs(Length);
		string text = (num / 1024).ToStringInvariant() + "c" + (num % 1024).ToStringInvariant();
		if (Length >= 0)
		{
			return text;
		}
		return "-" + text;
	}

	public LuaValue Add(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<WDist>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.Add(WDist, WDist) with invalid arguments.");
		}
		return new LuaCustomClrObject(clrObject + clrObject2);
	}

	public LuaValue Subtract(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<WDist>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.Subtract(WDist, WDist) with invalid arguments.");
		}
		return new LuaCustomClrObject(clrObject - clrObject2);
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<WDist>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.Equals(WDist, WDist) with invalid arguments.");
		}
		return clrObject == clrObject2;
	}

	public LuaValue Minus(LuaRuntime runtime)
	{
		return new LuaCustomClrObject(-this);
	}

	public LuaValue Multiply(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<int>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.Multiply(WDist, integer) with invalid arguments.");
		}
		return new LuaCustomClrObject(clrObject * clrObject2);
	}

	public LuaValue Divide(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<int>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.Divide(WDist, integer) with invalid arguments.");
		}
		return new LuaCustomClrObject(clrObject / clrObject2);
	}

	public LuaValue LessThan(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<WDist>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.LessThan(WDist, WDist) with invalid arguments.");
		}
		return clrObject < clrObject2;
	}

	public LuaValue LessThanOrEqualTo(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WDist>(out var clrObject) || !right.TryGetClrValue<WDist>(out var clrObject2))
		{
			throw new LuaException("Attempted to call WDist.LessThanOrEqualTo(WDist, WDist) with invalid arguments.");
		}
		return clrObject <= clrObject2;
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return ToString();
	}
}
