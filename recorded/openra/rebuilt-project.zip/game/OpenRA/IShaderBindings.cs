using OpenRA.Graphics;

namespace OpenRA;

public interface IShaderBindings
{
	string VertexShaderName { get; }

	string VertexShaderCode { get; }

	string FragmentShaderName { get; }

	string FragmentShaderCode { get; }

	int Stride { get; }

	ShaderVertexAttribute[] Attributes { get; }
}
