using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using OpenRA.FileSystem;

namespace OpenRA;

public sealed class MiniYaml
{
	private const int SpacesPerLevel = 4;

	private static readonly Func<string, string> StringIdentity = (string s) => s;

	private static readonly Func<MiniYaml, MiniYaml> MiniYamlIdentity = (MiniYaml my) => my;

	private static readonly Dictionary<string, MiniYamlNode> ConflictScratch = new Dictionary<string, MiniYamlNode>();

	public readonly string Value;

	public readonly ImmutableArray<MiniYamlNode> Nodes;

	public MiniYaml WithValue(string value)
	{
		if (Value == value)
		{
			return this;
		}
		return new MiniYaml(value, Nodes);
	}

	public MiniYaml WithNodes(IEnumerable<MiniYamlNode> nodes)
	{
		if (nodes is ImmutableArray<MiniYamlNode> immutableArray && Nodes == immutableArray)
		{
			return this;
		}
		return new MiniYaml(Value, nodes);
	}

	public MiniYaml WithNodesAppended(IEnumerable<MiniYamlNode> nodes)
	{
		ImmutableArray<MiniYamlNode> immutableArray = Nodes.AddRange(nodes);
		if (Nodes == immutableArray)
		{
			return this;
		}
		return new MiniYaml(Value, immutableArray);
	}

	public MiniYamlNode NodeWithKey(string key)
	{
		MiniYamlNode miniYamlNode = NodeWithKeyOrDefault(key);
		if (miniYamlNode == null)
		{
			throw new InvalidDataException("No node with key '" + key + "'");
		}
		return miniYamlNode;
	}

	public MiniYamlNode NodeWithKeyOrDefault(string key)
	{
		bool flag = true;
		MiniYamlNode result = null;
		foreach (MiniYamlNode node in Nodes)
		{
			if (!(node.Key != key))
			{
				if (!flag)
				{
					throw new InvalidDataException($"Duplicate key '{node.Key}' in {node.Location}");
				}
				flag = false;
				result = node;
			}
		}
		return result;
	}

	public Dictionary<string, MiniYaml> ToDictionary()
	{
		return ToDictionary(MiniYamlIdentity);
	}

	public Dictionary<string, TElement> ToDictionary<TElement>(Func<MiniYaml, TElement> elementSelector)
	{
		return ToDictionary(StringIdentity, elementSelector);
	}

	public Dictionary<TKey, TElement> ToDictionary<TKey, TElement>(Func<string, TKey> keySelector, Func<MiniYaml, TElement> elementSelector)
	{
		Dictionary<TKey, TElement> dictionary = new Dictionary<TKey, TElement>(Nodes.Length);
		foreach (MiniYamlNode node in Nodes)
		{
			TKey key = keySelector(node.Key);
			TElement value = elementSelector(node.Value);
			if (!dictionary.TryAdd(key, value))
			{
				throw new InvalidDataException($"Duplicate key '{node.Key}' in {node.Location}");
			}
		}
		return dictionary;
	}

	public MiniYaml(string value)
		: this(value, Enumerable.Empty<MiniYamlNode>())
	{
	}

	public MiniYaml(string value, IEnumerable<MiniYamlNode> nodes)
	{
		Value = value;
		Nodes = ImmutableArray.CreateRange(nodes);
	}

	private static List<MiniYamlNode> FromLines(IEnumerable<ReadOnlyMemory<char>> lines, string name, bool discardCommentsAndWhitespace, HashSet<string> stringPool)
	{
		if (stringPool == null)
		{
			stringPool = new HashSet<string>();
		}
		List<List<MiniYamlNode>> result = new List<List<MiniYamlNode>>
		{
			new List<MiniYamlNode>()
		};
		List<(int Level, string Key, string Value, string Comment, MiniYamlNode.SourceLocation Location)> parsedLines = new List<(int, string, string, string, MiniYamlNode.SourceLocation)>();
		int num = 0;
		foreach (ReadOnlyMemory<char> line in lines)
		{
			ReadOnlySpan<char> span = line.Span;
			num++;
			int num2 = 0;
			int num3 = 0;
			int num4 = 0;
			bool flag = false;
			ReadOnlySpan<char> readOnlySpan = default;
			ReadOnlySpan<char> span2 = default;
			ReadOnlySpan<char> readOnlySpan2 = default;
			MiniYamlNode.SourceLocation sourceLocation = new MiniYamlNode.SourceLocation(name, num);
			int num8;
			int num9;
			if (span.Length > 0)
			{
				char c = span[num2];
				while (c != '\n' && c != '\r' && num2 < span.Length && !flag)
				{
					c = span[num2];
					switch (c)
					{
					case ' ':
						num4++;
						if (num4 >= 4)
						{
							num4 = 0;
							num3++;
						}
						num2++;
						break;
					case '\t':
						num3++;
						num2++;
						break;
					default:
						flag = true;
						break;
					}
				}
				int num5 = span.Length - num2;
				int num6 = -1;
				int length = 0;
				int num7 = -1;
				for (int i = 0; i < span.Length; i++)
				{
					if (num6 < 0 && span[i] == ':')
					{
						num6 = i + 1;
						num5 = i - num2;
						length = span.Length - i - 1;
					}
					if (num7 < 0 && span[i] == '#' && (i == 0 || span[i - 1] != '\\'))
					{
						num7 = i + 1;
						if (i <= num2 + num5)
						{
							num5 = i - num2;
						}
						else
						{
							length = i - num6;
						}
						break;
					}
				}
				if (num5 > 0)
				{
					readOnlySpan = span.Slice(num2, num5).Trim();
				}
				if (num6 >= 0)
				{
					ReadOnlySpan<char> readOnlySpan3 = span.Slice(num6, length).Trim();
					if (readOnlySpan3.Length > 0)
					{
						span2 = readOnlySpan3;
					}
				}
				if (num7 >= 0 && !discardCommentsAndWhitespace)
				{
					readOnlySpan2 = span.Slice(num7);
				}
				if (span2.Length > 1)
				{
					num8 = ((span2[0] == '\\' && (span2[1] == ' ' || span2[1] == '\t')) ? 1 : 0);
					if (span2[span2.Length - 1] != '\\')
					{
						goto IL_0260;
					}
					if (span2[span2.Length - 2] != ' ')
					{
						if (span2[span2.Length - 2] != '\t')
						{
							goto IL_0260;
						}
					}
					num9 = 1;
					goto IL_0264;
				}
			}
			goto IL_02bd;
			IL_0260:
			num9 = 0;
			goto IL_0264;
			IL_02bd:
			if (readOnlySpan.IsEmpty && discardCommentsAndWhitespace)
			{
				continue;
			}
			if (parsedLines.Count > 0)
			{
				List<(int Level, string Key, string Value, string Comment, MiniYamlNode.SourceLocation Location)> list = parsedLines;
				if (list[list.Count - 1].Level < num3 - 1)
				{
					throw new YamlException($"Bad indent in miniyaml at {sourceLocation}");
				}
			}
			while (parsedLines.Count > 0)
			{
				List<(int Level, string Key, string Value, string Comment, MiniYamlNode.SourceLocation Location)> list2 = parsedLines;
				if (list2[list2.Count - 1].Level <= num3)
				{
					break;
				}
				BuildCompletedSubNode(num3);
			}
			string text = (readOnlySpan.IsEmpty ? null : readOnlySpan.ToString());
			string text2 = (span2.IsEmpty ? null : span2.ToString());
			string text3 = ((readOnlySpan2 == ReadOnlySpan<char>.Empty) ? null : readOnlySpan2.ToString());
			text = ((text == null) ? null : stringPool.GetOrAdd(text));
			text2 = ((text2 == null) ? null : stringPool.GetOrAdd(text2));
			text3 = ((text3 == null) ? null : stringPool.GetOrAdd(text3));
			parsedLines.Add((num3, text, text2, text3, sourceLocation));
			continue;
			IL_0264:
			int num10 = num9;
			if (num8 + num10 > 0)
			{
				span2 = span2.Slice(num8, span2.Length - num8 - num10);
			}
			if (span2.Contains("\\#", StringComparison.Ordinal))
			{
				span2 = span2.ToString().Replace("\\#", "#");
			}
			goto IL_02bd;
		}
		if (parsedLines.Count > 0)
		{
			BuildCompletedSubNode(0);
		}
		return result[0];
		void BuildCompletedSubNode(int level)
		{
			List<(int Level, string Key, string Value, string Comment, MiniYamlNode.SourceLocation Location)> list3 = parsedLines;
			int item = list3[list3.Count - 1].Level;
			while (item >= result.Count)
			{
				result.Add(new List<MiniYamlNode>());
			}
			while (parsedLines.Count > 0)
			{
				List<(int Level, string Key, string Value, string Comment, MiniYamlNode.SourceLocation Location)> list4 = parsedLines;
				if (list4[list4.Count - 1].Level < level)
				{
					break;
				}
				List<(int Level, string Key, string Value, string Comment, MiniYamlNode.SourceLocation Location)> list5 = parsedLines;
				(int, string, string, string, MiniYamlNode.SourceLocation) tuple = list5[list5.Count - 1];
				int num11 = parsedLines.Count - 1;
				while (num11 > 0 && parsedLines[num11 - 1].Level == tuple.Item1)
				{
					num11--;
				}
				for (int j = num11; j < parsedLines.Count - 1; j++)
				{
					(int, string, string, string, MiniYamlNode.SourceLocation) tuple2 = parsedLines[j];
					result[tuple.Item1].Add(new MiniYamlNode(tuple2.Item2, new MiniYaml(tuple2.Item3), tuple2.Item4, tuple2.Item5));
				}
				List<MiniYamlNode> list6 = ((tuple.Item1 + 1 < result.Count) ? result[tuple.Item1 + 1] : null);
				List<MiniYamlNode> list7 = result[tuple.Item1];
				string item2 = tuple.Item2;
				string item3 = tuple.Item3;
				IEnumerable<MiniYamlNode> enumerable = list6;
				list7.Add(new MiniYamlNode(item2, new MiniYaml(item3, enumerable ?? Enumerable.Empty<MiniYamlNode>()), tuple.Item4, tuple.Item5));
				list6?.Clear();
				parsedLines.RemoveRange(num11, parsedLines.Count - num11);
			}
		}
	}

	public static List<MiniYamlNode> FromFile(string path, bool discardCommentsAndWhitespace = true, HashSet<string> stringPool = null)
	{
		return FromStream(File.OpenRead(path), path, discardCommentsAndWhitespace, stringPool);
	}

	public static List<MiniYamlNode> FromStream(Stream s, string name, bool discardCommentsAndWhitespace = true, HashSet<string> stringPool = null)
	{
		return FromLines(s.ReadAllLinesAsMemory(), name, discardCommentsAndWhitespace, stringPool);
	}

	public static List<MiniYamlNode> FromString(string text, string name, bool discardCommentsAndWhitespace = true, HashSet<string> stringPool = null)
	{
		return FromLines(from s in text.Split(new string[2] { "\r\n", "\n" }, StringSplitOptions.None)
			select s.AsMemory(), name, discardCommentsAndWhitespace, stringPool);
	}

	public static List<MiniYamlNode> Merge(IEnumerable<IReadOnlyCollection<MiniYamlNode>> sources)
	{
		List<IReadOnlyCollection<MiniYamlNode>> list = sources.ToList();
		if (list.Count == 0)
		{
			return new List<MiniYamlNode>();
		}
		Dictionary<string, MiniYaml> dictionary = (from n in list.Where((IReadOnlyCollection<MiniYamlNode> s) => s != null).Select(MergeSelfPartial).Aggregate(MergePartial)
			where n.Key != null
			select n).ToDictionary((MiniYamlNode n) => n.Key, (MiniYamlNode n) => n.Value);
		Dictionary<string, MiniYaml> dictionary2 = new Dictionary<string, MiniYaml>(dictionary.Count);
		foreach (KeyValuePair<string, MiniYaml> item in dictionary)
		{
			ImmutableDictionary<string, MiniYamlNode.SourceLocation> inherited = ImmutableDictionary<string, MiniYamlNode.SourceLocation>.Empty.Add(item.Key, default);
			IReadOnlyCollection<MiniYamlNode> nodes = ResolveInherits(item.Value, dictionary, inherited);
			dictionary2.Add(item.Key, new MiniYaml(item.Value.Value, nodes));
		}
		MiniYaml node = new MiniYaml("", dictionary2.Select((KeyValuePair<string, MiniYaml> kv) => new MiniYamlNode(kv.Key, kv.Value)));
		IReadOnlyCollection<MiniYamlNode> readOnlyCollection = ResolveInherits(node, dictionary, ImmutableDictionary<string, MiniYamlNode.SourceLocation>.Empty);
		return (readOnlyCollection as List<MiniYamlNode>) ?? readOnlyCollection.ToList();
	}

	private static void MergeIntoResolved(MiniYamlNode overrideNode, List<MiniYamlNode> existingNodes, HashSet<string> existingNodeKeys, Dictionary<string, MiniYaml> tree, ImmutableDictionary<string, MiniYamlNode.SourceLocation> inherited)
	{
		int index = -1;
		MiniYamlNode miniYamlNode = null;
		if (!existingNodeKeys.Add(overrideNode.Key))
		{
			index = IndexOfKey(existingNodes, overrideNode.Key);
			miniYamlNode = existingNodes[index];
		}
		MiniYaml miniYaml = MergePartial(miniYamlNode?.Value, overrideNode.Value);
		IReadOnlyCollection<MiniYamlNode> readOnlyCollection = ResolveInherits(miniYaml, tree, inherited);
		if (!miniYaml.Nodes.SequenceEqual(readOnlyCollection))
		{
			miniYaml = miniYaml.WithNodes(readOnlyCollection);
		}
		if (miniYamlNode != null)
		{
			existingNodes[index] = miniYamlNode.WithValue(miniYaml);
		}
		else
		{
			existingNodes.Add(overrideNode.WithValue(miniYaml));
		}
	}

	private static IReadOnlyCollection<MiniYamlNode> ResolveInherits(MiniYaml node, Dictionary<string, MiniYaml> tree, ImmutableDictionary<string, MiniYamlNode.SourceLocation> inherited)
	{
		if (node.Nodes.Length == 0)
		{
			return node.Nodes;
		}
		List<MiniYamlNode> list = new List<MiniYamlNode>(node.Nodes.Length);
		HashSet<string> hashSet = new HashSet<string>(node.Nodes.Length);
		foreach (MiniYamlNode node2 in node.Nodes)
		{
			if (node2.Key == "Inherits" || node2.Key.StartsWith("Inherits@", StringComparison.Ordinal))
			{
				if (!tree.TryGetValue(node2.Value.Value, out var value))
				{
					throw new YamlException($"{node2.Location}: Parent type `{node2.Value.Value}` not found");
				}
				try
				{
					inherited = inherited.Add(node2.Value.Value, node2.Location);
				}
				catch (ArgumentException)
				{
					throw new YamlException($"{node2.Location}: Parent type `{node2.Value.Value}` was already inherited by this yaml tree at {inherited[node2.Value.Value]} (note: may be from a derived tree)");
				}
				foreach (MiniYamlNode item in ResolveInherits(value, tree, inherited))
				{
					MergeIntoResolved(item, list, hashSet, tree, inherited);
				}
			}
			else if (node2.Key.StartsWith('-'))
			{
				string removed = node2.Key.Substring(1);
				if (list.RemoveAll((MiniYamlNode r) => r.Key == removed) == 0)
				{
					throw new YamlException($"{node2.Location}: There are no elements with key `{removed}` to remove");
				}
				hashSet.Remove(removed);
			}
			else
			{
				MergeIntoResolved(node2, list, hashSet, tree, inherited);
			}
		}
		return list;
	}

	private static IReadOnlyCollection<MiniYamlNode> MergeSelfPartial(IReadOnlyCollection<MiniYamlNode> existingNodes)
	{
		if (existingNodes.Count == 0)
		{
			return existingNodes;
		}
		HashSet<string> hashSet = new HashSet<string>(existingNodes.Count);
		List<MiniYamlNode> list = new List<MiniYamlNode>(existingNodes.Count);
		foreach (MiniYamlNode existingNode in existingNodes)
		{
			if (hashSet.Add(existingNode.Key))
			{
				list.Add(existingNode);
				continue;
			}
			int index = IndexOfKey(list, existingNode.Key);
			MiniYamlNode miniYamlNode = list[index];
			list[index] = miniYamlNode.WithValue(MergePartial(miniYamlNode.Value, existingNode.Value));
		}
		return list;
	}

	private static MiniYaml MergePartial(MiniYaml existingNodes, MiniYaml overrideNodes)
	{
		lock (ConflictScratch)
		{
			if (existingNodes != null)
			{
				existingNodes.Nodes.IntoDictionaryWithConflictLog((MiniYamlNode n) => n.Key, (MiniYamlNode n) => n, "MiniYaml.Merge", ConflictScratch, (string k) => k, (MiniYamlNode n) => $"{n.Key} (at {n.Location})");
			}
			if (overrideNodes != null)
			{
				overrideNodes.Nodes.IntoDictionaryWithConflictLog((MiniYamlNode n) => n.Key, (MiniYamlNode n) => n, "MiniYaml.Merge", ConflictScratch, (string k) => k, (MiniYamlNode n) => $"{n.Key} (at {n.Location})");
			}
			ConflictScratch.Clear();
		}
		if (existingNodes == null)
		{
			return overrideNodes;
		}
		if (overrideNodes == null)
		{
			return existingNodes;
		}
		return new MiniYaml(overrideNodes.Value ?? existingNodes.Value, MergePartial(existingNodes.Nodes, overrideNodes.Nodes));
	}

	private static IReadOnlyCollection<MiniYamlNode> MergePartial(IReadOnlyCollection<MiniYamlNode> existingNodes, IReadOnlyCollection<MiniYamlNode> overrideNodes)
	{
		if (existingNodes.Count == 0)
		{
			return overrideNodes;
		}
		if (overrideNodes.Count == 0)
		{
			return existingNodes;
		}
		List<MiniYamlNode> ret = new List<MiniYamlNode>(existingNodes.Count + overrideNodes.Count);
		HashSet<string> plainKeys = new HashSet<string>(existingNodes.Count + overrideNodes.Count);
		foreach (MiniYamlNode existingNode in existingNodes)
		{
			MergeNode(existingNode);
		}
		foreach (MiniYamlNode overrideNode in overrideNodes)
		{
			MergeNode(overrideNode);
		}
		return ret;
		void MergeNode(MiniYamlNode node)
		{
			if (node.Key.StartsWith('-'))
			{
				ret.Add(node);
			}
			else if (plainKeys.Add(node.Key))
			{
				ret.Add(node);
			}
			else
			{
				int num = LastIndexOfKey(ret, node.Key);
				int num2 = LastIndexOfKey(ret, "-" + node.Key);
				if (num2 != -1 && num2 > num)
				{
					ret.Add(node);
				}
				else
				{
					ret[num] = node.WithValue(MergePartial(ret[num].Value, node.Value));
				}
			}
		}
	}

	private static int IndexOfKey(List<MiniYamlNode> nodes, string key)
	{
		for (int i = 0; i < nodes.Count; i++)
		{
			if (nodes[i].Key == key)
			{
				return i;
			}
		}
		return -1;
	}

	private static int LastIndexOfKey(List<MiniYamlNode> nodes, string key)
	{
		for (int num = nodes.Count - 1; num >= 0; num--)
		{
			if (nodes[num].Key == key)
			{
				return num;
			}
		}
		return -1;
	}

	public IEnumerable<string> ToLines(string key, string comment = null)
	{
		bool flag = !string.IsNullOrEmpty(key);
		bool flag2 = !string.IsNullOrEmpty(Value);
		bool flag3 = comment != null;
		yield return (flag ? (key + ":") : "") + (flag2 ? (" " + Value.Replace("#", "\\#")) : "") + (flag3 ? (((flag | flag2) ? " " : "") + "#" + comment) : "");
		if (!(Nodes != null))
		{
			yield break;
		}
		foreach (string item in Nodes.ToLines())
		{
			yield return "\t" + item;
		}
	}

	public static List<MiniYamlNode> Load(IReadOnlyFileSystem fileSystem, IEnumerable<string> files, MiniYaml mapRules)
	{
		if (mapRules != null && mapRules.Value != null)
		{
			string[] value = FieldLoader.GetValue<string[]>("value", mapRules.Value);
			files = files.Append(value);
		}
		HashSet<string> stringPool = new HashSet<string>();
		IEnumerable<IReadOnlyCollection<MiniYamlNode>> enumerable = files.Select((string s) => FromStream(fileSystem.Open(s), s, discardCommentsAndWhitespace: true, stringPool));
		if (mapRules != null && mapRules.Nodes.Length > 0)
		{
			enumerable = enumerable.Append(mapRules.Nodes);
		}
		return Merge(enumerable);
	}
}
