namespace OpenRA;

public enum GLProfile
{
	Automatic,
	ANGLE,
	Modern,
	Embedded
}
