namespace OpenRA;

public enum WorldViewport
{
	Native,
	Close,
	Medium,
	Far
}
