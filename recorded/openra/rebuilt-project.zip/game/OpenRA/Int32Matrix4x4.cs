using System;

namespace OpenRA;

public readonly struct Int32Matrix4x4(int m11, int m12, int m13, int m14, int m21, int m22, int m23, int m24, int m31, int m32, int m33, int m34, int m41, int m42, int m43, int m44) : IEquatable<Int32Matrix4x4>
{
	public readonly int M11 = m11;

	public readonly int M12 = m12;

	public readonly int M13 = m13;

	public readonly int M14 = m14;

	public readonly int M21 = m21;

	public readonly int M22 = m22;

	public readonly int M23 = m23;

	public readonly int M24 = m24;

	public readonly int M31 = m31;

	public readonly int M32 = m32;

	public readonly int M33 = m33;

	public readonly int M34 = m34;

	public readonly int M41 = m41;

	public readonly int M42 = m42;

	public readonly int M43 = m43;

	public readonly int M44 = m44;

	public static bool operator ==(Int32Matrix4x4 me, Int32Matrix4x4 other)
	{
		if (me.M11 == other.M11 && me.M12 == other.M12 && me.M13 == other.M13 && me.M14 == other.M14 && me.M21 == other.M21 && me.M22 == other.M22 && me.M23 == other.M23 && me.M24 == other.M24 && me.M31 == other.M31 && me.M32 == other.M32 && me.M33 == other.M33 && me.M34 == other.M34 && me.M41 == other.M41 && me.M42 == other.M42 && me.M43 == other.M43)
		{
			return me.M44 == other.M44;
		}
		return false;
	}

	public static bool operator !=(Int32Matrix4x4 me, Int32Matrix4x4 other)
	{
		return !(me == other);
	}

	public override int GetHashCode()
	{
		return M11 ^ M22 ^ M33 ^ M44;
	}

	public bool Equals(Int32Matrix4x4 other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is Int32Matrix4x4 other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return "[" + M11 + " " + M12 + " " + M13 + " " + M14 + "],[[" + M21 + " " + M22 + " " + M23 + " " + M24 + "],[[" + M31 + " " + M32 + " " + M33 + " " + M34 + "],[[" + M41 + " " + M42 + " " + M43 + " " + M44 + "]";
	}
}
