namespace OpenRA;

public class MouseButtonPreference
{
	public MouseButton Action
	{
		get
		{
			if (!Game.Settings.Game.UseClassicMouseStyle)
			{
				return MouseButton.Right;
			}
			return MouseButton.Left;
		}
	}

	public MouseButton Cancel
	{
		get
		{
			if (!Game.Settings.Game.UseClassicMouseStyle)
			{
				return MouseButton.Left;
			}
			return MouseButton.Right;
		}
	}
}
