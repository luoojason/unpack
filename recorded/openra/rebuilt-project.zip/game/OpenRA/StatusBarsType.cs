namespace OpenRA;

public enum StatusBarsType
{
	Standard,
	DamageShow,
	AlwaysShow
}
