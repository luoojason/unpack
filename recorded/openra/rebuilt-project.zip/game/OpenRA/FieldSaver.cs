using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using OpenRA.Primitives;

namespace OpenRA;

public static class FieldSaver
{
	public static MiniYaml Save(object o, bool includePrivateByDefault = false)
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>();
		string value = null;
		foreach (FieldLoader.FieldLoadInfo item in FieldLoader.GetTypeLoadInfo(o.GetType(), includePrivateByDefault))
		{
			if (item.Attribute.DictionaryFromYamlKey)
			{
				IDictionary dictionary = (IDictionary)item.Field.GetValue(o);
				foreach (object item2 in dictionary)
				{
					object key = ((DictionaryEntry)item2).Key;
					object value2 = ((DictionaryEntry)item2).Value;
					list.Add(new MiniYamlNode(FormatValue(key), FormatValue(value2)));
				}
			}
			else if (item.Attribute.FromYamlKey)
			{
				value = FormatValue(o, item.Field);
			}
			else
			{
				list.Add(new MiniYamlNode(item.YamlName, FormatValue(o, item.Field)));
			}
		}
		return new MiniYaml(value, list);
	}

	public static MiniYaml SaveDifferences(object o, object from, bool includePrivateByDefault = false)
	{
		if (o.GetType() != from.GetType())
		{
			throw new InvalidOperationException("FieldLoader: can't diff objects of different types");
		}
		IEnumerable<FieldLoader.FieldLoadInfo> source = from info in FieldLoader.GetTypeLoadInfo(o.GetType(), includePrivateByDefault)
			where FormatValue(o, info.Field) != FormatValue(@from, info.Field)
			select info;
		return new MiniYaml(null, source.Select((FieldLoader.FieldLoadInfo info) => new MiniYamlNode(info.YamlName, FormatValue(o, info.Field))));
	}

	public static MiniYamlNode SaveField(object o, string field)
	{
		return new MiniYamlNode(field, FormatValue(o, o.GetType().GetField(field)));
	}

	public static string FormatValue(object v)
	{
		if (v == null)
		{
			return "";
		}
		Type type = v.GetType();
		if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(BitSet<>))
		{
			return ((IEnumerable<string>)v).Select(FormatValue).JoinWith(", ");
		}
		if (type.IsArray && type.GetArrayRank() == 1)
		{
			return ((Array)v).Cast<object>().Select(FormatValue).JoinWith(", ");
		}
		if (type.IsGenericType && (type.GetGenericTypeDefinition() == typeof(HashSet<>) || type.GetGenericTypeDefinition() == typeof(List<>)))
		{
			return ((IEnumerable)v).Cast<object>().Select(FormatValue).JoinWith(", ");
		}
		if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Dictionary<, >))
		{
			StringBuilder stringBuilder = new StringBuilder();
			IDictionary dictionary = (IDictionary)v;
			foreach (object item in dictionary)
			{
				object key = ((DictionaryEntry)item).Key;
				object value = ((DictionaryEntry)item).Value;
				string text = FormatValue(key);
				string text2 = FormatValue(value);
				stringBuilder.Append(text + ": " + text2 + Environment.NewLine);
			}
			return stringBuilder.ToString();
		}
		if (v is DateTime dateTime)
		{
			return dateTime.ToString("yyyy-MM-dd HH-mm-ss", CultureInfo.InvariantCulture);
		}
		TypeConverter converter = TypeDescriptor.GetConverter(type);
		if (converter.CanConvertTo(typeof(string)))
		{
			try
			{
				return converter.ConvertToInvariantString(v);
			}
			catch
			{
			}
		}
		return v.ToString();
	}

	public static string FormatValue(object o, FieldInfo f)
	{
		return FormatValue(f.GetValue(o));
	}
}
