using System.Collections.Generic;

namespace OpenRA;

public static class IEnumerableExtensions
{
	public static WPos Average(this IEnumerable<WPos> source)
	{
		int num = 0;
		long num2 = 0L;
		long num3 = 0L;
		long num4 = 0L;
		foreach (WPos item in source)
		{
			num++;
			num2 += item.X;
			num3 += item.Y;
			num4 += item.Z;
		}
		if (num == 0)
		{
			return WPos.Zero;
		}
		num2 /= num;
		num3 /= num;
		num4 /= num;
		return new WPos((int)num2, (int)num3, (int)num4);
	}
}
