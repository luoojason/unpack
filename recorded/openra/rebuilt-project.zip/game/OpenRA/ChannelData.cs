namespace OpenRA;

internal readonly struct ChannelData(string channel, string text)
{
	public readonly string Channel = channel;

	public readonly string Text = text;
}
