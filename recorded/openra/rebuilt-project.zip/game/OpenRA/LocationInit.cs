namespace OpenRA;

public class LocationInit : ValueActorInit<CPos>, ISingleInstanceInit
{
	public LocationInit(CPos value)
		: base(value)
	{
	}
}
