using System;

namespace OpenRA;

[Flags]
public enum MPGameFilters
{
	None = 0,
	Waiting = 1,
	Empty = 2,
	Protected = 4,
	Started = 8,
	Incompatible = 0x10
}
