using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OpenRA;

public static class HttpExtension
{
	public static async Task ReadAsStreamWithProgress(this HttpResponseMessage response, Stream outputStream, OnProgress onProgress, CancellationToken token)
	{
		long total = response.Content.Headers.ContentLength ?? (-1);
		bool canReportProgress = total > 0;
		using Stream contentStream = await response.Content.ReadAsStreamAsync(token);
		long totalRead = 0L;
		byte[] buffer = new byte[8192];
		bool hasMoreToRead = true;
		do
		{
			int read = await contentStream.ReadAsync(buffer.AsMemory(0, buffer.Length), token);
			if (read == 0)
			{
				hasMoreToRead = false;
				continue;
			}
			await outputStream.WriteAsync(buffer.AsMemory(0, read), token);
			totalRead += read;
			if (canReportProgress)
			{
				int progressPercentage = (int)((double)totalRead / (double)total * 100.0);
				onProgress?.Invoke(total, totalRead, progressPercentage);
			}
		}
		while (hasMoreToRead && !token.IsCancellationRequested);
		onProgress?.Invoke(total, totalRead, 100);
	}
}
