using OpenRA.Primitives;

namespace OpenRA;

public struct FontGlyph
{
	public int2 Offset;

	public Size Size;

	public float Advance;

	public byte[] Data;
}
