namespace OpenRA;

public enum KeyInputEvent
{
	Down,
	Up
}
