namespace OpenRA;

public enum MouseInputEvent
{
	Down,
	Move,
	Up,
	Scroll
}
