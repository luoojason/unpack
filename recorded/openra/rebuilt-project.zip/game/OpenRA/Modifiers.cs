using System;

namespace OpenRA;

[Flags]
public enum Modifiers
{
	None = 0,
	Shift = 1,
	Alt = 2,
	Ctrl = 4,
	Meta = 8
}
