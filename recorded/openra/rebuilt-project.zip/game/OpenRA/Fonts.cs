using System.Collections.Generic;

namespace OpenRA;

public class Fonts : IGlobalModData
{
	[FieldLoader.LoadUsing("LoadFonts", false)]
	public readonly Dictionary<string, FontData> FontList;

	private static object LoadFonts(MiniYaml y)
	{
		Dictionary<string, FontData> dictionary = new Dictionary<string, FontData>();
		foreach (MiniYamlNode node in y.Nodes)
		{
			dictionary.Add(node.Key, FieldLoader.Load<FontData>(node.Value));
		}
		return dictionary;
	}
}
