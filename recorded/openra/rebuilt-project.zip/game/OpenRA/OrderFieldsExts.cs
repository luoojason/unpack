namespace OpenRA;

internal static class OrderFieldsExts
{
	public static bool HasField(this OrderFields of, OrderFields f)
	{
		return (of & f) != 0;
	}
}
