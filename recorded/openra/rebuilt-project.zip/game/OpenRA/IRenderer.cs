using OpenRA.Graphics;

namespace OpenRA;

public interface IRenderer
{
	void BeginFrame();

	void EndFrame();

	void SetPalette(HardwarePalette palette);
}
