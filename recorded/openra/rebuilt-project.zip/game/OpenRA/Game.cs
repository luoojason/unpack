using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime;
using System.Threading;
using OpenRA.Graphics;
using OpenRA.Network;
using OpenRA.Primitives;
using OpenRA.Server;
using OpenRA.Support;
using OpenRA.Widgets;

namespace OpenRA;

public static class Game
{
	[FluentReference(new string[] { "filename" })]
	private const string SavedScreenshot = "notification-saved-screenshot";

	public const int TimestepJankThreshold = 250;

	public static ModData ModData;

	public static Settings Settings;

	public static CursorManager Cursor;

	public static bool HideCursor;

	private static WorldRenderer worldRenderer;

	private static string modLaunchWrapper;

	internal static OrderManager OrderManager;

	private static OpenRA.Server.Server server;

	public static MersenneTwister CosmeticRandom = new MersenneTwister();

	public static Renderer Renderer;

	public static Sound Sound;

	public static LocalPlayerProfile LocalPlayerProfile;

	private static bool takeScreenshot = false;

	private static Benchmark benchmark = null;

	private static readonly Stopwatch Stopwatch = Stopwatch.StartNew();

	public static int RenderFrame = 0;

	private static ConnectionState lastConnectionState = ConnectionState.PreConnecting;

	private static Modifiers modifiers;

	private static RunStatus state = RunStatus.Running;

	private static volatile ActionQueue delayedActions = new ActionQueue();

	public static InstalledMods Mods { get; private set; }

	public static ExternalMods ExternalMods { get; private set; }

	public static string EngineVersion { get; private set; }

	public static long RunTime => Stopwatch.ElapsedMilliseconds;

	public static int NetFrameNumber => OrderManager.NetFrameNumber;

	public static int LocalTick => OrderManager.LocalFrameNumber;

	public static int LocalClientId => OrderManager.Connection.LocalClientId;

	public static bool IsHost
	{
		get
		{
			int localClientId = OrderManager.Connection.LocalClientId;
			return OrderManager.LobbyInfo.ClientWithIndex(localClientId)?.IsAdmin ?? false;
		}
	}

	public static event Action OnShellmapLoaded = () =>
	{
	};

	public static event Action<ConnectionTarget> OnRemoteDirectConnect = (ConnectionTarget _) =>
	{
	};

	public static event Action<OrderManager, string, NetworkConnection> ConnectionStateChanged = (OrderManager om, string pass, NetworkConnection conn) =>
	{
	};

	public static event Action LobbyInfoChanged = () =>
	{
	};

	public static event Action BeforeGameStart = () =>
	{
	};

	public static event Action AfterGameStart = () =>
	{
	};

	public static event Action OnQuit = () =>
	{
	};

	public static OrderManager JoinServer(ConnectionTarget endpoint, string password, bool recordReplay = true)
	{
		NetworkConnection networkConnection = new NetworkConnection(endpoint);
		if (recordReplay)
		{
			networkConnection.StartRecording(() => TimestampedFilename());
		}
		OrderManager orderManager = new OrderManager(networkConnection);
		JoinInner(orderManager);
		CurrentServerSettings.Password = password;
		CurrentServerSettings.Target = endpoint;
		lastConnectionState = ConnectionState.PreConnecting;
		ConnectionStateChanged(OrderManager, password, networkConnection);
		return orderManager;
	}

	public static string TimestampedFilename(bool includemilliseconds = false, string extra = "")
	{
		string text = (includemilliseconds ? "yyyy-MM-ddTHHmmssfffZ" : "yyyy-MM-ddTHHmmssZ");
		return ModData.Manifest.Id + extra + "-" + DateTime.UtcNow.ToString(text, CultureInfo.InvariantCulture);
	}

	private static void JoinInner(OrderManager om)
	{
		TextNotificationsManager.Clear();
		UnitOrders.Clear();
		if (OrderManager?.World == null || OrderManager.World.Type != WorldType.Shellmap)
		{
			OrderManager?.Dispose();
		}
		OrderManager = om;
	}

	public static void JoinReplay(string replayFile)
	{
		JoinInner(new OrderManager(new ReplayConnection(replayFile)));
	}

	private static void JoinLocal()
	{
		JoinInner(new OrderManager(new EchoConnection()));
		OrderManager.LobbyInfo.Clients.Add(new Session.Client
		{
			Index = OrderManager.Connection.LocalClientId,
			Name = Settings.Player.Name,
			PreferredColor = Settings.Player.Color,
			Color = Settings.Player.Color,
			Faction = "Random",
			SpawnPoint = 0,
			Team = 0,
			State = Session.ClientState.Ready
		});
	}

	public static void RemoteDirectConnect(ConnectionTarget endpoint)
	{
		OnRemoteDirectConnect(endpoint);
	}

	public static Widget OpenWindow(World world, string widget)
	{
		return Ui.OpenWindow(widget, new WidgetArgs
		{
			{ "world", world },
			{ "orderManager", OrderManager },
			{ "worldRenderer", worldRenderer }
		});
	}

	public static Widget OpenWindow(string widget, WidgetArgs args)
	{
		return Ui.OpenWindow(widget, new WidgetArgs(args)
		{
			{ "world", worldRenderer.World },
			{ "orderManager", OrderManager },
			{ "worldRenderer", worldRenderer }
		});
	}

	public static Widget LoadWidget(World world, string id, Widget parent, WidgetArgs args)
	{
		return ModData.WidgetLoader.LoadWidget(new WidgetArgs(args)
		{
			{ "world", world },
			{ "orderManager", OrderManager },
			{ "worldRenderer", worldRenderer }
		}, parent, id);
	}

	internal static void SyncLobbyInfo()
	{
		LobbyInfoChanged();
	}

	internal static void StartGame(string mapUID, WorldType type)
	{
		worldRenderer?.Dispose();
		Cursor.SetCursor(null);
		BeforeGameStart();
		using (new PerfTimer("NewWorld"))
		{
			OrderManager.World = new World(mapUID, ModData, OrderManager, type);
		}
		OrderManager.World.GameOver += FinishBenchmark;
		worldRenderer = new WorldRenderer(ModData, OrderManager.World);
		GC.Collect();
		using (new PerfTimer("LoadComplete"))
		{
			OrderManager.World.LoadComplete(worldRenderer);
		}
		GC.Collect();
		if (!OrderManager.GameStarted)
		{
			Ui.MouseFocusWidget = null;
			Ui.KeyboardFocusWidget = null;
			OrderManager.StartGame();
			worldRenderer.RefreshPalette();
			Cursor.SetCursor(ChromeMetrics.Get<string>("DefaultCursor"));
			GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;
			GC.Collect();
			OrderManager.World.PostLoadComplete(worldRenderer);
			AfterGameStart();
		}
	}

	public static void RestartGame()
	{
		ReplayConnection replayConnection = OrderManager.Connection as ReplayConnection;
		string replayFile = replayConnection?.Filename;
		Session lobbyInfo = OrderManager.LobbyInfo;
		lobbyInfo.GlobalSettings.RandomSeed = CosmeticRandom.Next();
		lobbyInfo.GlobalSettings.Map = ModData.MapCache.GetUpdatedMap(lobbyInfo.GlobalSettings.Map);
		if (lobbyInfo.GlobalSettings.Map == null)
		{
			Disconnect();
			Ui.ResetAll();
			LoadShellMap();
			return;
		}
		Order[] setupOrders = new Order[2]
		{
			Order.Command("sync_lobby " + lobbyInfo.Serialize()),
			Order.Command("startgame")
		};
		Disconnect();
		Ui.ResetAll();
		if (replayConnection != null)
		{
			JoinReplay(replayFile);
		}
		else
		{
			CreateAndStartLocalServer(lobbyInfo.GlobalSettings.Map, setupOrders);
		}
	}

	public static void CreateAndStartLocalServer(string mapUID, IEnumerable<Order> setupOrders)
	{
		OrderManager om = null;
		LobbyInfoChanged += LobbyReady;
		om = JoinServer(CreateLocalServer(mapUID), "");
		void LobbyReady()
		{
			LobbyInfoChanged -= LobbyReady;
			foreach (Order setupOrder in setupOrders)
			{
				om.IssueOrder(setupOrder);
			}
		}
	}

	public static Modifiers GetModifierKeys()
	{
		return modifiers;
	}

	internal static void HandleModifierKeys(Modifiers mods)
	{
		modifiers = mods;
	}

	public static void InitializeSettings(Arguments args)
	{
		Settings = new Settings(Path.Combine(Platform.SupportDir, "settings.yaml"), args);
	}

	public static RunStatus InitializeAndRun(string[] args)
	{
		Initialize(new Arguments(args));
		GC.Collect();
		return Run();
	}

	private static void Initialize(Arguments args)
	{
		string value = args.GetValue("Engine.EngineDir", null);
		if (!string.IsNullOrEmpty(value))
		{
			Platform.OverrideEngineDir(value);
		}
		string value2 = args.GetValue("Engine.SupportDir", null);
		if (!string.IsNullOrEmpty(value2))
		{
			Platform.OverrideSupportDir(value2);
		}
		Console.WriteLine($"Platform is {Platform.CurrentPlatform} ({Platform.CurrentArchitecture})");
		try
		{
			EngineVersion = File.ReadAllText(Path.Combine(Platform.EngineDir, "VERSION")).Trim();
		}
		catch
		{
		}
		if (string.IsNullOrEmpty(EngineVersion))
		{
			EngineVersion = "Unknown";
		}
		Console.WriteLine("Engine version is " + EngineVersion);
		Console.WriteLine("Runtime: " + Platform.RuntimeVersion);
		string text = args.GetValue("Game.Mod", null);
		string[] explicitPaths = Array.Empty<string>();
		if (text != null && (File.Exists(text) || Directory.Exists(text)))
		{
			explicitPaths = new string[1] { text };
			text = Path.GetFileNameWithoutExtension(text);
		}
		InitializeSettings(args);
		Log.AddChannel("perf", "perf.log");
		Log.AddChannel("debug", "debug.log");
		Log.AddChannel("server", "server.log", isTimestamped: true);
		Log.AddChannel("sound", "sound.log");
		Log.AddChannel("graphics", "graphics.log");
		Log.AddChannel("geoip", "geoip.log");
		Log.AddChannel("nat", "nat.log");
		Log.AddChannel("client", "client.log");
		string[] array = new string[3]
		{
			Settings.Game.Platform,
			"Default",
			null
		};
		string[] array2 = array;
		foreach (string text2 in array2)
		{
			if (text2 == null)
			{
				throw new InvalidOperationException("Failed to initialize platform-integration library. Check graphics.log for details.");
			}
			Settings.Game.Platform = text2;
			try
			{
				IPlatform platform = CreatePlatform(text2);
				Renderer = new Renderer(platform, Settings.Graphics);
				Sound = new Sound(platform, Settings.Sound);
			}
			catch (Exception value3)
			{
				Log.Write("graphics", $"{value3}");
				Console.WriteLine("Renderer initialization failed. Check graphics.log for details.");
				Renderer?.Dispose();
				Sound?.Dispose();
				continue;
			}
			break;
		}
		Nat.Initialize();
		string value4 = args.GetValue("Engine.ModSearchPaths", null);
		string[] searchPaths = ((value4 != null) ? FieldLoader.GetValue<string[]>("Engine.ModsPath", value4) : new string[1] { Path.Combine(Platform.EngineDir, "mods") });
		Mods = new InstalledMods(searchPaths, explicitPaths);
		Console.WriteLine("Internal mods:");
		foreach (KeyValuePair<string, Manifest> mod in Mods)
		{
			Console.WriteLine($"\t{mod.Key} ({mod.Value.Metadata.Version})");
		}
		modLaunchWrapper = args.GetValue("Engine.LaunchWrapper", null);
		ExternalMods = new ExternalMods();
		if (text != null && Mods.TryGetValue(text, out var _))
		{
			string text3 = args.GetValue("Engine.LaunchPath", null);
			List<string> launchArgs = new List<string>();
			if (text3 != null && text3[0] == '"' && text3.Last() == '"')
			{
				string text4 = text3;
				text3 = text4.Substring(1, text4.Length - 1 - 1);
			}
			if (text3 != null)
			{
				ExternalMods.Register(Mods[text], text3, launchArgs, ModRegistration.User);
			}
			ExternalMods.ClearInvalidRegistrations(ModRegistration.User);
		}
		Console.WriteLine("External mods:");
		foreach (KeyValuePair<string, ExternalMod> externalMod in ExternalMods)
		{
			Console.WriteLine($"\t{externalMod.Key} ({externalMod.Value.Version})");
		}
		InitializeMod(text, args);
	}

	public static IPlatform CreatePlatform(string platformName)
	{
		string assemblyFile = Path.Combine(Platform.BinDir, "OpenRA.Platforms." + platformName + ".dll");
		AssemblyLoader assemblyLoader = new AssemblyLoader(assemblyFile);
		Type type = assemblyLoader.LoadDefaultAssembly().GetTypes().SingleOrDefault((Type t) => typeof(IPlatform).IsAssignableFrom(t));
		if (type == null)
		{
			throw new InvalidOperationException("Platform dll must include exactly one IPlatform implementation.");
		}
		return (IPlatform)type.GetConstructor(Type.EmptyTypes).Invoke(null);
	}

	public static void InitializeMod(string mod, Arguments args)
	{
		LobbyInfoChanged = () =>
		{
		};
		ConnectionStateChanged = (OrderManager om, string p, NetworkConnection conn) =>
		{
		};
		BeforeGameStart = () =>
		{
		};
		OnRemoteDirectConnect = (ConnectionTarget endpoint) =>
		{
		};
		delayedActions = new ActionQueue();
		Ui.ResetAll();
		worldRenderer?.Dispose();
		worldRenderer = null;
		server?.Shutdown();
		OrderManager?.Dispose();
		if (ModData != null)
		{
			ModData.ModFiles.UnmountAll();
			ModData.Dispose();
		}
		ModData = null;
		if (mod == null)
		{
			throw new InvalidOperationException("Game.Mod argument missing.");
		}
		if (!Mods.ContainsKey(mod))
		{
			throw new InvalidOperationException("Unknown or invalid mod '" + mod + "'.");
		}
		Console.WriteLine("Loading mod: " + mod);
		Sound.StopVideo();
		ModData = new ModData(Mods[mod], Mods, useLoadScreen: true);
		LocalPlayerProfile = new LocalPlayerProfile(Path.Combine(Platform.SupportDir, Settings.Game.AuthProfile), ModData.Manifest.Get<PlayerDatabase>());
		if (ModData.LoadScreen.BeforeLoad())
		{
			ModData.InitializeLoaders(ModData.DefaultFileSystem);
			Renderer.InitializeFonts(ModData);
			using (new PerfTimer("LoadMaps"))
			{
				ModData.MapCache.LoadMaps();
			}
			MapGrid mapGrid = (ModData.Manifest.Contains<MapGrid>() ? ModData.Manifest.Get<MapGrid>() : null);
			Renderer.InitializeDepthBuffer(mapGrid);
			Cursor?.Dispose();
			Cursor = new CursorManager(ModData.CursorProvider, ModData.Manifest.CursorSheetSize);
			ModMetadata metadata = ModData.Manifest.Metadata;
			if (!string.IsNullOrEmpty(metadata.WindowTitleTranslated))
			{
				Renderer.Window.SetWindowTitle(metadata.WindowTitleTranslated);
			}
			PerfHistory.Items["render"].HasNormalTick = false;
			PerfHistory.Items["batches"].HasNormalTick = false;
			PerfHistory.Items["render_world"].HasNormalTick = false;
			PerfHistory.Items["render_widgets"].HasNormalTick = false;
			PerfHistory.Items["render_flip"].HasNormalTick = false;
			PerfHistory.Items["terrain_lighting"].HasNormalTick = false;
			JoinLocal();
			ModData.LoadScreen.StartGame(args);
		}
	}

	public static void LoadEditor(string mapUid)
	{
		JoinLocal();
		StartGame(mapUid, WorldType.Editor);
	}

	public static void LoadShellMap()
	{
		string mapUID = ChooseShellmap();
		using (new PerfTimer("StartGame"))
		{
			StartGame(mapUID, WorldType.Shellmap);
			OnShellmapLoaded();
		}
	}

	private static string ChooseShellmap()
	{
		IEnumerable<string> ts = from m in ModData.MapCache
			where m.Status == MapStatus.Available && m.Visibility.HasFlag(MapVisibility.Shellmap)
			select m.Uid;
		string text = ts.RandomOrDefault(CosmeticRandom);
		if (text == null)
		{
			throw new InvalidDataException("No valid shellmaps available");
		}
		return text;
	}

	public static void SwitchToExternalMod(ExternalMod mod, string[] launchArguments = null, Action onFailed = null)
	{
		try
		{
			string launchPath = mod.LaunchPath;
			IEnumerable<string> enumerable;
			if (launchArguments == null)
			{
				IEnumerable<string> launchArgs = mod.LaunchArgs;
				enumerable = launchArgs;
			}
			else
			{
				enumerable = mod.LaunchArgs.Append(launchArguments);
			}
			IEnumerable<string> enumerable2 = enumerable;
			if (modLaunchWrapper != null)
			{
				launchPath = modLaunchWrapper;
				enumerable2 = new string[1] { mod.LaunchPath }.Concat(enumerable2);
			}
			Process process = Process.Start(launchPath, enumerable2.Select((string a) => "\"" + a + "\"").JoinWith(" "));
			if (process == null || process.HasExited)
			{
				onFailed();
				return;
			}
			process.Close();
			Exit();
		}
		catch (Exception ex)
		{
			Log.Write("debug", "Failed to switch to external mod.");
			Log.Write("debug", "Error was: " + ex.Message);
			onFailed();
		}
	}

	public static void RunAfterTick(Action a)
	{
		delayedActions.Add(a, RunTime);
	}

	public static void RunAfterDelay(int delayMilliseconds, Action a)
	{
		delayedActions.Add(a, RunTime + delayMilliseconds);
	}

	private static void TakeScreenshotInner()
	{
		using (new PerfTimer("Renderer.SaveScreenshot"))
		{
			ModMetadata metadata = ModData.Manifest.Metadata;
			string text = Path.Combine(Platform.SupportDir, "Screenshots", ModData.Manifest.Id, metadata.Version);
			Directory.CreateDirectory(text);
			string text2 = TimestampedFilename(includemilliseconds: true);
			string text3 = Path.Combine(text, text2 + ".png");
			Log.Write("debug", "Taking screenshot " + text3);
			Renderer.SaveScreenshot(text3);
			TextNotificationsManager.Debug(FluentProvider.GetMessage("notification-saved-screenshot", "filename", text2));
		}
	}

	private static void InnerLogicTick(OrderManager orderManager)
	{
		long runTime = RunTime;
		World world = orderManager.World;
		if (Ui.LastTickTime.ShouldAdvance(runTime))
		{
			Ui.LastTickTime.AdvanceTickTime(runTime);
			Sync.RunUnsynced(world, Ui.Tick);
			Cursor.Tick();
		}
		if (!orderManager.LastTickTime.ShouldAdvance(runTime))
		{
			return;
		}
		if (orderManager.GameStarted && orderManager.LocalFrameNumber == 0)
		{
			PerfHistory.Reset();
		}
		using (new PerfSample("tick_time"))
		{
			orderManager.LastTickTime.AdvanceTickTime(runTime);
			Sound.Tick();
			Sync.RunUnsynced(world, orderManager.TickImmediate);
			if (world == null)
			{
				if (orderManager.GameStarted)
				{
					PerfHistory.Reset();
				}
				return;
			}
			if (orderManager.TryTick())
			{
				Sync.RunUnsynced(world, () =>
				{
					world.OrderGenerator.Tick(world);
				});
				world.Tick();
				PerfHistory.Tick();
			}
			if (orderManager.LocalFrameNumber > 0)
			{
				Sync.RunUnsynced(world, () =>
				{
					world.TickRender(worldRenderer);
				});
			}
		}
		benchmark?.Tick(LocalTick);
	}

	private static void LogicTick()
	{
		PerformDelayedActions();
		if (OrderManager.Connection is NetworkConnection networkConnection && networkConnection.ConnectionState != lastConnectionState)
		{
			lastConnectionState = networkConnection.ConnectionState;
			ConnectionStateChanged(OrderManager, null, networkConnection);
		}
		InnerLogicTick(OrderManager);
		if (worldRenderer != null && OrderManager.World != worldRenderer.World)
		{
			InnerLogicTick(worldRenderer.World.OrderManager);
		}
	}

	public static void PerformDelayedActions()
	{
		delayedActions.PerformActions(RunTime);
	}

	public static void TakeScreenshot()
	{
		takeScreenshot = true;
	}

	private static void RenderTick()
	{
		using (new PerfSample("render"))
		{
			RenderFrame++;
			using (new PerfSample("render_prepare"))
			{
				worldRenderer?.BeginFrame();
				if (worldRenderer != null && !worldRenderer.World.IsLoadingGameSave)
				{
					worldRenderer.Viewport.Tick();
					worldRenderer.PrepareRenderables();
				}
				Ui.PrepareRenderables();
				worldRenderer?.EndFrame();
			}
			if (worldRenderer != null && !worldRenderer.World.IsLoadingGameSave)
			{
				Renderer.BeginWorld(worldRenderer.Viewport.Rectangle);
				Sound.SetListenerPosition(worldRenderer.Viewport.CenterPosition);
				using (new PerfSample("render_world"))
				{
					worldRenderer.Draw();
				}
			}
			using (new PerfSample("render_widgets"))
			{
				Renderer.BeginUI();
				if (worldRenderer != null && !worldRenderer.World.IsLoadingGameSave)
				{
					worldRenderer.DrawAnnotations();
				}
				Ui.Draw();
				if (ModData != null && ModData.CursorProvider != null)
				{
					if (HideCursor)
					{
						Cursor.SetCursor(null);
					}
					else
					{
						Cursor.SetCursor(Ui.Root.GetCursorOuter(Viewport.LastMousePos) ?? "default");
						Cursor.Render(Renderer);
					}
				}
			}
			using (new PerfSample("render_flip"))
			{
				Renderer.EndFrame(new DefaultInputHandler(OrderManager.World));
			}
			if (takeScreenshot)
			{
				takeScreenshot = false;
				TakeScreenshotInner();
			}
		}
		PerfHistory.Items["render"].Tick();
		PerfHistory.Items["batches"].Tick();
		PerfHistory.Items["render_world"].Tick();
		PerfHistory.Items["render_widgets"].Tick();
		PerfHistory.Items["render_flip"].Tick();
		PerfHistory.Items["terrain_lighting"].Tick();
	}

	private static void Loop()
	{
		long num = RunTime;
		long num2 = RunTime;
		long num3 = RunTime;
		bool flag = false;
		while (state == RunStatus.Running)
		{
			int num4 = 40;
			World world = worldRenderer?.World;
			if (world != null && (!world.IsReplay || world.ReplayTimestep != 0))
			{
				num4 = ((world == OrderManager.World) ? OrderManager.SuggestedTimestep : world.Timestep);
			}
			int num5 = num4;
			if (!Settings.Graphics.CapFramerateToGameFps)
			{
				int num6 = (Settings.Graphics.CapFramerate ? Settings.Graphics.MaxFramerate.Clamp(1, 1000) : 1000);
				num5 = 1000 / num6;
			}
			if (OrderManager.World != null && OrderManager.World.IsLoadingGameSave)
			{
				num4 = 1;
				num5 = 200;
			}
			long runTime = RunTime;
			if (runTime - num > 250)
			{
				num = runTime;
			}
			long num7 = Math.Min(num, num2);
			if (runTime >= num7)
			{
				bool flag2 = flag || runTime >= num3;
				if (runTime >= num && !flag)
				{
					num += num4;
					LogicTick();
					if (OrderManager.World != null && !OrderManager.World.IsLoadingGameSave && !OrderManager.World.IsReplay)
					{
						flag = true;
					}
				}
				bool flag3 = runTime < num;
				bool flag4 = runTime >= num2;
				if (!Renderer.WindowIsSuspended && ((flag4 & flag3) | flag2))
				{
					num2 = runTime + num5;
					int num8 = Math.Max(100, num5);
					num3 = runTime + num8;
					RenderTick();
					flag = false;
				}
				if (Renderer.WindowIsSuspended & flag4)
				{
					num2 = runTime + num5;
					Renderer.Window.PumpInput(new NullInputHandler());
					flag = false;
				}
			}
			else
			{
				Thread.Sleep((int)(num7 - runTime));
			}
		}
	}

	private static RunStatus Run()
	{
		if (Settings.Graphics.MaxFramerate < 1)
		{
			Settings.Graphics.MaxFramerate = new GraphicSettings().MaxFramerate;
			Settings.Graphics.CapFramerate = false;
		}
		try
		{
			Loop();
		}
		finally
		{
			OrderManager?.Dispose();
		}
		worldRenderer?.Dispose();
		ModData.Dispose();
		ChromeProvider.Deinitialize();
		Sound.Dispose();
		Renderer.Dispose();
		OnQuit();
		return state;
	}

	public static void Exit()
	{
		state = RunStatus.Success;
	}

	public static void Disconnect()
	{
		OrderManager.World?.TraitDict.PrintReport();
		OrderManager.Dispose();
		CloseServer();
		JoinLocal();
	}

	public static void CloseServer()
	{
		server?.Shutdown();
	}

	public static T CreateObject<T>(string name)
	{
		return ModData.ObjectCreator.CreateObject<T>(name);
	}

	public static ConnectionTarget CreateServer(ServerSettings settings)
	{
		List<IPEndPoint> endpoints = new List<IPEndPoint>
		{
			new IPEndPoint(IPAddress.IPv6Any, settings.ListenPort),
			new IPEndPoint(IPAddress.Any, settings.ListenPort)
		};
		server = new OpenRA.Server.Server(endpoints, settings, ModData, ServerType.Multiplayer);
		return server.GetEndpointForLocalConnection();
	}

	public static ConnectionTarget CreateLocalServer(string map, bool isSkirmish = false)
	{
		ServerSettings settings = new ServerSettings
		{
			Name = "Skirmish Game",
			Map = map,
			AdvertiseOnline = false
		};
		List<IPEndPoint> endpoints = new List<IPEndPoint>
		{
			new IPEndPoint(IPAddress.Loopback, 0)
		};
		server = new OpenRA.Server.Server(endpoints, settings, ModData, isSkirmish ? ServerType.Skirmish : ServerType.Local);
		return server.GetEndpointForLocalConnection();
	}

	public static bool IsCurrentWorld(World world)
	{
		if (OrderManager != null && OrderManager.World == world)
		{
			return !world.Disposing;
		}
		return false;
	}

	public static bool SetClipboardText(string text)
	{
		return Renderer.Window.SetClipboardText(text);
	}

	public static void BenchmarkMode(string prefix)
	{
		benchmark = new Benchmark(prefix);
	}

	public static void LoadMap(string launchMap)
	{
		List<Order> setupOrders = new List<Order>
		{
			Order.Command("option gamespeed default"),
			Order.Command($"state {Session.ClientState.Ready}")
		};
		MapPreview mapPreview = ModData.MapCache.SingleOrDefault((MapPreview m) => m.Uid == launchMap || Path.GetFileName(m.PackageName) == launchMap);
		if (mapPreview == null)
		{
			throw new ArgumentException("Could not find map '" + launchMap + "'.");
		}
		CreateAndStartLocalServer(mapPreview.Uid, setupOrders);
	}

	public static void FinishBenchmark()
	{
		if (benchmark != null)
		{
			benchmark.Write();
			Exit();
		}
	}
}
