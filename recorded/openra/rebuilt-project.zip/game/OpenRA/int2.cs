using System;
using OpenRA.Primitives;

namespace OpenRA;

public readonly struct int2 : IEquatable<int2>
{
	public readonly int X;

	public readonly int Y;

	public static readonly int2 Zero = new int2(0, 0);

	public int LengthSquared => X * X + Y * Y;

	public int Length => Exts.ISqrt(LengthSquared);

	public int2(int x, int y)
	{
		X = x;
		Y = y;
	}

	public int2(Size p)
	{
		X = p.Width;
		Y = p.Height;
	}

	public static int2 operator +(int2 a, int2 b)
	{
		return new int2(a.X + b.X, a.Y + b.Y);
	}

	public static int2 operator +(int2 a, Size b)
	{
		return new int2(a.X + b.Width, a.Y + b.Height);
	}

	public static int2 operator -(int2 a, int2 b)
	{
		return new int2(a.X - b.X, a.Y - b.Y);
	}

	public static int2 operator *(int a, int2 b)
	{
		return new int2(a * b.X, a * b.Y);
	}

	public static int2 operator *(int2 b, int a)
	{
		return new int2(a * b.X, a * b.Y);
	}

	public static int2 operator /(int2 a, int b)
	{
		return new int2(a.X / b, a.Y / b);
	}

	public static int2 operator -(int2 a)
	{
		return new int2(-a.X, -a.Y);
	}

	public static bool operator ==(int2 me, int2 other)
	{
		if (me.X == other.X)
		{
			return me.Y == other.Y;
		}
		return false;
	}

	public static bool operator !=(int2 me, int2 other)
	{
		return !(me == other);
	}

	public override int GetHashCode()
	{
		return X.GetHashCode() ^ Y.GetHashCode();
	}

	public bool Equals(int2 other)
	{
		return this == other;
	}

	public override bool Equals(object obj)
	{
		if (obj is int2 other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return X + "," + Y;
	}

	public int2 Sign()
	{
		return new int2(Math.Sign(X), Math.Sign(Y));
	}

	public int2 Abs()
	{
		return new int2(Math.Abs(X), Math.Abs(Y));
	}

	public int2 WithX(int newX)
	{
		return new int2(newX, Y);
	}

	public int2 WithY(int newY)
	{
		return new int2(X, newY);
	}

	public static int2 Max(int2 a, int2 b)
	{
		return new int2(Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
	}

	public static int2 Min(int2 a, int2 b)
	{
		return new int2(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y));
	}

	public float2 ToFloat2()
	{
		return new float2(X, Y);
	}

	public static uint Swap(uint orig)
	{
		return ((orig & 0xFF000000u) >> 24) | ((orig & 0xFF0000) >> 8) | ((orig & 0xFF00) << 8) | ((orig & 0xFF) << 24);
	}

	public static int Lerp(int a, int b, int mul, int div)
	{
		return a + (b - a) * mul / div;
	}

	public static int2 Lerp(int2 a, int2 b, int mul, int div)
	{
		return a + (b - a) * mul / div;
	}

	public int2 Clamp(Rectangle r)
	{
		return new int2(Math.Min(r.Right, Math.Max(X, r.Left)), Math.Min(r.Bottom, Math.Max(Y, r.Top)));
	}

	public static int Dot(int2 a, int2 b)
	{
		return a.X * b.X + a.Y * b.Y;
	}
}
