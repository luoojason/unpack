using OpenRA.FileSystem;

namespace OpenRA;

public interface ITerrainLoader
{
	ITerrainInfo ParseTerrain(IReadOnlyFileSystem fileSystem, string path);
}
