using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.Widgets;

namespace OpenRA;

public class WidgetLoader
{
	private readonly Dictionary<string, MiniYamlNode> widgets = new Dictionary<string, MiniYamlNode>();

	private readonly ModData modData;

	public WidgetLoader(ModData modData)
	{
		this.modData = modData;
		HashSet<string> stringPool = new HashSet<string>();
		foreach (List<MiniYamlNode> item in modData.Manifest.ChromeLayout.Select((string a) => MiniYaml.FromStream(modData.DefaultFileSystem.Open(a), a, discardCommentsAndWhitespace: true, stringPool)))
		{
			foreach (MiniYamlNode item2 in item)
			{
				string key = item2.Key.Substring(item2.Key.IndexOf('@') + 1);
				if (widgets.ContainsKey(key))
				{
					throw new InvalidDataException($"Widget has duplicate Key `{item2.Key}` at {item2.Location}");
				}
				widgets.Add(key, item2);
			}
		}
	}

	public Widget LoadWidget(WidgetArgs args, Widget parent, string w)
	{
		if (!widgets.TryGetValue(w, out var value))
		{
			throw new InvalidDataException("Cannot find widget with Id `" + w + "`");
		}
		return LoadWidget(args, parent, value);
	}

	public Widget LoadWidget(WidgetArgs args, Widget parent, MiniYamlNode node)
	{
		if (!args.ContainsKey("modData"))
		{
			args = new WidgetArgs(args) { { "modData", modData } };
		}
		Widget widget = NewWidget(node.Key, args);
		parent?.AddChild(widget);
		if (node.Key.Contains('@'))
		{
			FieldLoader.LoadField(widget, "Id", node.Key.Split('@')[1]);
		}
		foreach (MiniYamlNode node2 in node.Value.Nodes)
		{
			if (node2.Key != "Children")
			{
				FieldLoader.LoadField(widget, node2.Key, node2.Value.Value);
			}
		}
		widget.Initialize(args);
		foreach (MiniYamlNode node3 in node.Value.Nodes)
		{
			if (node3.Key == "Children")
			{
				foreach (MiniYamlNode node4 in node3.Value.Nodes)
				{
					LoadWidget(args, widget, node4);
				}
			}
		}
		Dictionary<string, MiniYaml> value = node.Value.NodeWithKeyOrDefault("Logic")?.Value.ToDictionary();
		args.Add("logicArgs", value);
		widget.PostInit(args);
		args.Remove("logicArgs");
		return widget;
	}

	private static Widget NewWidget(string widgetType, WidgetArgs args)
	{
		widgetType = widgetType.Split('@')[0];
		return Game.ModData.ObjectCreator.CreateObject<Widget>(widgetType + "Widget", args);
	}
}
