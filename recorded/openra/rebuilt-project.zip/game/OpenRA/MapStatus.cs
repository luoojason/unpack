namespace OpenRA;

public enum MapStatus
{
	Available,
	Unavailable,
	Searching,
	DownloadAvailable,
	Downloading,
	DownloadError
}
