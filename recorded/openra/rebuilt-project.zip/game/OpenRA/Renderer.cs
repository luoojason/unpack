using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using OpenRA.FileFormats;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public sealed class Renderer : IDisposable
{
	private enum RenderType
	{
		None,
		World,
		UI
	}

	public interface IBatchRenderer
	{
		void Flush();
	}

	public IRenderer[] WorldRenderers = Array.Empty<IRenderer>();

	public IReadOnlyDictionary<string, SpriteFont> Fonts;

	private readonly IVertexBuffer<Vertex> tempVertexBuffer;

	private readonly IIndexBuffer quadIndexBuffer;

	private readonly Stack<Rectangle> scissorState = new Stack<Rectangle>();

	private readonly ITexture worldBufferSnapshot;

	private IFrameBuffer screenBuffer;

	private Sprite screenSprite;

	private IFrameBuffer worldBuffer;

	private Sheet worldSheet;

	private Sprite worldSprite;

	private Size lastMaximumViewportSize;

	private Size lastWorldViewportSize;

	private SheetBuilder fontSheetBuilder;

	private readonly IPlatform platform;

	private float depthMargin;

	private Size lastBufferSize = new Size(-1, -1);

	private Rectangle lastWorldViewport = Rectangle.Empty;

	private ITexture currentPaletteTexture;

	private int currentPaletteHeight;

	private IBatchRenderer currentBatchRenderer;

	private RenderType renderType;

	public SpriteRenderer WorldSpriteRenderer { get; }

	public RgbaSpriteRenderer WorldRgbaSpriteRenderer { get; }

	public RgbaColorRenderer WorldRgbaColorRenderer { get; }

	public RgbaColorRenderer RgbaColorRenderer { get; }

	public SpriteRenderer SpriteRenderer { get; }

	public RgbaSpriteRenderer RgbaSpriteRenderer { get; }

	public bool WindowHasInputFocus => Window.HasInputFocus;

	public bool WindowIsSuspended => Window.IsSuspended;

	internal IPlatformWindow Window { get; }

	internal IGraphicsContext Context { get; }

	internal int SheetSize { get; }

	internal int TempVertexBufferSize { get; }

	internal int TempIndexBufferSize { get; }

	public Size WorldFrameBufferSize => worldSheet.Size;

	public int WorldDownscaleFactor { get; private set; } = 1;

	public Size Resolution => Window.EffectiveWindowSize;

	public Size NativeResolution => Window.NativeWindowSize;

	public float WindowScale => Window.EffectiveWindowScale;

	public float NativeWindowScale => Window.NativeWindowScale;

	public GLProfile GLProfile => Window.GLProfile;

	public GLProfile[] SupportedGLProfiles => Window.SupportedGLProfiles;

	public IBatchRenderer CurrentBatchRenderer
	{
		get
		{
			return currentBatchRenderer;
		}
		set
		{
			if (currentBatchRenderer != value)
			{
				currentBatchRenderer?.Flush();
				currentBatchRenderer = value;
			}
		}
	}

	public string GLVersion => Context.GLVersion;

	public int DisplayCount => Window.DisplayCount;

	public int CurrentDisplay => Window.CurrentDisplay;

	public ITexture WorldBufferSnapshot()
	{
		worldBufferSnapshot.SetDataFromReadBuffer(new Rectangle(int2.Zero, worldSheet.Size));
		return worldBufferSnapshot;
	}

	public Renderer(IPlatform platform, GraphicSettings graphicSettings)
	{
		this.platform = platform;
		Size resolution = GetResolution(graphicSettings);
		TempVertexBufferSize = graphicSettings.BatchSize - graphicSettings.BatchSize % 4;
		TempIndexBufferSize = TempVertexBufferSize / 4 * 6;
		Window = platform.CreateWindow(new Size(resolution.Width, resolution.Height), graphicSettings.Mode, graphicSettings.UIScale, TempVertexBufferSize, TempIndexBufferSize, graphicSettings.VideoDisplay, graphicSettings.GLProfile);
		Context = Window.Context;
		SheetSize = graphicSettings.SheetSize;
		CombinedShaderBindings shaderBindings = new CombinedShaderBindings();
		WorldSpriteRenderer = new SpriteRenderer(this, Context.CreateShader(shaderBindings));
		WorldRgbaSpriteRenderer = new RgbaSpriteRenderer(WorldSpriteRenderer);
		WorldRgbaColorRenderer = new RgbaColorRenderer(WorldSpriteRenderer);
		SpriteRenderer = new SpriteRenderer(this, Context.CreateShader(shaderBindings));
		RgbaSpriteRenderer = new RgbaSpriteRenderer(SpriteRenderer);
		RgbaColorRenderer = new RgbaColorRenderer(SpriteRenderer);
		tempVertexBuffer = Context.CreateVertexBuffer<Vertex>(TempVertexBufferSize);
		quadIndexBuffer = Context.CreateIndexBuffer(Util.CreateQuadIndices(TempIndexBufferSize / 6));
		worldBufferSnapshot = Context.CreateTexture();
	}

	private static Size GetResolution(GraphicSettings graphicsSettings)
	{
		int2 int3 = ((graphicsSettings.Mode == WindowMode.Windowed) ? graphicsSettings.WindowedSize : graphicsSettings.FullscreenSize);
		return new Size(int3.X, int3.Y);
	}

	public void SetUIScale(float scale)
	{
		Window.SetScaleModifier(scale);
	}

	public void InitializeFonts(ModData modData)
	{
		if (Fonts != null)
		{
			foreach (SpriteFont value in Fonts.Values)
			{
				value.Dispose();
			}
		}
		using (new PerfTimer("SpriteFonts"))
		{
			fontSheetBuilder?.Dispose();
			fontSheetBuilder = new SheetBuilder(SheetType.BGRA, modData.Manifest.FontSheetSize);
			Fonts = modData.Manifest.Get<Fonts>().FontList.ToDictionary((KeyValuePair<string, FontData> x) => x.Key, (KeyValuePair<string, FontData> x) => new SpriteFont(platform, x.Value.Font, modData.DefaultFileSystem.Open(x.Value.Font).ReadAllBytes(), x.Value.Size, x.Value.Ascender, Window.EffectiveWindowScale, fontSheetBuilder));
		}
		Window.OnWindowScaleChanged += (float oldNative, float oldEffective, float newNative, float newEffective) =>
		{
			Game.RunAfterTick(() =>
			{
				SetMaximumViewportSize(lastMaximumViewportSize);
				ChromeProvider.SetDPIScale(newEffective);
				foreach (KeyValuePair<string, SpriteFont> font in Fonts)
				{
					font.Value.SetScale(newEffective);
				}
			});
		};
	}

	public void InitializeDepthBuffer(MapGrid mapGrid)
	{
		depthMargin = ((mapGrid != null && mapGrid.EnableDepthBuffer) ? (mapGrid.TileSize.Height * mapGrid.MaximumTerrainHeight) : 0);
	}

	private void BeginFrame()
	{
		Context.Clear();
		Size surfaceSize = Window.SurfaceSize;
		Size size = surfaceSize.NextPowerOf2();
		if (screenSprite == null || screenSprite.Sheet.Size != size)
		{
			screenBuffer?.Dispose();
			screenBuffer = Context.CreateFrameBuffer(size, Color.FromArgb(255, 0, 0, 0));
		}
		if (screenSprite == null || surfaceSize.Width != screenSprite.Bounds.Width || -surfaceSize.Height != screenSprite.Bounds.Height)
		{
			Sheet sheet = new Sheet(SheetType.BGRA, screenBuffer.Texture);
			Rectangle bounds = Rectangle.FromLTRB(0, surfaceSize.Height, surfaceSize.Width, 0);
			screenSprite = new Sprite(sheet, bounds, TextureChannel.RGBA);
		}
		float effectiveWindowScale = Window.EffectiveWindowScale;
		Size size2 = new Size((int)((float)size.Width / effectiveWindowScale), (int)((float)size.Height / effectiveWindowScale));
		if (lastBufferSize != size2)
		{
			SpriteRenderer.SetViewportParams(size2, 1, 0f, int2.Zero);
			lastBufferSize = size2;
		}
	}

	public void SetMaximumViewportSize(Size size)
	{
		Size size2;
		if (depthMargin == 0f)
		{
			Size surfaceSize = Window.SurfaceSize;
			size2 = new Size(Math.Min(size.Width, 2 * surfaceSize.Width), Math.Min(size.Height, 2 * surfaceSize.Height)).NextPowerOf2();
		}
		else
		{
			size2 = size.NextPowerOf2();
		}
		if (worldSprite == null || worldSheet.Size != size2)
		{
			worldBuffer?.Dispose();
			worldBuffer = Context.CreateFrameBuffer(size2);
			worldBuffer.Texture.ScaleFilter = TextureScaleFilter.Linear;
			worldSheet = new Sheet(SheetType.BGRA, worldBuffer.Texture);
			lastWorldViewport = Rectangle.Empty;
			worldSprite = null;
		}
		lastMaximumViewportSize = size;
	}

	public void BeginWorld(Rectangle worldViewport)
	{
		if (renderType != RenderType.None)
		{
			throw new InvalidOperationException($"BeginWorld called with renderType = {renderType}, expected RenderType.None.");
		}
		BeginFrame();
		if (worldSheet == null)
		{
			throw new InvalidOperationException("BeginWorld called before SetMaximumViewportSize has been set.");
		}
		if (worldSprite == null || worldViewport.Size != lastWorldViewportSize)
		{
			int width = worldViewport.Size.Width;
			int height = worldViewport.Size.Height;
			int width2 = worldSheet.Size.Width;
			int height2 = worldSheet.Size.Height;
			WorldDownscaleFactor = 1;
			while (width / WorldDownscaleFactor > width2 || height / WorldDownscaleFactor > height2)
			{
				WorldDownscaleFactor++;
			}
			Size size = new Size(width / WorldDownscaleFactor, height / WorldDownscaleFactor);
			worldSprite = new Sprite(worldSheet, new Rectangle(int2.Zero, size), TextureChannel.RGBA);
			lastWorldViewportSize = worldViewport.Size;
		}
		worldBuffer.Bind();
		if (lastWorldViewport != worldViewport)
		{
			WorldSpriteRenderer.SetViewportParams(worldSheet.Size, WorldDownscaleFactor, depthMargin, worldViewport.Location);
			lastWorldViewport = worldViewport;
		}
		renderType = RenderType.World;
	}

	public void BeginUI()
	{
		if (renderType == RenderType.World)
		{
			Flush();
			worldBuffer.Unbind();
			screenBuffer.Bind();
			float effectiveWindowScale = Window.EffectiveWindowScale;
			float3 scale = new float3((float)(int)((float)screenSprite.Bounds.Width / effectiveWindowScale) / worldSprite.Size.X, (float)(int)((float)(-screenSprite.Bounds.Height) / effectiveWindowScale) / worldSprite.Size.Y, 1f);
			SpriteRenderer.EnablePixelArtScaling(enabled: true);
			RgbaSpriteRenderer.DrawSprite(worldSprite, in float3.Zero, in scale);
			Flush();
			SpriteRenderer.EnablePixelArtScaling(enabled: false);
		}
		else
		{
			BeginFrame();
			screenBuffer.Bind();
		}
		renderType = RenderType.UI;
	}

	public void SetPalette(HardwarePalette palette)
	{
		if (palette.Texture != currentPaletteTexture || palette.Height != currentPaletteHeight)
		{
			Flush();
			currentPaletteTexture = palette.Texture;
			currentPaletteHeight = palette.Height;
			SpriteRenderer.SetPalette(palette);
			WorldSpriteRenderer.SetPalette(palette);
			IRenderer[] worldRenderers = WorldRenderers;
			foreach (IRenderer renderer in worldRenderers)
			{
				renderer.SetPalette(palette);
			}
		}
	}

	public void EndFrame(IInputHandler inputHandler)
	{
		if (renderType != RenderType.UI)
		{
			throw new InvalidOperationException($"EndFrame called with renderType = {renderType}, expected RenderType.UI.");
		}
		Flush();
		screenBuffer.Unbind();
		RgbaSpriteRenderer.DrawSprite(screenSprite, new float3(0f, lastBufferSize.Height, 0f), new float3((float)lastBufferSize.Width / screenSprite.Size.X, (float)(-lastBufferSize.Height) / screenSprite.Size.Y, 1f));
		Flush();
		Window.PumpInput(inputHandler);
		Context.Present();
		renderType = RenderType.None;
	}

	public void DrawBatch<T>(IVertexBuffer<T> vertices, IShader shader, int firstVertex, int numVertices, PrimitiveType type) where T : struct
	{
		vertices.Bind();
		shader.Bind();
		Context.DrawPrimitives(type, firstVertex, numVertices);
		PerfHistory.Increment("batches", 1.0);
	}

	public void DrawQuadBatch(ref Vertex[] vertices, IShader shader, int numVertices)
	{
		tempVertexBuffer.SetData(ref vertices, numVertices);
		DrawQuadBatch(tempVertexBuffer, quadIndexBuffer, shader, numVertices / 4 * 6, 0);
	}

	public void DrawQuadBatch<T>(IVertexBuffer<T> vertices, IIndexBuffer indices, IShader shader, int numIndices, int start) where T : struct
	{
		vertices.Bind();
		indices.Bind();
		shader.Bind();
		Context.DrawElements(numIndices, start);
		PerfHistory.Increment("batches", 1.0);
	}

	public void Flush()
	{
		CurrentBatchRenderer = null;
	}

	public IFrameBuffer CreateFrameBuffer(Size s)
	{
		return Context.CreateFrameBuffer(s);
	}

	public IShader CreateShader(IShaderBindings bindings)
	{
		return Context.CreateShader(bindings);
	}

	public IVertexBuffer<T> CreateVertexBuffer<T>(int length) where T : struct
	{
		return Context.CreateVertexBuffer<T>(length);
	}

	public void EnableScissor(Rectangle rect)
	{
		if (scissorState.Count > 0)
		{
			rect = Rectangle.Intersect(rect, scissorState.Peek());
		}
		Flush();
		if (renderType == RenderType.World)
		{
			Rectangle rect2 = Rectangle.FromLTRB(rect.Left / WorldDownscaleFactor, rect.Top / WorldDownscaleFactor, (rect.Right + WorldDownscaleFactor - 1) / WorldDownscaleFactor, (rect.Bottom + WorldDownscaleFactor - 1) / WorldDownscaleFactor);
			worldBuffer.EnableScissor(rect2);
		}
		else
		{
			Context.EnableScissor(rect.X, rect.Y, rect.Width, rect.Height);
		}
		scissorState.Push(rect);
	}

	public void DisableScissor()
	{
		scissorState.Pop();
		Flush();
		if (renderType == RenderType.World)
		{
			if (scissorState.Count > 0)
			{
				Rectangle rectangle = scissorState.Peek();
				Rectangle rect = Rectangle.FromLTRB(rectangle.Left / WorldDownscaleFactor, rectangle.Top / WorldDownscaleFactor, (rectangle.Right + WorldDownscaleFactor - 1) / WorldDownscaleFactor, (rectangle.Bottom + WorldDownscaleFactor - 1) / WorldDownscaleFactor);
				worldBuffer.EnableScissor(rect);
			}
			else
			{
				worldBuffer.DisableScissor();
			}
		}
		else if (scissorState.Count > 0)
		{
			Rectangle rectangle2 = scissorState.Peek();
			Context.EnableScissor(rectangle2.X, rectangle2.Y, rectangle2.Width, rectangle2.Height);
		}
		else
		{
			Context.DisableScissor();
		}
	}

	public void EnableDepthBuffer()
	{
		Flush();
		Context.EnableDepthBuffer();
	}

	public void DisableDepthBuffer()
	{
		Flush();
		Context.DisableDepthBuffer();
	}

	public void ClearDepthBuffer()
	{
		Flush();
		Context.ClearDepthBuffer();
	}

	public void EnableAntialiasingFilter()
	{
		if (renderType != RenderType.UI)
		{
			throw new InvalidOperationException($"EndFrame called with renderType = {renderType}, expected RenderType.UI.");
		}
		Flush();
		SpriteRenderer.EnablePixelArtScaling(enabled: true);
	}

	public void DisableAntialiasingFilter()
	{
		if (renderType != RenderType.UI)
		{
			throw new InvalidOperationException($"EndFrame called with renderType = {renderType}, expected RenderType.UI.");
		}
		Flush();
		SpriteRenderer.EnablePixelArtScaling(enabled: false);
	}

	public void GrabWindowMouseFocus()
	{
		Window.GrabWindowMouseFocus();
	}

	public void ReleaseWindowMouseFocus()
	{
		Window.ReleaseWindowMouseFocus();
	}

	public void SaveScreenshot(string path)
	{
		byte[] src = screenBuffer.Texture.GetData();
		int srcWidth = screenSprite.Sheet.Size.Width;
		int destWidth = screenSprite.Bounds.Width;
		int destHeight = -screenSprite.Bounds.Height;
		ThreadPool.QueueUserWorkItem((object? _) =>
		{
			byte[] array = new byte[4 * destWidth * destHeight];
			for (int i = 0; i < destHeight; i++)
			{
				Array.Copy(src, 4 * i * srcWidth, array, 4 * i * destWidth, 4 * destWidth);
			}
			new Png(array, SpriteFrameType.Bgra32, destWidth, destHeight).Save(path);
		});
	}

	public void Dispose()
	{
		worldBuffer?.Dispose();
		screenBuffer.Dispose();
		worldBufferSnapshot.Dispose();
		tempVertexBuffer.Dispose();
		quadIndexBuffer.Dispose();
		fontSheetBuilder?.Dispose();
		if (Fonts != null)
		{
			foreach (SpriteFont value in Fonts.Values)
			{
				value.Dispose();
			}
		}
		Window.Dispose();
	}

	public void SetVSyncEnabled(bool enabled)
	{
		Window.Context.SetVSyncEnabled(enabled);
	}

	public string GetClipboardText()
	{
		return Window.GetClipboardText();
	}

	public bool SetClipboardText(string text)
	{
		return Window.SetClipboardText(text);
	}
}
