namespace OpenRA;

public struct MouseInput(MouseInputEvent ev, MouseButton button, int2 location, int2 delta, Modifiers mods, int multiTapCount)
{
	public MouseInputEvent Event = ev;

	public MouseButton Button = button;

	public int2 Location = location;

	public int2 Delta = delta;

	public Modifiers Modifiers = mods;

	public int MultiTapCount = multiTapCount;
}
