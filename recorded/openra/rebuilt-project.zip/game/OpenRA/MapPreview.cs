using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenRA.FileFormats;
using OpenRA.FileSystem;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public sealed class MapPreview : IDisposable, IReadOnlyFileSystem
{
	private sealed class InnerData
	{
		public int MapFormat;

		public string Title;

		public string[] Categories;

		public string Author;

		public string TileSet;

		public MapPlayers Players;

		public int PlayerCount;

		public CPos[] SpawnPoints;

		public MapGridType GridType;

		public Rectangle Bounds;

		public Png Preview;

		public MapStatus Status;

		public MapClassification Class;

		public MapVisibility Visibility;

		public DateTime ModifiedDate;

		public MiniYaml RuleDefinitions;

		public MiniYaml WeaponDefinitions;

		public MiniYaml VoiceDefinitions;

		public MiniYaml MusicDefinitions;

		public MiniYaml NotificationDefinitions;

		public MiniYaml SequenceDefinitions;

		public MiniYaml ModelSequenceDefinitions;

		public MiniYaml FluentMessageDefinitions;

		public FluentBundle FluentBundle { get; private set; }

		public ActorInfo WorldActorInfo { get; private set; }

		public ActorInfo PlayerActorInfo { get; private set; }

		private static MiniYaml LoadRuleSection(Dictionary<string, MiniYaml> yaml, string section)
		{
			if (!yaml.TryGetValue(section, out var value))
			{
				return null;
			}
			return value;
		}

		private static bool IsLoadableRuleDefinition(MiniYamlNode n)
		{
			if (n.Key[0] == '^')
			{
				return true;
			}
			string text = n.Key.ToLowerInvariant();
			if (!(text == "world"))
			{
				return text == "player";
			}
			return true;
		}

		public void SetCustomRules(ModData modData, IReadOnlyFileSystem fileSystem, Dictionary<string, MiniYaml> yaml, IEnumerable<List<MiniYamlNode>> modDataRules)
		{
			RuleDefinitions = LoadRuleSection(yaml, "Rules");
			WeaponDefinitions = LoadRuleSection(yaml, "Weapons");
			VoiceDefinitions = LoadRuleSection(yaml, "Voices");
			MusicDefinitions = LoadRuleSection(yaml, "Music");
			NotificationDefinitions = LoadRuleSection(yaml, "Notifications");
			SequenceDefinitions = LoadRuleSection(yaml, "Sequences");
			ModelSequenceDefinitions = LoadRuleSection(yaml, "ModelSequences");
			FluentMessageDefinitions = LoadRuleSection(yaml, "FluentMessages");
			try
			{
				if (FluentMessageDefinitions != null)
				{
					string[] paths = Array.Empty<string>();
					if (FluentMessageDefinitions.Value != null)
					{
						paths = FieldLoader.GetValue<string[]>("value", FluentMessageDefinitions.Value);
					}
					string text = null;
					if (FluentMessageDefinitions.Nodes.Length > 0)
					{
						StringBuilder stringBuilder = new StringBuilder();
						foreach (MiniYamlNode node in FluentMessageDefinitions.Nodes)
						{
							if (node.Key == "base64")
							{
								stringBuilder.Append(Encoding.UTF8.GetString(Convert.FromBase64String(node.Value.Value)));
							}
						}
						text = stringBuilder.ToString();
					}
					FluentBundle = new FluentBundle(modData.Manifest.FluentCulture, paths, fileSystem, text);
				}
				else
				{
					FluentBundle = null;
				}
				if (RuleDefinitions != null)
				{
					if (modDataRules == null)
					{
						modDataRules = modData.GetRulesYaml();
					}
					IEnumerable<string> enumerable = Enumerable.Empty<string>();
					if (RuleDefinitions.Value != null)
					{
						string[] value = FieldLoader.GetValue<string[]>("value", RuleDefinitions.Value);
						enumerable = enumerable.Append(value);
					}
					HashSet<string> stringPool = new HashSet<string>();
					IEnumerable<List<MiniYamlNode>> enumerable2 = modDataRules.Select((List<MiniYamlNode> x) => x.Where(IsLoadableRuleDefinition).ToList()).Concat(enumerable.Select((string s) => MiniYaml.FromStream(fileSystem.Open(s), s, discardCommentsAndWhitespace: true, stringPool).Where(IsLoadableRuleDefinition).ToList()));
					if (RuleDefinitions.Nodes.Length > 0)
					{
						enumerable2 = enumerable2.Append(RuleDefinitions.Nodes.Where(IsLoadableRuleDefinition).ToList());
					}
					List<MiniYamlNode> source = MiniYaml.Merge(enumerable2);
					WorldActorInfo = new ActorInfo(modData.ObjectCreator, "world", source.First((MiniYamlNode n) => string.Equals(n.Key, "world", StringComparison.InvariantCultureIgnoreCase)).Value);
					PlayerActorInfo = new ActorInfo(modData.ObjectCreator, "player", source.First((MiniYamlNode n) => string.Equals(n.Key, "player", StringComparison.InvariantCultureIgnoreCase)).Value);
					return;
				}
			}
			catch (Exception e)
			{
				Log.Write("debug", "Failed to load rules for `" + Title + "` with error:");
				Log.Write("debug", e);
			}
			WorldActorInfo = modData.DefaultRules.Actors[SystemActors.World];
			PlayerActorInfo = modData.DefaultRules.Actors[SystemActors.Player];
		}

		public InnerData Clone()
		{
			return (InnerData)MemberwiseClone();
		}
	}

	private static readonly CPos[] NoSpawns = Array.Empty<CPos>();

	private readonly MapCache cache;

	private readonly ModData modData;

	public readonly string Uid;

	private IReadOnlyPackage package;

	private IReadOnlyPackage parentPackage;

	private volatile InnerData innerData;

	private Sprite minimap;

	private bool generatingMinimap;

	public string PackageName { get; private set; }

	public IReadOnlyPackage Package
	{
		get
		{
			if (package == null)
			{
				package = parentPackage.OpenPackage(PackageName, modData.ModFiles);
			}
			return package;
		}
		private set
		{
			package = value;
		}
	}

	public int MapFormat => innerData.MapFormat;

	public string Title => innerData.Title;

	public string[] Categories => innerData.Categories;

	public string Author => innerData.Author;

	public string TileSet => innerData.TileSet;

	public MapPlayers Players => innerData.Players;

	public int PlayerCount => innerData.PlayerCount;

	public CPos[] SpawnPoints => innerData.SpawnPoints;

	public MapGridType GridType => innerData.GridType;

	public Rectangle Bounds => innerData.Bounds;

	public Png Preview => innerData.Preview;

	public MapStatus Status => innerData.Status;

	public MapClassification Class => innerData.Class;

	public MapVisibility Visibility => innerData.Visibility;

	public MiniYaml RuleDefinitions => innerData.RuleDefinitions;

	public MiniYaml WeaponDefinitions => innerData.WeaponDefinitions;

	public MiniYaml SequenceDefinitions => innerData.SequenceDefinitions;

	public ActorInfo WorldActorInfo => innerData.WorldActorInfo;

	public ActorInfo PlayerActorInfo => innerData.PlayerActorInfo;

	public DateTime ModifiedDate => innerData.ModifiedDate;

	public long DownloadBytes { get; private set; }

	public int DownloadPercentage { get; private set; }

	public string GetMessage(string key, object[] args = null)
	{
		if (TryGetMessage(key, out var message, args))
		{
			return message;
		}
		return key;
	}

	public bool TryGetMessage(string key, out string message, object[] args = null)
	{
		if (FluentProvider.TryGetModMessage(key, out message, args))
		{
			return true;
		}
		if (innerData.FluentBundle == null)
		{
			return false;
		}
		return innerData.FluentBundle.TryGetMessage(key, out message, args);
	}

	public Sprite GetMinimap()
	{
		if (minimap != null)
		{
			return minimap;
		}
		if (!generatingMinimap && Status == MapStatus.Available)
		{
			generatingMinimap = true;
			cache.CacheMinimap(this);
		}
		return null;
	}

	internal void SetMinimap(Sprite minimap)
	{
		this.minimap = minimap;
		generatingMinimap = false;
	}

	public bool DefinesUnsafeCustomRules()
	{
		return Ruleset.DefinesUnsafeCustomRules(modData, this, innerData.RuleDefinitions, innerData.WeaponDefinitions, innerData.VoiceDefinitions, innerData.NotificationDefinitions, innerData.SequenceDefinitions);
	}

	public Ruleset LoadRuleset()
	{
		return Ruleset.Load(modData, this, TileSet, innerData.RuleDefinitions, innerData.WeaponDefinitions, innerData.VoiceDefinitions, innerData.NotificationDefinitions, innerData.MusicDefinitions, innerData.ModelSequenceDefinitions);
	}

	public MapPreview(ModData modData, string uid, MapGridType gridType, MapCache cache)
	{
		this.cache = cache;
		this.modData = modData;
		Uid = uid;
		innerData = new InnerData
		{
			MapFormat = 0,
			Title = "Unknown Map",
			Categories = new string[1] { "Unknown" },
			Author = "Unknown Author",
			TileSet = "unknown",
			Players = null,
			PlayerCount = 0,
			SpawnPoints = NoSpawns,
			GridType = gridType,
			Bounds = Rectangle.Empty,
			Preview = null,
			Status = MapStatus.Unavailable,
			Class = MapClassification.Unknown,
			Visibility = MapVisibility.Lobby
		};
	}

	public MapPreview(Map map, ModData modData)
	{
		this.modData = modData;
		cache = modData.MapCache;
		Uid = map.Uid;
		PackageName = map.Package.Name;
		MapPlayers mapPlayers = new MapPlayers(map.PlayerDefinitions);
		List<CPos> list = new List<CPos>();
		foreach (MiniYamlNode item in map.ActorDefinitions.Where((MiniYamlNode d) => d.Value.Value == "mpspawn"))
		{
			ActorReference actorReference = new ActorReference(item.Value.Value, item.Value.ToDictionary());
			list.Add(actorReference.Get<LocationInit>().Value);
		}
		innerData = new InnerData
		{
			MapFormat = map.MapFormat,
			Title = map.Title,
			Categories = map.Categories,
			Author = map.Author,
			TileSet = map.Tileset,
			Players = mapPlayers,
			PlayerCount = mapPlayers.Players.Count((KeyValuePair<string, PlayerReference> x) => x.Value.Playable),
			SpawnPoints = list.ToArray(),
			GridType = map.Grid.Type,
			Bounds = map.Bounds,
			Preview = null,
			Status = MapStatus.Available,
			Class = MapClassification.Unknown,
			Visibility = map.Visibility
		};
		innerData.SetCustomRules(modData, this, new Dictionary<string, MiniYaml>
		{
			{ "Rules", map.RuleDefinitions },
			{ "FluentMessages", map.FluentMessageDefinitions },
			{ "Weapons", map.WeaponDefinitions },
			{ "Voices", map.VoiceDefinitions },
			{ "Music", map.MusicDefinitions },
			{ "Notifications", map.NotificationDefinitions },
			{ "Sequences", map.SequenceDefinitions },
			{ "ModelSequences", map.ModelSequenceDefinitions }
		}, null);
	}

	public void UpdateFromMap(IReadOnlyPackage p, IReadOnlyPackage parent, MapClassification classification, string[] mapCompatibility, MapGridType gridType, IEnumerable<List<MiniYamlNode>> modDataRules)
	{
		Dictionary<string, MiniYaml> dictionary;
		using (Stream stream = p.GetStream("map.yaml"))
		{
			if (stream == null)
			{
				throw new FileNotFoundException("Required file map.yaml not present in this map");
			}
			dictionary = new MiniYaml(null, MiniYaml.FromStream(stream, p.Name + ":map.yaml", discardCommentsAndWhitespace: true, cache.StringPool)).ToDictionary();
		}
		PackageName = p.Name;
		parentPackage = parent;
		InnerData innerData = this.innerData.Clone();
		innerData.GridType = gridType;
		innerData.Class = classification;
		if (dictionary.TryGetValue("MapFormat", out var value))
		{
			int value2 = FieldLoader.GetValue<int>("MapFormat", value.Value);
			if (value2 < 11)
			{
				throw new InvalidDataException($"Map format {value2} is not supported.");
			}
		}
		if (dictionary.TryGetValue("Title", out value))
		{
			innerData.Title = value.Value;
		}
		if (dictionary.TryGetValue("Categories", out value))
		{
			innerData.Categories = FieldLoader.GetValue<string[]>("Categories", value.Value);
		}
		if (dictionary.TryGetValue("Tileset", out value))
		{
			innerData.TileSet = value.Value;
		}
		if (dictionary.TryGetValue("Author", out value))
		{
			innerData.Author = value.Value;
		}
		if (dictionary.TryGetValue("Bounds", out value))
		{
			innerData.Bounds = FieldLoader.GetValue<Rectangle>("Bounds", value.Value);
		}
		if (dictionary.TryGetValue("Visibility", out value))
		{
			innerData.Visibility = FieldLoader.GetValue<MapVisibility>("Visibility", value.Value);
		}
		string value3 = string.Empty;
		if (dictionary.TryGetValue("RequiresMod", out value))
		{
			value3 = value.Value;
		}
		if (dictionary.TryGetValue("MapFormat", out value))
		{
			innerData.MapFormat = FieldLoader.GetValue<int>("MapFormat", value.Value);
		}
		innerData.Status = ((mapCompatibility != null && !Enumerable.Contains(mapCompatibility, value3)) ? MapStatus.Unavailable : MapStatus.Available);
		try
		{
			if (dictionary.TryGetValue("Actors", out var value4))
			{
				List<CPos> list = new List<CPos>();
				foreach (MiniYamlNode item in value4.Nodes.Where((MiniYamlNode d) => d.Value.Value == "mpspawn"))
				{
					ActorReference actorReference = new ActorReference(item.Value.Value, item.Value.ToDictionary());
					list.Add(actorReference.Get<LocationInit>().Value);
				}
				innerData.SpawnPoints = list.ToArray();
			}
			else
			{
				innerData.SpawnPoints = Array.Empty<CPos>();
			}
		}
		catch (Exception)
		{
			innerData.SpawnPoints = Array.Empty<CPos>();
			innerData.Status = MapStatus.Unavailable;
		}
		try
		{
			if (dictionary.TryGetValue("Players", out var value5))
			{
				innerData.Players = new MapPlayers(value5.Nodes);
				innerData.PlayerCount = innerData.Players.Players.Count((KeyValuePair<string, PlayerReference> x) => x.Value.Playable);
			}
		}
		catch (Exception)
		{
			innerData.Status = MapStatus.Unavailable;
		}
		innerData.SetCustomRules(modData, this, dictionary, modDataRules);
		if (cache.LoadPreviewImages && p.Contains("map.png"))
		{
			using Stream s = p.GetStream("map.png");
			innerData.Preview = new Png(s);
		}
		innerData.ModifiedDate = File.GetLastWriteTime(p.Name);
		this.innerData = innerData;
	}

	public void UpdateRemoteSearch(MapStatus status, MiniYaml yaml, string[] mapCompatibility, Action<MapPreview> parseMetadata = null)
	{
		InnerData innerData = this.innerData.Clone();
		innerData.Status = status;
		innerData.Class = MapClassification.Remote;
		if (status == MapStatus.DownloadAvailable)
		{
			try
			{
				RemoteMapData remoteMapData = FieldLoader.Load<RemoteMapData>(yaml);
				if (!remoteMapData.downloading)
				{
					innerData.Status = MapStatus.Unavailable;
					return;
				}
				innerData.Title = remoteMapData.title;
				innerData.Categories = remoteMapData.categories;
				innerData.Author = remoteMapData.author;
				innerData.PlayerCount = remoteMapData.players;
				innerData.Bounds = remoteMapData.bounds;
				innerData.TileSet = remoteMapData.tileset;
				innerData.MapFormat = remoteMapData.mapformat;
				CPos[] array = new CPos[remoteMapData.spawnpoints.Length / 2];
				for (int i = 0; i < remoteMapData.spawnpoints.Length; i += 2)
				{
					array[i / 2] = new CPos(remoteMapData.spawnpoints[i], remoteMapData.spawnpoints[i + 1]);
				}
				innerData.SpawnPoints = array;
				innerData.GridType = remoteMapData.map_grid_type;
				if (cache.LoadPreviewImages)
				{
					try
					{
						innerData.Preview = new Png(new MemoryStream(Convert.FromBase64String(remoteMapData.minimap)));
					}
					catch (Exception e)
					{
						Log.Write("debug", "Failed parsing mapserver minimap response:");
						Log.Write("debug", e);
						innerData.Preview = null;
					}
				}
				string text = Encoding.UTF8.GetString(Convert.FromBase64String(remoteMapData.players_block));
				innerData.Players = new MapPlayers(MiniYaml.FromString(text, yaml.NodeWithKey("players_block").Location.Name + ":players_block"));
				string text2 = Encoding.UTF8.GetString(Convert.FromBase64String(remoteMapData.rules));
				Dictionary<string, MiniYaml> yaml2 = new MiniYaml("", MiniYaml.FromString(text2, yaml.NodeWithKey("rules").Location.Name + ":rules")).ToDictionary();
				innerData.SetCustomRules(modData, this, yaml2, null);
				if (!Enumerable.Contains(mapCompatibility, remoteMapData.game_mod))
				{
					innerData.Status = MapStatus.Unavailable;
				}
			}
			catch (Exception e2)
			{
				Log.Write("debug", "Failed parsing mapserver response:");
				Log.Write("debug", e2);
			}
			this.innerData = innerData;
			if (this.innerData.Preview != null)
			{
				cache.CacheMinimap(this);
			}
			parseMetadata?.Invoke(this);
		}
		this.innerData = innerData;
	}

	public void Install(string mapRepositoryUrl, Action onSuccess)
	{
		if ((Status != MapStatus.DownloadError && Status != MapStatus.DownloadAvailable) || !Game.Settings.Game.AllowDownloading)
		{
			return;
		}
		innerData.Status = MapStatus.Downloading;
		IReadOnlyPackage key = cache.MapLocations.FirstOrDefault((KeyValuePair<IReadOnlyPackage, MapClassification> p) => p.Value == MapClassification.User).Key;
		IReadWritePackage mapInstallPackage = key as IReadWritePackage;
		if (mapInstallPackage == null)
		{
			Log.Write("debug", "Map install directory not found");
			innerData.Status = MapStatus.DownloadError;
			return;
		}
		Task.Run(async () =>
		{
			string requestUri = mapRepositoryUrl + Uid;
			try
			{
				HttpClient httpClient = HttpClientFactory.Create();
				HttpResponseMessage httpResponseMessage = await httpClient.GetAsync(requestUri, HttpCompletionOption.ResponseHeadersRead);
				if (!httpResponseMessage.IsSuccessStatusCode)
				{
					innerData.Status = MapStatus.DownloadError;
				}
				else
				{
					string mapFilename = httpResponseMessage.Content.Headers.ContentDisposition?.FileName;
					if (string.IsNullOrEmpty(mapFilename))
					{
						innerData.Status = MapStatus.DownloadError;
					}
					else
					{
						MemoryStream fileStream = new MemoryStream();
						await httpResponseMessage.ReadAsStreamWithProgress(fileStream, OnDownloadProgress, CancellationToken.None);
						mapInstallPackage.Update(mapFilename, fileStream.ToArray());
						Log.Write("debug", "Downloaded map to '" + mapFilename + "'");
						IReadOnlyPackage readOnlyPackage = mapInstallPackage.OpenPackage(mapFilename, modData.ModFiles);
						if (readOnlyPackage == null)
						{
							innerData.Status = MapStatus.DownloadError;
						}
						else
						{
							UpdateFromMap(readOnlyPackage, mapInstallPackage, MapClassification.User, null, GridType, null);
							Game.RunAfterTick(onSuccess);
						}
					}
				}
			}
			catch (Exception e)
			{
				Log.Write("debug", "Map installation failed with error:");
				Log.Write("debug", e);
				innerData.Status = MapStatus.DownloadError;
			}
		});
		void OnDownloadProgress(long total, long received, int percentage)
		{
			DownloadBytes = total;
			DownloadPercentage = percentage;
		}
	}

	public void Invalidate()
	{
		innerData.Status = MapStatus.Unavailable;
	}

	public void Dispose()
	{
		DisposePackage();
	}

	public void DisposePackage()
	{
		if (package != null)
		{
			package.Dispose();
			package = null;
		}
	}

	public void Delete()
	{
		Invalidate();
		(parentPackage as IReadWritePackage)?.Delete(Package.Name);
	}

	Stream IReadOnlyFileSystem.Open(string filename)
	{
		if (!filename.Contains('|') && Package.Contains(filename))
		{
			return Package.GetStream(filename);
		}
		return modData.DefaultFileSystem.Open(filename);
	}

	bool IReadOnlyFileSystem.TryGetPackageContaining(string path, out IReadOnlyPackage package, out string filename)
	{
		return modData.DefaultFileSystem.TryGetPackageContaining(path, out package, out filename);
	}

	bool IReadOnlyFileSystem.TryOpen(string filename, out Stream s)
	{
		if (!filename.Contains('|'))
		{
			s = Package.GetStream(filename);
			if (s != null)
			{
				return true;
			}
		}
		return modData.DefaultFileSystem.TryOpen(filename, out s);
	}

	bool IReadOnlyFileSystem.Exists(string filename)
	{
		if (!filename.Contains('|') && Package.Contains(filename))
		{
			return true;
		}
		return modData.DefaultFileSystem.Exists(filename);
	}

	bool IReadOnlyFileSystem.IsExternalFile(string filename)
	{
		if (filename.Contains('|'))
		{
			return modData.DefaultFileSystem.IsExternalFile(filename);
		}
		return false;
	}
}
