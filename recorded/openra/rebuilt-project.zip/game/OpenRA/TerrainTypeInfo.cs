using System.Collections.Generic;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA;

public class TerrainTypeInfo
{
	public readonly string Type;

	public readonly BitSet<TargetableType> TargetTypes;

	public readonly HashSet<string> AcceptsSmudgeType = new HashSet<string>();

	public readonly Color Color;

	public readonly bool RestrictPlayerColor;

	public TerrainTypeInfo(MiniYaml my)
	{
		FieldLoader.Load(this, my);
	}
}
