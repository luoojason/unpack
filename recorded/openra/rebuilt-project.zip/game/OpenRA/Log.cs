using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Threading.Channels;

namespace OpenRA;

public static class Log
{
	private const int CreateLogFileMaxRetryCount = 128;

	private static readonly ConcurrentDictionary<string, ChannelInfo> Channels;

	private static readonly Channel<ChannelData> Channel;

	private static readonly ChannelWriter<ChannelData> ChannelWriter;

	private static readonly CancellationTokenSource CancellationToken;

	private static readonly TimeSpan FlushInterval;

	private static readonly Timer Timer;

	private static readonly Thread Thread;

	static Log()
	{
		Channels = new ConcurrentDictionary<string, ChannelInfo>();
		CancellationToken = new CancellationTokenSource();
		FlushInterval = TimeSpan.FromSeconds(5.0);
		Channel = System.Threading.Channels.Channel.CreateUnbounded<ChannelData>();
		ChannelWriter = Channel.Writer;
		Thread = new Thread(DoWork)
		{
			Name = "OpenRA Logging Thread"
		};
		Thread.Start(CancellationToken.Token);
		Timer = new Timer(FlushToDisk, CancellationToken.Token, FlushInterval, Timeout.InfiniteTimeSpan);
	}

	private static void FlushToDisk(object state)
	{
		FlushToDisk();
		if (!((CancellationToken)state).IsCancellationRequested)
		{
			Timer.Change(FlushInterval, Timeout.InfiniteTimeSpan);
		}
	}

	private static void FlushToDisk()
	{
		foreach (var (_, channelInfo2) in Channels)
		{
			channelInfo2.Writer?.Flush();
		}
	}

	private static void DoWork(object obj)
	{
		CancellationToken cancellationToken = (CancellationToken)obj;
		ChannelReader<ChannelData> reader = Channel.Reader;
		while (!cancellationToken.IsCancellationRequested)
		{
			ChannelData item;
			while (reader.TryRead(out item))
			{
				WriteValue(item);
			}
			Thread.Sleep(1);
		}
		ChannelData item2;
		while (reader.TryRead(out item2))
		{
			WriteValue(item2);
		}
		FlushToDisk();
	}

	private static void WriteValue(ChannelData item)
	{
		ChannelInfo channel = GetChannel(item.Channel);
		TextWriter writer = channel.Writer;
		if (writer != null)
		{
			if (!channel.IsTimestamped)
			{
				writer.WriteLine(item.Text);
				return;
			}
			string arg = DateTime.Now.ToString(Game.Settings.Server.TimestampFormat, CultureInfo.CurrentCulture);
			writer.WriteLine("[{0}] {1}", arg, item.Text);
		}
	}

	private static IEnumerable<string> FilenamesForChannel(string baseFilename)
	{
		string path = Platform.SupportDir + "Logs";
		Directory.CreateDirectory(path);
		for (int i = 0; i < 128; i++)
		{
			yield return Path.Combine(path, (i > 0) ? $"{baseFilename}.{i}" : baseFilename);
		}
		throw new ApplicationException("Error creating log file \"" + baseFilename + "\"");
	}

	private static ChannelInfo GetChannel(string channelName)
	{
		if (!Channels.TryGetValue(channelName, out var value))
		{
			throw new ArgumentException("Tried logging to non-existent channel " + channelName, "channelName");
		}
		return value;
	}

	public static void AddChannel(string channelName, string baseFilename, bool isTimestamped = false)
	{
		if (Channels.ContainsKey(channelName))
		{
			return;
		}
		if (string.IsNullOrEmpty(baseFilename))
		{
			Channels.TryAdd(channelName, default);
			return;
		}
		foreach (string item in FilenamesForChannel(baseFilename))
		{
			try
			{
				StreamWriter streamWriter = File.CreateText(item);
				streamWriter.AutoFlush = false;
				Channels.TryAdd(channelName, new ChannelInfo
				{
					Filename = item,
					IsTimestamped = isTimestamped,
					Writer = TextWriter.Synchronized(streamWriter)
				});
				break;
			}
			catch (IOException)
			{
			}
		}
	}

	public static void Write(string channelName, string value)
	{
		ChannelWriter.TryWrite(new ChannelData(channelName, value));
	}

	public static void Write(string channelName, Exception e)
	{
		ChannelWriter.TryWrite(new ChannelData(channelName, e.Message + Environment.NewLine + e.StackTrace));
	}

	public static void Dispose()
	{
		CancellationToken.Cancel();
		Timer.Dispose();
		Thread.Join();
	}
}
