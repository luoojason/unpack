namespace OpenRA;

public enum WinState
{
	Undefined,
	Won,
	Lost
}
