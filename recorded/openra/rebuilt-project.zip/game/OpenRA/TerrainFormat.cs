using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace OpenRA;

public sealed class TerrainFormat : IGlobalModData
{
	public readonly string Type;

	public readonly IReadOnlyDictionary<string, MiniYaml> Metadata;

	public TerrainFormat(MiniYaml yaml)
	{
		Type = yaml.Value;
		Metadata = new ReadOnlyDictionary<string, MiniYaml>(yaml.ToDictionary());
	}
}
