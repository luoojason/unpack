using System;

namespace OpenRA;

[AttributeUsage(AttributeTargets.Field)]
public sealed class FieldFromYamlKeyAttribute : FieldLoader.SerializeAttribute
{
	public FieldFromYamlKeyAttribute()
	{
		FromYamlKey = true;
	}
}
