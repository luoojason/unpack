using OpenRA.Widgets;

namespace OpenRA;

public class DefaultInputHandler : IInputHandler
{
	private readonly World world;

	public DefaultInputHandler(World world)
	{
		this.world = world;
	}

	public void ModifierKeys(Modifiers mods)
	{
		Game.HandleModifierKeys(mods);
	}

	public void OnKeyInput(KeyInput input)
	{
		Sync.RunUnsynced(world, () => Ui.HandleKeyPress(input));
	}

	public void OnTextInput(string text)
	{
		Sync.RunUnsynced(world, () => Ui.HandleTextInput(text));
	}

	public void OnMouseInput(MouseInput input)
	{
		Sync.RunUnsynced(world, () => Ui.HandleInput(input));
	}
}
