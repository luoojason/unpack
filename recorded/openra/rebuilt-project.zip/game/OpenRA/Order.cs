using System;
using System.IO;
using OpenRA.Traits;

namespace OpenRA;

public sealed class Order
{
	public const int SyncHashOrderLength = 13;

	public const int DisconnectOrderLength = 5;

	public readonly string OrderString;

	public readonly Actor Subject;

	public readonly bool Queued;

	public readonly Actor[] GroupedActors;

	public string TargetString;

	public CPos ExtraLocation;

	public Actor[] ExtraActors;

	public uint ExtraData;

	public bool IsImmediate;

	public OrderType Type = OrderType.Fields;

	public bool SuppressVisualFeedback;

	private readonly Target target;

	private readonly Target visualFeedbackTarget;

	public ref readonly Target Target => ref target;

	public ref readonly Target VisualFeedbackTarget => ref visualFeedbackTarget;

	public Player Player => Subject?.Owner;

	private Order(string orderString, Actor subject, in Target target, string targetString, bool queued, Actor[] extraActors, CPos extraLocation, uint extraData, Actor[] groupedActors = null)
	{
		OrderString = orderString ?? "";
		Subject = subject;
		this.target = target;
		TargetString = targetString;
		Queued = queued;
		ExtraActors = extraActors;
		ExtraLocation = extraLocation;
		ExtraData = extraData;
		GroupedActors = groupedActors;
	}

	public static Order Deserialize(World world, BinaryReader r)
	{
		try
		{
			OrderType orderType = (OrderType)r.ReadByte();
			switch (orderType)
			{
			case OrderType.Fields:
			{
				string orderString2 = r.ReadString();
				OrderFields of = (OrderFields)r.ReadInt16();
				Actor ret = null;
				if (of.HasField(OrderFields.Subject))
				{
					uint aID = r.ReadUInt32();
					if (world != null)
					{
						TryGetActorFromUInt(world, aID, out ret);
					}
				}
				Target target = Target.Invalid;
				if (of.HasField(OrderFields.Target))
				{
					switch ((TargetType)r.ReadByte())
					{
					case TargetType.Actor:
					{
						uint aID3 = r.ReadUInt32();
						int generation = r.ReadInt32();
						if (world != null && TryGetActorFromUInt(world, aID3, out var ret3))
						{
							target = Target.FromSerializedActor(ret3, generation);
						}
						break;
					}
					case TargetType.FrozenActor:
					{
						uint aID2 = r.ReadUInt32();
						uint id = r.ReadUInt32();
						if (world != null && TryGetActorFromUInt(world, aID2, out var ret2) && ret2.Owner.FrozenActorLayer != null)
						{
							FrozenActor frozenActor = ret2.Owner.FrozenActorLayer.FromID(id);
							if (frozenActor != null)
							{
								target = Target.FromFrozenActor(frozenActor);
							}
						}
						break;
					}
					case TargetType.Terrain:
					{
						if (of.HasField(OrderFields.TargetIsCell))
						{
							CPos c = new CPos(r.ReadInt32());
							SubCell subCell = (SubCell)r.ReadByte();
							if (world != null)
							{
								target = Target.FromCell(world, c, subCell);
							}
							break;
						}
						WPos wPos = new WPos(r.ReadInt32(), r.ReadInt32(), r.ReadInt32());
						short num = r.ReadInt16();
						if (num == -1)
						{
							target = Target.FromPos(wPos);
							break;
						}
						WPos[] array = new WPos[num];
						for (int i = 0; i < num; i++)
						{
							array[i] = new WPos(r.ReadInt32(), r.ReadInt32(), r.ReadInt32());
						}
						target = Target.FromSerializedTerrainPosition(wPos, array);
						break;
					}
					}
				}
				string targetString2 = (of.HasField(OrderFields.TargetString) ? r.ReadString() : null);
				bool queued = of.HasField(OrderFields.Queued);
				Actor[] extraActors = null;
				if (of.HasField(OrderFields.ExtraActors))
				{
					int num2 = r.ReadInt32();
					if (world != null)
					{
						extraActors = Exts.MakeArray(num2, (int _) => world.GetActorById(r.ReadUInt32()));
					}
					else
					{
						r.ReadBytes(4 * num2);
					}
				}
				CPos extraLocation = (of.HasField(OrderFields.ExtraLocation) ? new CPos(r.ReadInt32()) : CPos.Zero);
				uint extraData = (of.HasField(OrderFields.ExtraData) ? r.ReadUInt32() : 0u);
				Actor[] groupedActors = null;
				if (of.HasField(OrderFields.Grouped))
				{
					int num3 = r.ReadInt32();
					if (world != null)
					{
						groupedActors = Exts.MakeArray(num3, (int _) => world.GetActorById(r.ReadUInt32()));
					}
					else
					{
						r.ReadBytes(4 * num3);
					}
				}
				if (world == null)
				{
					return new Order(orderString2, null, in target, targetString2, queued, extraActors, extraLocation, extraData, groupedActors);
				}
				if (ret == null && of.HasField(OrderFields.Subject))
				{
					return null;
				}
				return new Order(orderString2, ret, in target, targetString2, queued, extraActors, extraLocation, extraData, groupedActors);
			}
			case OrderType.Handshake:
			{
				string orderString = r.ReadString();
				string targetString = r.ReadString();
				return new Order(orderString, null, queued: false)
				{
					Type = OrderType.Handshake,
					TargetString = targetString
				};
			}
			default:
				Log.Write("debug", $"Received unknown order with type {orderType}");
				return null;
			}
		}
		catch (Exception e)
		{
			Log.Write("debug", "Caught exception while processing order");
			Log.Write("debug", e);
			TextNotificationsManager.Debug("Ignoring malformed order that would have crashed the game");
			TextNotificationsManager.Debug("Please file a bug report and include the replay from this match");
			return null;
		}
	}

	private static uint UIntFromActor(Actor a)
	{
		return (uint)(((int?)a?.ActorID) ?? (-1));
	}

	private static bool TryGetActorFromUInt(World world, uint aID, out Actor ret)
	{
		if (aID == uint.MaxValue)
		{
			ret = null;
			return true;
		}
		ret = world.GetActorById(aID);
		return ret != null;
	}

	public static Order Chat(string text, uint teamNumber = 0u)
	{
		return new Order("Chat", null, queued: false)
		{
			IsImmediate = true,
			TargetString = text,
			ExtraData = teamNumber
		};
	}

	public static Order FromTargetString(string order, string targetString, bool isImmediate)
	{
		return new Order(order, null, queued: false)
		{
			IsImmediate = isImmediate,
			TargetString = targetString
		};
	}

	public static Order FromGroupedOrder(Order grouped, Actor subject)
	{
		return new Order(grouped.OrderString, subject, in grouped.Target, grouped.TargetString, grouped.Queued, grouped.ExtraActors, grouped.ExtraLocation, grouped.ExtraData);
	}

	public static Order Command(string text)
	{
		return new Order("Command", null, queued: false)
		{
			IsImmediate = true,
			TargetString = text
		};
	}

	public static Order StartProduction(Actor subject, string item, int count, bool queued = true)
	{
		return new Order("StartProduction", subject, queued)
		{
			ExtraData = (uint)count,
			TargetString = item
		};
	}

	public static Order PauseProduction(Actor subject, string item, bool pause)
	{
		return new Order("PauseProduction", subject, queued: false)
		{
			ExtraData = (pause ? 1u : 0u),
			TargetString = item
		};
	}

	public static Order CancelProduction(Actor subject, string item, int count)
	{
		return new Order("CancelProduction", subject, queued: false)
		{
			ExtraData = (uint)count,
			TargetString = item
		};
	}

	public Order()
		: this(null, null, in Target.Invalid, null, queued: false, null, CPos.Zero, 0u)
	{
	}

	public Order(string orderString, Actor subject, bool queued, Actor[] extraActors = null, Actor[] groupedActors = null)
		: this(orderString, subject, in Target.Invalid, null, queued, extraActors, CPos.Zero, 0u, groupedActors)
	{
	}

	public Order(string orderString, Actor subject, in Target target, bool queued, Actor[] extraActors = null, Actor[] groupedActors = null)
		: this(orderString, subject, in target, null, queued, extraActors, CPos.Zero, 0u, groupedActors)
	{
	}

	public Order(string orderString, Actor subject, Target target, Target visualFeedbackTarget, bool queued)
		: this(orderString, subject, in target, null, queued, null, CPos.Zero, 0u)
	{
		this.visualFeedbackTarget = visualFeedbackTarget;
	}

	public byte[] Serialize()
	{
		int num = 1 + OrderString.Length + 1;
		if (Type == OrderType.Handshake)
		{
			num += TargetString.Length + 1;
		}
		else if (Type == OrderType.Fields)
		{
			num += 19 + ((TargetString != null) ? (TargetString.Length + 1) : 0) + 4 + 4 + 4;
		}
		if (ExtraActors != null)
		{
			num += ExtraActors.Length * 4;
		}
		MemoryStream memoryStream = new MemoryStream(num);
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write((byte)Type);
		binaryWriter.Write(OrderString);
		switch (Type)
		{
		case OrderType.Handshake:
			binaryWriter.Write(TargetString ?? "");
			break;
		case OrderType.Fields:
		{
			(TargetType, Actor, int, CPos?, SubCell?, WPos, WPos[]) serializableState = Target.SerializableState;
			OrderFields orderFields = OrderFields.None;
			if (Subject != null)
			{
				orderFields |= OrderFields.Subject;
			}
			if (TargetString != null)
			{
				orderFields |= OrderFields.TargetString;
			}
			if (ExtraData != 0)
			{
				orderFields |= OrderFields.ExtraData;
			}
			if (serializableState.Item1 != TargetType.Invalid)
			{
				orderFields |= OrderFields.Target;
			}
			if (Queued)
			{
				orderFields |= OrderFields.Queued;
			}
			if (GroupedActors != null)
			{
				orderFields |= OrderFields.Grouped;
			}
			if (ExtraActors != null)
			{
				orderFields |= OrderFields.ExtraActors;
			}
			if (ExtraLocation != CPos.Zero)
			{
				orderFields |= OrderFields.ExtraLocation;
			}
			if (serializableState.Item4.HasValue)
			{
				orderFields |= OrderFields.TargetIsCell;
			}
			binaryWriter.Write((short)orderFields);
			if (orderFields.HasField(OrderFields.Subject))
			{
				binaryWriter.Write(UIntFromActor(Subject));
			}
			if (orderFields.HasField(OrderFields.Target))
			{
				binaryWriter.Write((byte)serializableState.Item1);
				switch (serializableState.Item1)
				{
				case TargetType.Actor:
					binaryWriter.Write(UIntFromActor(serializableState.Item2));
					binaryWriter.Write(serializableState.Item3);
					break;
				case TargetType.FrozenActor:
					binaryWriter.Write(Target.FrozenActor.Viewer.PlayerActor.ActorID);
					binaryWriter.Write(Target.FrozenActor.ID);
					break;
				case TargetType.Terrain:
				{
					if (orderFields.HasField(OrderFields.TargetIsCell))
					{
						binaryWriter.Write(serializableState.Item4.Value.Bits);
						binaryWriter.Write((byte)serializableState.Item5.Value);
						break;
					}
					binaryWriter.Write(serializableState.Item6.X);
					binaryWriter.Write(serializableState.Item6.Y);
					binaryWriter.Write(serializableState.Item6.Z);
					int num2 = serializableState.Item7.Length;
					if (num2 == 1 && serializableState.Item7[0] == serializableState.Item6)
					{
						binaryWriter.Write((short)(-1));
						break;
					}
					binaryWriter.Write((short)num2);
					WPos[] item = serializableState.Item7;
					for (int i = 0; i < item.Length; i++)
					{
						WPos wPos = item[i];
						binaryWriter.Write(wPos.X);
						binaryWriter.Write(wPos.Y);
						binaryWriter.Write(wPos.Z);
					}
					break;
				}
				}
			}
			if (orderFields.HasField(OrderFields.TargetString))
			{
				binaryWriter.Write(TargetString);
			}
			if (orderFields.HasField(OrderFields.ExtraActors))
			{
				binaryWriter.Write(ExtraActors.Length);
				Actor[] extraActors = ExtraActors;
				foreach (Actor a in extraActors)
				{
					binaryWriter.Write(UIntFromActor(a));
				}
			}
			if (orderFields.HasField(OrderFields.ExtraLocation))
			{
				binaryWriter.Write(ExtraLocation.Bits);
			}
			if (orderFields.HasField(OrderFields.ExtraData))
			{
				binaryWriter.Write(ExtraData);
			}
			if (orderFields.HasField(OrderFields.Grouped))
			{
				binaryWriter.Write(GroupedActors.Length);
				Actor[] groupedActors = GroupedActors;
				foreach (Actor a2 in groupedActors)
				{
					binaryWriter.Write(UIntFromActor(a2));
				}
			}
			break;
		}
		default:
			throw new InvalidDataException($"Cannot serialize order type {Type}");
		}
		return memoryStream.ToArray();
	}

	public override string ToString()
	{
		return $"OrderString: \"{OrderString}\" \n\t Type: \"{Type}\".  \n\t Subject: \"{Subject}\". \n\t Target: \"{Target}\".\n\t TargetString: \"{TargetString}\".\n\t IsImmediate: {IsImmediate}.\n\t Player(PlayerName): {Player?.ResolvedPlayerName}\n";
	}
}
