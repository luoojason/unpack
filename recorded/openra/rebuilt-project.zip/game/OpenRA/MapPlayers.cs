using System.Collections.Generic;
using System.Linq;
using OpenRA.Traits;

namespace OpenRA;

public class MapPlayers
{
	public const int MaximumPlayerCount = 63;

	public readonly Dictionary<string, PlayerReference> Players;

	public MapPlayers()
		: this(new List<MiniYamlNode>())
	{
	}

	public MapPlayers(IEnumerable<MiniYamlNode> playerDefinitions)
	{
		Players = playerDefinitions.Select((MiniYamlNode pr) => new PlayerReference(new MiniYaml(pr.Key, pr.Value.Nodes))).ToDictionary((PlayerReference player) => player.Name);
	}

	public MapPlayers(Ruleset rules, int playerCount)
	{
		string internalName = rules.Actors[SystemActors.World].TraitInfos<FactionInfo>().First((FactionInfo f) => f.Selectable).InternalName;
		Players = new Dictionary<string, PlayerReference>
		{
			{
				"Neutral",
				new PlayerReference
				{
					Name = "Neutral",
					Faction = internalName,
					OwnsWorld = true,
					NonCombatant = true
				}
			},
			{
				"Creeps",
				new PlayerReference
				{
					Name = "Creeps",
					Faction = internalName,
					NonCombatant = true,
					Enemies = Exts.MakeArray(playerCount, (int i) => $"Multi{i}")
				}
			}
		};
		for (int num = 0; num < playerCount; num++)
		{
			PlayerReference playerReference = new PlayerReference
			{
				Name = $"Multi{num}",
				Faction = "Random",
				Playable = true,
				Enemies = new string[1] { "Creeps" }
			};
			Players.Add(playerReference.Name, playerReference);
		}
	}

	public List<MiniYamlNode> ToMiniYaml()
	{
		return Players.Select((KeyValuePair<string, PlayerReference> p) => new MiniYamlNode("PlayerReference@" + p.Key, FieldSaver.SaveDifferences(p.Value, new PlayerReference()))).ToList();
	}
}
