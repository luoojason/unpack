using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace OpenRA;

public static class MiniYamlExts
{
	public static void WriteToFile(this IEnumerable<MiniYamlNode> y, string filename)
	{
		File.WriteAllLines(filename, (from x in y.ToLines()
			select x.TrimEnd()).ToArray());
	}

	public static string WriteToString(this IEnumerable<MiniYamlNode> y)
	{
		return y.ToLines().JoinWith("\n").TrimEnd('\n') + "\n";
	}

	public static IEnumerable<string> ToLines(this IEnumerable<MiniYamlNode> y)
	{
		foreach (MiniYamlNode item in y)
		{
			foreach (string item2 in item.Value.ToLines(item.Key, item.Comment))
			{
				yield return item2;
			}
		}
	}

	public static void WriteToFile(this IEnumerable<MiniYamlNodeBuilder> y, string filename)
	{
		File.WriteAllLines(filename, (from x in y.ToLines()
			select x.TrimEnd()).ToArray());
	}

	public static string WriteToString(this IEnumerable<MiniYamlNodeBuilder> y)
	{
		return y.ToLines().JoinWith("\n").TrimEnd('\n') + "\n";
	}

	public static IEnumerable<string> ToLines(this IEnumerable<MiniYamlNodeBuilder> y)
	{
		foreach (MiniYamlNodeBuilder item in y)
		{
			foreach (string item2 in item.Value.ToLines(item.Key, item.Comment))
			{
				yield return item2;
			}
		}
	}
}
