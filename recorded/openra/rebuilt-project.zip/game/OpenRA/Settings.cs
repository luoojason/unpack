using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace OpenRA;

public class Settings
{
	private readonly string settingsFile;

	public readonly PlayerSettings Player = new PlayerSettings();

	public readonly GameSettings Game = new GameSettings();

	public readonly SoundSettings Sound = new SoundSettings();

	public readonly GraphicSettings Graphics = new GraphicSettings();

	public readonly ServerSettings Server = new ServerSettings();

	public readonly DebugSettings Debug = new DebugSettings();

	internal Dictionary<string, Hotkey> Keys = new Dictionary<string, Hotkey>();

	public readonly Dictionary<string, object> Sections;

	private readonly List<MiniYamlNode> yamlCache = new List<MiniYamlNode>();

	public Settings(string file, Arguments args)
	{
		settingsFile = file;
		Sections = new Dictionary<string, object>
		{
			{ "Player", Player },
			{ "Game", Game },
			{ "Sound", Sound },
			{ "Graphics", Graphics },
			{ "Server", Server },
			{ "Debug", Debug }
		};
		Action<string, Type> unknownFieldAction = FieldLoader.UnknownFieldAction;
		Func<string, Type, string, object> invalidValueAction = FieldLoader.InvalidValueAction;
		try
		{
			FieldLoader.UnknownFieldAction = (string s, Type f) =>
			{
				Console.WriteLine($"Ignoring unknown field `{s}` on `{f.Name}`");
			};
			if (File.Exists(settingsFile))
			{
				yamlCache = MiniYaml.FromFile(settingsFile, discardCommentsAndWhitespace: false);
				foreach (MiniYamlNode item in yamlCache)
				{
					if (item.Key != null && Sections.TryGetValue(item.Key, out var value))
					{
						LoadSectionYaml(item.Value, value);
					}
				}
				MiniYamlNode miniYamlNode = yamlCache.FirstOrDefault((MiniYamlNode n) => n.Key == "Keys");
				if (miniYamlNode != null)
				{
					foreach (MiniYamlNode node in miniYamlNode.Value.Nodes)
					{
						if (node.Key != null)
						{
							Keys[node.Key] = FieldLoader.GetValue<Hotkey>(node.Key, node.Value.Value);
						}
					}
				}
			}
			foreach (KeyValuePair<string, object> section in Sections)
			{
				FieldInfo[] fields = section.Value.GetType().GetFields();
				foreach (FieldInfo fieldInfo in fields)
				{
					if (args.Contains(section.Key + "." + fieldInfo.Name))
					{
						FieldLoader.LoadField(section.Value, fieldInfo.Name, args.GetValue(section.Key + "." + fieldInfo.Name, ""));
					}
				}
			}
		}
		finally
		{
			FieldLoader.UnknownFieldAction = unknownFieldAction;
			FieldLoader.InvalidValueAction = invalidValueAction;
		}
	}

	public void Save()
	{
		List<MiniYamlNodeBuilder> list = yamlCache.ConvertAll((MiniYamlNode n) => new MiniYamlNodeBuilder(n));
		foreach (KeyValuePair<string, object> kv in Sections)
		{
			MiniYamlNodeBuilder miniYamlNodeBuilder = list.FirstOrDefault((MiniYamlNodeBuilder x) => x.Key == kv.Key);
			if (miniYamlNodeBuilder == null)
			{
				miniYamlNodeBuilder = new MiniYamlNodeBuilder(kv.Key, new MiniYamlBuilder(""));
				list.Add(miniYamlNodeBuilder);
			}
			object o = Activator.CreateInstance(kv.Value.GetType());
			IEnumerable<FieldLoader.FieldLoadInfo> typeLoadInfo = FieldLoader.GetTypeLoadInfo(kv.Value.GetType());
			foreach (FieldLoader.FieldLoadInfo fli in typeLoadInfo)
			{
				string text = FieldSaver.FormatValue(kv.Value, fli.Field);
				string text2 = FieldSaver.FormatValue(o, fli.Field);
				if (text == text2)
				{
					miniYamlNodeBuilder.Value.Nodes.RemoveAll((MiniYamlNodeBuilder n) => n.Key == fli.YamlName);
					continue;
				}
				MiniYamlNodeBuilder miniYamlNodeBuilder2 = miniYamlNodeBuilder.Value.NodeWithKeyOrDefault(fli.YamlName);
				if (miniYamlNodeBuilder2 != null)
				{
					miniYamlNodeBuilder2.Value.Value = text;
				}
				else
				{
					miniYamlNodeBuilder.Value.Nodes.Add(new MiniYamlNodeBuilder(fli.YamlName, new MiniYamlBuilder(text)));
				}
			}
		}
		MiniYamlNodeBuilder miniYamlNodeBuilder3 = list.FirstOrDefault((MiniYamlNodeBuilder x) => x.Key == "Keys");
		if (miniYamlNodeBuilder3 == null)
		{
			miniYamlNodeBuilder3 = new MiniYamlNodeBuilder("Keys", new MiniYamlBuilder(""));
			list.Add(miniYamlNodeBuilder3);
		}
		miniYamlNodeBuilder3.Value.Nodes.Clear();
		foreach (KeyValuePair<string, Hotkey> key in Keys)
		{
			miniYamlNodeBuilder3.Value.Nodes.Add(new MiniYamlNodeBuilder(key.Key, FieldSaver.FormatValue(key.Value)));
		}
		list.WriteToFile(settingsFile);
		yamlCache.Clear();
		yamlCache.AddRange(list.Select((MiniYamlNodeBuilder n) => n.Build()));
	}

	private static string SanitizedName(string dirty)
	{
		if (string.IsNullOrEmpty(dirty))
		{
			return null;
		}
		string text = dirty;
		char[] array = new char[13]
		{
			'#', '@', ':', '\n', '\t', '[', ']', '{', '}', '<',
			'>', '"', '`'
		};
		char[] array2 = array;
		foreach (char c in array2)
		{
			text = text.Replace(c.ToString(), string.Empty);
		}
		return text;
	}

	public string SanitizedServerName(string dirty)
	{
		string text = SanitizedName(dirty);
		if (string.IsNullOrWhiteSpace(text))
		{
			return SanitizedPlayerName(Player.Name) + "'s Game";
		}
		return text;
	}

	public static string SanitizedPlayerName(string dirty)
	{
		string[] source = new string[2] { "Open", "Closed" };
		string text = SanitizedName(dirty);
		if (string.IsNullOrWhiteSpace(text) || Enumerable.Contains(source, text))
		{
			text = new PlayerSettings().Name;
		}
		if (text.Length > 16)
		{
			text = text.Substring(0, 16);
		}
		return text;
	}

	private static void LoadSectionYaml(MiniYaml yaml, object section)
	{
		object defaults = Activator.CreateInstance(section.GetType());
		FieldLoader.InvalidValueAction = (string s, Type t, string f) =>
		{
			object value = defaults.GetType().GetField(f).GetValue(defaults);
			Console.WriteLine($"FieldLoader: Cannot parse `{s}` into `{f}:{t.Name}`; substituting default `{value}`");
			return value;
		};
		FieldLoader.Load(section, yaml);
	}
}
