using System;

namespace OpenRA;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class SyncAttribute : Attribute
{
}
