using Linguini.Shared.Types.Bundle;

namespace OpenRA;

public static class FluentExts
{
	public static IFluentType ToFluentType(this object value)
	{
		if (!(value is byte b))
		{
			if (!(value is sbyte b2))
			{
				if (!(value is short num))
				{
					if (!(value is uint num2))
					{
						if (!(value is int num3))
						{
							if (!(value is long num4))
							{
								if (!(value is ulong num5))
								{
									if (!(value is float num6))
									{
										if (value is double num7)
										{
											return (FluentNumber)num7;
										}
										return (FluentString)value.ToString();
									}
									return (FluentNumber)num6;
								}
								return (FluentNumber)num5;
							}
							return (FluentNumber)num4;
						}
						return (FluentNumber)num3;
					}
					return (FluentNumber)num2;
				}
				return (FluentNumber)num;
			}
			return (FluentNumber)b2;
		}
		return (FluentNumber)(int)b;
	}
}
