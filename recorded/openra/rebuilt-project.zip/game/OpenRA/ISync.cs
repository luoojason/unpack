namespace OpenRA;

public interface ISync
{
}
