using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA;

public class ProjectedCellRegion : IEnumerable<PPos>, IEnumerable
{
	public struct ProjectedCellRegionEnumerator : IEnumerator<PPos>, IEnumerator, IDisposable
	{
		private readonly ProjectedCellRegion r;

		private int u;

		private int v;

		public PPos Current { get; private set; }

		readonly object IEnumerator.Current => Current;

		public ProjectedCellRegionEnumerator(ProjectedCellRegion region)
		{
			this = default;
			r = region;
			Reset();
			Current = new PPos(u, v);
		}

		public bool MoveNext()
		{
			u++;
			if (u > r.BottomRight.U)
			{
				v++;
				u = r.TopLeft.U;
				if (v > r.BottomRight.V)
				{
					return false;
				}
			}
			Current = new PPos(u, v);
			return true;
		}

		public void Reset()
		{
			u = r.TopLeft.U - 1;
			v = r.TopLeft.V;
		}

		public readonly void Dispose()
		{
		}
	}

	public readonly PPos TopLeft;

	public readonly PPos BottomRight;

	private readonly MPos mapTopLeft;

	private readonly MPos mapBottomRight;

	public MapCoordsRegion CandidateMapCoords => new MapCoordsRegion(mapTopLeft, mapBottomRight);

	public ProjectedCellRegion(Map map, PPos topLeft, PPos bottomRight)
	{
		TopLeft = topLeft;
		BottomRight = bottomRight;
		mapTopLeft = (MPos)topLeft;
		byte maximumTerrainHeight = map.Grid.MaximumTerrainHeight;
		int num = ((map.Grid.Type == MapGridType.RectangularIsometric) ? maximumTerrainHeight : (maximumTerrainHeight / 2));
		mapBottomRight = map.Height.Clamp(new MPos(bottomRight.U, bottomRight.V + num));
	}

	public bool Contains(PPos puv)
	{
		if (puv.U >= TopLeft.U && puv.U <= BottomRight.U && puv.V >= TopLeft.V)
		{
			return puv.V <= BottomRight.V;
		}
		return false;
	}

	public ProjectedCellRegionEnumerator GetEnumerator()
	{
		return new ProjectedCellRegionEnumerator(this);
	}

	IEnumerator<PPos> IEnumerable<PPos>.GetEnumerator()
	{
		return GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
