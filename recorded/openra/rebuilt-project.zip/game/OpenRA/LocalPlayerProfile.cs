using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using OpenRA.Support;

namespace OpenRA;

public sealed class LocalPlayerProfile
{
	public enum LinkState
	{
		Uninitialized,
		GeneratingKeys,
		Unlinked,
		CheckingLink,
		ConnectionFailed,
		Linked
	}

	private const int AuthKeySize = 2048;

	private volatile LinkState innerState;

	private volatile PlayerProfile innerData;

	private volatile string innerFingerprint;

	private volatile string innerPublicKey;

	private RSAParameters parameters;

	private readonly string filePath;

	private readonly PlayerDatabase playerDatabase;

	public LinkState State => innerState;

	public string Fingerprint => innerFingerprint;

	public string PublicKey => innerPublicKey;

	public PlayerProfile ProfileData => innerData;

	public LocalPlayerProfile(string filePath, PlayerDatabase playerDatabase)
	{
		this.filePath = filePath;
		this.playerDatabase = playerDatabase;
		innerState = LinkState.Uninitialized;
		try
		{
			if (!File.Exists(filePath))
			{
				return;
			}
			using RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider();
			using (FileStream s = File.OpenRead(filePath))
			{
				byte[] bytes = Convert.FromBase64String(s.ReadAllText());
				rSACryptoServiceProvider.FromXmlString(new string(Encoding.ASCII.GetChars(bytes)));
			}
			parameters = rSACryptoServiceProvider.ExportParameters(includePrivateParameters: true);
			innerPublicKey = CryptoUtil.EncodePEMPublicKey(parameters);
			innerFingerprint = CryptoUtil.PublicKeyFingerprint(parameters);
			innerState = LinkState.Unlinked;
		}
		catch (Exception ex)
		{
			Console.WriteLine("Failed to load keys:");
			Console.WriteLine(ex);
			Log.Write("debug", "Failed to load player keypair from `" + filePath + "` with exception:");
			Log.Write("debug", ex);
		}
	}

	public void RefreshPlayerData(Action onComplete = null)
	{
		if (State != LinkState.Unlinked && State != LinkState.Linked && State != LinkState.ConnectionFailed)
		{
			return;
		}
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				HttpClient httpClient = HttpClientFactory.Create();
				string url = playerDatabase.Profile + Fingerprint;
				MiniYamlNode miniYamlNode = MiniYaml.FromStream(await (await httpClient.GetAsync(url)).Content.ReadAsStreamAsync(), url).First();
				if (miniYamlNode.Key == "Player")
				{
					innerData = FieldLoader.Load<PlayerProfile>(miniYamlNode.Value);
					if (innerData.KeyRevoked)
					{
						Log.Write("debug", "Revoking key with fingerprint " + Fingerprint);
						DeleteKeypair();
					}
					else
					{
						innerState = LinkState.Linked;
					}
				}
				else
				{
					innerState = LinkState.Unlinked;
				}
			}
			catch (Exception e)
			{
				Log.Write("debug", "Failed to parse player data result with exception:");
				Log.Write("debug", e);
				innerState = LinkState.ConnectionFailed;
			}
			finally
			{
				onComplete?.Invoke();
			}
		});
		innerState = LinkState.CheckingLink;
	}

	public void GenerateKeypair()
	{
		if (State != LinkState.Uninitialized)
		{
			return;
		}
		innerState = LinkState.GeneratingKeys;
		new Task(() =>
		{
			try
			{
				RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider(2048);
				parameters = rSACryptoServiceProvider.ExportParameters(includePrivateParameters: true);
				innerPublicKey = CryptoUtil.EncodePEMPublicKey(parameters);
				innerFingerprint = CryptoUtil.PublicKeyFingerprint(parameters);
				string contents = Convert.ToBase64String(Encoding.ASCII.GetBytes(rSACryptoServiceProvider.ToXmlString(includePrivateParameters: true)));
				File.WriteAllText(filePath, contents);
				innerState = LinkState.Unlinked;
			}
			catch (Exception ex)
			{
				Log.Write("debug", "Failed to generate keypair with exception:");
				Log.Write("debug", ex);
				Console.WriteLine("Key generation failed:");
				Console.WriteLine(ex);
				innerState = LinkState.Uninitialized;
			}
		}).Start();
	}

	public void DeleteKeypair()
	{
		try
		{
			File.Delete(filePath);
		}
		catch (Exception ex)
		{
			Log.Write("debug", "Failed to delete keypair with exception:");
			Log.Write("debug", ex);
			Console.WriteLine("Key deletion failed:");
			Console.WriteLine(ex);
		}
		innerState = LinkState.Uninitialized;
		parameters = default;
		innerFingerprint = null;
		innerData = null;
	}

	public string Sign(params string[] data)
	{
		if (State <= LinkState.Unlinked)
		{
			return null;
		}
		return CryptoUtil.Sign(parameters, data.Where((string x) => !string.IsNullOrEmpty(x)).JoinWith(string.Empty));
	}

	public string DecryptString(string data)
	{
		if (State <= LinkState.Unlinked)
		{
			return null;
		}
		return CryptoUtil.DecryptString(parameters, data);
	}
}
