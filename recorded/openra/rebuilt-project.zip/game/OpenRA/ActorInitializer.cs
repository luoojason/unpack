using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA;

public class ActorInitializer : IActorInitializer
{
	public readonly Actor Self;

	internal TypeDictionary Dict;

	public World World => Self.World;

	public ActorInitializer(Actor actor, TypeDictionary dict)
	{
		Self = actor;
		Dict = dict;
	}

	public T GetOrDefault<T>(TraitInfo info) where T : ActorInit
	{
		IReadOnlyCollection<T> source = Dict.WithInterface<T>();
		if (!string.IsNullOrEmpty(info?.InstanceName))
		{
			return source.LastOrDefault((T i) => i.InstanceName == info.InstanceName) ?? source.LastOrDefault((T i) => string.IsNullOrEmpty(i.InstanceName));
		}
		return source.LastOrDefault((T i) => string.IsNullOrEmpty(i.InstanceName));
	}

	public T Get<T>(TraitInfo info) where T : ActorInit
	{
		T orDefault = GetOrDefault<T>(info);
		if (orDefault == null)
		{
			throw new InvalidOperationException($"TypeDictionary does not contain instance of type `{typeof(T)}`");
		}
		return orDefault;
	}

	public U GetValue<T, U>(TraitInfo info) where T : ValueActorInit<U>
	{
		return Get<T>(info).Value;
	}

	public U GetValue<T, U>(TraitInfo info, U fallback) where T : ValueActorInit<U>
	{
		T orDefault = GetOrDefault<T>(info);
		if (orDefault == null)
		{
			return fallback;
		}
		return orDefault.Value;
	}

	public bool Contains<T>(TraitInfo info) where T : ActorInit
	{
		return GetOrDefault<T>(info) != null;
	}

	public T GetOrDefault<T>() where T : ActorInit, ISingleInstanceInit
	{
		return Dict.GetOrDefault<T>();
	}

	public T Get<T>() where T : ActorInit, ISingleInstanceInit
	{
		return Dict.Get<T>();
	}

	public U GetValue<T, U>() where T : ValueActorInit<U>, ISingleInstanceInit
	{
		return Get<T>().Value;
	}

	public U GetValue<T, U>(U fallback) where T : ValueActorInit<U>, ISingleInstanceInit
	{
		T orDefault = GetOrDefault<T>();
		if (orDefault == null)
		{
			return fallback;
		}
		return orDefault.Value;
	}

	public bool Contains<T>() where T : ActorInit, ISingleInstanceInit
	{
		return GetOrDefault<T>() != null;
	}
}
