namespace OpenRA;

public enum MouseScrollType
{
	Disabled,
	Standard,
	Inverted,
	Joystick
}
