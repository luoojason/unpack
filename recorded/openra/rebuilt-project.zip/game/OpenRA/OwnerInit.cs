using System.Linq;
using System.Reflection;

namespace OpenRA;

public class OwnerInit : ActorInit, ISingleInstanceInit
{
	public readonly string InternalName;

	private readonly Player value;

	public OwnerInit(Player value)
	{
		this.value = value;
		InternalName = value.InternalName;
	}

	public OwnerInit(string value)
	{
		InternalName = value;
	}

	public Player Value(World world)
	{
		return value ?? world.Players.First((Player x) => x.InternalName == InternalName);
	}

	public void Initialize(MiniYaml yaml)
	{
		typeof(OwnerInit).GetField("InternalName", BindingFlags.Instance | BindingFlags.Public)?.SetValue(this, yaml.Value);
	}

	public void Initialize(Player player)
	{
		typeof(OwnerInit).GetField("value", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(this, player);
	}

	public override MiniYaml Save()
	{
		return new MiniYaml(InternalName);
	}
}
