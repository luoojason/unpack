using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Linguini.Bundle;
using Linguini.Bundle.Builder;
using Linguini.Bundle.Errors;
using Linguini.Shared.Types.Bundle;
using Linguini.Syntax.Ast;
using Linguini.Syntax.Parser;
using Linguini.Syntax.Parser.Error;
using OpenRA.FileSystem;

namespace OpenRA;

public class FluentBundle
{
	private readonly Linguini.Bundle.FluentBundle bundle;

	public FluentBundle(string culture, string[] paths, IReadOnlyFileSystem fileSystem)
		: this(culture, paths, fileSystem, (ParseError error) =>
		{
			Log.Write("debug", error.Message);
		})
	{
	}

	public FluentBundle(string culture, string[] paths, IReadOnlyFileSystem fileSystem, string text)
		: this(culture, paths, fileSystem, text, (ParseError error) =>
		{
			Log.Write("debug", error.Message);
		})
	{
	}

	public FluentBundle(string culture, string[] paths, IReadOnlyFileSystem fileSystem, Action<ParseError> onError)
		: this(culture, paths, fileSystem, null, onError)
	{
	}

	public FluentBundle(string culture, string text, Action<ParseError> onError)
		: this(culture, null, null, text, onError)
	{
	}

	public FluentBundle(string culture, string[] paths, IReadOnlyFileSystem fileSystem, string text, Action<ParseError> onError)
	{
		bundle = LinguiniBuilder.Builder().CultureInfo(new CultureInfo(culture)).SkipResources()
			.SetUseIsolating(isIsolating: false)
			.UseConcurrent()
			.UncheckedBuild();
		if (paths != null)
		{
			foreach (string filename in paths)
			{
				Stream stream = fileSystem.Open(filename);
				using StreamReader input = new StreamReader(stream);
				LinguiniParser linguiniParser = new LinguiniParser(input);
				Resource resource = linguiniParser.Parse();
				foreach (ParseError error in resource.Errors)
				{
					onError(error);
				}
				bundle.AddResourceOverriding(resource);
			}
		}
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		LinguiniParser linguiniParser2 = new LinguiniParser(text);
		Resource resource2 = linguiniParser2.Parse();
		foreach (ParseError error2 in resource2.Errors)
		{
			onError(error2);
		}
		bundle.AddResourceOverriding(resource2);
	}

	public string GetMessage(string key, object[] args = null)
	{
		if (!TryGetMessage(key, out var value, args))
		{
			return key;
		}
		return value;
	}

	public bool TryGetMessage(string key, out string value, object[] args = null)
	{
		if (key == null)
		{
			throw new ArgumentNullException("key");
		}
		try
		{
			if (!HasMessage(key))
			{
				value = null;
				return false;
			}
			Dictionary<string, IFluentType> dictionary = null;
			if (args != null)
			{
				if (args.Length % 2 != 0)
				{
					throw new ArgumentException("Expected a comma separated list of name, value arguments but the number of arguments is not a multiple of two", "args");
				}
				dictionary = new Dictionary<string, IFluentType>();
				for (int i = 0; i < args.Length; i += 2)
				{
					string text = args[i] as string;
					if (string.IsNullOrEmpty(text))
					{
						throw new ArgumentException($"Expected the argument at index {i} to be a non-empty string", "args");
					}
					object obj = args[i + 1];
					if (obj == null)
					{
						throw new ArgumentNullException("args", $"Expected the argument at index {i + 1} to be a non-null value");
					}
					dictionary.Add(text, obj.ToFluentType());
				}
			}
			bool result = bundle.TryGetAttrMessage(key, dictionary, out IList<FluentError> errors, out value);
			foreach (FluentError item in errors)
			{
				Log.Write("debug", $"FluentBundle of {key}: {item}");
			}
			return result;
		}
		catch (Exception)
		{
			Log.Write("debug", "FluentBundle of " + key + ": threw exception");
			value = null;
			return false;
		}
	}

	public bool HasMessage(string key)
	{
		return bundle.HasAttrMessage(key);
	}
}
