using System;
using OpenRA.Primitives;

namespace OpenRA;

public interface ITexture : IDisposable
{
	Size Size { get; }

	TextureScaleFilter ScaleFilter { get; set; }

	void SetData(byte[] colors, int width, int height);

	void SetFloatData(float[] data, int width, int height);

	void SetDataFromReadBuffer(Rectangle rect);

	byte[] GetData();
}
