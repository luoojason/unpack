using System.IO;

namespace OpenRA;

internal readonly struct BinaryDataHeader
{
	public readonly byte Format;

	public readonly uint TilesOffset;

	public readonly uint HeightsOffset;

	public readonly uint ResourcesOffset;

	public BinaryDataHeader(Stream s, int2 expectedSize)
	{
		Format = s.ReadUInt8();
		ushort num = s.ReadUInt16();
		ushort num2 = s.ReadUInt16();
		if (num != expectedSize.X || num2 != expectedSize.Y)
		{
			throw new InvalidDataException("Invalid tile data");
		}
		if (Format == 1)
		{
			TilesOffset = 5u;
			HeightsOffset = 0u;
			ResourcesOffset = (uint)(3 * num * num2 + 5);
			return;
		}
		if (Format == 2)
		{
			TilesOffset = s.ReadUInt32();
			HeightsOffset = s.ReadUInt32();
			ResourcesOffset = s.ReadUInt32();
			return;
		}
		throw new InvalidDataException($"Unknown binary map format '{Format}'");
	}
}
