using System;
using OpenRA.Primitives;

namespace OpenRA;

public sealed class CellLayer<T> : CellLayerBase<T>
{
	public T this[CPos cell]
	{
		get
		{
			return Entries[Index(cell)];
		}
		set
		{
			Entries[Index(cell)] = value;
			CellEntryChanged?.Invoke(cell);
		}
	}

	public T this[MPos uv]
	{
		get
		{
			return Entries[Index(uv)];
		}
		set
		{
			Entries[Index(uv)] = value;
			CellEntryChanged?.Invoke(uv.ToCPos(GridType));
		}
	}

	public event Action<CPos> CellEntryChanged;

	public CellLayer(Map map)
		: base(map)
	{
	}

	public CellLayer(MapGridType gridType, Size size)
		: base(gridType, size)
	{
	}

	public override void CopyValuesFrom(CellLayerBase<T> anotherLayer)
	{
		if (CellEntryChanged != null)
		{
			throw new InvalidOperationException("Cannot copy values when there are listeners attached to the CellEntryChanged event.");
		}
		base.CopyValuesFrom(anotherLayer);
	}

	public override void Clear()
	{
		if (CellEntryChanged != null)
		{
			throw new InvalidOperationException("Cannot clear values when there are listeners attached to the CellEntryChanged event.");
		}
		base.Clear();
	}

	public override void Clear(T clearValue)
	{
		if (CellEntryChanged != null)
		{
			throw new InvalidOperationException("Cannot clear values when there are listeners attached to the CellEntryChanged event.");
		}
		base.Clear(clearValue);
	}

	private int Index(CPos cell)
	{
		int x = cell.X;
		int y = cell.Y;
		if (GridType == MapGridType.Rectangular)
		{
			return y * Size.Width + x;
		}
		int num = (x - y) / 2;
		int num2 = x + y;
		return num2 * Size.Width + num;
	}

	private int Index(MPos uv)
	{
		return uv.V * Size.Width + uv.U;
	}

	public bool TryGetValue(CPos cell, out T value)
	{
		if (GridType == MapGridType.RectangularIsometric && cell.X < cell.Y)
		{
			value = default;
			return false;
		}
		MPos uv = cell.ToMPos(GridType);
		if (Bounds.Contains(uv.U, uv.V))
		{
			value = Entries[Index(uv)];
			return true;
		}
		value = default;
		return false;
	}

	public bool Contains(CPos cell)
	{
		if (GridType == MapGridType.RectangularIsometric && cell.X < cell.Y)
		{
			return false;
		}
		return Contains(cell.ToMPos(GridType));
	}

	public bool Contains(MPos uv)
	{
		return Bounds.Contains(uv.U, uv.V);
	}

	public CPos Clamp(CPos uv)
	{
		return Clamp(uv.ToMPos(GridType)).ToCPos(GridType);
	}

	public MPos Clamp(MPos uv)
	{
		return uv.Clamp(new Rectangle(0, 0, Size.Width - 1, Size.Height - 1));
	}
}
public static class CellLayer
{
	public static CellLayer<T> Resize<T>(CellLayer<T> layer, Size newSize, T defaultValue)
	{
		CellLayer<T> cellLayer = new CellLayer<T>(layer.GridType, newSize);
		int num = Math.Min(layer.Size.Width, newSize.Width);
		int num2 = Math.Min(layer.Size.Height, newSize.Height);
		cellLayer.Clear(defaultValue);
		for (int i = 0; i < num2; i++)
		{
			for (int j = 0; j < num; j++)
			{
				cellLayer[new MPos(j, i)] = layer[new MPos(j, i)];
			}
		}
		return cellLayer;
	}
}
