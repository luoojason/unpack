using System;

namespace OpenRA;

public interface IHardwareCursor : IDisposable
{
}
