using System.Collections.Generic;
using System.Linq;

namespace OpenRA;

public sealed class MiniYamlNode
{
	public readonly struct SourceLocation(string name, int line)
	{
		public readonly string Name = name;

		public readonly int Line = line;

		public override string ToString()
		{
			return $"{Name}:{Line}";
		}
	}

	public readonly SourceLocation Location;

	public readonly string Key;

	public readonly MiniYaml Value;

	public readonly string Comment;

	public MiniYamlNode WithValue(MiniYaml value)
	{
		if (Value == value)
		{
			return this;
		}
		return new MiniYamlNode(Key, value, Comment, Location);
	}

	public MiniYamlNode(string k, MiniYaml v, string c = null)
	{
		Key = k;
		Value = v;
		Comment = c;
	}

	public MiniYamlNode(string k, MiniYaml v, string c, SourceLocation loc)
		: this(k, v, c)
	{
		Location = loc;
	}

	public MiniYamlNode(string k, string v, string c = null)
		: this(k, new MiniYaml(v, Enumerable.Empty<MiniYamlNode>()), c)
	{
	}

	public MiniYamlNode(string k, string v, IEnumerable<MiniYamlNode> n)
		: this(k, new MiniYaml(v, n))
	{
	}

	public override string ToString()
	{
		return $"{{YamlNode: {Key} @ {Location}}}";
	}
}
