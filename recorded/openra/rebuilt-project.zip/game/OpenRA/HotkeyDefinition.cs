using System.Collections.Generic;
using System.Linq;

namespace OpenRA;

public sealed class HotkeyDefinition
{
	public const string ContextFluentPrefix = "hotkey-context";

	public readonly string Name;

	public readonly Hotkey Default = Hotkey.Invalid;

	[FluentReference]
	public readonly string Description = "";

	public readonly HashSet<string> Types = new HashSet<string>();

	[FluentReference]
	public readonly HashSet<string> Contexts = new HashSet<string>();

	public readonly bool Readonly;

	public bool HasDuplicates { get; internal set; }

	public HotkeyDefinition(string name, MiniYaml node)
	{
		Name = name;
		if (!string.IsNullOrEmpty(node.Value))
		{
			Default = FieldLoader.GetValue<Hotkey>("value", node.Value);
		}
		Dictionary<string, MiniYaml> dictionary = node.ToDictionary();
		if (dictionary.TryGetValue("Description", out var value))
		{
			Description = value.Value;
		}
		if (dictionary.TryGetValue("Types", out var value2))
		{
			Types = FieldLoader.GetValue<HashSet<string>>("Types", value2.Value);
		}
		if (dictionary.TryGetValue("Contexts", out var value3))
		{
			Contexts = (from c in FieldLoader.GetValue<HashSet<string>>("Contexts", value3.Value)
				select "hotkey-context." + c).ToHashSet();
		}
		if (dictionary.TryGetValue("Platform", out var value4))
		{
			MiniYamlNode miniYamlNode = value4.NodeWithKeyOrDefault(Platform.CurrentPlatform.ToString());
			if (miniYamlNode != null)
			{
				Default = FieldLoader.GetValue<Hotkey>("value", miniYamlNode.Value.Value);
			}
		}
		if (dictionary.TryGetValue("Readonly", out var value5))
		{
			Readonly = FieldLoader.GetValue<bool>("Readonly", value5.Value);
		}
	}
}
