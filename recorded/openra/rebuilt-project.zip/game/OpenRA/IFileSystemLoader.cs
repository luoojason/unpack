using OpenRA.FileSystem;

namespace OpenRA;

public interface IFileSystemLoader
{
	void Mount(OpenRA.FileSystem.FileSystem fileSystem, ObjectCreator objectCreator);
}
