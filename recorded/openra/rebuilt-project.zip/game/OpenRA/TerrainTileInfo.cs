using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public class TerrainTileInfo
{
	[FieldLoader.Ignore]
	public readonly byte TerrainType = byte.MaxValue;

	public readonly byte Height;

	public readonly byte RampType;

	public readonly Color MinColor;

	public readonly Color MaxColor;

	public Color GetColor(MersenneTwister random)
	{
		if (MinColor != MaxColor)
		{
			return Exts.ColorLerp(random.NextFloat(), MinColor, MaxColor);
		}
		return MinColor;
	}
}
