namespace OpenRA;

public enum RampSplit
{
	Flat,
	X,
	Y
}
