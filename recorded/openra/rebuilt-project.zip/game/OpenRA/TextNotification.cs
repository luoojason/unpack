using System;
using OpenRA.Primitives;

namespace OpenRA;

public class TextNotification : IEquatable<TextNotification>
{
	public readonly TextNotificationPool Pool;

	public readonly string Prefix;

	public readonly int ClientId;

	public readonly string Text;

	public readonly Color? PrefixColor;

	public readonly Color? TextColor;

	public readonly DateTime Time;

	public TextNotification(TextNotificationPool pool, int clientId, string prefix, string text, Color? prefixColor, Color? textColor)
	{
		Pool = pool;
		ClientId = clientId;
		Prefix = prefix;
		Text = text;
		PrefixColor = prefixColor;
		TextColor = textColor;
		Time = DateTime.Now;
	}

	public bool CanIncrementOnDuplicate()
	{
		if (Pool != TextNotificationPool.Feedback && Pool != TextNotificationPool.System)
		{
			return Pool == TextNotificationPool.Transients;
		}
		return true;
	}

	public static bool operator ==(TextNotification me, TextNotification other)
	{
		return me.GetHashCode() == other.GetHashCode();
	}

	public static bool operator !=(TextNotification me, TextNotification other)
	{
		return !(me == other);
	}

	public bool Equals(TextNotification other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is TextNotification other)
		{
			return Equals(other);
		}
		return false;
	}

	public override int GetHashCode()
	{
		return HashCode.Combine(Prefix, Text, (int)Pool);
	}
}
