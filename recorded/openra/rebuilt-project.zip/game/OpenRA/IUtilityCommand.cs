using OpenRA.Traits;

namespace OpenRA;

[RequireExplicitImplementation]
public interface IUtilityCommand
{
	string Name { get; }

	bool ValidateArguments(string[] args);

	void Run(Utility utility, string[] args);
}
