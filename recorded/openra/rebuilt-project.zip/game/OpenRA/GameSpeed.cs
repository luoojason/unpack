namespace OpenRA;

public class GameSpeed
{
	[FluentReference]
	[FieldLoader.Require]
	public readonly string Name;

	[FieldLoader.Require]
	public readonly int Timestep;

	[FieldLoader.Require]
	public readonly int OrderLatency;
}
