using System;
using System.Reflection;
using OpenRA.Primitives;

namespace OpenRA;

public class Utility
{
	private static readonly ConcurrentCache<Type, FieldInfo[]> TypeFields = new ConcurrentCache<Type, FieldInfo[]>((Type type) => type.GetFields());

	private static readonly ConcurrentCache<(MemberInfo Member, Type AttributeType), bool> MemberHasAttribute = new ConcurrentCache<(MemberInfo, Type), bool>(((MemberInfo Member, Type AttributeType) x) => Attribute.IsDefined(x.Member, x.AttributeType));

	private static readonly ConcurrentCache<(MemberInfo Member, Type AttributeType, bool Inherit), object[]> MemberCustomAttributes = new ConcurrentCache<(MemberInfo, Type, bool), object[]>(((MemberInfo Member, Type AttributeType, bool Inherit) x) => x.Member.GetCustomAttributes(x.AttributeType, x.Inherit));

	public readonly ModData ModData;

	public readonly InstalledMods Mods;

	public static FieldInfo[] GetFields(Type type)
	{
		return TypeFields[type];
	}

	public static bool HasAttribute<TAttribute>(MemberInfo member) where TAttribute : Attribute
	{
		return MemberHasAttribute[(member, typeof(TAttribute))];
	}

	public static TAttribute[] GetCustomAttributes<TAttribute>(MemberInfo member, bool inherit) where TAttribute : Attribute
	{
		return (TAttribute[])MemberCustomAttributes[(member, typeof(TAttribute), inherit)];
	}

	public Utility(ModData modData, InstalledMods mods)
	{
		ModData = modData;
		Mods = mods;
	}
}
