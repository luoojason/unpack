using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Activities;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Scripting;
using OpenRA.Traits;

namespace OpenRA;

public sealed class Actor : IScriptBindable, IScriptNotifyBind, ILuaTableBinding, ILuaEqualityBinding, ILuaToStringBinding, IEquatable<Actor>, IDisposable
{
	internal readonly struct SyncHash(ISync trait)
	{
		public readonly ISync Trait = trait;

		private readonly Func<object, int> hashFunction = Sync.GetHashFunction(trait);

		public int Hash()
		{
			return hashFunction(Trait);
		}
	}

	private sealed class ConditionState
	{
		public readonly List<VariableObserverNotifier> Notifiers = new List<VariableObserverNotifier>();

		public readonly HashSet<int> Tokens = new HashSet<int>();
	}

	public const int InvalidConditionToken = -1;

	public readonly ActorInfo Info;

	public readonly World World;

	public readonly uint ActorID;

	private Activity currentActivity;

	public int Generation;

	public Actor ReplacedByActor;

	private readonly ICrushable[] crushables;

	private readonly Dictionary<string, ConditionState> conditionStates = new Dictionary<string, ConditionState>();

	private readonly Dictionary<int, string> conditionTokens = new Dictionary<int, string>();

	private int nextConditionToken = 1;

	private readonly Dictionary<string, int> conditionCache = new Dictionary<string, int>();

	private readonly IReadOnlyDictionary<string, int> readOnlyConditionCache;

	private readonly IFacing facing;

	private readonly IHealth health;

	private readonly IResolveOrder[] resolveOrders;

	private readonly IRenderModifier[] renderModifiers;

	private readonly IRender[] renders;

	private readonly IMouseBounds[] mouseBounds;

	private readonly IVisibilityModifier[] visibilityModifiers;

	private readonly IDefaultVisibility defaultVisibility;

	private readonly INotifyBecomingIdle[] becomingIdles;

	private readonly INotifyIdle[] tickIdles;

	private readonly IEnumerable<WPos> enabledTargetableWorldPositions;

	private bool created;

	private Lazy<ScriptActorInterface> luaInterface;

	public Player Owner { get; internal set; }

	public bool IsInWorld { get; internal set; }

	public bool WillDispose { get; private set; }

	public bool Disposed { get; private set; }

	public Activity CurrentActivity
	{
		get
		{
			return Activity.SkipDoneActivities(currentActivity);
		}
		private set
		{
			currentActivity = value;
		}
	}

	public IEffectiveOwner EffectiveOwner { get; }

	public IOccupySpace OccupiesSpace { get; }

	public ITargetable[] Targetables { get; }

	public IEnumerable<ITargetablePositions> EnabledTargetablePositions { get; }

	public ICrushable[] Crushables => crushables ?? throw new InvalidOperationException("Crushables for " + Info.Name + " are not initialized.");

	public bool IsIdle => CurrentActivity == null;

	public bool IsDead
	{
		get
		{
			if (!Disposed)
			{
				if (health != null)
				{
					return health.IsDead;
				}
				return false;
			}
			return true;
		}
	}

	public CPos Location => OccupiesSpace.TopLeft;

	public WPos CenterPosition => OccupiesSpace.CenterPosition;

	public WRot Orientation => facing?.Orientation ?? WRot.None;

	internal SyncHash[] SyncHashes { get; }

	public LuaValue this[LuaRuntime runtime, LuaValue keyValue]
	{
		get
		{
			return luaInterface.Value[runtime, keyValue];
		}
		set
		{
			luaInterface.Value[runtime, keyValue] = value;
		}
	}

	internal Actor(World world, string name, TypeDictionary initDict)
	{
		IGrouping<Type, ISingleInstanceInit> grouping = (from i in initDict.WithInterface<ISingleInstanceInit>()
			group i by i.GetType()).FirstOrDefault((IGrouping<Type, ISingleInstanceInit> i) => i.Count() > 1);
		if (grouping != null)
		{
			throw new InvalidDataException("Duplicate initializer '" + grouping.Key.Name + "'");
		}
		ActorInitializer actorInitializer = new ActorInitializer(this, initDict);
		readOnlyConditionCache = new ReadOnlyDictionary<string, int>(conditionCache);
		World = world;
		ActorID = world.NextAID();
		OwnerInit orDefault = actorInitializer.GetOrDefault<OwnerInit>();
		if (orDefault != null)
		{
			Owner = orDefault.Value(world);
		}
		if (name == null)
		{
			return;
		}
		name = name.ToLowerInvariant();
		if (!world.Map.Rules.Actors.ContainsKey(name))
		{
			throw new NotImplementedException("No rules definition for unit " + name);
		}
		Info = world.Map.Rules.Actors[name];
		List<IResolveOrder> list = new List<IResolveOrder>();
		List<IRenderModifier> list2 = new List<IRenderModifier>();
		List<IRender> list3 = new List<IRender>();
		List<IMouseBounds> list4 = new List<IMouseBounds>();
		List<IVisibilityModifier> list5 = new List<IVisibilityModifier>();
		List<INotifyBecomingIdle> list6 = new List<INotifyBecomingIdle>();
		List<INotifyIdle> list7 = new List<INotifyIdle>();
		List<ITargetable> list8 = new List<ITargetable>();
		List<ITargetablePositions> list9 = new List<ITargetablePositions>();
		List<SyncHash> list10 = new List<SyncHash>();
		List<ICrushable> list11 = new List<ICrushable>();
		foreach (TraitInfo item11 in Info.TraitsInConstructOrder())
		{
			object obj = item11.Create(actorInitializer);
			AddTrait(obj);
			if (obj is IOccupySpace occupySpace)
			{
				OccupiesSpace = occupySpace;
			}
			if (obj is IEffectiveOwner effectiveOwner)
			{
				EffectiveOwner = effectiveOwner;
			}
			if (obj is IFacing facing)
			{
				this.facing = facing;
			}
			if (obj is IHealth health)
			{
				this.health = health;
			}
			if (obj is IResolveOrder item)
			{
				list.Add(item);
			}
			if (obj is IRenderModifier item2)
			{
				list2.Add(item2);
			}
			if (obj is IRender item3)
			{
				list3.Add(item3);
			}
			if (obj is IMouseBounds item4)
			{
				list4.Add(item4);
			}
			if (obj is IVisibilityModifier item5)
			{
				list5.Add(item5);
			}
			if (obj is IDefaultVisibility defaultVisibility)
			{
				this.defaultVisibility = defaultVisibility;
			}
			if (obj is INotifyBecomingIdle item6)
			{
				list6.Add(item6);
			}
			if (obj is INotifyIdle item7)
			{
				list7.Add(item7);
			}
			if (obj is ITargetable item8)
			{
				list8.Add(item8);
			}
			if (obj is ITargetablePositions item9)
			{
				list9.Add(item9);
			}
			if (obj is ISync trait)
			{
				list10.Add(new SyncHash(trait));
			}
			if (obj is ICrushable item10)
			{
				list11.Add(item10);
			}
		}
		resolveOrders = list.ToArray();
		renderModifiers = list2.ToArray();
		renders = list3.ToArray();
		mouseBounds = list4.ToArray();
		visibilityModifiers = list5.ToArray();
		becomingIdles = list6.ToArray();
		tickIdles = list7.ToArray();
		Targetables = list8.ToArray();
		ITargetablePositions[] source = list9.ToArray();
		EnabledTargetablePositions = source.Where(Exts.IsTraitEnabled);
		enabledTargetableWorldPositions = EnabledTargetablePositions.SelectMany((ITargetablePositions tp) => tp.TargetablePositions(this));
		SyncHashes = list10.ToArray();
		crushables = list11.ToArray();
	}

	internal void Initialize(bool addToWorld = true)
	{
		created = true;
		foreach (INotifyCreated item in TraitsImplementing<INotifyCreated>())
		{
			item.Created(this);
		}
		HashSet<VariableObserverNotifier> hashSet = new HashSet<VariableObserverNotifier>();
		foreach (IObservesVariables item2 in TraitsImplementing<IObservesVariables>())
		{
			foreach (VariableObserver variableObserver in item2.GetVariableObservers())
			{
				hashSet.Add(variableObserver.Notifier);
				foreach (string variable in variableObserver.Variables)
				{
					ConditionState orAdd = conditionStates.GetOrAdd(variable);
					orAdd.Notifiers.Add(variableObserver.Notifier);
					conditionCache[variable] = orAdd.Tokens.Count;
				}
			}
		}
		foreach (VariableObserverNotifier item3 in hashSet)
		{
			item3(this, readOnlyConditionCache);
		}
		ICreationActivity creationActivity = null;
		foreach (ICreationActivity item4 in TraitsImplementing<ICreationActivity>())
		{
			if (item4.IsTraitEnabled())
			{
				if (creationActivity != null)
				{
					throw new InvalidOperationException("More than one enabled ICreationActivity trait: " + creationActivity.GetType().Name + " and " + item4.GetType().Name);
				}
				Activity creationActivity2 = item4.GetCreationActivity();
				if (creationActivity2 != null)
				{
					creationActivity = item4;
					creationActivity2.Queue(CurrentActivity);
					CurrentActivity = creationActivity2;
				}
			}
		}
		if (addToWorld)
		{
			World.Add(this);
		}
	}

	public void Tick()
	{
		bool isIdle = IsIdle;
		CurrentActivity = ActivityUtils.RunActivity(this, CurrentActivity);
		if (!isIdle && IsIdle)
		{
			INotifyBecomingIdle[] array = becomingIdles;
			foreach (INotifyBecomingIdle notifyBecomingIdle in array)
			{
				notifyBecomingIdle.OnBecomingIdle(this);
			}
			CurrentActivity = ActivityUtils.RunActivity(this, CurrentActivity);
		}
		else if (isIdle)
		{
			INotifyIdle[] array2 = tickIdles;
			foreach (INotifyIdle notifyIdle in array2)
			{
				notifyIdle.TickIdle(this);
			}
		}
	}

	public IEnumerable<IRenderable> Render(WorldRenderer wr)
	{
		IEnumerable<IRenderable> enumerable = Renderables(wr);
		IRenderModifier[] array = renderModifiers;
		foreach (IRenderModifier renderModifier in array)
		{
			enumerable = renderModifier.ModifyRender(this, wr, enumerable);
		}
		return enumerable;
	}

	private IEnumerable<IRenderable> Renderables(WorldRenderer wr)
	{
		IRender[] array = renders;
		foreach (IRender render in array)
		{
			foreach (IRenderable item in render.Render(this, wr))
			{
				yield return item;
			}
		}
	}

	public IEnumerable<Rectangle> ScreenBounds(WorldRenderer wr)
	{
		IEnumerable<Rectangle> enumerable = Bounds(wr);
		IRenderModifier[] array = renderModifiers;
		foreach (IRenderModifier renderModifier in array)
		{
			enumerable = renderModifier.ModifyScreenBounds(this, wr, enumerable);
		}
		return enumerable;
	}

	private IEnumerable<Rectangle> Bounds(WorldRenderer wr)
	{
		IRender[] array = renders;
		foreach (IRender render in array)
		{
			foreach (Rectangle item in render.ScreenBounds(this, wr))
			{
				if (!item.IsEmpty)
				{
					yield return item;
				}
			}
		}
	}

	public Polygon MouseBounds(WorldRenderer wr)
	{
		IMouseBounds[] array = this.mouseBounds;
		foreach (IMouseBounds mouseBounds in array)
		{
			Polygon result = mouseBounds.MouseoverBounds(this, wr);
			if (!result.IsEmpty)
			{
				return result;
			}
		}
		return Polygon.Empty;
	}

	public void QueueActivity(bool queued, Activity nextActivity)
	{
		if (!queued)
		{
			CancelActivity();
		}
		QueueActivity(nextActivity);
	}

	public void QueueActivity(Activity nextActivity)
	{
		if (!created)
		{
			throw new InvalidOperationException("An activity was queued before the actor was created. Queue it inside the INotifyCreated.Created callback instead.");
		}
		if (CurrentActivity == null)
		{
			CurrentActivity = nextActivity;
		}
		else
		{
			CurrentActivity.Queue(nextActivity);
		}
	}

	public void CancelActivity()
	{
		CurrentActivity?.Cancel(this);
	}

	public override int GetHashCode()
	{
		return (int)ActorID;
	}

	public override bool Equals(object obj)
	{
		if (obj is Actor other)
		{
			return Equals(other);
		}
		return false;
	}

	public bool Equals(Actor other)
	{
		return ActorID == other.ActorID;
	}

	public override string ToString()
	{
		string text = Info.Name + " " + ActorID;
		if (!IsInWorld)
		{
			text += " (not in world)";
		}
		return text;
	}

	public T Trait<T>()
	{
		return World.TraitDict.Get<T>(this);
	}

	public T TraitOrDefault<T>()
	{
		return World.TraitDict.GetOrDefault<T>(this);
	}

	public IEnumerable<T> TraitsImplementing<T>()
	{
		return World.TraitDict.WithInterface<T>(this);
	}

	public void AddTrait(object trait)
	{
		World.TraitDict.AddTrait(this, trait);
	}

	public void Dispose()
	{
		CurrentActivity?.OnActorDisposeOuter(this);
		WillDispose = true;
		World.AddFrameEndTask((World w) =>
		{
			if (!Disposed)
			{
				if (IsInWorld)
				{
					World.Remove(this);
				}
				foreach (INotifyActorDisposing item in TraitsImplementing<INotifyActorDisposing>())
				{
					item.Disposing(this);
				}
				World.TraitDict.RemoveActor(this);
				Disposed = true;
				luaInterface?.Value.OnActorDestroyed();
			}
		});
	}

	public void ResolveOrder(Order order)
	{
		IResolveOrder[] array = resolveOrders;
		foreach (IResolveOrder resolveOrder in array)
		{
			resolveOrder.ResolveOrder(this, order);
		}
	}

	public void ChangeOwner(Player newOwner)
	{
		World.AddFrameEndTask((World _) =>
		{
			ChangeOwnerSync(newOwner);
		});
	}

	public void ChangeOwnerSync(Player newOwner)
	{
		if (Disposed)
		{
			return;
		}
		Player owner = Owner;
		bool isInWorld = IsInWorld;
		if (isInWorld)
		{
			World.Remove(this);
		}
		Owner = newOwner;
		Generation++;
		foreach (INotifyOwnerChanged item in TraitsImplementing<INotifyOwnerChanged>())
		{
			item.OnOwnerChanged(this, owner, newOwner);
		}
		foreach (INotifyOwnerChanged item2 in World.WorldActor.TraitsImplementing<INotifyOwnerChanged>())
		{
			item2.OnOwnerChanged(this, owner, newOwner);
		}
		if (isInWorld)
		{
			World.Add(this);
		}
	}

	public DamageState GetDamageState()
	{
		if (Disposed)
		{
			return DamageState.Dead;
		}
		if (health != null)
		{
			return health.DamageState;
		}
		return DamageState.Undamaged;
	}

	public void InflictDamage(Actor attacker, Damage damage)
	{
		if (!Disposed && health != null)
		{
			health.InflictDamage(this, attacker, damage, ignoreModifiers: false);
		}
	}

	public void Kill(Actor attacker, BitSet<DamageType> damageTypes = default(BitSet<DamageType>))
	{
		if (!Disposed && health != null)
		{
			health.Kill(this, attacker, damageTypes);
		}
	}

	public bool CanBeViewedByPlayer(Player player)
	{
		IVisibilityModifier[] array = visibilityModifiers;
		foreach (IVisibilityModifier visibilityModifier in array)
		{
			if (!visibilityModifier.IsVisible(this, player))
			{
				return false;
			}
		}
		return defaultVisibility.IsVisible(this, player);
	}

	public BitSet<TargetableType> GetAllTargetTypes()
	{
		BitSet<TargetableType> result = default;
		ITargetable[] targetables = Targetables;
		foreach (ITargetable targetable in targetables)
		{
			result = result.Union(targetable.TargetTypes);
		}
		return result;
	}

	public BitSet<TargetableType> GetEnabledTargetTypes()
	{
		BitSet<TargetableType> result = default;
		ITargetable[] targetables = Targetables;
		foreach (ITargetable targetable in targetables)
		{
			if (targetable.IsTraitEnabled())
			{
				result = result.Union(targetable.TargetTypes);
			}
		}
		return result;
	}

	public bool IsTargetableBy(Actor byActor)
	{
		ITargetable[] targetables = Targetables;
		foreach (ITargetable targetable in targetables)
		{
			if (targetable.TargetableBy(this, byActor))
			{
				return true;
			}
		}
		return false;
	}

	public IEnumerable<WPos> GetTargetablePositions()
	{
		if (EnabledTargetablePositions.Any())
		{
			return enabledTargetableWorldPositions;
		}
		return new WPos[1] { CenterPosition };
	}

	private void UpdateConditionState(string condition, int token, bool isRevoke)
	{
		ConditionState orAdd = conditionStates.GetOrAdd(condition);
		if (isRevoke)
		{
			orAdd.Tokens.Remove(token);
		}
		else
		{
			orAdd.Tokens.Add(token);
		}
		conditionCache[condition] = orAdd.Tokens.Count;
		if (!created)
		{
			return;
		}
		foreach (VariableObserverNotifier notifier in orAdd.Notifiers)
		{
			notifier(this, readOnlyConditionCache);
		}
	}

	public int GrantCondition(string condition)
	{
		if (string.IsNullOrEmpty(condition))
		{
			return -1;
		}
		int num = nextConditionToken++;
		conditionTokens.Add(num, condition);
		UpdateConditionState(condition, num, isRevoke: false);
		return num;
	}

	public int RevokeCondition(int token)
	{
		if (!conditionTokens.TryGetValue(token, out var value))
		{
			throw new InvalidOperationException($"Attempting to revoke condition with invalid token {token} for {this}.");
		}
		conditionTokens.Remove(token);
		UpdateConditionState(value, token, isRevoke: true);
		return -1;
	}

	public bool TokenValid(int token)
	{
		return conditionTokens.ContainsKey(token);
	}

	public void OnScriptBind(ScriptContext context)
	{
		if (luaInterface == null)
		{
			luaInterface = Exts.Lazy(() => new ScriptActorInterface(context, this));
		}
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<Actor>(out var clrObject) || !right.TryGetClrValue<Actor>(out var clrObject2))
		{
			return false;
		}
		return clrObject == clrObject2;
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return $"Actor ({this})";
	}

	public bool HasScriptProperty(string name)
	{
		return luaInterface.Value.ContainsKey(name);
	}
}
