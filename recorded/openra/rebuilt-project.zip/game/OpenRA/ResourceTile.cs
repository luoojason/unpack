namespace OpenRA;

public readonly struct ResourceTile(byte type, byte index)
{
	public readonly byte Type = type;

	public readonly byte Index = index;

	public override int GetHashCode()
	{
		return Type.GetHashCode() ^ Index.GetHashCode();
	}
}
