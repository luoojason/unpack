using System;
using System.Collections.Generic;
using System.Linq;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Graphics;
using OpenRA.Network;
using OpenRA.Primitives;
using OpenRA.Scripting;
using OpenRA.Support;
using OpenRA.Traits;
using OpenRA.Widgets;

namespace OpenRA;

public class Player : IScriptBindable, IScriptNotifyBind, ILuaTableBinding, ILuaEqualityBinding, ILuaToStringBinding
{
	[FluentReference(new string[] { "name", "number" })]
	private const string EnumeratedBotName = "enumerated-bot-name";

	public readonly Actor PlayerActor;

	public readonly string PlayerName;

	public readonly string InternalName;

	public readonly FactionInfo Faction;

	public readonly bool NonCombatant;

	public readonly bool Playable = true;

	public readonly int ClientIndex;

	public readonly CPos HomeLocation;

	public readonly int Handicap;

	public readonly PlayerReference PlayerReference;

	public readonly bool IsBot;

	public readonly string BotType;

	public readonly Shroud Shroud;

	public readonly FrozenActorLayer FrozenActorLayer;

	private readonly Color color;

	public readonly FactionInfo DisplayFaction;

	public readonly int SpawnPoint;

	public readonly int DisplaySpawnPoint;

	public WinState WinState;

	public bool HasObjectives;

	private readonly bool inMissionMap;

	private readonly bool spectating;

	private readonly IUnlocksRenderPlayer[] unlockRenderPlayer;

	private readonly INotifyPlayerDisconnected[] notifyDisconnected;

	private readonly IReadOnlyCollection<IBotInfo> botInfos;

	private string resolvedPlayerName;

	public LongBitSet<PlayerBitMask> PlayerMask;

	public LongBitSet<PlayerBitMask> AlliedPlayersMask;

	public LongBitSet<PlayerBitMask> EnemyPlayersMask;

	private Lazy<ScriptPlayerInterface> luaInterface;

	public Color Color { get; private set; }

	public bool Spectating
	{
		get
		{
			if (!inMissionMap)
			{
				if (!spectating)
				{
					return WinState != WinState.Undefined;
				}
				return true;
			}
			return false;
		}
	}

	public World World { get; }

	public bool UnlockedRenderPlayer
	{
		get
		{
			if (unlockRenderPlayer.Any((IUnlocksRenderPlayer x) => x.RenderPlayerUnlocked))
			{
				return true;
			}
			if (WinState != WinState.Undefined)
			{
				return !inMissionMap;
			}
			return false;
		}
	}

	public string ResolvedPlayerName
	{
		get
		{
			if (resolvedPlayerName == null)
			{
				resolvedPlayerName = ResolvePlayerName();
			}
			return resolvedPlayerName;
		}
	}

	public LuaValue this[LuaRuntime runtime, LuaValue keyValue]
	{
		get
		{
			return luaInterface.Value[runtime, keyValue];
		}
		set
		{
			luaInterface.Value[runtime, keyValue] = value;
		}
	}

	public static FactionInfo ResolveFaction(string factionName, IEnumerable<FactionInfo> factionInfos, MersenneTwister playerRandom, bool requireSelectable = true)
	{
		List<FactionInfo> list = factionInfos.Where((FactionInfo f) => !requireSelectable || f.Selectable).ToList();
		FactionInfo factionInfo = list.FirstOrDefault((FactionInfo f) => f.InternalName == factionName) ?? list.Random(playerRandom);
		for (int num = 0; num <= 10; num++)
		{
			if (factionInfo.RandomFactionMembers.Count <= 0)
			{
				break;
			}
			string faction = factionInfo.RandomFactionMembers.Random(playerRandom);
			factionInfo = list.FirstOrDefault((FactionInfo f) => f.InternalName == faction);
			if (factionInfo == null)
			{
				throw new YamlException("Unknown faction: " + faction);
			}
		}
		return factionInfo;
	}

	private static FactionInfo ResolveFaction(World world, string factionName, MersenneTwister playerRandom, bool requireSelectable)
	{
		IReadOnlyCollection<FactionInfo> factionInfos = world.Map.Rules.Actors[SystemActors.World].TraitInfos<FactionInfo>();
		return ResolveFaction(factionName, factionInfos, playerRandom, requireSelectable);
	}

	private static FactionInfo ResolveDisplayFaction(World world, string factionName)
	{
		IReadOnlyCollection<FactionInfo> source = world.Map.Rules.Actors[SystemActors.World].TraitInfos<FactionInfo>();
		return source.FirstOrDefault((FactionInfo f) => f.InternalName == factionName) ?? source.First();
	}

	public Player(World world, Session.Client client, PlayerReference pr, MersenneTwister playerRandom)
	{
		World = world;
		InternalName = pr.Name;
		PlayerReference = pr;
		inMissionMap = world.Map.Visibility.HasFlag(MapVisibility.MissionSelector);
		botInfos = World.Map.Rules.Actors[SystemActors.Player].TraitInfos<IBotInfo>();
		if (client != null)
		{
			ClientIndex = client.Index;
			color = client.Color;
			Color = color;
			PlayerName = client.Name;
			BotType = client.Bot;
			Faction = ResolveFaction(world, client.Faction, playerRandom, !pr.LockFaction);
			DisplayFaction = ResolveDisplayFaction(world, client.Faction);
			IAssignSpawnPoints assignSpawnPoints = world.WorldActor.TraitOrDefault<IAssignSpawnPoints>();
			HomeLocation = assignSpawnPoints?.AssignHomeLocation(world, client, playerRandom) ?? pr.HomeLocation;
			SpawnPoint = assignSpawnPoints?.SpawnPointForPlayer(this) ?? client.SpawnPoint;
			DisplaySpawnPoint = client.SpawnPoint;
			Handicap = client.Handicap;
		}
		else
		{
			ClientIndex = world.LobbyInfo.Clients.FirstOrDefault((Session.Client c) => c.IsAdmin)?.Index ?? 0;
			color = pr.Color;
			Color = pr.Color;
			PlayerName = pr.Name;
			NonCombatant = pr.NonCombatant;
			Playable = pr.Playable;
			spectating = pr.Spectating;
			BotType = pr.Bot;
			Faction = ResolveFaction(world, pr.Faction, playerRandom, requireSelectable: false);
			DisplayFaction = ResolveDisplayFaction(world, pr.Faction);
			HomeLocation = pr.HomeLocation;
			SpawnPoint = (DisplaySpawnPoint = 0);
			Handicap = pr.Handicap;
		}
		if (!spectating)
		{
			PlayerMask = new LongBitSet<PlayerBitMask>(InternalName);
		}
		IsBot = BotType != null;
		PlayerActor = new Actor(world, ((world.Type == WorldType.Editor) ? SystemActors.EditorPlayer : SystemActors.Player).ToString(), new TypeDictionary
		{
			new OwnerInit(this)
		});
		PlayerActor.Initialize();
		Shroud = PlayerActor.Trait<Shroud>();
		FrozenActorLayer = PlayerActor.TraitOrDefault<FrozenActorLayer>();
		if (IsBot && Game.IsHost)
		{
			IBot bot = PlayerActor.TraitsImplementing<IBot>().FirstOrDefault((IBot b) => b.Info.Type == BotType);
			if (bot == null)
			{
				Log.Write("debug", "Invalid bot type: " + BotType);
			}
			else
			{
				bot.Activate(this);
			}
		}
		unlockRenderPlayer = PlayerActor.TraitsImplementing<IUnlocksRenderPlayer>().ToArray();
		notifyDisconnected = PlayerActor.TraitsImplementing<INotifyPlayerDisconnected>().ToArray();
	}

	public override string ToString()
	{
		return $"{ResolvedPlayerName} ({ClientIndex})";
	}

	private string ResolvePlayerName()
	{
		if (IsBot)
		{
			IBotInfo botInfo = botInfos.First((IBotInfo b) => b.Type == BotType);
			Player[] array = World.Players.Where((Player c) => c.BotType == BotType).ToArray();
			return FluentProvider.GetMessage("enumerated-bot-name", "name", FluentProvider.GetMessage(botInfo.Name), "number", array.IndexOf(this) + 1);
		}
		return PlayerName;
	}

	public PlayerRelationship RelationshipWith(Player other)
	{
		if (this == other)
		{
			return PlayerRelationship.Ally;
		}
		if (other == null || other.Spectating)
		{
			if (!NonCombatant)
			{
				return PlayerRelationship.Ally;
			}
			return PlayerRelationship.Neutral;
		}
		if (AlliedPlayersMask.Overlaps(other.PlayerMask))
		{
			return PlayerRelationship.Ally;
		}
		if (EnemyPlayersMask.Overlaps(other.PlayerMask))
		{
			return PlayerRelationship.Enemy;
		}
		return PlayerRelationship.Neutral;
	}

	public bool IsAlliedWith(Player p)
	{
		return RelationshipWith(p) == PlayerRelationship.Ally;
	}

	public static Color GetColor(Player p)
	{
		return p.color;
	}

	public static void SetupRelationshipColors(Player[] players, Player viewer, WorldRenderer worldRenderer, bool firstRun)
	{
		foreach (Player player in players)
		{
			player.Color = PlayerRelationshipColor(player, viewer);
			worldRenderer.UpdatePalettesForPlayer(player.InternalName, player.Color, !firstRun);
		}
	}

	public static Color PlayerRelationshipColor(Player player, Player viewer)
	{
		if (!Game.Settings.Game.UsePlayerStanceColors || viewer == null || viewer.Spectating)
		{
			return player.color;
		}
		if (viewer == player)
		{
			return ChromeMetrics.Get<Color>("PlayerStanceColorSelf");
		}
		if (player.IsAlliedWith(viewer))
		{
			return ChromeMetrics.Get<Color>("PlayerStanceColorAllies");
		}
		if (player.NonCombatant)
		{
			return ChromeMetrics.Get<Color>("PlayerStanceColorNeutrals");
		}
		return ChromeMetrics.Get<Color>("PlayerStanceColorEnemies");
	}

	internal void PlayerDisconnected(Player p)
	{
		INotifyPlayerDisconnected[] array = notifyDisconnected;
		foreach (INotifyPlayerDisconnected notifyPlayerDisconnected in array)
		{
			notifyPlayerDisconnected.PlayerDisconnected(PlayerActor, p);
		}
	}

	public void OnScriptBind(ScriptContext context)
	{
		if (luaInterface == null)
		{
			luaInterface = Exts.Lazy(() => new ScriptPlayerInterface(context, this));
		}
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<Player>(out var clrObject) || !right.TryGetClrValue<Player>(out var clrObject2))
		{
			return false;
		}
		return clrObject == clrObject2;
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return "Player (" + ResolvedPlayerName + ")";
	}
}
