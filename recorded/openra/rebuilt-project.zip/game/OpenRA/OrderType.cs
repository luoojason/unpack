namespace OpenRA;

public enum OrderType : byte
{
	Ack = 16,
	Ping = 32,
	SyncHash = 101,
	TickScale = 118,
	Disconnect = 191,
	Handshake = 254,
	Fields = byte.MaxValue
}
