using System.Collections.Generic;

namespace OpenRA;

public class PlayerProfile
{
	public readonly string Fingerprint;

	public readonly string PublicKey;

	public readonly bool KeyRevoked;

	public readonly int ProfileID;

	public readonly string ProfileName;

	public readonly string ProfileRank = "Registered Player";

	[FieldLoader.LoadUsing("LoadBadges", false)]
	public readonly List<PlayerBadge> Badges;

	private static object LoadBadges(MiniYaml yaml)
	{
		List<PlayerBadge> badges = new List<PlayerBadge>();
		MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault("Badges");
		if (miniYamlNode != null)
		{
			PlayerDatabase playerDatabase = Game.ModData.Manifest.Get<PlayerDatabase>();
			foreach (MiniYamlNode badgeNode in miniYamlNode.Value.Nodes)
			{
				Game.RunAfterTick(() =>
				{
					try
					{
						PlayerBadge playerBadge = playerDatabase.LoadBadge(badgeNode.Value);
						if (playerBadge != null)
						{
							badges.Add(playerBadge);
						}
					}
					catch
					{
					}
				});
			}
		}
		return badges;
	}
}
