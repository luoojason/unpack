using System;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Primitives;
using OpenRA.Scripting;

namespace OpenRA;

public readonly struct CVec(int x, int y) : IEquatable<CVec>, IScriptBindable, ILuaAdditionBinding, ILuaSubtractionBinding, ILuaEqualityBinding, ILuaUnaryMinusBinding, ILuaMultiplicationBinding, ILuaDivisionBinding, ILuaTableBinding, ILuaToStringBinding
{
	public readonly int X = x;

	public readonly int Y = y;

	public static readonly CVec Zero = new CVec(0, 0);

	public static readonly CVec[] Directions = new CVec[8]
	{
		new CVec(-1, -1),
		new CVec(-1, 0),
		new CVec(-1, 1),
		new CVec(0, -1),
		new CVec(0, 1),
		new CVec(1, -1),
		new CVec(1, 0),
		new CVec(1, 1)
	};

	public int LengthSquared => X * X + Y * Y;

	public int Length => Exts.ISqrt(LengthSquared);

	public LuaValue this[LuaRuntime runtime, LuaValue key]
	{
		get
		{
			return key.ToString() switch
			{
				"X" => (LuaValue)X, 
				"Y" => Y, 
				"Length" => Length, 
				_ => throw new LuaException($"CVec does not define a member '{key}'"), 
			};
		}
		set
		{
			throw new LuaException("CVec is read-only. Use CVec.New to create a new value");
		}
	}

	public static CVec operator +(CVec a, CVec b)
	{
		return new CVec(a.X + b.X, a.Y + b.Y);
	}

	public static CVec operator -(CVec a, CVec b)
	{
		return new CVec(a.X - b.X, a.Y - b.Y);
	}

	public static CVec operator *(int a, CVec b)
	{
		return new CVec(a * b.X, a * b.Y);
	}

	public static CVec operator *(CVec b, int a)
	{
		return new CVec(a * b.X, a * b.Y);
	}

	public static CVec operator /(CVec a, int b)
	{
		return new CVec(a.X / b, a.Y / b);
	}

	public static CVec operator -(CVec a)
	{
		return new CVec(-a.X, -a.Y);
	}

	public static bool operator ==(CVec me, CVec other)
	{
		if (me.X == other.X)
		{
			return me.Y == other.Y;
		}
		return false;
	}

	public static bool operator !=(CVec me, CVec other)
	{
		return !(me == other);
	}

	public static CVec Max(CVec a, CVec b)
	{
		return new CVec(Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
	}

	public static CVec Min(CVec a, CVec b)
	{
		return new CVec(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y));
	}

	public static int Dot(CVec a, CVec b)
	{
		return a.X * b.X + a.Y * b.Y;
	}

	public CVec Sign()
	{
		return new CVec(Math.Sign(X), Math.Sign(Y));
	}

	public CVec Abs()
	{
		return new CVec(Math.Abs(X), Math.Abs(Y));
	}

	public CVec Clamp(Rectangle r)
	{
		return new CVec(Math.Min(r.Right, Math.Max(X, r.Left)), Math.Min(r.Bottom, Math.Max(Y, r.Top)));
	}

	public override int GetHashCode()
	{
		return X.GetHashCode() ^ Y.GetHashCode();
	}

	public bool Equals(CVec other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is CVec other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return X + "," + Y;
	}

	public LuaValue Add(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CVec>(out var clrObject) || !right.TryGetClrValue<CVec>(out var clrObject2))
		{
			throw new LuaException("Attempted to call CVec.Add(CVec, CVec) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject + clrObject2);
	}

	public LuaValue Subtract(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CVec>(out var clrObject) || !right.TryGetClrValue<CVec>(out var clrObject2))
		{
			throw new LuaException("Attempted to call CVec.Subtract(CVec, CVec) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject - clrObject2);
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CVec>(out var clrObject) || !right.TryGetClrValue<CVec>(out var clrObject2))
		{
			return false;
		}
		return clrObject == clrObject2;
	}

	public LuaValue Minus(LuaRuntime runtime)
	{
		return new LuaCustomClrObject(-this);
	}

	public LuaValue Multiply(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CVec>(out var clrObject) || !right.TryGetClrValue<int>(out var clrObject2))
		{
			throw new LuaException("Attempted to call CVec.Multiply(CVec, integer) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject * clrObject2);
	}

	public LuaValue Divide(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CVec>(out var clrObject) || !right.TryGetClrValue<int>(out var clrObject2))
		{
			throw new LuaException("Attempted to call CVec.Multiply(CVec, integer) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject / clrObject2);
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return ToString();
	}
}
