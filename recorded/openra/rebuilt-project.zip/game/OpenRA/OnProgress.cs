namespace OpenRA;

public delegate void OnProgress(long total, long totalRead, int progressPercentage);
