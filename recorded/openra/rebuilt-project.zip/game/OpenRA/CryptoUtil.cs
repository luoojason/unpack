using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace OpenRA;

public static class CryptoUtil
{
	private static readonly byte[] OIDHeader = new byte[15]
	{
		48, 13, 6, 9, 42, 134, 72, 134, 247, 13,
		1, 1, 1, 5, 0
	};

	private static readonly char[] HexUpperAlphabet = "0123456789ABCDEF".ToArray();

	private static readonly char[] HexLowerAlphabet = "0123456789abcdef".ToArray();

	public static string PublicKeyFingerprint(RSAParameters parameters)
	{
		return SHA1Hash(parameters.Modulus.Append(parameters.Exponent).ToArray());
	}

	public static string EncodePEMPublicKey(RSAParameters parameters)
	{
		string text = Convert.ToBase64String(EncodePublicKey(parameters));
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("-----BEGIN PUBLIC KEY-----");
		for (int i = 0; i < text.Length; i += 64)
		{
			stringBuilder.AppendLine(text.Substring(i, Math.Min(64, text.Length - i)));
		}
		stringBuilder.Append("-----END PUBLIC KEY-----");
		return stringBuilder.ToString();
	}

	public static RSAParameters DecodePEMPublicKey(string key)
	{
		try
		{
			string[] array = key.Split('\n');
			byte[] buffer = Convert.FromBase64String(array.Skip(1).Take(array.Length - 2).JoinWith(""));
			using MemoryStream memoryStream = new MemoryStream(buffer);
			memoryStream.ReadUInt8();
			ReadTLVLength(memoryStream);
			memoryStream.ReadUInt8();
			int num = ReadTLVLength(memoryStream);
			memoryStream.Position += num;
			memoryStream.ReadUInt8();
			ReadTLVLength(memoryStream);
			memoryStream.ReadUInt8();
			memoryStream.ReadUInt8();
			ReadTLVLength(memoryStream);
			memoryStream.ReadUInt8();
			int num2 = ReadTLVLength(memoryStream);
			memoryStream.ReadUInt8();
			byte[] modulus = memoryStream.ReadBytes(num2 - 1);
			memoryStream.ReadUInt8();
			int num3 = ReadTLVLength(memoryStream);
			memoryStream.ReadUInt8();
			byte[] exponent = memoryStream.ReadBytes(num3 - 1);
			return new RSAParameters
			{
				Modulus = modulus,
				Exponent = exponent
			};
		}
		catch (Exception innerException)
		{
			throw new InvalidDataException("Invalid PEM public key", innerException);
		}
	}

	private static byte[] EncodePublicKey(RSAParameters parameters)
	{
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		int num = TripletFullLength(parameters.Modulus.Length + 1) + TripletFullLength(parameters.Exponent.Length + 1);
		int num2 = TripletFullLength(num + 1);
		int length = TripletFullLength(num2 + OIDHeader.Length);
		binaryWriter.Write((byte)48);
		WriteTLVLength(binaryWriter, length);
		binaryWriter.Write(OIDHeader);
		binaryWriter.Write((byte)3);
		WriteTLVLength(binaryWriter, num2);
		binaryWriter.Write((byte)0);
		binaryWriter.Write((byte)48);
		WriteTLVLength(binaryWriter, num);
		binaryWriter.Write((byte)2);
		WriteTLVLength(binaryWriter, parameters.Modulus.Length + 1);
		binaryWriter.Write((byte)0);
		binaryWriter.Write(parameters.Modulus);
		binaryWriter.Write((byte)2);
		WriteTLVLength(binaryWriter, parameters.Exponent.Length + 1);
		binaryWriter.Write((byte)0);
		binaryWriter.Write(parameters.Exponent);
		return memoryStream.ToArray();
	}

	private static void WriteTLVLength(BinaryWriter writer, int length)
	{
		if (length < 128)
		{
			writer.Write((byte)length);
			return;
		}
		byte[] array = Enumerable.Reverse(BitConverter.GetBytes(length)).SkipWhile((byte b) => b == 0).ToArray();
		writer.Write((byte)(0x80 | array.Length));
		writer.Write(array);
	}

	private static int ReadTLVLength(Stream s)
	{
		byte b = s.ReadUInt8();
		if (b < 128)
		{
			return b;
		}
		Span<byte> span = stackalloc byte[4];
		s.ReadBytes(span.Slice(0, Math.Min(b & 0x7F, 4)));
		return BitConverter.ToInt32(span);
	}

	private static int TripletFullLength(int dataLength)
	{
		if (dataLength < 128)
		{
			return 2 + dataLength;
		}
		return 2 + dataLength + Enumerable.Reverse(BitConverter.GetBytes(dataLength)).SkipWhile((byte b) => b == 0).Count();
	}

	public static string DecryptString(RSAParameters parameters, string data)
	{
		try
		{
			using RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider();
			rSACryptoServiceProvider.ImportParameters(parameters);
			return Encoding.UTF8.GetString(rSACryptoServiceProvider.Decrypt(Convert.FromBase64String(data), fOAEP: false));
		}
		catch (Exception ex)
		{
			Log.Write("debug", "Failed to decrypt string with exception:");
			Log.Write("debug", ex);
			Console.WriteLine("String decryption failed:");
			Console.WriteLine(ex);
			return null;
		}
	}

	public static string Sign(RSAParameters parameters, string data)
	{
		return Sign(parameters, Encoding.UTF8.GetBytes(data));
	}

	public static string Sign(RSAParameters parameters, byte[] data)
	{
		try
		{
			using RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider();
			rSACryptoServiceProvider.ImportParameters(parameters);
			using SHA1 sHA = SHA1.Create();
			return Convert.ToBase64String(rSACryptoServiceProvider.SignHash(sHA.ComputeHash(data), CryptoConfig.MapNameToOID("SHA1")));
		}
		catch (Exception ex)
		{
			Log.Write("debug", "Failed to sign string with exception");
			Log.Write("debug", ex);
			Console.WriteLine("String signing failed:");
			Console.WriteLine(ex);
			return null;
		}
	}

	public static bool VerifySignature(RSAParameters parameters, string data, string signature)
	{
		return VerifySignature(parameters, Encoding.UTF8.GetBytes(data), signature);
	}

	public static bool VerifySignature(RSAParameters parameters, byte[] data, string signature)
	{
		try
		{
			using RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider();
			rSACryptoServiceProvider.ImportParameters(parameters);
			using SHA1 sHA = SHA1.Create();
			return rSACryptoServiceProvider.VerifyHash(sHA.ComputeHash(data), CryptoConfig.MapNameToOID("SHA1"), Convert.FromBase64String(signature));
		}
		catch (Exception ex)
		{
			Log.Write("debug", "Failed to verify signature with exception:");
			Log.Write("debug", ex);
			Console.WriteLine("Signature validation failed:");
			Console.WriteLine(ex);
			return false;
		}
	}

	public static string SHA1Hash(Stream data)
	{
		using SHA1 sHA = SHA1.Create();
		return ToHex(sHA.ComputeHash(data), lowerCase: true);
	}

	public static string SHA1Hash(byte[] data)
	{
		using SHA1 sHA = SHA1.Create();
		return ToHex(sHA.ComputeHash(data), lowerCase: true);
	}

	public static string SHA1Hash(string data)
	{
		return SHA1Hash(Encoding.UTF8.GetBytes(data));
	}

	public static string ToHex(ReadOnlySpan<byte> source, bool lowerCase = false)
	{
		if (source.Length == 0)
		{
			return string.Empty;
		}
		Span<char> span = ((source.Length > 256) ? ((Span<char>)new char[source.Length * 2]) : stackalloc char[source.Length * 2]);
		Span<char> buffer = span;
		return ToHexInternal(source, buffer, lowerCase);
	}

	private static string ToHexInternal(ReadOnlySpan<byte> source, Span<char> buffer, bool lowerCase)
	{
		int num = 0;
		char[] array = (lowerCase ? HexLowerAlphabet : HexUpperAlphabet);
		for (int i = 0; i < buffer.Length; i += 2)
		{
			byte b = source[num++];
			buffer[i] = array[b >> 4];
			buffer[i + 1] = array[b & 0xF];
		}
		return new string(buffer);
	}
}
