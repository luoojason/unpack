namespace OpenRA;

public class PlayerBitMask
{
}
