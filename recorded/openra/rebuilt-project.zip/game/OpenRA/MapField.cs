using System;
using System.Collections.Generic;
using System.Reflection;

namespace OpenRA;

internal sealed class MapField
{
	private enum Type
	{
		Normal,
		NodeList,
		MiniYaml
	}

	private readonly FieldInfo field;

	private readonly PropertyInfo property;

	private readonly Type type;

	private readonly string key;

	private readonly string fieldName;

	private readonly bool required;

	private readonly string ignoreIfValue;

	public MapField(string key, string fieldName = null, bool required = true, string ignoreIfValue = null)
	{
		this.key = key;
		this.fieldName = fieldName ?? key;
		this.required = required;
		this.ignoreIfValue = ignoreIfValue;
		field = typeof(Map).GetField(this.fieldName);
		property = typeof(Map).GetProperty(this.fieldName);
		if (field == null && property == null)
		{
			throw new InvalidOperationException("Map does not have a field/property " + fieldName);
		}
		System.Type type = ((field != null) ? field.FieldType : property.PropertyType);
		this.type = ((type == typeof(IReadOnlyCollection<MiniYamlNode>)) ? Type.NodeList : ((type == typeof(MiniYaml)) ? Type.MiniYaml : Type.Normal));
	}

	public void Deserialize(Map map, MiniYaml yaml)
	{
		MiniYamlNode miniYamlNode = yaml.NodeWithKeyOrDefault(key);
		if (miniYamlNode == null)
		{
			if (required)
			{
				throw new YamlException("Required field `" + key + "` not found in map.yaml");
			}
			return;
		}
		if (field != null)
		{
			if (type == Type.NodeList)
			{
				field.SetValue(map, miniYamlNode.Value.Nodes);
			}
			else if (type == Type.MiniYaml)
			{
				field.SetValue(map, miniYamlNode.Value);
			}
			else
			{
				FieldLoader.LoadField(map, fieldName, miniYamlNode.Value.Value);
			}
		}
		if (property != null)
		{
			if (type == Type.NodeList)
			{
				property.SetValue(map, miniYamlNode.Value.Nodes, null);
			}
			else if (type == Type.MiniYaml)
			{
				property.SetValue(map, miniYamlNode.Value, null);
			}
			else
			{
				FieldLoader.LoadField(map, fieldName, miniYamlNode.Value.Value);
			}
		}
	}

	public void Serialize(Map map, List<MiniYamlNode> nodes)
	{
		object obj = ((field != null) ? field.GetValue(map) : property.GetValue(map, null));
		if (type == Type.NodeList)
		{
			IReadOnlyCollection<MiniYamlNode> readOnlyCollection = (IReadOnlyCollection<MiniYamlNode>)obj;
			if (required || readOnlyCollection.Count > 0)
			{
				nodes.Add(new MiniYamlNode(key, null, readOnlyCollection));
			}
		}
		else if (type == Type.MiniYaml)
		{
			MiniYaml miniYaml = (MiniYaml)obj;
			if (required || (miniYaml != null && (miniYaml.Value != null || miniYaml.Nodes.Length > 0)))
			{
				nodes.Add(new MiniYamlNode(key, miniYaml));
			}
		}
		else
		{
			string text = FieldSaver.FormatValue(obj);
			if (required || text != ignoreIfValue)
			{
				nodes.Add(new MiniYamlNode(key, text));
			}
		}
	}
}
