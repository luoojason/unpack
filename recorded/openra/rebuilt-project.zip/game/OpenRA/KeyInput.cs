namespace OpenRA;

public struct KeyInput
{
	public KeyInputEvent Event;

	public Keycode Key;

	public Modifiers Modifiers;

	public int MultiTapCount;

	public char UnicodeChar;

	public bool IsRepeat;
}
