using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public static class FieldLoader
{
	[Serializable]
	public class MissingFieldsException : YamlException
	{
		public readonly string[] Missing;

		public readonly string Header;

		public override string Message => string.Concat(string.IsNullOrEmpty(Header) ? "" : (Header + ": "), Missing[0], string.Concat(from m in Missing.Skip(1)
			select ", " + m));

		public MissingFieldsException(string[] missing, string header = null, string headerSingle = null)
			: base(null)
		{
			Header = ((missing.Length > 1) ? header : (headerSingle ?? header));
			Missing = missing;
		}

		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("Missing", Missing);
			info.AddValue("Header", Header);
		}
	}

	public sealed class FieldLoadInfo
	{
		public readonly FieldInfo Field;

		public readonly SerializeAttribute Attribute;

		public readonly string YamlName;

		public readonly Func<MiniYaml, object> Loader;

		internal FieldLoadInfo(FieldInfo field, SerializeAttribute attr, string yamlName, Func<MiniYaml, object> loader = null)
		{
			Field = field;
			Attribute = attr;
			YamlName = yamlName;
			Loader = loader;
		}
	}

	[AttributeUsage(AttributeTargets.Field)]
	public sealed class IgnoreAttribute : SerializeAttribute
	{
		public IgnoreAttribute()
			: base(serialize: false)
		{
		}
	}

	[AttributeUsage(AttributeTargets.Field)]
	public sealed class RequireAttribute : SerializeAttribute
	{
		public RequireAttribute()
			: base(serialize: true, required: true)
		{
		}
	}

	[AttributeUsage(AttributeTargets.Field)]
	public sealed class AllowEmptyEntriesAttribute : SerializeAttribute
	{
		public AllowEmptyEntriesAttribute()
			: base(serialize: true, required: false, allowEmptyEntries: true)
		{
		}
	}

	[AttributeUsage(AttributeTargets.Field)]
	public sealed class LoadUsingAttribute : SerializeAttribute
	{
		public LoadUsingAttribute(string loader, bool required = false)
		{
			Loader = loader;
			Required = required;
		}
	}

	[AttributeUsage(AttributeTargets.Field)]
	public class SerializeAttribute : Attribute
	{
		public static readonly SerializeAttribute Default = new SerializeAttribute();

		public readonly bool Serialize;

		public string YamlName;

		public string Loader;

		public bool FromYamlKey;

		public bool DictionaryFromYamlKey;

		public bool Required;

		public bool AllowEmptyEntries;

		public bool IsDefault => this == Default;

		public SerializeAttribute(bool serialize = true, bool required = false, bool allowEmptyEntries = false)
		{
			Serialize = serialize;
			Required = required;
			AllowEmptyEntries = allowEmptyEntries;
		}

		internal Func<MiniYaml, object> GetLoader(Type type)
		{
			if (!string.IsNullOrEmpty(Loader))
			{
				MethodInfo method = type.GetMethod(Loader, BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
				if (method == null)
				{
					throw new InvalidOperationException(type.Name + " does not specify a loader function '" + Loader + "'");
				}
				return (Func<MiniYaml, object>)Delegate.CreateDelegate(typeof(Func<MiniYaml, object>), method);
			}
			return null;
		}
	}

	private const char SplitComma = ',';

	public static Func<string, Type, string, object> InvalidValueAction = (string s, Type t, string f) =>
	{
		throw new YamlException($"FieldLoader: Cannot parse `{s}` into `{f}.{t}` ");
	};

	public static Action<string, Type> UnknownFieldAction = (string s, Type f) =>
	{
		throw new NotImplementedException($"FieldLoader: Missing field `{s}` on `{f.Name}`");
	};

	private static readonly ConcurrentCache<Type, FieldLoadInfo[]> TypeLoadInfo = new ConcurrentCache<Type, FieldLoadInfo[]>(BuildTypeLoadInfo);

	private static readonly ConcurrentCache<string, BooleanExpression> BooleanExpressionCache = new ConcurrentCache<string, BooleanExpression>((string expression) => new BooleanExpression(expression));

	private static readonly ConcurrentCache<string, IntegerExpression> IntegerExpressionCache = new ConcurrentCache<string, IntegerExpression>((string expression) => new IntegerExpression(expression));

	private static readonly Dictionary<Type, Func<string, Type, string, MemberInfo, object>> TypeParsers = new Dictionary<Type, Func<string, Type, string, MemberInfo, object>>
	{
		{
			typeof(int),
			ParseInt
		},
		{
			typeof(ushort),
			ParseUShort
		},
		{
			typeof(long),
			ParseLong
		},
		{
			typeof(float),
			ParseFloat
		},
		{
			typeof(decimal),
			ParseDecimal
		},
		{
			typeof(string),
			ParseString
		},
		{
			typeof(Color),
			ParseColor
		},
		{
			typeof(Hotkey),
			ParseHotkey
		},
		{
			typeof(HotkeyReference),
			ParseHotkeyReference
		},
		{
			typeof(WDist),
			ParseWDist
		},
		{
			typeof(WVec),
			ParseWVec
		},
		{
			typeof(WVec[]),
			ParseWVecArray
		},
		{
			typeof(WPos),
			ParseWPos
		},
		{
			typeof(WAngle),
			ParseWAngle
		},
		{
			typeof(WRot),
			ParseWRot
		},
		{
			typeof(CPos),
			ParseCPos
		},
		{
			typeof(CPos[]),
			ParseCPosArray
		},
		{
			typeof(CVec),
			ParseCVec
		},
		{
			typeof(CVec[]),
			ParseCVecArray
		},
		{
			typeof(BooleanExpression),
			ParseBooleanExpression
		},
		{
			typeof(IntegerExpression),
			ParseIntegerExpression
		},
		{
			typeof(Enum),
			ParseEnum
		},
		{
			typeof(bool),
			ParseBool
		},
		{
			typeof(int2[]),
			ParseInt2Array
		},
		{
			typeof(Size),
			ParseSize
		},
		{
			typeof(int2),
			ParseInt2
		},
		{
			typeof(float2),
			ParseFloat2
		},
		{
			typeof(float3),
			ParseFloat3
		},
		{
			typeof(Rectangle),
			ParseRectangle
		},
		{
			typeof(DateTime),
			ParseDateTime
		}
	};

	private static readonly Dictionary<Type, Func<string, Type, string, MiniYaml, MemberInfo, object>> GenericTypeParsers = new Dictionary<Type, Func<string, Type, string, MiniYaml, MemberInfo, object>>
	{
		{
			typeof(HashSet<>),
			ParseHashSetOrList
		},
		{
			typeof(List<>),
			ParseHashSetOrList
		},
		{
			typeof(Dictionary<, >),
			ParseDictionary
		},
		{
			typeof(BitSet<>),
			ParseBitSet
		},
		{
			typeof(Nullable<>),
			ParseNullable
		}
	};

	private static readonly object BoxedTrue = true;

	private static readonly object BoxedFalse = false;

	private static readonly object[] BoxedInts = Exts.MakeArray(33, (Func<int, object>)((int i) => i));

	private static object ParseInt(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (Exts.TryParseInt32Invariant(value, out var i))
		{
			if (i >= 0 && i < BoxedInts.Length)
			{
				return BoxedInts[i];
			}
			return i;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseUShort(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (ushort.TryParse(value, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out var result))
		{
			return result;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseLong(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (long.TryParse(value, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out var result))
		{
			return result;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseFloat(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null && float.TryParse(value.Replace("%", ""), NumberStyles.Float, NumberFormatInfo.InvariantInfo, out var result))
		{
			return result * (value.Contains('%') ? 0.01f : 1f);
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseDecimal(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null && decimal.TryParse(value.Replace("%", ""), NumberStyles.Float, NumberFormatInfo.InvariantInfo, out var result))
		{
			return result * (value.Contains('%') ? 0.01m : 1m);
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseString(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		return value;
	}

	private static object ParseColor(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null && Color.TryParse(value, out var color))
		{
			return color;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseHotkey(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (Hotkey.TryParse(value, out var result))
		{
			return result;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseHotkeyReference(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		return Game.ModData.Hotkeys[value];
	}

	private static object ParseWDist(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (WDist.TryParse(value, out var result))
		{
			return result;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseWVec(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',');
			if (array.Length == 3 && WDist.TryParse(array[0], out var result) && WDist.TryParse(array[1], out var result2) && WDist.TryParse(array[2], out var result3))
			{
				return new WVec(result, result2, result3);
			}
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseWVecArray(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',');
			if (array.Length % 3 != 0)
			{
				return InvalidValueAction(value, fieldType, fieldName);
			}
			WVec[] array2 = new WVec[array.Length / 3];
			for (int i = 0; i < array2.Length; i++)
			{
				if (WDist.TryParse(array[3 * i], out var result) && WDist.TryParse(array[3 * i + 1], out var result2) && WDist.TryParse(array[3 * i + 2], out var result3))
				{
					array2[i] = new WVec(result, result2, result3);
				}
			}
			return array2;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseWPos(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',');
			if (array.Length == 3 && WDist.TryParse(array[0], out var result) && WDist.TryParse(array[1], out var result2) && WDist.TryParse(array[2], out var result3))
			{
				return new WPos(result, result2, result3);
			}
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseWAngle(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (Exts.TryParseInt32Invariant(value, out var i))
		{
			return new WAngle(i);
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseWRot(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',');
			if (array.Length == 3 && Exts.TryParseInt32Invariant(array[0], out var i) && Exts.TryParseInt32Invariant(array[1], out var i2) && Exts.TryParseInt32Invariant(array[2], out var i3))
			{
				return new WRot(new WAngle(i), new WAngle(i2), new WAngle(i3));
			}
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseCPos(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			if (array.Length == 3)
			{
				return new CPos(Exts.ParseInt32Invariant(array[0]), Exts.ParseInt32Invariant(array[1]), Exts.ParseByteInvariant(array[2]));
			}
			return new CPos(Exts.ParseInt32Invariant(array[0]), Exts.ParseInt32Invariant(array[1]));
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseCPosArray(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',');
			if (array.Length % 2 != 0)
			{
				return InvalidValueAction(value, fieldType, fieldName);
			}
			CPos[] array2 = new CPos[array.Length / 2];
			for (int i = 0; i < array2.Length; i++)
			{
				if (int.TryParse(array[2 * i], out var result) && int.TryParse(array[2 * i + 1], out var result2))
				{
					array2[i] = new CPos(result, result2);
				}
			}
			return array2;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseCVec(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			return new CVec(Exts.ParseInt32Invariant(array[0]), Exts.ParseInt32Invariant(array[1]));
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseCVecArray(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',');
			if (array.Length % 2 != 0)
			{
				return InvalidValueAction(value, fieldType, fieldName);
			}
			CVec[] array2 = new CVec[array.Length / 2];
			for (int i = 0; i < array2.Length; i++)
			{
				if (int.TryParse(array[2 * i], out var result) && int.TryParse(array[2 * i + 1], out var result2))
				{
					array2[i] = new CVec(result, result2);
				}
			}
			return array2;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseBooleanExpression(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			try
			{
				return BooleanExpressionCache[value];
			}
			catch (InvalidDataException ex)
			{
				throw new YamlException(ex.Message);
			}
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseIntegerExpression(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			try
			{
				return IntegerExpressionCache[value];
			}
			catch (InvalidDataException ex)
			{
				throw new YamlException(ex.Message);
			}
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseEnum(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		try
		{
			return Enum.Parse(fieldType, value, ignoreCase: true);
		}
		catch (ArgumentException)
		{
			return InvalidValueAction(value, fieldType, fieldName);
		}
	}

	private static object ParseBool(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (bool.TryParse(value.ToLowerInvariant(), out var result))
		{
			if (!result)
			{
				return BoxedFalse;
			}
			return BoxedTrue;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseInt2Array(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			if (array.Length % 2 != 0)
			{
				return InvalidValueAction(value, fieldType, fieldName);
			}
			int2[] array2 = new int2[array.Length / 2];
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i] = new int2(Exts.ParseInt32Invariant(array[2 * i]), Exts.ParseInt32Invariant(array[2 * i + 1]));
			}
			return array2;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseSize(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			return new Size(Exts.ParseInt32Invariant(array[0]), Exts.ParseInt32Invariant(array[1]));
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseInt2(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			if (array.Length != 2)
			{
				return InvalidValueAction(value, fieldType, fieldName);
			}
			return new int2(Exts.ParseInt32Invariant(array[0]), Exts.ParseInt32Invariant(array[1]));
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseFloat2(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			float x = 0f;
			float y = 0f;
			if (float.TryParse(array[0].Replace("%", ""), NumberStyles.Float, NumberFormatInfo.InvariantInfo, out var result))
			{
				x = result * (array[0].Contains('%') ? 0.01f : 1f);
			}
			if (float.TryParse(array[1].Replace("%", ""), NumberStyles.Float, NumberFormatInfo.InvariantInfo, out result))
			{
				y = result * (array[1].Contains('%') ? 0.01f : 1f);
			}
			return new float2(x, y);
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseFloat3(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			float.TryParse(array[0], NumberStyles.Float, NumberFormatInfo.InvariantInfo, out var result);
			float.TryParse(array[1], NumberStyles.Float, NumberFormatInfo.InvariantInfo, out var result2);
			float result3 = 0f;
			if (array.Length > 2)
			{
				float.TryParse(array[2], NumberStyles.Float, NumberFormatInfo.InvariantInfo, out result3);
			}
			return new float3(result, result2, result3);
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseRectangle(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (value != null)
		{
			string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			return new Rectangle(Exts.ParseInt32Invariant(array[0]), Exts.ParseInt32Invariant(array[1]), Exts.ParseInt32Invariant(array[2]), Exts.ParseInt32Invariant(array[3]));
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseDateTime(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		if (DateTime.TryParseExact(value, "yyyy-MM-dd HH-mm-ss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var result))
		{
			return result;
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseHashSetOrList(string fieldName, Type fieldType, string value, MiniYaml yaml, MemberInfo field)
	{
		if (value == null)
		{
			return Activator.CreateInstance(fieldType);
		}
		string[] array = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
		object obj = Activator.CreateInstance(fieldType, array.Length);
		Type[] genericArguments = fieldType.GetGenericArguments();
		MethodInfo method = fieldType.GetMethod("Add", genericArguments);
		object[] array2 = new object[1];
		for (int i = 0; i < array.Length; i++)
		{
			array2[0] = GetValue(fieldName, genericArguments[0], array[i].Trim(), field);
			method.Invoke(obj, array2);
		}
		return obj;
	}

	private static object ParseDictionary(string fieldName, Type fieldType, string value, MiniYaml yaml, MemberInfo field)
	{
		if (yaml == null)
		{
			return Activator.CreateInstance(fieldType);
		}
		object obj = Activator.CreateInstance(fieldType, yaml.Nodes.Length);
		Type[] genericArguments = fieldType.GetGenericArguments();
		MethodInfo method = fieldType.GetMethod("Add", genericArguments);
		object[] array = new object[2];
		foreach (MiniYamlNode node in yaml.Nodes)
		{
			array[0] = GetValue(fieldName, genericArguments[0], node.Key, field);
			array[1] = GetValue(fieldName, genericArguments[1], node.Value, field);
			method.Invoke(obj, array);
		}
		return obj;
	}

	private static object ParseBitSet(string fieldName, Type fieldType, string value, MiniYaml yaml, MemberInfo field)
	{
		if (value != null)
		{
			string[] source = value.Split(',', StringSplitOptions.RemoveEmptyEntries);
			ConstructorInfo constructor = fieldType.GetConstructor(new Type[1] { typeof(string[]) });
			return constructor.Invoke(new object[1] { source.Select((string p) => p.Trim()).ToArray() });
		}
		return InvalidValueAction(value, fieldType, fieldName);
	}

	private static object ParseNullable(string fieldName, Type fieldType, string value, MiniYaml yaml, MemberInfo field)
	{
		if (string.IsNullOrEmpty(value))
		{
			return null;
		}
		Type type = fieldType.GetGenericArguments()[0];
		object value2 = GetValue("Nullable<T>", type, value, field);
		return fieldType.GetConstructor(new Type[1] { type }).Invoke(new object[1] { value2 });
	}

	public static void Load(object self, MiniYaml my)
	{
		FieldLoadInfo[] array = TypeLoadInfo[self.GetType()];
		List<string> list = null;
		Dictionary<string, MiniYaml> dictionary = null;
		FieldLoadInfo[] array2 = array;
		foreach (FieldLoadInfo fieldLoadInfo in array2)
		{
			if (dictionary == null)
			{
				dictionary = my.ToDictionary();
			}
			object ret;
			if (fieldLoadInfo.Loader != null)
			{
				if (fieldLoadInfo.Attribute.Required && !dictionary.ContainsKey(fieldLoadInfo.YamlName))
				{
					if (list == null)
					{
						list = new List<string>();
					}
					list.Add(fieldLoadInfo.YamlName);
					continue;
				}
				ret = fieldLoadInfo.Loader(my);
			}
			else if (!TryGetValueFromYaml(fieldLoadInfo.YamlName, fieldLoadInfo.Field, dictionary, out ret))
			{
				if (fieldLoadInfo.Attribute.Required)
				{
					if (list == null)
					{
						list = new List<string>();
					}
					list.Add(fieldLoadInfo.YamlName);
				}
				continue;
			}
			fieldLoadInfo.Field.SetValue(self, ret);
		}
		if (list != null)
		{
			throw new MissingFieldsException(list.ToArray());
		}
	}

	private static bool TryGetValueFromYaml(string yamlName, FieldInfo field, Dictionary<string, MiniYaml> md, out object ret)
	{
		ret = null;
		if (!md.TryGetValue(yamlName, out var value))
		{
			return false;
		}
		ret = GetValue(field.Name, field.FieldType, value, field);
		return true;
	}

	public static T Load<T>(MiniYaml y) where T : new()
	{
		T val = new T();
		Load(val, y);
		return val;
	}

	public static void LoadField(object target, string key, string value)
	{
		key = key.Trim();
		FieldInfo field = target.GetType().GetField(key, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		if (field != null)
		{
			SerializeAttribute serializeAttribute = field.GetCustomAttributes<SerializeAttribute>(inherit: false).DefaultIfEmpty(SerializeAttribute.Default).First();
			if (!serializeAttribute.FromYamlKey)
			{
				field.SetValue(target, GetValue(field.Name, field.FieldType, value, field));
			}
			return;
		}
		PropertyInfo property = target.GetType().GetProperty(key, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		if (property != null)
		{
			SerializeAttribute serializeAttribute2 = property.GetCustomAttributes<SerializeAttribute>(inherit: false).DefaultIfEmpty(SerializeAttribute.Default).First();
			if (!serializeAttribute2.FromYamlKey)
			{
				property.SetValue(target, GetValue(property.Name, property.PropertyType, value, property), null);
			}
		}
		else
		{
			UnknownFieldAction(key, target.GetType());
		}
	}

	public static T GetValue<T>(string field, string value)
	{
		return (T)GetValue(field, typeof(T), value, null);
	}

	public static object GetValue(string fieldName, Type fieldType, string value)
	{
		return GetValue(fieldName, fieldType, value, null);
	}

	public static object GetValue(string fieldName, Type fieldType, string value, MemberInfo field)
	{
		return GetValue(fieldName, fieldType, value, null, field);
	}

	public static object GetValue(string fieldName, Type fieldType, MiniYaml yaml, MemberInfo field)
	{
		return GetValue(fieldName, fieldType, yaml.Value, yaml, field);
	}

	private static object GetValue(string fieldName, Type fieldType, string value, MiniYaml yaml, MemberInfo field)
	{
		value = value?.Trim();
		if (fieldType.IsGenericType)
		{
			if (GenericTypeParsers.TryGetValue(fieldType.GetGenericTypeDefinition(), out var value2))
			{
				return value2(fieldName, fieldType, value, yaml, field);
			}
		}
		else
		{
			if (TypeParsers.TryGetValue(fieldType, out var value3))
			{
				return value3(fieldName, fieldType, value, field);
			}
			if (fieldType.IsArray && fieldType.GetArrayRank() == 1)
			{
				if (value == null)
				{
					return Array.CreateInstance(fieldType.GetElementType(), 0);
				}
				StringSplitOptions options = ((!(field != null) || !field.HasAttribute<AllowEmptyEntriesAttribute>()) ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None);
				string[] array = value.Split(',', options);
				Array array2 = Array.CreateInstance(fieldType.GetElementType(), array.Length);
				for (int i = 0; i < array.Length; i++)
				{
					array2.SetValue(GetValue(fieldName, fieldType.GetElementType(), array[i].Trim(), field), i);
				}
				return array2;
			}
		}
		TypeConverter converter = TypeDescriptor.GetConverter(fieldType);
		if (converter.CanConvertFrom(typeof(string)))
		{
			try
			{
				return converter.ConvertFromInvariantString(value);
			}
			catch
			{
				return InvalidValueAction(value, fieldType, fieldName);
			}
		}
		UnknownFieldAction("[Type] " + value, fieldType);
		return null;
	}

	public static IEnumerable<FieldLoadInfo> GetTypeLoadInfo(Type type, bool includePrivateByDefault = false)
	{
		return TypeLoadInfo[type].Where((FieldLoadInfo fli) => includePrivateByDefault || fli.Field.IsPublic || (fli.Attribute.Serialize && !fli.Attribute.IsDefault));
	}

	private static FieldLoadInfo[] BuildTypeLoadInfo(Type type)
	{
		List<FieldLoadInfo> list = new List<FieldLoadInfo>();
		FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		foreach (FieldInfo fieldInfo in fields)
		{
			FieldInfo field = fieldInfo;
			SerializeAttribute serializeAttribute = field.GetCustomAttributes<SerializeAttribute>(inherit: false).DefaultIfEmpty(SerializeAttribute.Default).First();
			if (!serializeAttribute.Serialize)
			{
				continue;
			}
			string yamlName = (string.IsNullOrEmpty(serializeAttribute.YamlName) ? field.Name : serializeAttribute.YamlName);
			Func<MiniYaml, object> func = serializeAttribute.GetLoader(type);
			if (func == null && serializeAttribute.FromYamlKey)
			{
				func = (MiniYaml yaml) => GetValue(yamlName, field.FieldType, yaml, field);
			}
			FieldLoadInfo item = new FieldLoadInfo(field, serializeAttribute, yamlName, func);
			list.Add(item);
		}
		return list.ToArray();
	}
}
