using System;
using System.Buffers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace OpenRA;

public static class StreamExts
{
	public static void ReadBytes(this Stream s, Span<byte> dest)
	{
		while (dest.Length > 0)
		{
			int num = s.Read(dest);
			if (num == 0)
			{
				throw new EndOfStreamException();
			}
			dest = dest.Slice(num);
		}
	}

	public static byte[] ReadBytes(this Stream s, int count)
	{
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count", "Non-negative number required.");
		}
		byte[] array = new byte[count];
		s.ReadBytes(array, 0, count);
		return array;
	}

	public static void ReadBytes(this Stream s, byte[] buffer, int offset, int count)
	{
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count", "Non-negative number required.");
		}
		while (count > 0)
		{
			int num = s.Read(buffer, offset, count);
			if (num == 0)
			{
				throw new EndOfStreamException();
			}
			offset += num;
			count -= num;
		}
	}

	public static int Peek(this Stream s)
	{
		int num = s.ReadByte();
		if (num == -1)
		{
			return -1;
		}
		s.Seek(-1L, SeekOrigin.Current);
		return (byte)num;
	}

	public static byte ReadUInt8(this Stream s)
	{
		int num = s.ReadByte();
		if (num == -1)
		{
			throw new EndOfStreamException();
		}
		return (byte)num;
	}

	public static ushort ReadUInt16(this Stream s)
	{
		Span<byte> span = stackalloc byte[2];
		s.ReadBytes(span);
		return BitConverter.ToUInt16(span);
	}

	public static short ReadInt16(this Stream s)
	{
		Span<byte> span = stackalloc byte[2];
		s.ReadBytes(span);
		return BitConverter.ToInt16(span);
	}

	public static uint ReadUInt32(this Stream s)
	{
		Span<byte> span = stackalloc byte[4];
		s.ReadBytes(span);
		return BitConverter.ToUInt32(span);
	}

	public static int ReadInt32(this Stream s)
	{
		Span<byte> span = stackalloc byte[4];
		s.ReadBytes(span);
		return BitConverter.ToInt32(span);
	}

	public static void Write(this Stream s, int value)
	{
		Span<byte> span = stackalloc byte[4];
		BitConverter.TryWriteBytes(span, value);
		s.Write(span);
	}

	public static void Write(this Stream s, long value)
	{
		Span<byte> span = stackalloc byte[8];
		BitConverter.TryWriteBytes(span, value);
		s.Write(span);
	}

	public static void Write(this Stream s, ulong value)
	{
		Span<byte> span = stackalloc byte[8];
		BitConverter.TryWriteBytes(span, value);
		s.Write(span);
	}

	public static void Write(this Stream s, float value)
	{
		Span<byte> span = stackalloc byte[4];
		BitConverter.TryWriteBytes(span, value);
		s.Write(span);
	}

	public static float ReadSingle(this Stream s)
	{
		Span<byte> span = stackalloc byte[4];
		s.ReadBytes(span);
		return BitConverter.ToSingle(span);
	}

	public static double ReadDouble(this Stream s)
	{
		Span<byte> span = stackalloc byte[8];
		s.ReadBytes(span);
		return BitConverter.ToDouble(span);
	}

	public static string ReadASCII(this Stream s, int length)
	{
		Span<byte> span = ((length >= 128) ? ((Span<byte>)new byte[length]) : stackalloc byte[length]);
		Span<byte> span2 = span;
		s.ReadBytes(span2);
		return Encoding.ASCII.GetString(span2);
	}

	public static string ReadASCIIZ(this Stream s)
	{
		List<byte> list = new List<byte>();
		byte item;
		while ((item = s.ReadUInt8()) != 0)
		{
			list.Add(item);
		}
		return Encoding.ASCII.GetString(CollectionsMarshal.AsSpan(list));
	}

	public static string ReadAllText(this Stream s)
	{
		using (s)
		{
			using StreamReader streamReader = new StreamReader(s);
			return streamReader.ReadToEnd();
		}
	}

	public static byte[] ReadAllBytes(this Stream s)
	{
		using (s)
		{
			if (s.CanSeek)
			{
				return s.ReadBytes((int)(s.Length - s.Position));
			}
			List<byte> list = new List<byte>();
			byte[] array = new byte[1024];
			int count;
			while ((count = s.Read(array, 0, array.Length)) > 0)
			{
				list.AddRange(array.Take(count));
			}
			return list.ToArray();
		}
	}

	public static IEnumerable<string> ReadAllLines(this Stream s)
	{
		using StreamReader sr = new StreamReader(s);
		string text;
		while ((text = sr.ReadLine()) != null)
		{
			yield return text;
		}
	}

	public static IEnumerable<ReadOnlyMemory<char>> ReadAllLinesAsMemory(this Stream s)
	{
		char[] buffer = ArrayPool<char>.Shared.Rent(128);
		try
		{
			using StreamReader sr = new StreamReader(s);
			int offset = 0;
			int num;
			while ((num = sr.ReadBlock(buffer, offset, buffer.Length - offset)) != 0)
			{
				offset += num;
				int num2 = 0;
				while (true)
				{
					int num3;
					int newlineIndex = (num3 = Array.IndexOf(buffer, '\n', offset - num, num));
					if (num3 == -1)
					{
						break;
					}
					if (newlineIndex > 0 && buffer[newlineIndex - 1] == '\r')
					{
						yield return buffer.AsMemory(num2, newlineIndex - num2 - 1);
					}
					else
					{
						yield return buffer.AsMemory(num2, newlineIndex - num2);
					}
					int num4 = newlineIndex + 1;
					num = offset - num4;
					num2 = num4;
				}
				if (num2 > 0)
				{
					Array.Copy(buffer, num2, buffer, 0, offset - num2);
					offset = num;
				}
				if (offset == buffer.Length)
				{
					char[] array = ArrayPool<char>.Shared.Rent(buffer.Length * 2);
					Array.Copy(buffer, array, buffer.Length);
					ArrayPool<char>.Shared.Return(buffer);
					buffer = array;
				}
			}
			if (offset > 0)
			{
				yield return buffer.AsMemory(0, offset);
			}
		}
		finally
		{
			ArrayPool<char>.Shared.Return(buffer);
		}
	}

	public static string ReadLengthPrefixedString(this Stream s, Encoding encoding, int maxLength)
	{
		int num = s.ReadInt32();
		if (num > maxLength)
		{
			throw new InvalidOperationException($"The length of the string ({num}) is longer than the maximum allowed ({maxLength}).");
		}
		Span<byte> span = ((num >= 128) ? ((Span<byte>)new byte[num]) : stackalloc byte[num]);
		Span<byte> span2 = span;
		s.ReadBytes(span2);
		return encoding.GetString(span2);
	}

	public static int WriteLengthPrefixedString(this Stream s, Encoding encoding, string text)
	{
		byte[] array = (string.IsNullOrEmpty(text) ? Array.Empty<byte>() : encoding.GetBytes(text));
		s.Write(array.Length);
		s.Write(array);
		return 4 + array.Length;
	}
}
