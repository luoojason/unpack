namespace OpenRA;

public interface IGlobalModData
{
}
