using System.Reflection;
using OpenRA.Traits;

namespace OpenRA;

public abstract class ValueActorInit<T> : ActorInit
{
	private readonly T value;

	public virtual T Value => value;

	protected ValueActorInit(TraitInfo info, T value)
		: base(info.InstanceName)
	{
		this.value = value;
	}

	protected ValueActorInit(string instanceName, T value)
		: base(instanceName)
	{
		this.value = value;
	}

	protected ValueActorInit(T value)
	{
		this.value = value;
	}

	public virtual void Initialize(MiniYaml yaml)
	{
		Initialize(FieldLoader.GetValue<T>("value", yaml.Value));
	}

	public virtual void Initialize(T value)
	{
		typeof(ValueActorInit<T>).GetField("value", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(this, value);
	}

	public override MiniYaml Save()
	{
		return new MiniYaml(FieldSaver.FormatValue(value));
	}
}
