using System.Collections.Generic;
using OpenRA.Primitives;

namespace OpenRA;

public interface ITerrainInfo
{
	string Id { get; }

	TerrainTypeInfo[] TerrainTypes { get; }

	TerrainTile DefaultTerrainTile { get; }

	Color[] HeightDebugColors { get; }

	IEnumerable<Color> RestrictedPlayerColors { get; }

	float MinHeightColorBrightness { get; }

	float MaxHeightColorBrightness { get; }

	TerrainTileInfo GetTerrainInfo(TerrainTile r);

	bool TryGetTerrainInfo(TerrainTile r, out TerrainTileInfo info);

	byte GetTerrainIndex(string type);

	byte GetTerrainIndex(TerrainTile r);
}
