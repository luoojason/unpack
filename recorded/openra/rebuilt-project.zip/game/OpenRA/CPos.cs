using System;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Scripting;

namespace OpenRA;

public readonly struct CPos : IEquatable<CPos>, IScriptBindable, ILuaAdditionBinding, ILuaSubtractionBinding, ILuaEqualityBinding, ILuaTableBinding, ILuaToStringBinding
{
	public readonly int Bits;

	public static readonly CPos Zero = new CPos(0, 0, 0);

	public int X => Bits >> 20;

	public int Y => (short)(Bits >> 4) >> 4;

	public byte Layer => (byte)Bits;

	public LuaValue this[LuaRuntime runtime, LuaValue key]
	{
		get
		{
			return key.ToString() switch
			{
				"X" => (LuaValue)X, 
				"Y" => Y, 
				"Layer" => (int)Layer, 
				_ => throw new LuaException($"CPos does not define a member '{key}'"), 
			};
		}
		set
		{
			throw new LuaException("CPos is read-only. Use CPos.New to create a new value");
		}
	}

	public CPos(int bits)
	{
		Bits = bits;
	}

	public CPos(int x, int y)
		: this(x, y, 0)
	{
	}

	public CPos(int x, int y, byte layer)
	{
		Bits = ((x & 0xFFF) << 20) | ((y & 0xFFF) << 8) | layer;
	}

	public static explicit operator CPos(int2 a)
	{
		return new CPos(a.X, a.Y);
	}

	public static CPos operator +(CVec a, CPos b)
	{
		return new CPos(a.X + b.X, a.Y + b.Y, b.Layer);
	}

	public static CPos operator +(CPos a, CVec b)
	{
		return new CPos(a.X + b.X, a.Y + b.Y, a.Layer);
	}

	public static CPos operator -(CPos a, CVec b)
	{
		return new CPos(a.X - b.X, a.Y - b.Y, a.Layer);
	}

	public static CVec operator -(CPos a, CPos b)
	{
		return new CVec(a.X - b.X, a.Y - b.Y);
	}

	public static bool operator ==(CPos me, CPos other)
	{
		return me.Bits == other.Bits;
	}

	public static bool operator !=(CPos me, CPos other)
	{
		return !(me == other);
	}

	public override int GetHashCode()
	{
		return Bits.GetHashCode();
	}

	public bool Equals(CPos other)
	{
		return Bits == other.Bits;
	}

	public override bool Equals(object obj)
	{
		if (obj is CPos other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		if (Layer == 0)
		{
			return X + "," + Y;
		}
		return X + "," + Y + "," + Layer;
	}

	public MPos ToMPos(Map map)
	{
		return ToMPos(map.Grid.Type);
	}

	public MPos ToMPos(MapGridType gridType)
	{
		if (gridType == MapGridType.Rectangular)
		{
			return new MPos(X, Y);
		}
		int u = (X - Y) / 2;
		int v = X + Y;
		return new MPos(u, v);
	}

	public LuaValue Add(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CPos>(out var clrObject) || !right.TryGetClrValue<CVec>(out var clrObject2))
		{
			throw new LuaException("Attempted to call CPos.Add(CPos, CVec) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject + clrObject2);
	}

	public LuaValue Subtract(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		Type type = right.WrappedClrType();
		if (!left.TryGetClrValue<CPos>(out var clrObject))
		{
			throw new LuaException("Attempted to call CPos.Subtract(CPos, (CPos|CVec)) with invalid arguments " + $"({left.WrappedClrType().Name}, {type.Name})");
		}
		if (type == typeof(CPos))
		{
			right.TryGetClrValue<CPos>(out var clrObject2);
			return new LuaCustomClrObject(clrObject - clrObject2);
		}
		if (type == typeof(CVec))
		{
			right.TryGetClrValue<CVec>(out var clrObject3);
			return new LuaCustomClrObject(clrObject - clrObject3);
		}
		throw new LuaException("Attempted to call CPos.Subtract(CPos, (CPos|CVec)) with invalid arguments " + $"({left.WrappedClrType().Name}, {type.Name})");
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<CPos>(out var clrObject) || !right.TryGetClrValue<CPos>(out var clrObject2))
		{
			return false;
		}
		return clrObject == clrObject2;
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return ToString();
	}
}
