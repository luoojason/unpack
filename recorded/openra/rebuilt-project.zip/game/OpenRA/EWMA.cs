namespace OpenRA;

public class EWMA
{
	private readonly float animRate;

	private float? value;

	public EWMA(float animRate)
	{
		this.animRate = animRate;
	}

	public float Update(float newValue)
	{
		value = float2.Lerp(value ?? newValue, newValue, animRate);
		return value.Value;
	}
}
