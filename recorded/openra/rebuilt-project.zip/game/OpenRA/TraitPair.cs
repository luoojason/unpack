using System;

namespace OpenRA;

public readonly struct TraitPair<T>(Actor actor, T trait) : IEquatable<TraitPair<T>>
{
	public readonly Actor Actor = actor;

	public readonly T Trait = trait;

	public static bool operator ==(TraitPair<T> me, TraitPair<T> other)
	{
		if (me.Actor == other.Actor)
		{
			return object.Equals(me.Trait, other.Trait);
		}
		return false;
	}

	public static bool operator !=(TraitPair<T> me, TraitPair<T> other)
	{
		return !(me == other);
	}

	public override int GetHashCode()
	{
		return Actor.GetHashCode() ^ Trait.GetHashCode();
	}

	public bool Equals(TraitPair<T> other)
	{
		return this == other;
	}

	public override bool Equals(object obj)
	{
		if (obj is TraitPair<T> other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return Actor.Info.Name + "->" + Trait.GetType().Name;
	}
}
