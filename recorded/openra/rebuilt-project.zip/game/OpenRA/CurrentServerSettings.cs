using OpenRA.Network;

namespace OpenRA;

public static class CurrentServerSettings
{
	public static string Password;

	public static ConnectionTarget Target;

	public static ExternalMod ServerExternalMod;
}
