using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA;

public class ActorInfoDictionary : IReadOnlyDictionary<string, ActorInfo>, IEnumerable<KeyValuePair<string, ActorInfo>>, IEnumerable, IReadOnlyCollection<KeyValuePair<string, ActorInfo>>
{
	private readonly Dictionary<string, ActorInfo> dict;

	public int Count => dict.Count;

	public ActorInfo this[string key] => dict[key];

	public ActorInfo this[SystemActors key] => dict[key.ToString().ToLowerInvariant()];

	IEnumerable<string> IReadOnlyDictionary<string, ActorInfo>.Keys => dict.Keys;

	IEnumerable<ActorInfo> IReadOnlyDictionary<string, ActorInfo>.Values => dict.Values;

	public ICollection<string> Keys => dict.Keys;

	public ICollection<ActorInfo> Values => dict.Values;

	public ActorInfoDictionary(IReadOnlyDictionary<string, ActorInfo> dict)
	{
		if (dict == null)
		{
			throw new ArgumentNullException("dict");
		}
		this.dict = new Dictionary<string, ActorInfo>(dict);
	}

	public bool ContainsKey(string key)
	{
		return dict.ContainsKey(key);
	}

	public bool TryGetValue(string key, out ActorInfo value)
	{
		return dict.TryGetValue(key, out value);
	}

	public IEnumerator<KeyValuePair<string, ActorInfo>> GetEnumerator()
	{
		return dict.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return dict.GetEnumerator();
	}
}
