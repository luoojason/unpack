using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Network;
using OpenRA.Primitives;

namespace OpenRA;

public class GameInformation
{
	public class Player
	{
		public int ClientIndex;

		public string Name;

		public bool IsHuman;

		public bool IsBot;

		public string BotType;

		public string FactionName;

		public string FactionId;

		public Color Color;

		public string DisplayFactionName;

		public string DisplayFactionId;

		public int Team;

		public int SpawnPoint;

		public int Handicap;

		public bool IsRandomFaction;

		public bool IsRandomSpawnPoint;

		public string Fingerprint;

		public WinState Outcome;

		public DateTime OutcomeTimestampUtc;

		public int DisconnectFrame;
	}

	[FluentReference(new string[] { "name", "number" })]
	private const string EnumeratedBotName = "enumerated-bot-name";

	public string Mod;

	public string Version;

	public string MapUid;

	public string MapTitle;

	public int FinalGameTick;

	public DateTime StartTimeUtc;

	public DateTime EndTimeUtc;

	public HashSet<int> DisabledSpawnPoints = new HashSet<int>();

	private readonly Dictionary<OpenRA.Player, Player> playersByRuntime;

	public TimeSpan Duration
	{
		get
		{
			if (!(EndTimeUtc > StartTimeUtc))
			{
				return TimeSpan.Zero;
			}
			return EndTimeUtc - StartTimeUtc;
		}
	}

	public IList<Player> Players { get; }

	public MapPreview MapPreview => Game.ModData.MapCache[MapUid];

	public IEnumerable<Player> HumanPlayers => Players.Where((Player p) => p.IsHuman);

	public bool IsSinglePlayer => HumanPlayers.Count() == 1;

	public GameInformation()
	{
		Players = new List<Player>();
		playersByRuntime = new Dictionary<OpenRA.Player, Player>();
	}

	public static GameInformation Deserialize(string data, string path)
	{
		try
		{
			GameInformation gameInformation = new GameInformation();
			List<MiniYamlNode> list = MiniYaml.FromString(data, path);
			foreach (MiniYamlNode item in list)
			{
				string[] array = item.Key.Split('@');
				string text = array[0];
				if (!(text == "Root"))
				{
					if (text == "Player")
					{
						gameInformation.Players.Add(FieldLoader.Load<Player>(item.Value));
					}
				}
				else
				{
					FieldLoader.Load(gameInformation, item.Value);
				}
			}
			return gameInformation;
		}
		catch (YamlException)
		{
			Log.Write("debug", "GameInformation deserialized invalid MiniYaml:\n" + data);
			throw;
		}
	}

	public string Serialize()
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>
		{
			new MiniYamlNode("Root", FieldSaver.Save(this))
		};
		for (int i = 0; i < Players.Count; i++)
		{
			list.Add(new MiniYamlNode($"Player@{i}", FieldSaver.Save(Players[i])));
		}
		return list.WriteToString();
	}

	public void AddPlayer(OpenRA.Player runtimePlayer, Session lobbyInfo)
	{
		if (runtimePlayer == null)
		{
			throw new ArgumentNullException("runtimePlayer");
		}
		if (lobbyInfo == null)
		{
			throw new ArgumentNullException("lobbyInfo");
		}
		if (!runtimePlayer.NonCombatant && runtimePlayer.Playable)
		{
			Session.Client client = lobbyInfo.ClientWithIndex(runtimePlayer.ClientIndex);
			if (client != null)
			{
				Player player = new Player
				{
					ClientIndex = runtimePlayer.ClientIndex,
					Name = runtimePlayer.PlayerName,
					IsHuman = !runtimePlayer.IsBot,
					IsBot = runtimePlayer.IsBot,
					BotType = runtimePlayer.BotType,
					FactionName = runtimePlayer.Faction.Name,
					FactionId = runtimePlayer.Faction.InternalName,
					DisplayFactionName = runtimePlayer.DisplayFaction.Name,
					DisplayFactionId = runtimePlayer.DisplayFaction.InternalName,
					Color = OpenRA.Player.GetColor(runtimePlayer),
					Team = client.Team,
					Handicap = client.Handicap,
					SpawnPoint = runtimePlayer.SpawnPoint,
					IsRandomFaction = (runtimePlayer.Faction.InternalName != client.Faction),
					IsRandomSpawnPoint = (runtimePlayer.DisplaySpawnPoint == 0),
					Fingerprint = client.Fingerprint
				};
				playersByRuntime.Add(runtimePlayer, player);
				Players.Add(player);
			}
		}
	}

	public Player GetPlayer(OpenRA.Player runtimePlayer)
	{
		playersByRuntime.TryGetValue(runtimePlayer, out var value);
		return value;
	}

	public string ResolvedPlayerName(Player player)
	{
		if (player.IsBot)
		{
			int num = Players.Where((Player p) => p.BotType == player.BotType).ToList().IndexOf(player) + 1;
			return FluentProvider.GetMessage("enumerated-bot-name", "name", FluentProvider.GetMessage(player.Name), "number", num);
		}
		return player.Name;
	}
}
