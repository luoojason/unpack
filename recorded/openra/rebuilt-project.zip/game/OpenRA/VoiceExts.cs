using System.Linq;
using OpenRA.Traits;

namespace OpenRA;

public static class VoiceExts
{
	public static void PlayVoice(this Actor self, string phrase)
	{
		if (phrase == null)
		{
			return;
		}
		foreach (IVoiced item in self.TraitsImplementing<IVoiced>())
		{
			if (string.IsNullOrEmpty(item.VoiceSet))
			{
				break;
			}
			item.PlayVoice(self, phrase, self.Owner.Faction.InternalName);
		}
	}

	public static void PlayVoiceLocal(this Actor self, string phrase, float volume)
	{
		if (phrase == null)
		{
			return;
		}
		foreach (IVoiced item in self.TraitsImplementing<IVoiced>())
		{
			if (string.IsNullOrEmpty(item.VoiceSet))
			{
				break;
			}
			item.PlayVoiceLocal(self, phrase, self.Owner.Faction.InternalName, volume);
		}
	}

	public static bool HasVoice(this Actor self, string voice)
	{
		return self.TraitsImplementing<IVoiced>().Any((IVoiced x) => x.HasVoice(self, voice));
	}

	public static void PlayVoiceForOrders(this Order[] orders)
	{
		foreach (Order order in orders)
		{
			if (order == null)
			{
				continue;
			}
			if (order.GroupedActors != null)
			{
				Actor[] groupedActors = order.GroupedActors;
				foreach (Actor subject in groupedActors)
				{
					if (PlayVoiceForOrder(Order.FromGroupedOrder(order, subject)))
					{
						return;
					}
				}
			}
			else if (PlayVoiceForOrder(order))
			{
				break;
			}
		}
	}

	private static bool PlayVoiceForOrder(Order o)
	{
		Actor subject = o.Subject;
		if (subject == null || subject.Disposed)
		{
			return false;
		}
		foreach (IVoiced item in subject.TraitsImplementing<IVoiced>())
		{
			foreach (IOrderVoice item2 in subject.TraitsImplementing<IOrderVoice>())
			{
				if (item.PlayVoice(subject, item2.VoicePhraseForOrder(subject, o), subject.Owner.Faction.InternalName))
				{
					return true;
				}
			}
		}
		return false;
	}
}
