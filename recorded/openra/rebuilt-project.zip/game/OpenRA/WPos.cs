using System;
using Eluant;
using Eluant.ObjectBinding;
using OpenRA.Scripting;

namespace OpenRA;

public readonly struct WPos : IEquatable<WPos>, IScriptBindable, ILuaAdditionBinding, ILuaSubtractionBinding, ILuaEqualityBinding, ILuaTableBinding, ILuaToStringBinding
{
	public readonly int X;

	public readonly int Y;

	public readonly int Z;

	public static readonly WPos Zero = new WPos(0, 0, 0);

	public LuaValue this[LuaRuntime runtime, LuaValue key]
	{
		get
		{
			return key.ToString() switch
			{
				"X" => (LuaValue)X, 
				"Y" => Y, 
				"Z" => Z, 
				_ => throw new LuaException($"WPos does not define a member '{key}'"), 
			};
		}
		set
		{
			throw new LuaException("WPos is read-only. Use WPos.New to create a new value");
		}
	}

	public WPos(int x, int y, int z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	public WPos(WDist x, WDist y, WDist z)
	{
		X = x.Length;
		Y = y.Length;
		Z = z.Length;
	}

	public static explicit operator WVec(in WPos a)
	{
		return new WVec(a.X, a.Y, a.Z);
	}

	public static WPos operator +(in WPos a, in WVec b)
	{
		return new WPos(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
	}

	public static WPos operator -(in WPos a, in WVec b)
	{
		return new WPos(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
	}

	public static WVec operator -(in WPos a, in WPos b)
	{
		return new WVec(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
	}

	public static bool operator ==(in WPos me, in WPos other)
	{
		if (me.X == other.X && me.Y == other.Y)
		{
			return me.Z == other.Z;
		}
		return false;
	}

	public static bool operator !=(in WPos me, in WPos other)
	{
		return !(me == other);
	}

	public static WPos Lerp(in WPos a, in WPos b, int mul, int div)
	{
		return a + ILSpyHelper_AsRefReadOnly((b - a) * mul / div);
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	public static WPos Lerp(in WPos a, in WPos b, long mul, long div)
	{
		int x = (int)(a.X + (b.X - a.X) * mul / div);
		int y = (int)(a.Y + (b.Y - a.Y) * mul / div);
		int z = (int)(a.Z + (b.Z - a.Z) * mul / div);
		return new WPos(x, y, z);
	}

	public static WPos LerpQuadratic(in WPos a, in WPos b, WAngle pitch, int mul, int div)
	{
		WPos result = Lerp(in a, in b, mul, div);
		if (pitch.Angle == 0)
		{
			return result;
		}
		decimal num = (decimal)(b - a).Length * (decimal)pitch.Tan() * (decimal)mul * (decimal)(div - mul) / (decimal)(1024 * div * div);
		int z = (int)(num + (decimal)result.Z).Clamp(-2147483648m, 2147483647m);
		return new WPos(result.X, result.Y, z);
	}

	public override int GetHashCode()
	{
		return X.GetHashCode() ^ Y.GetHashCode() ^ Z.GetHashCode();
	}

	public bool Equals(WPos other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is WPos other)
		{
			return Equals(other);
		}
		return false;
	}

	public override string ToString()
	{
		return X + "," + Y + "," + Z;
	}

	public LuaValue Add(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WPos>(out var clrObject) || !right.TryGetClrValue<WVec>(out var b))
		{
			throw new LuaException("Attempted to call WPos.Add(WPos, WVec) with invalid arguments " + $"({left.WrappedClrType().Name}, {right.WrappedClrType().Name})");
		}
		return new LuaCustomClrObject(clrObject + b);
	}

	public LuaValue Subtract(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		Type type = right.WrappedClrType();
		if (!left.TryGetClrValue<WPos>(out var clrObject))
		{
			throw new LuaException("Attempted to call WPos.Subtract(WPos, (WPos|WVec)) with invalid arguments " + $"({left.WrappedClrType().Name}, {type.Name})");
		}
		if (type == typeof(WPos))
		{
			right.TryGetClrValue<WPos>(out var clrObject2);
			return new LuaCustomClrObject(clrObject - clrObject2);
		}
		if (type == typeof(WVec))
		{
			right.TryGetClrValue<WVec>(out var clrObject3);
			return new LuaCustomClrObject(clrObject - clrObject3);
		}
		throw new LuaException("Attempted to call WPos.Subtract(WPos, (WPos|WVec)) with invalid arguments " + $"({left.WrappedClrType().Name}, {type.Name})");
	}

	public LuaValue Equals(LuaRuntime runtime, LuaValue left, LuaValue right)
	{
		if (!left.TryGetClrValue<WPos>(out var clrObject) || !right.TryGetClrValue<WPos>(out var other))
		{
			return false;
		}
		return clrObject == other;
	}

	public LuaValue ToString(LuaRuntime runtime)
	{
		return ToString();
	}
}
