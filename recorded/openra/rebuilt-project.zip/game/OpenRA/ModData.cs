using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using OpenRA.FileSystem;
using OpenRA.GameRules;
using OpenRA.Graphics;
using OpenRA.Support;
using OpenRA.Video;
using OpenRA.Widgets;

namespace OpenRA;

public sealed class ModData : IDisposable
{
	public readonly Manifest Manifest;

	public readonly ObjectCreator ObjectCreator;

	public readonly WidgetLoader WidgetLoader;

	public readonly MapCache MapCache;

	public readonly IPackageLoader[] PackageLoaders;

	public readonly ISoundLoader[] SoundLoaders;

	public readonly ISpriteLoader[] SpriteLoaders;

	public readonly ITerrainLoader TerrainLoader;

	public readonly ISpriteSequenceLoader SpriteSequenceLoader;

	public readonly IVideoLoader[] VideoLoaders;

	public readonly HotkeyManager Hotkeys;

	public readonly IFileSystemLoader FileSystemLoader;

	public OpenRA.FileSystem.FileSystem ModFiles;

	private readonly Lazy<Ruleset> defaultRules;

	private readonly Lazy<IReadOnlyDictionary<string, ITerrainInfo>> defaultTerrainInfo;

	private readonly int initialThreadId;

	public ILoadScreen LoadScreen { get; }

	public CursorProvider CursorProvider { get; private set; }

	public IReadOnlyFileSystem DefaultFileSystem => ModFiles;

	public Ruleset DefaultRules => defaultRules.Value;

	public IReadOnlyDictionary<string, ITerrainInfo> DefaultTerrainInfo => defaultTerrainInfo.Value;

	internal bool IsOnMainThread => Environment.CurrentManagedThreadId == initialThreadId;

	public IEnumerable<string> Languages { get; }

	public ModData(Manifest mod, InstalledMods mods, bool useLoadScreen = false)
	{
		Languages = Array.Empty<string>();
		Manifest = new Manifest(mod.Id, mod.Package);
		ObjectCreator = new ObjectCreator(Manifest, mods);
		PackageLoaders = ObjectCreator.GetLoaders<IPackageLoader>(Manifest.PackageFormats, "package");
		ModFiles = new OpenRA.FileSystem.FileSystem(mod.Id, mods, PackageLoaders);
		FileSystemLoader = ObjectCreator.GetLoader<IFileSystemLoader>(Manifest.FileSystem.Value, "filesystem");
		FieldLoader.Load(FileSystemLoader, Manifest.FileSystem);
		FileSystemLoader.Mount(ModFiles, ObjectCreator);
		ModFiles.TrimExcess();
		Manifest.LoadCustomData(ObjectCreator);
		FluentProvider.Initialize(this, DefaultFileSystem);
		if (useLoadScreen)
		{
			LoadScreen = ObjectCreator.CreateObject<ILoadScreen>(Manifest.LoadScreen.Value);
			LoadScreen.Init(this, Manifest.LoadScreen.ToDictionary((MiniYaml my) => my.Value));
			LoadScreen.Display();
		}
		WidgetLoader = new WidgetLoader(this);
		MapCache = new MapCache(this);
		SoundLoaders = ObjectCreator.GetLoaders<ISoundLoader>(Manifest.SoundFormats, "sound");
		SpriteLoaders = ObjectCreator.GetLoaders<ISpriteLoader>(Manifest.SpriteFormats, "sprite");
		VideoLoaders = ObjectCreator.GetLoaders<IVideoLoader>(Manifest.VideoFormats, "video");
		TerrainFormat terrainFormat = Manifest.Get<TerrainFormat>();
		Type type = ObjectCreator.FindType(terrainFormat.Type + "Loader");
		ConstructorInfo constructorInfo = type?.GetConstructor(new Type[1] { typeof(ModData) });
		if (type == null || !Enumerable.Contains(type.GetInterfaces(), typeof(ITerrainLoader)) || constructorInfo == null)
		{
			throw new InvalidOperationException("Unable to find a terrain loader for type '" + terrainFormat.Type + "'.");
		}
		object[] parameters = new ModData[1] { this };
		TerrainLoader = (ITerrainLoader)constructorInfo.Invoke(parameters);
		SpriteSequenceFormat spriteSequenceFormat = Manifest.Get<SpriteSequenceFormat>();
		Type type2 = ObjectCreator.FindType(spriteSequenceFormat.Type + "Loader");
		ConstructorInfo constructorInfo2 = type2?.GetConstructor(new Type[1] { typeof(ModData) });
		if (type2 == null || !Enumerable.Contains(type2.GetInterfaces(), typeof(ISpriteSequenceLoader)) || constructorInfo2 == null)
		{
			throw new InvalidOperationException("Unable to find a sequence loader for type '" + spriteSequenceFormat.Type + "'.");
		}
		parameters = new ModData[1] { this };
		SpriteSequenceLoader = (ISpriteSequenceLoader)constructorInfo2.Invoke(parameters);
		Hotkeys = new HotkeyManager(ModFiles, Game.Settings.Keys, Manifest);
		defaultRules = Exts.Lazy(() => Ruleset.LoadDefaults(this));
		defaultTerrainInfo = Exts.Lazy((Func<IReadOnlyDictionary<string, ITerrainInfo>>)(() =>
		{
			Dictionary<string, ITerrainInfo> dictionary = new Dictionary<string, ITerrainInfo>();
			string[] tileSets = Manifest.TileSets;
			foreach (string path in tileSets)
			{
				ITerrainInfo terrainInfo = TerrainLoader.ParseTerrain(DefaultFileSystem, path);
				dictionary.Add(terrainInfo.Id, terrainInfo);
			}
			return new ReadOnlyDictionary<string, ITerrainInfo>(dictionary);
		}));
		initialThreadId = Environment.CurrentManagedThreadId;
	}

	internal void HandleLoadingProgress()
	{
		if (LoadScreen != null && IsOnMainThread)
		{
			LoadScreen.Display();
		}
	}

	public void InitializeLoaders(IReadOnlyFileSystem fileSystem)
	{
		ChromeMetrics.Initialize(this);
		ChromeProvider.Initialize(this);
		FluentProvider.Initialize(this, fileSystem);
		Game.Sound.Initialize(SoundLoaders, fileSystem);
		CursorProvider = new CursorProvider(this);
	}

	public Map PrepareMap(string uid)
	{
		LoadScreen?.Display();
		if (MapCache[uid].Status != MapStatus.Available)
		{
			throw new InvalidDataException("Invalid map uid: " + uid);
		}
		Map map;
		using (new PerfTimer("Map"))
		{
			map = new Map(this, MapCache[uid].Package);
		}
		InitializeLoaders(map);
		map.Sequences.LoadSprites();
		using (new PerfTimer("Map.Music"))
		{
			foreach (KeyValuePair<string, MusicInfo> item in map.Rules.Music)
			{
				item.Value.Load(map);
			}
			return map;
		}
	}

	public List<MiniYamlNode>[] GetRulesYaml()
	{
		HashSet<string> stringPool = new HashSet<string>();
		return Manifest.Rules.Select((string s) => MiniYaml.FromStream(DefaultFileSystem.Open(s), s, discardCommentsAndWhitespace: true, stringPool)).ToArray();
	}

	public void Dispose()
	{
		LoadScreen?.Dispose();
		MapCache.Dispose();
		ObjectCreator?.Dispose();
		Manifest.Dispose();
	}
}
