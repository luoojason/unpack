using System;

namespace OpenRA;

[Flags]
public enum MapVisibility
{
	Lobby = 1,
	Shellmap = 2,
	MissionSelector = 4
}
