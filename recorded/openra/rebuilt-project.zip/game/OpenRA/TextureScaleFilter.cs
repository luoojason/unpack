namespace OpenRA;

public enum TextureScaleFilter
{
	Nearest,
	Linear
}
