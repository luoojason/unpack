namespace OpenRA;

public class GraphicSettings
{
	[Desc(new string[] { "This can be set to Windowed, Fullscreen or PseudoFullscreen." })]
	public WindowMode Mode = WindowMode.PseudoFullscreen;

	[Desc(new string[] { "Enable VSync." })]
	public bool VSync = true;

	[Desc(new string[] { "Screen resolution in fullscreen mode." })]
	public int2 FullscreenSize = new int2(0, 0);

	[Desc(new string[] { "Screen resolution in windowed mode." })]
	public int2 WindowedSize = new int2(1024, 768);

	public bool CursorDouble;

	public WorldViewport ViewportDistance = WorldViewport.Medium;

	public float UIScale = 1f;

	[Desc(new string[] { "Add a frame rate limiter." })]
	public bool CapFramerate;

	[Desc(new string[] { "At which frames per second to cap the framerate." })]
	public int MaxFramerate = 60;

	[Desc(new string[] { "Set a frame rate limit of 1 render frame per game simulation frame (overrides CapFramerate/MaxFramerate)." })]
	public bool CapFramerateToGameFps;

	[Desc(new string[] { "Disable the OpenGL debug message callback feature." })]
	public bool DisableGLDebugMessageCallback;

	[Desc(new string[] { "Disable operating-system provided cursor rendering." })]
	public bool DisableHardwareCursors;

	[Desc(new string[] { "Display index to use in a multi-monitor fullscreen setup." })]
	public int VideoDisplay;

	[Desc(new string[] { "Preferred OpenGL profile to use.", "Modern: OpenGL Core Profile 3.2 or greater.", "Embedded: OpenGL ES 3.0 or greater.", "Legacy: OpenGL 2.1 with framebuffer_object extension (requires DisableLegacyGL: False)", "Automatic: Use the first supported profile." })]
	public GLProfile GLProfile;

	public int BatchSize = 8192;

	public int SheetSize = 2048;
}
