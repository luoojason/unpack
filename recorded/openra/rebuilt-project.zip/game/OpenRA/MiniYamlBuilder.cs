using System.Collections.Generic;
using System.Linq;

namespace OpenRA;

public sealed class MiniYamlBuilder
{
	public string Value;

	public List<MiniYamlNodeBuilder> Nodes;

	public MiniYamlBuilder(MiniYaml yaml)
	{
		Value = yaml.Value;
		Nodes = yaml.Nodes.Select((MiniYamlNode n) => new MiniYamlNodeBuilder(n)).ToList();
	}

	public MiniYamlBuilder(string value)
		: this(value, null)
	{
	}

	public MiniYamlBuilder(string value, List<MiniYamlNode> nodes)
	{
		Value = value;
		Nodes = ((nodes == null) ? new List<MiniYamlNodeBuilder>() : nodes.ConvertAll((MiniYamlNode x) => new MiniYamlNodeBuilder(x)));
	}

	public MiniYaml Build()
	{
		return new MiniYaml(Value, Nodes.Select((MiniYamlNodeBuilder n) => n.Build()));
	}

	public IEnumerable<string> ToLines(string key, string comment = null)
	{
		bool flag = !string.IsNullOrEmpty(key);
		bool flag2 = !string.IsNullOrEmpty(Value);
		bool flag3 = comment != null;
		yield return (flag ? (key + ":") : "") + (flag2 ? (" " + Value.Replace("#", "\\#")) : "") + (flag3 ? (((flag | flag2) ? " " : "") + "#" + comment) : "");
		if (Nodes == null)
		{
			yield break;
		}
		foreach (string item in Nodes.ToLines())
		{
			yield return "\t" + item;
		}
	}

	public MiniYamlNodeBuilder NodeWithKeyOrDefault(string key)
	{
		return Nodes.SingleOrDefault((MiniYamlNodeBuilder n) => n.Key == key);
	}
}
