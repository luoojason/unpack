namespace OpenRA;

public readonly struct Range<T>(T start, T end)
{
	public readonly T Start = start;

	public readonly T End = end;
}
