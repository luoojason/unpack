using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OpenRA.FileSystem;
using OpenRA.GameRules;
using OpenRA.Traits;

namespace OpenRA;

public class Ruleset
{
	public readonly ActorInfoDictionary Actors;

	public readonly IReadOnlyDictionary<string, WeaponInfo> Weapons;

	public readonly IReadOnlyDictionary<string, SoundInfo> Voices;

	public readonly IReadOnlyDictionary<string, SoundInfo> Notifications;

	public readonly IReadOnlyDictionary<string, MusicInfo> Music;

	public readonly ITerrainInfo TerrainInfo;

	public readonly IReadOnlyDictionary<string, MiniYamlNode> ModelSequences;

	public IEnumerable<KeyValuePair<string, MusicInfo>> InstalledMusic => Music.Where((KeyValuePair<string, MusicInfo> m) => m.Value.Exists);

	public Ruleset(IReadOnlyDictionary<string, ActorInfo> actors, IReadOnlyDictionary<string, WeaponInfo> weapons, IReadOnlyDictionary<string, SoundInfo> voices, IReadOnlyDictionary<string, SoundInfo> notifications, IReadOnlyDictionary<string, MusicInfo> music, ITerrainInfo terrainInfo, IReadOnlyDictionary<string, MiniYamlNode> modelSequences)
	{
		Actors = new ActorInfoDictionary(actors);
		Weapons = weapons;
		Voices = voices;
		Notifications = notifications;
		Music = music;
		TerrainInfo = terrainInfo;
		ModelSequences = modelSequences;
		foreach (ActorInfo value in Actors.Values)
		{
			foreach (IRulesetLoaded item in value.TraitInfos<IRulesetLoaded>())
			{
				try
				{
					item.RulesetLoaded(this, value);
				}
				catch (YamlException ex)
				{
					throw new YamlException("Actor type " + value.Name + ": " + ex.Message);
				}
			}
		}
		foreach (KeyValuePair<string, WeaponInfo> weapon in Weapons)
		{
			if (weapon.Value.Projectile is IRulesetLoaded<WeaponInfo> rulesetLoaded)
			{
				try
				{
					rulesetLoaded.RulesetLoaded(this, weapon.Value);
				}
				catch (YamlException ex2)
				{
					throw new YamlException("Projectile type " + weapon.Key + ": " + ex2.Message);
				}
			}
			foreach (IWarhead warhead in weapon.Value.Warheads)
			{
				if (warhead is IRulesetLoaded<WeaponInfo> rulesetLoaded2)
				{
					try
					{
						rulesetLoaded2.RulesetLoaded(this, weapon.Value);
					}
					catch (YamlException ex3)
					{
						throw new YamlException("Weapon type " + weapon.Key + ": " + ex3.Message);
					}
				}
			}
		}
	}

	private static IReadOnlyDictionary<string, T> MergeOrDefault<T>(string name, IReadOnlyFileSystem fileSystem, IEnumerable<string> files, MiniYaml additional, IReadOnlyDictionary<string, T> defaults, Func<MiniYamlNode, T> makeObject, Func<MiniYamlNode, bool> filterNode = null)
	{
		if (additional == null && defaults != null)
		{
			return defaults;
		}
		IEnumerable<MiniYamlNode> source = MiniYaml.Load(fileSystem, files, additional);
		if (filterNode != null)
		{
			source = source.Where((MiniYamlNode k) => !filterNode(k));
		}
		return source.ToDictionaryWithConflictLog((MiniYamlNode k) => k.Key.ToLowerInvariant(), makeObject, "LoadFromManifest<" + name + ">");
	}

	public static Ruleset LoadDefaults(ModData modData)
	{
		Manifest m = modData.Manifest;
		IReadOnlyFileSystem fs = modData.DefaultFileSystem;
		Ruleset ruleset = null;
		if (modData.IsOnMainThread)
		{
			modData.HandleLoadingProgress();
			Task task = new Task(LoadRuleset);
			task.Start();
			while (!task.Wait(40))
			{
				modData.HandleLoadingProgress();
			}
		}
		else
		{
			LoadRuleset();
		}
		return ruleset;
		void LoadRuleset()
		{
			IReadOnlyDictionary<string, ActorInfo> actors = MergeOrDefault("Manifest,Rules", fs, m.Rules, null, null, (MiniYamlNode k) => new ActorInfo(modData.ObjectCreator, k.Key.ToLowerInvariant(), k.Value), (MiniYamlNode n) => n.Key.StartsWith('^'));
			IReadOnlyDictionary<string, WeaponInfo> weapons = MergeOrDefault("Manifest,Weapons", fs, m.Weapons, null, null, (MiniYamlNode k) => new WeaponInfo(k.Value));
			IReadOnlyDictionary<string, SoundInfo> voices = MergeOrDefault("Manifest,Voices", fs, m.Voices, null, null, (MiniYamlNode k) => new SoundInfo(k.Value));
			IReadOnlyDictionary<string, SoundInfo> notifications = MergeOrDefault("Manifest,Notifications", fs, m.Notifications, null, null, (MiniYamlNode k) => new SoundInfo(k.Value));
			IReadOnlyDictionary<string, MusicInfo> music = MergeOrDefault("Manifest,Music", fs, m.Music, null, null, (MiniYamlNode k) => new MusicInfo(k.Key, k.Value));
			IReadOnlyDictionary<string, MiniYamlNode> modelSequences = MergeOrDefault("Manifest,ModelSequences", fs, m.ModelSequences, null, null, (MiniYamlNode k) => k);
			ruleset = new Ruleset(actors, weapons, voices, notifications, music, null, modelSequences);
		}
	}

	public static Ruleset LoadDefaultsForTileSet(ModData modData, string tileSet)
	{
		Ruleset defaultRules = modData.DefaultRules;
		ITerrainInfo terrainInfo = modData.DefaultTerrainInfo[tileSet];
		return new Ruleset(defaultRules.Actors, defaultRules.Weapons, defaultRules.Voices, defaultRules.Notifications, defaultRules.Music, terrainInfo, defaultRules.ModelSequences);
	}

	public static Ruleset Load(ModData modData, IReadOnlyFileSystem fileSystem, string tileSet, MiniYaml mapRules, MiniYaml mapWeapons, MiniYaml mapVoices, MiniYaml mapNotifications, MiniYaml mapMusic, MiniYaml mapModelSequences)
	{
		Manifest m = modData.Manifest;
		Ruleset dr = modData.DefaultRules;
		Ruleset ruleset = null;
		if (modData.IsOnMainThread)
		{
			modData.HandleLoadingProgress();
			Task task = new Task(LoadRuleset);
			task.Start();
			while (!task.Wait(40))
			{
				modData.HandleLoadingProgress();
			}
		}
		else
		{
			LoadRuleset();
		}
		return ruleset;
		void LoadRuleset()
		{
			IReadOnlyDictionary<string, ActorInfo> actors = MergeOrDefault("Rules", fileSystem, m.Rules, mapRules, dr.Actors, (MiniYamlNode k) => new ActorInfo(modData.ObjectCreator, k.Key.ToLowerInvariant(), k.Value), (MiniYamlNode n) => n.Key.StartsWith('^'));
			IReadOnlyDictionary<string, WeaponInfo> weapons = MergeOrDefault("Weapons", fileSystem, m.Weapons, mapWeapons, dr.Weapons, (MiniYamlNode k) => new WeaponInfo(k.Value));
			IReadOnlyDictionary<string, SoundInfo> voices = MergeOrDefault("Voices", fileSystem, m.Voices, mapVoices, dr.Voices, (MiniYamlNode k) => new SoundInfo(k.Value));
			IReadOnlyDictionary<string, SoundInfo> notifications = MergeOrDefault("Notifications", fileSystem, m.Notifications, mapNotifications, dr.Notifications, (MiniYamlNode k) => new SoundInfo(k.Value));
			IReadOnlyDictionary<string, MusicInfo> music = MergeOrDefault("Music", fileSystem, m.Music, mapMusic, dr.Music, (MiniYamlNode k) => new MusicInfo(k.Key, k.Value));
			ITerrainInfo terrainInfo = modData.DefaultTerrainInfo[tileSet];
			IReadOnlyDictionary<string, MiniYamlNode> modelSequences = dr.ModelSequences;
			if (mapModelSequences != null)
			{
				modelSequences = MergeOrDefault("ModelSequences", fileSystem, m.ModelSequences, mapModelSequences, dr.ModelSequences, (MiniYamlNode k) => k);
			}
			ruleset = new Ruleset(actors, weapons, voices, notifications, music, terrainInfo, modelSequences);
		}
	}

	private static bool AnyCustomYaml(MiniYaml yaml)
	{
		if (yaml != null)
		{
			if (yaml.Value == null)
			{
				return yaml.Nodes.Length > 0;
			}
			return true;
		}
		return false;
	}

	private static bool AnyFlaggedTraits(ModData modData, IEnumerable<MiniYamlNode> actors)
	{
		foreach (MiniYamlNode actor in actors)
		{
			foreach (MiniYamlNode node in actor.Value.Nodes)
			{
				try
				{
					string text = node.Key.Split('@')[0];
					Type type = modData.ObjectCreator.FindType(text + "Info");
					if (type != null && type.GetInterface("ILobbyCustomRulesIgnore") == null)
					{
						return true;
					}
				}
				catch (Exception ex)
				{
					Log.Write("debug", "Error in AnyFlaggedTraits\n" + ex.ToString());
				}
			}
		}
		return false;
	}

	public static bool DefinesUnsafeCustomRules(ModData modData, IReadOnlyFileSystem fileSystem, MiniYaml mapRules, MiniYaml mapWeapons, MiniYaml mapVoices, MiniYaml mapNotifications, MiniYaml mapSequences)
	{
		if (AnyCustomYaml(mapWeapons) || AnyCustomYaml(mapVoices) || AnyCustomYaml(mapNotifications) || AnyCustomYaml(mapSequences))
		{
			return true;
		}
		if (mapRules == null)
		{
			return false;
		}
		if (AnyFlaggedTraits(modData, mapRules.Nodes))
		{
			return true;
		}
		if (mapRules.Value != null)
		{
			string[] value = FieldLoader.GetValue<string[]>("value", mapRules.Value);
			string[] array = value;
			foreach (string text in array)
			{
				if (AnyFlaggedTraits(modData, MiniYaml.FromStream(fileSystem.Open(text), text)))
				{
					return true;
				}
			}
		}
		return false;
	}
}
