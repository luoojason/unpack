using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using OpenRA.Traits;

namespace OpenRA;

public abstract class CompositeActorInit : ActorInit
{
	protected CompositeActorInit(TraitInfo info)
		: base(info.InstanceName)
	{
	}

	protected CompositeActorInit()
	{
	}

	public virtual void Initialize(MiniYaml yaml)
	{
		FieldLoader.Load(this, yaml);
	}

	public virtual void Initialize(Dictionary<string, object> values)
	{
		FieldInfo[] fields = GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		foreach (FieldInfo fieldInfo in fields)
		{
			FieldLoader.SerializeAttribute serializeAttribute = fieldInfo.GetCustomAttributes<FieldLoader.SerializeAttribute>(inherit: false).DefaultIfEmpty(FieldLoader.SerializeAttribute.Default).First();
			if (serializeAttribute.Serialize && values.TryGetValue(fieldInfo.Name, out var value))
			{
				fieldInfo.SetValue(this, value);
			}
		}
	}

	public virtual Dictionary<string, Type> InitializeArgs()
	{
		Dictionary<string, Type> dictionary = new Dictionary<string, Type>();
		FieldInfo[] fields = GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		foreach (FieldInfo fieldInfo in fields)
		{
			FieldLoader.SerializeAttribute serializeAttribute = fieldInfo.GetCustomAttributes<FieldLoader.SerializeAttribute>(inherit: false).DefaultIfEmpty(FieldLoader.SerializeAttribute.Default).First();
			if (serializeAttribute.Serialize)
			{
				dictionary[fieldInfo.Name] = fieldInfo.FieldType;
			}
		}
		return dictionary;
	}

	public override MiniYaml Save()
	{
		return FieldSaver.Save(this);
	}
}
