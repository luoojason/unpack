using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA;

public class MapGrid : IGlobalModData
{
	public readonly MapGridType Type;

	public readonly Size TileSize = new Size(24, 24);

	public readonly byte MaximumTerrainHeight;

	public readonly SubCell DefaultSubCell = SubCell.Invalid;

	public readonly int MaximumTileSearchRange = 50;

	public readonly bool EnableDepthBuffer;

	public readonly WVec[] SubCellOffsets = new WVec[6]
	{
		new WVec(0, 0, 0),
		new WVec(-299, -256, 0),
		new WVec(256, -256, 0),
		new WVec(0, 0, 0),
		new WVec(-299, 256, 0),
		new WVec(256, 256, 0)
	};

	internal readonly CVec[][] TilesByDistance;

	public CellRamp[] Ramps { get; }

	public int TileScale { get; }

	public MapGrid(MiniYaml yaml)
	{
		FieldLoader.Load(this, yaml);
		TileScale = ((Type == MapGridType.RectangularIsometric) ? 1448 : 1024);
		byte defaultSubCell = (byte)DefaultSubCell;
		if (defaultSubCell == byte.MaxValue)
		{
			DefaultSubCell = (SubCell)(SubCellOffsets.Length / 2);
		}
		else
		{
			int num = ((SubCellOffsets.Length > 1) ? 1 : 0);
			if (defaultSubCell < num || defaultSubCell >= SubCellOffsets.Length)
			{
				throw new InvalidDataException("Subcell default index must be a valid index into the offset triples and must be greater than 0 for mods with subcells");
			}
		}
		WVec axis = new WVec(724, 724, 0);
		WVec axis2 = new WVec(-724, 724, 0);
		WVec axis3 = new WVec(0, 1024, 0);
		WVec axis4 = new WVec(1024, 0, 0);
		WAngle wAngle = new WAngle(64);
		WAngle angle = -wAngle;
		WAngle wAngle2 = new WAngle(48);
		WAngle angle2 = -wAngle2;
		Ramps = new CellRamp[21]
		{
			new CellRamp(Type, WRot.None),
			new CellRamp(Type, new WRot(axis, angle), RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Half),
			new CellRamp(Type, new WRot(axis2, angle), RampCornerHeight.Low, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Half),
			new CellRamp(Type, new WRot(axis, wAngle), RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Low, RampCornerHeight.Half),
			new CellRamp(Type, new WRot(axis2, wAngle), RampCornerHeight.Half, RampCornerHeight.Half),
			new CellRamp(Type, new WRot(axis3, angle2), RampCornerHeight.Low, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Low, RampSplit.X),
			new CellRamp(Type, new WRot(axis4, wAngle2), RampCornerHeight.Low, RampCornerHeight.Low, RampCornerHeight.Low, RampCornerHeight.Half, RampSplit.Y),
			new CellRamp(Type, new WRot(axis3, wAngle2), RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Low, RampCornerHeight.Low, RampSplit.X),
			new CellRamp(Type, new WRot(axis4, angle2), RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Low, RampSplit.Y),
			new CellRamp(Type, new WRot(axis3, angle2), RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Half, RampCornerHeight.Half, RampSplit.X),
			new CellRamp(Type, new WRot(axis4, wAngle2), RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Half, RampSplit.Y),
			new CellRamp(Type, new WRot(axis3, wAngle2), RampCornerHeight.Half, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampSplit.X),
			new CellRamp(Type, new WRot(axis4, angle2), RampCornerHeight.Half, RampCornerHeight.Half, RampCornerHeight.Half, RampCornerHeight.Low, RampSplit.Y),
			new CellRamp(Type, new WRot(axis3, angle), RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Full, RampCornerHeight.Half),
			new CellRamp(Type, new WRot(axis4, wAngle), RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Full),
			new CellRamp(Type, new WRot(axis3, wAngle), RampCornerHeight.Full, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half),
			new CellRamp(Type, new WRot(axis4, angle), RampCornerHeight.Half, RampCornerHeight.Full, RampCornerHeight.Half),
			new CellRamp(Type, WRot.None, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampSplit.Y),
			new CellRamp(Type, WRot.None, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Low, RampSplit.Y),
			new CellRamp(Type, WRot.None, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampSplit.X),
			new CellRamp(Type, WRot.None, RampCornerHeight.Half, RampCornerHeight.Low, RampCornerHeight.Half, RampCornerHeight.Low, RampSplit.X)
		};
		TilesByDistance = CreateTilesByDistance();
	}

	private CVec[][] CreateTilesByDistance()
	{
		List<CVec>[] array = new List<CVec>[MaximumTileSearchRange + 1];
		for (int i = 0; i < MaximumTileSearchRange + 1; i++)
		{
			array[i] = new List<CVec>();
		}
		for (int j = -MaximumTileSearchRange; j <= MaximumTileSearchRange; j++)
		{
			for (int k = -MaximumTileSearchRange; k <= MaximumTileSearchRange; k++)
			{
				if (MaximumTileSearchRange * MaximumTileSearchRange >= k * k + j * j)
				{
					array[Exts.ISqrt(k * k + j * j, Exts.ISqrtRoundMode.Ceiling)].Add(new CVec(k, j));
				}
			}
		}
		List<CVec>[] array2 = array;
		foreach (List<CVec> list in array2)
		{
			list.Sort((CVec a, CVec b) =>
			{
				int num = a.LengthSquared.CompareTo(b.LengthSquared);
				if (num != 0)
				{
					return num;
				}
				num = a.GetHashCode().CompareTo(b.GetHashCode());
				if (num != 0)
				{
					return num;
				}
				num = a.X.CompareTo(b.X);
				return (num != 0) ? num : a.Y.CompareTo(b.Y);
			});
		}
		return array.Select((List<CVec> list2) => list2.ToArray()).ToArray();
	}

	public WVec OffsetOfSubCell(SubCell subCell)
	{
		if (subCell == SubCell.Invalid || subCell == SubCell.Any)
		{
			return WVec.Zero;
		}
		if ((int)subCell >= 0 && (int)subCell < SubCellOffsets.Length)
		{
			return SubCellOffsets[(uint)subCell];
		}
		return WVec.Zero;
	}
}
