using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace OpenRA;

public class Arguments
{
	private readonly Dictionary<string, string> args = new Dictionary<string, string>();

	public static Arguments Empty => new Arguments();

	public Arguments(params string[] src)
	{
		Regex regex = new Regex("([^=]+)=(.*)");
		foreach (string input in src)
		{
			Match match = regex.Match(input);
			if (match.Success)
			{
				args[match.Groups[1].Value] = match.Groups[2].Value;
			}
		}
	}

	public bool Contains(string key)
	{
		return args.ContainsKey(key);
	}

	public string GetValue(string key, string defaultValue)
	{
		if (!Contains(key))
		{
			return defaultValue;
		}
		return args[key];
	}

	public void ReplaceValue(string key, string value)
	{
		args[key] = value;
	}
}
