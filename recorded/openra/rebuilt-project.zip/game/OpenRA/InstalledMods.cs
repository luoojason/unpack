using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.FileSystem;

namespace OpenRA;

public class InstalledMods : IReadOnlyDictionary<string, Manifest>, IEnumerable<KeyValuePair<string, Manifest>>, IEnumerable, IReadOnlyCollection<KeyValuePair<string, Manifest>>
{
	private readonly Dictionary<string, Manifest> mods;

	public Manifest this[string key] => mods[key];

	public IEnumerable<string> Keys => mods.Keys;

	public IEnumerable<Manifest> Values => mods.Values;

	public int Count => mods.Count;

	public InstalledMods(IEnumerable<string> searchPaths, IEnumerable<string> explicitPaths)
	{
		mods = GetInstalledMods(searchPaths, explicitPaths);
	}

	private static IEnumerable<(string Id, string Path)> GetCandidateMods(IEnumerable<string> searchPaths)
	{
		List<(string, string)> list = new List<(string, string)>();
		foreach (string searchPath in searchPaths)
		{
			try
			{
				string path = Platform.ResolvePath(searchPath);
				if (!Directory.Exists(path))
				{
					continue;
				}
				DirectoryInfo directoryInfo = new DirectoryInfo(path);
				foreach (DirectoryInfo item in directoryInfo.EnumerateDirectories())
				{
					list.Add((item.Name, item.FullName));
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Failed to enumerate mod search path {0}: {1}", searchPath, ex.Message);
			}
		}
		return list;
	}

	private static Manifest LoadMod(string id, string path)
	{
		IReadOnlyPackage readOnlyPackage = null;
		try
		{
			if (!Directory.Exists(path))
			{
				Log.Write("debug", path + " is not a valid mod package");
				return null;
			}
			readOnlyPackage = new Folder(path);
			if (readOnlyPackage.Contains("mod.yaml"))
			{
				return new Manifest(id, readOnlyPackage);
			}
		}
		catch (Exception value)
		{
			Log.Write("debug", $"Load mod '{path}': {value}");
		}
		readOnlyPackage?.Dispose();
		return null;
	}

	private static Dictionary<string, Manifest> GetInstalledMods(IEnumerable<string> searchPaths, IEnumerable<string> explicitPaths)
	{
		Dictionary<string, Manifest> dictionary = new Dictionary<string, Manifest>();
		IEnumerable<(string, string)> enumerable = GetCandidateMods(searchPaths).Concat(explicitPaths.Select((string p) => (Id: Path.GetFileNameWithoutExtension(p), Path: p)));
		foreach (var item in enumerable)
		{
			Manifest manifest = LoadMod(item.Item1, item.Item2);
			if (manifest != null)
			{
				dictionary[item.Item1] = manifest;
			}
		}
		return dictionary;
	}

	public bool ContainsKey(string key)
	{
		return mods.ContainsKey(key);
	}

	public IEnumerator<KeyValuePair<string, Manifest>> GetEnumerator()
	{
		return mods.GetEnumerator();
	}

	public bool TryGetValue(string key, out Manifest value)
	{
		return mods.TryGetValue(key, out value);
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return mods.GetEnumerator();
	}
}
