using System;
using System.Reflection;
using OpenRA.Network;

namespace OpenRA;

public class LaunchArguments
{
	[Desc(new string[] { "Connect to the following server given as IP:PORT on startup." })]
	public string Connect;

	[Desc(new string[] { "Connect to the unified resource identifier openra://IP:PORT on startup." })]
	public string URI;

	[Desc(new string[] { "Automatically start playing the given replay file." })]
	public string Replay;

	[Desc(new string[] { "Dump performance data into cpu.csv and render.csv in the logs folder with the given prefix." })]
	public string Benchmark;

	[Desc(new string[] { "Automatically start playing the given map." })]
	public string Map;

	public LaunchArguments(Arguments args)
	{
		if (args == null)
		{
			return;
		}
		FieldInfo[] fields = GetType().GetFields();
		foreach (FieldInfo fieldInfo in fields)
		{
			if (args.Contains("Launch." + fieldInfo.Name))
			{
				FieldLoader.LoadField(this, fieldInfo.Name, args.GetValue("Launch." + fieldInfo.Name, ""));
			}
		}
	}

	public ConnectionTarget GetConnectEndPoint()
	{
		try
		{
			Uri uri;
			if (!string.IsNullOrEmpty(URI))
			{
				uri = new Uri(URI);
			}
			else
			{
				if (string.IsNullOrEmpty(Connect))
				{
					return null;
				}
				uri = new Uri("tcp://" + Connect);
			}
			if (uri.IsAbsoluteUri)
			{
				return new ConnectionTarget(uri.Host, uri.Port);
			}
			return null;
		}
		catch (Exception ex)
		{
			Log.Write("client", "Failed to parse Launch.URI or Launch.Connect: " + ex.Message);
			return null;
		}
	}
}
