using System;
using System.Collections.Generic;
using OpenRA.FileSystem;

namespace OpenRA;

public sealed class HotkeyManager
{
	private readonly Dictionary<string, Hotkey> settings;

	private readonly Dictionary<string, HotkeyDefinition> definitions = new Dictionary<string, HotkeyDefinition>();

	private readonly Dictionary<string, Hotkey> keys = new Dictionary<string, Hotkey>();

	public HotkeyReference this[string name] => new HotkeyReference(GetHotkeyReference(name));

	public IEnumerable<HotkeyDefinition> Definitions => definitions.Values;

	public HotkeyManager(IReadOnlyFileSystem fileSystem, Dictionary<string, Hotkey> settings, Manifest manifest)
	{
		this.settings = settings;
		List<MiniYamlNode> list = MiniYaml.Load(fileSystem, manifest.Hotkeys, null);
		foreach (MiniYamlNode item in list)
		{
			HotkeyDefinition hotkeyDefinition = new HotkeyDefinition(item.Key, item.Value);
			definitions[item.Key] = hotkeyDefinition;
			keys[item.Key] = hotkeyDefinition.Default;
		}
		foreach (KeyValuePair<string, Hotkey> setting in settings)
		{
			if (definitions.TryGetValue(setting.Key, out var value) && !value.Readonly)
			{
				keys[setting.Key] = setting.Value;
			}
		}
		foreach (KeyValuePair<string, HotkeyDefinition> definition in definitions)
		{
			definition.Value.HasDuplicates = GetFirstDuplicate(definition.Value, this[definition.Value.Name].GetValue()) != null;
		}
	}

	internal Func<Hotkey> GetHotkeyReference(string name)
	{
		if (keys.ContainsKey(name))
		{
			return () => keys[name];
		}
		if (!Hotkey.TryParse(name, out var key))
		{
			key = Hotkey.Invalid;
		}
		return () => key;
	}

	public void Set(string name, Hotkey value)
	{
		if (!definitions.TryGetValue(name, out var value2) || value2.Readonly)
		{
			return;
		}
		keys[name] = value;
		if (value != value2.Default)
		{
			settings[name] = value;
		}
		else
		{
			settings.Remove(name);
		}
		bool hasDuplicates = value2.HasDuplicates;
		value2.HasDuplicates = GetFirstDuplicate(value2, this[value2.Name].GetValue()) != null;
		if (!hasDuplicates && !value2.HasDuplicates)
		{
			return;
		}
		foreach (KeyValuePair<string, HotkeyDefinition> definition in definitions)
		{
			if (definition.Value != value2)
			{
				definition.Value.HasDuplicates = GetFirstDuplicate(definition.Value, this[definition.Value.Name].GetValue()) != null;
			}
		}
	}

	public HotkeyDefinition GetFirstDuplicate(HotkeyDefinition definition, Hotkey value)
	{
		if (definition == null)
		{
			return null;
		}
		foreach (KeyValuePair<string, Hotkey> key in keys)
		{
			if (!(key.Key == definition.Name) && key.Value == value && definitions[key.Key].Contexts.Overlaps(definition.Contexts))
			{
				return definitions[key.Key];
			}
		}
		return null;
	}
}
