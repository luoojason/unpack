using System;

namespace OpenRA;

public interface IVertexBuffer<T> : IDisposable where T : struct
{
	void Bind();

	void SetData(T[] vertices, int length);

	void SetData(ref T[] vertices, int length);

	void SetData(T[] vertices, int offset, int start, int length);
}
