using System;
using OpenRA.Primitives;

namespace OpenRA;

public class PlayerSettings
{
	[Desc(new string[] { "Sets the player nickname." })]
	public string Name = "Commander";

	public Color Color = Color.FromArgb(200, 32, 32);

	public string LastServer = "localhost:1234";

	public Color[] CustomColors = Array.Empty<Color>();
}
