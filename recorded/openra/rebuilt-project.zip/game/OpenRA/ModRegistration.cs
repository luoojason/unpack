using System;

namespace OpenRA;

[Flags]
internal enum ModRegistration
{
	User = 1,
	System = 2
}
