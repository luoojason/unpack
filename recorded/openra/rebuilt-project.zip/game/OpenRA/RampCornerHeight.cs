namespace OpenRA;

public enum RampCornerHeight
{
	Low,
	Half,
	Full
}
