using System;
using OpenRA.Primitives;

namespace OpenRA;

public sealed class ProjectedCellLayer<T> : CellLayerBase<T>
{
	public int MaxIndex => Size.Width * Size.Height;

	public T this[int index]
	{
		get
		{
			return Entries[index];
		}
		set
		{
			Entries[index] = value;
		}
	}

	public T this[PPos uv]
	{
		get
		{
			return Entries[Index(uv)];
		}
		set
		{
			Entries[Index(uv)] = value;
		}
	}

	public ProjectedCellLayer(Map map)
		: base(map)
	{
	}

	public ProjectedCellLayer(MapGridType gridType, Size size)
		: base(gridType, size)
	{
	}

	public int Index(PPos uv)
	{
		return uv.V * Size.Width + uv.U;
	}

	public PPos PPosFromIndex(int index)
	{
		return new PPos(index % Size.Width, index / Size.Width);
	}

	public bool Contains(PPos uv)
	{
		return Bounds.Contains(uv.U, uv.V);
	}

	public int IndexOf(T value, int startIndex)
	{
		return Array.IndexOf(Entries, value, startIndex);
	}

	public void SetAll(T value)
	{
		Array.Fill(Entries, value);
	}
}
