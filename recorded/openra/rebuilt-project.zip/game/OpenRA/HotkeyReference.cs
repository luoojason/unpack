using System;

namespace OpenRA;

public class HotkeyReference
{
	private static readonly Func<Hotkey> Invalid = () => Hotkey.Invalid;

	private readonly Func<Hotkey> getValue;

	public HotkeyReference()
	{
		getValue = Invalid;
	}

	internal HotkeyReference(Func<Hotkey> getValue)
	{
		this.getValue = getValue;
	}

	public Hotkey GetValue()
	{
		return getValue();
	}

	public bool IsActivatedBy(KeyInput e)
	{
		Hotkey hotkey = getValue();
		if (hotkey.Key == e.Key)
		{
			return hotkey.Modifiers == e.Modifiers;
		}
		return false;
	}
}
