using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA;

public class CellRegion : IEnumerable<CPos>, IEnumerable
{
	public struct CellRegionEnumerator : IEnumerator<CPos>, IEnumerator, IDisposable
	{
		private readonly CellRegion r;

		private int u;

		private int v;

		public CPos Current { get; private set; }

		readonly object IEnumerator.Current => Current;

		public CellRegionEnumerator(CellRegion region)
		{
			this = default;
			r = region;
			Reset();
			Current = new MPos(u, v).ToCPos(r.gridType);
		}

		public bool MoveNext()
		{
			u++;
			if (u > r.mapBottomRight.U)
			{
				v++;
				u = r.mapTopLeft.U;
				if (v > r.mapBottomRight.V)
				{
					return false;
				}
			}
			Current = new MPos(u, v).ToCPos(r.gridType);
			return true;
		}

		public void Reset()
		{
			u = r.mapTopLeft.U - 1;
			v = r.mapTopLeft.V;
		}

		public readonly void Dispose()
		{
		}
	}

	public readonly CPos TopLeft;

	public readonly CPos BottomRight;

	private readonly MapGridType gridType;

	private readonly MPos mapTopLeft;

	private readonly MPos mapBottomRight;

	public MapCoordsRegion MapCoords => new MapCoordsRegion(mapTopLeft, mapBottomRight);

	public CellCoordsRegion CellCoords => new CellCoordsRegion(TopLeft, BottomRight);

	public CellRegion(MapGridType gridType, CPos topLeft, CPos bottomRight)
	{
		this.gridType = gridType;
		TopLeft = topLeft;
		BottomRight = bottomRight;
		mapTopLeft = TopLeft.ToMPos(gridType);
		mapBottomRight = BottomRight.ToMPos(gridType);
	}

	public CellRegion(MapGridType gridType, MPos topLeft, MPos bottomRight)
	{
		this.gridType = gridType;
		mapTopLeft = topLeft;
		mapBottomRight = bottomRight;
		TopLeft = topLeft.ToCPos(gridType);
		BottomRight = bottomRight.ToCPos(gridType);
	}

	public override string ToString()
	{
		return $"{TopLeft}->{BottomRight}";
	}

	public static CellRegion Expand(CellRegion region, int cordon)
	{
		CPos topLeft = new MPos(region.mapTopLeft.U - cordon, region.mapTopLeft.V - cordon).ToCPos(region.gridType);
		CPos bottomRight = new MPos(region.mapBottomRight.U + cordon, region.mapBottomRight.V + cordon).ToCPos(region.gridType);
		return new CellRegion(region.gridType, topLeft, bottomRight);
	}

	public static CellRegion BoundingRegion(MapGridType shape, IReadOnlyCollection<CPos> cells)
	{
		if (cells == null || cells.Count == 0)
		{
			throw new ArgumentException("cells must not be null or empty.", "cells");
		}
		int num = int.MaxValue;
		int num2 = int.MaxValue;
		int num3 = int.MinValue;
		int num4 = int.MinValue;
		foreach (CPos cell in cells)
		{
			MPos mPos = cell.ToMPos(shape);
			if (num > mPos.U)
			{
				num = mPos.U;
			}
			if (num3 < mPos.U)
			{
				num3 = mPos.U;
			}
			if (num2 > mPos.V)
			{
				num2 = mPos.V;
			}
			if (num4 < mPos.V)
			{
				num4 = mPos.V;
			}
		}
		return new CellRegion(shape, new MPos(num, num2).ToCPos(shape), new MPos(num3, num4).ToCPos(shape));
	}

	public bool Contains(CellRegion region)
	{
		if (TopLeft.X <= region.TopLeft.X && TopLeft.Y <= region.TopLeft.Y && BottomRight.X >= region.BottomRight.X)
		{
			return BottomRight.Y >= region.BottomRight.Y;
		}
		return false;
	}

	public bool Contains(CPos cell)
	{
		MPos mPos = cell.ToMPos(gridType);
		if (mPos.U >= mapTopLeft.U && mPos.U <= mapBottomRight.U && mPos.V >= mapTopLeft.V)
		{
			return mPos.V <= mapBottomRight.V;
		}
		return false;
	}

	public CellRegionEnumerator GetEnumerator()
	{
		return new CellRegionEnumerator(this);
	}

	IEnumerator<CPos> IEnumerable<CPos>.GetEnumerator()
	{
		return GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
