namespace OpenRA;

public enum TargetLinesType
{
	Disabled,
	Manual,
	Automatic
}
