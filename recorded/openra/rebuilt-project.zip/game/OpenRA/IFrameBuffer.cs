using System;
using OpenRA.Primitives;

namespace OpenRA;

public interface IFrameBuffer : IDisposable
{
	ITexture Texture { get; }

	void Bind();

	void Unbind();

	void EnableScissor(Rectangle rect);

	void DisableScissor();
}
