using System.IO;

namespace OpenRA;

public struct ChannelInfo
{
	public string Filename;

	public bool IsTimestamped;

	public TextWriter Writer;
}
