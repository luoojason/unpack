namespace OpenRA;

public enum MapGridType
{
	Rectangular,
	RectangularIsometric
}
