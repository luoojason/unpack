namespace OpenRA;

public class SoundSettings
{
	public float SoundVolume = 0.5f;

	public float MusicVolume = 0.5f;

	public float VideoVolume = 0.5f;

	public bool Shuffle;

	public bool Repeat;

	public string Device;

	public bool CashTicks = true;

	public bool Mute;

	public bool MuteBackgroundMusic;
}
