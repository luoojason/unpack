namespace OpenRA;

public enum RunStatus
{
	Error = -1,
	Success = 0,
	Running = int.MaxValue
}
