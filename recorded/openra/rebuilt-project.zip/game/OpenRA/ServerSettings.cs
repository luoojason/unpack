using System;

namespace OpenRA;

public class ServerSettings
{
	[Desc(new string[] { "Sets the server name." })]
	public string Name = "";

	[Desc(new string[] { "Sets the internal port." })]
	public int ListenPort = 1234;

	[Desc(new string[] { "Reports the game to the master server list." })]
	public bool AdvertiseOnline = true;

	[Desc(new string[] { "Locks the game with a password." })]
	public string Password = "";

	[Desc(new string[] { "Allow users to search UPnP/NAT-PMP enabled devices for automatic port forwarding." })]
	public bool DiscoverNatDevices;

	[Desc(new string[] { "Time in seconds for UPnP/NAT-PMP mappings to last." })]
	public int NatPortMappingLifetime = 36000;

	[Desc(new string[] { "Starts the game with a default map. Input as hash that can be obtained by the utility." })]
	public string Map;

	[Desc(new string[] { "Takes a comma separated list of IP addresses that are not allowed to join." })]
	public string[] Ban = Array.Empty<string>();

	[Desc(new string[] { "For dedicated servers only, allow anonymous clients to join." })]
	public bool RequireAuthentication;

	[Desc(new string[] { "For dedicated servers only, if non-empty, only allow authenticated players with these profile IDs to join." })]
	public int[] ProfileIDWhitelist = Array.Empty<int>();

	[Desc(new string[] { "For dedicated servers only, if non-empty, always reject players with these user IDs from joining." })]
	public int[] ProfileIDBlacklist = Array.Empty<int>();

	[Desc(new string[] { "For dedicated servers only, controls whether a game can be started with just one human player in the lobby." })]
	public bool EnableSingleplayer;

	[Desc(new string[] { "Query map information from the Resource Center if they are not available locally." })]
	public bool QueryMapRepository = true;

	[Desc(new string[] { "Enable client-side report generation to help debug desync errors." })]
	public bool EnableSyncReports;

	[Desc(new string[] { "Sets the timestamp format. Defaults to the ISO 8601 standard." })]
	public string TimestampFormat = "yyyy-MM-ddTHH:mm:ss";

	[Desc(new string[] { "Allow clients to see anonymised IPs for other clients." })]
	public bool ShareAnonymizedIPs = true;

	[Desc(new string[] { "Allow clients to see the country of other clients." })]
	public bool EnableGeoIP = true;

	[Desc(new string[] { "For dedicated servers only, save replays for all games played." })]
	public bool RecordReplays;

	[Desc(new string[] { "For dedicated servers only, treat maps that fail the lint checks as invalid." })]
	public bool EnableLintChecks = true;

	[Desc(new string[] { "For dedicated servers only, a comma separated list of map uids that are allowed to be used." })]
	public string[] MapPool = Array.Empty<string>();

	[Desc(new string[] { "Delay in milliseconds before newly joined players can send chat messages." })]
	public int FloodLimitJoinCooldown = 5000;

	[Desc(new string[] { "Amount of milliseconds player chat messages are tracked for." })]
	public int FloodLimitInterval = 5000;

	[Desc(new string[] { "Amount of chat messages per FloodLimitInterval a players can send before flood is detected." })]
	public int FloodLimitMessageCount = 5;

	[Desc(new string[] { "Delay in milliseconds before players can send chat messages after flood was detected." })]
	public int FloodLimitCooldown = 15000;

	[Desc(new string[] { "Can players vote to kick other players?" })]
	public bool EnableVoteKick = true;

	[Desc(new string[] { "After how much time in miliseconds should the vote kick fail after idling?" })]
	public int VoteKickTimer = 30000;

	[Desc(new string[] { "If a vote kick was unsuccessful for how long should the player who started the vote not be able to start new votes?" })]
	public int VoteKickerCooldown = 120000;

	public ServerSettings Clone()
	{
		return (ServerSettings)MemberwiseClone();
	}
}
