using System;
using System.Collections;
using System.Collections.Generic;

namespace OpenRA;

public readonly struct CellCoordsRegion(CPos topLeft, CPos bottomRight) : IEnumerable<CPos>, IEnumerable
{
	public struct CellCoordsEnumerator : IEnumerator<CPos>, IEnumerator, IDisposable
	{
		private readonly CellCoordsRegion r;

		public CPos Current { get; private set; }

		readonly object IEnumerator.Current => Current;

		public CellCoordsEnumerator(CellCoordsRegion region)
		{
			this = default;
			r = region;
			Reset();
		}

		public bool MoveNext()
		{
			int num = Current.X + 1;
			int num2 = Current.Y;
			if (num > r.BottomRight.X)
			{
				num2++;
				num = r.TopLeft.X;
				if (num2 > r.BottomRight.Y)
				{
					return false;
				}
			}
			Current = new CPos(num, num2);
			return true;
		}

		public void Reset()
		{
			Current = new CPos(r.TopLeft.X - 1, r.TopLeft.Y);
		}

		public readonly void Dispose()
		{
		}
	}

	public CPos TopLeft { get; } = topLeft;

	public CPos BottomRight { get; } = bottomRight;

	public bool Contains(CPos cell)
	{
		if (cell.X >= TopLeft.X && cell.X <= BottomRight.X && cell.Y >= TopLeft.Y)
		{
			return cell.Y <= BottomRight.Y;
		}
		return false;
	}

	public override string ToString()
	{
		return $"{TopLeft}->{BottomRight}";
	}

	public CellCoordsEnumerator GetEnumerator()
	{
		return new CellCoordsEnumerator(this);
	}

	IEnumerator<CPos> IEnumerable<CPos>.GetEnumerator()
	{
		return GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
