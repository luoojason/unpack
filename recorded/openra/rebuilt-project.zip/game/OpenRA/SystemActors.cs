using System;

namespace OpenRA;

[Flags]
public enum SystemActors
{
	Player = 0,
	EditorPlayer = 1,
	World = 2,
	EditorWorld = 4
}
