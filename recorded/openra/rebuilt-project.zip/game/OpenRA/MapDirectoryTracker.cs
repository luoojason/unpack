using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.FileSystem;

namespace OpenRA;

public sealed class MapDirectoryTracker : IDisposable
{
	private enum MapAction
	{
		Add,
		Delete,
		Update
	}

	private readonly FileSystemWatcher watcher;

	private readonly MapGrid mapGrid;

	private readonly IReadOnlyPackage package;

	private readonly MapClassification classification;

	private readonly Dictionary<string, MapAction> mapActionQueue = new Dictionary<string, MapAction>();

	private bool dirty;

	public MapDirectoryTracker(MapGrid mapGrid, IReadOnlyPackage package, MapClassification classification)
	{
		this.mapGrid = mapGrid;
		this.package = package;
		this.classification = classification;
		watcher = new FileSystemWatcher(package.Name);
		watcher.Changed += (object sender, FileSystemEventArgs e) =>
		{
			AddMapAction(MapAction.Update, e.FullPath);
		};
		watcher.Created += (object sender, FileSystemEventArgs e) =>
		{
			AddMapAction(MapAction.Add, e.FullPath);
		};
		watcher.Deleted += (object sender, FileSystemEventArgs e) =>
		{
			AddMapAction(MapAction.Delete, e.FullPath);
		};
		watcher.Renamed += (object sender, RenamedEventArgs e) =>
		{
			AddMapAction(MapAction.Add, e.FullPath, e.OldFullPath);
		};
		watcher.IncludeSubdirectories = true;
		watcher.EnableRaisingEvents = true;
	}

	public void Dispose()
	{
		watcher.Dispose();
	}

	private void AddMapAction(MapAction mapAction, string fullpath, string oldFullPath = null)
	{
		lock (mapActionQueue)
		{
			dirty = true;
			string text = RemoveSubDirs(fullpath);
			if (fullpath == text)
			{
				mapActionQueue[text] = mapAction;
			}
			else
			{
				mapActionQueue[text] = MapAction.Update;
			}
			if (oldFullPath == null)
			{
				return;
			}
			string text2 = RemoveSubDirs(oldFullPath);
			if (text2 != null)
			{
				if (oldFullPath == text2)
				{
					mapActionQueue[text2] = MapAction.Delete;
				}
				else
				{
					mapActionQueue[text2] = MapAction.Update;
				}
			}
		}
	}

	public void UpdateMaps(MapCache mapcache)
	{
		lock (mapActionQueue)
		{
			if (!dirty)
			{
				return;
			}
			dirty = false;
			foreach (KeyValuePair<string, MapAction> mapAction in mapActionQueue)
			{
				MapPreview mapPreview = mapcache.FirstOrDefault((MapPreview x) => x.PackageName == mapAction.Key && x.Status == MapStatus.Available);
				if (mapPreview != null)
				{
					if (mapAction.Value == MapAction.Delete)
					{
						Console.WriteLine(mapAction.Key + " was deleted");
						mapPreview.Invalidate();
					}
					else
					{
						Console.WriteLine(mapAction.Key + " was updated");
						mapPreview.Invalidate();
						mapcache.LoadMap(mapAction.Key.Replace(package.Name + Path.DirectorySeparatorChar, ""), package, classification, mapGrid, mapPreview.Uid);
					}
				}
				else if (mapAction.Value != MapAction.Delete)
				{
					Console.WriteLine(mapAction.Key + " was added");
					mapcache.LoadMap(mapAction.Key.Replace(package?.Name + Path.DirectorySeparatorChar, ""), package, classification, mapGrid, null);
				}
			}
			mapActionQueue.Clear();
		}
	}

	private string RemoveSubDirs(string path)
	{
		string text = path.Replace(package.Name + Path.DirectorySeparatorChar, "");
		if (path == text)
		{
			return null;
		}
		return package.Name + Path.DirectorySeparatorChar + text.Split(Path.DirectorySeparatorChar)[0];
	}
}
