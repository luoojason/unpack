using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public sealed class ObjectCreator : IDisposable
{
	[AttributeUsage(AttributeTargets.Constructor)]
	public sealed class UseCtorAttribute : Attribute
	{
	}

	private static readonly Dictionary<string, Assembly> ResolvedAssemblies = new Dictionary<string, Assembly>();

	private readonly Cache<string, Type> typeCache;

	private readonly Cache<Type, ConstructorInfo> ctorCache;

	private readonly (Assembly Assembly, string Namespace)[] assemblies;

	public static Action<string> MissingTypeAction = null;

	public ObjectCreator(Manifest manifest, InstalledMods mods)
	{
		typeCache = new Cache<string, Type>(FindType);
		ctorCache = new Cache<Type, ConstructorInfo>(GetCtor);
		List<Assembly> list = new List<Assembly> { typeof(Game).Assembly };
		string[] array = manifest.Assemblies;
		foreach (string path in array)
		{
			LoadAssembly(list, Path.Combine(Platform.BinDir, path));
		}
		AppDomain.CurrentDomain.AssemblyResolve += ResolveAssembly;
		assemblies = list.SelectMany((Assembly asm) => from ns in asm.GetNamespaces()
			select (asm: asm, ns: ns)).ToArray();
	}

	private static void LoadAssembly(List<Assembly> assemblyList, string resolvedPath)
	{
		string key;
		using (FileStream data = File.OpenRead(resolvedPath))
		{
			key = CryptoUtil.SHA1Hash(data);
		}
		if (!ResolvedAssemblies.TryGetValue(key, out var value))
		{
			AssemblyLoader assemblyLoader = new AssemblyLoader(resolvedPath);
			value = assemblyLoader.LoadDefaultAssembly();
			ResolvedAssemblies.Add(key, value);
		}
		assemblyList.Add(value);
	}

	private Assembly ResolveAssembly(object sender, ResolveEventArgs e)
	{
		Assembly[] array = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in array)
		{
			if (assembly.FullName == e.Name)
			{
				return assembly;
			}
		}
		return assemblies?.Select(((Assembly Assembly, string Namespace) a) => a.Assembly).FirstOrDefault((Assembly a) => a.FullName == e.Name);
	}

	public T CreateObject<T>(string className)
	{
		return CreateObject<T>(className, new Dictionary<string, object>());
	}

	public T CreateObject<T>(string className, Dictionary<string, object> args)
	{
		Type type = typeCache[className];
		if (type == null)
		{
			if (MissingTypeAction != null)
			{
				MissingTypeAction(className);
				return default;
			}
			throw new InvalidOperationException("Cannot locate type: " + className);
		}
		ConstructorInfo constructorInfo = ctorCache[type];
		if (constructorInfo == null)
		{
			return (T)CreateBasic(type);
		}
		return (T)CreateUsingArgs(constructorInfo, args);
	}

	public Type FindType(string className)
	{
		return assemblies.Select(((Assembly Assembly, string Namespace) pair) => pair.Assembly.GetType(pair.Namespace + "." + className, throwOnError: false)).FirstOrDefault((Type t) => t != null);
	}

	public ConstructorInfo GetCtor(Type type)
	{
		List<ConstructorInfo> list = (from x in type.GetConstructors(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
			where x.HasAttribute<UseCtorAttribute>()
			select x).ToList();
		if (list.Count > 1)
		{
			throw new InvalidOperationException("ObjectCreator: UseCtor on multiple constructors; invalid.");
		}
		return list.FirstOrDefault();
	}

	public object CreateBasic(Type type)
	{
		return type.GetConstructor(Array.Empty<Type>()).Invoke(Array.Empty<object>());
	}

	public object CreateUsingArgs(ConstructorInfo ctor, Dictionary<string, object> args)
	{
		ParameterInfo[] parameters = ctor.GetParameters();
		object[] array = new object[parameters.Length];
		for (int i = 0; i < parameters.Length; i++)
		{
			string name = parameters[i].Name;
			if (!args.TryGetValue(name, out var value))
			{
				throw new InvalidOperationException("ObjectCreator: key `" + name + "' not found");
			}
			array[i] = value;
		}
		return ctor.Invoke(array);
	}

	public IEnumerable<Type> GetTypesImplementing<T>()
	{
		Type it = typeof(T);
		return from t in GetTypes()
			where t != it && it.IsAssignableFrom(t)
			select t;
	}

	public IEnumerable<Type> GetTypes()
	{
		return assemblies.Select(((Assembly Assembly, string Namespace) ma) => ma.Assembly).Distinct().SelectMany((Assembly ma) => ma.GetTypes());
	}

	public TLoader GetLoader<TLoader>(string format, string name)
	{
		Type type = FindType(format + "Loader");
		if (type == null || !Enumerable.Contains(type.GetInterfaces(), typeof(TLoader)))
		{
			throw new InvalidOperationException($"Unable to find a {name} loader for type '{format}'.");
		}
		return (TLoader)CreateBasic(type);
	}

	public TLoader[] GetLoaders<TLoader>(IEnumerable<string> formats, string name)
	{
		List<TLoader> list = new List<TLoader>();
		foreach (string format in formats)
		{
			list.Add(GetLoader<TLoader>(format, name));
		}
		return list.ToArray();
	}

	~ObjectCreator()
	{
		Dispose(disposing: false);
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	private void Dispose(bool disposing)
	{
		if (disposing)
		{
			AppDomain.CurrentDomain.AssemblyResolve -= ResolveAssembly;
		}
	}
}
