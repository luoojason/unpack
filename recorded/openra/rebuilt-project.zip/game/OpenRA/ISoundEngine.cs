using System;
using System.IO;

namespace OpenRA;

public interface ISoundEngine : IDisposable
{
	bool Dummy { get; }

	float Volume { get; set; }

	SoundDevice[] AvailableDevices();

	ISoundSource AddSoundSourceFromMemory(byte[] data, int channels, int sampleBits, int sampleRate);

	ISound Play2D(ISoundSource sound, bool loop, bool relative, WPos pos, float volume, bool attenuateVolume);

	ISound Play2DStream(Stream stream, int channels, int sampleBits, int sampleRate, bool loop, bool relative, WPos pos, float volume);

	void PauseSound(ISound sound, bool paused);

	void StopSound(ISound sound);

	void SetAllSoundsPaused(bool paused);

	void StopAllSounds();

	void SetListenerPosition(WPos position);

	void SetSoundVolume(float volume, ISound music, ISound video);

	void SetSoundLooping(bool looping, ISound sound);

	void SetSoundPosition(ISound sound, WPos position);
}
