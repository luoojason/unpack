using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using OpenRA.FileSystem;
using OpenRA.Primitives;

namespace OpenRA;

public sealed class Manifest : IDisposable
{
	public readonly string Id;

	public readonly IReadOnlyPackage Package;

	public readonly ModMetadata Metadata;

	public readonly string[] Rules;

	public readonly string[] ServerTraits;

	public readonly string[] Sequences;

	public readonly string[] ModelSequences;

	public readonly string[] Cursors;

	public readonly string[] Chrome;

	public readonly string[] ChromeLayout;

	public readonly string[] Weapons;

	public readonly string[] Voices;

	public readonly string[] Notifications;

	public readonly string[] Music;

	public readonly string[] FluentMessages;

	public readonly string[] TileSets;

	public readonly string[] ChromeMetrics;

	public readonly string[] MapCompatibility;

	public readonly string[] Missions;

	public readonly string[] Hotkeys;

	public readonly IReadOnlyDictionary<string, string> MapFolders;

	public readonly MiniYaml FileSystem;

	public readonly MiniYaml LoadScreen;

	public readonly string DefaultOrderGenerator;

	public readonly string[] Assemblies = Array.Empty<string>();

	public readonly string[] SoundFormats = Array.Empty<string>();

	public readonly string[] SpriteFormats = Array.Empty<string>();

	public readonly string[] PackageFormats = Array.Empty<string>();

	public readonly string[] VideoFormats = Array.Empty<string>();

	public readonly int FontSheetSize = 512;

	public readonly int CursorSheetSize = 512;

	public readonly string FluentCulture = "en";

	public readonly bool AllowUnusedFluentMessagesInExternalPackages = true;

	private readonly string[] reservedModuleNames = new string[32]
	{
		"Include", "Metadata", "FileSystem", "MapFolders", "Rules", "Sequences", "ModelSequences", "Cursors", "Chrome", "Assemblies",
		"ChromeLayout", "Weapons", "Voices", "Notifications", "Music", "FluentMessages", "TileSets", "ChromeMetrics", "Missions", "Hotkeys",
		"ServerTraits", "LoadScreen", "DefaultOrderGenerator", "SupportsMapsFrom", "SoundFormats", "SpriteFormats", "VideoFormats", "RequiresMods", "PackageFormats", "AllowUnusedFluentMessagesInExternalPackages",
		"FontSheetSize", "CursorSheetSize"
	};

	private readonly TypeDictionary modules = new TypeDictionary();

	private readonly Dictionary<string, MiniYaml> yaml;

	private bool customDataLoaded;

	public Manifest(string modId, IReadOnlyPackage package)
	{
		Id = modId;
		Package = package;
		HashSet<string> stringPool = new HashSet<string>();
		List<MiniYamlNode> list = MiniYaml.FromStream(package.GetStream("mod.yaml"), package.Name + ":mod.yaml", discardCommentsAndWhitespace: true, stringPool);
		for (int num = list.Count - 1; num >= 0; num--)
		{
			if (!(list[num].Key != "Include"))
			{
				string value = list[num].Value.Value;
				Stream stream = package.GetStream(value);
				if (stream == null)
				{
					throw new YamlException($"{list[num].Location}: File `{value}` not found.");
				}
				list.RemoveAt(num);
				list.InsertRange(num, MiniYaml.FromStream(stream, package.Name + ":" + value, discardCommentsAndWhitespace: true, stringPool));
			}
		}
		yaml = new MiniYaml(null, MiniYaml.Merge(new List<MiniYamlNode>[1] { list })).ToDictionary();
		Metadata = FieldLoader.Load<ModMetadata>(yaml["Metadata"]);
		MapFolders = YamlDictionary(yaml, "MapFolders");
		if (!yaml.TryGetValue("FileSystem", out FileSystem))
		{
			throw new InvalidDataException("`FileSystem` section is not defined.");
		}
		Rules = YamlList(yaml, "Rules");
		Sequences = YamlList(yaml, "Sequences");
		ModelSequences = YamlList(yaml, "ModelSequences");
		Cursors = YamlList(yaml, "Cursors");
		Chrome = YamlList(yaml, "Chrome");
		ChromeLayout = YamlList(yaml, "ChromeLayout");
		Weapons = YamlList(yaml, "Weapons");
		Voices = YamlList(yaml, "Voices");
		Notifications = YamlList(yaml, "Notifications");
		Music = YamlList(yaml, "Music");
		FluentMessages = YamlList(yaml, "FluentMessages");
		TileSets = YamlList(yaml, "TileSets");
		ChromeMetrics = YamlList(yaml, "ChromeMetrics");
		Missions = YamlList(yaml, "Missions");
		Hotkeys = YamlList(yaml, "Hotkeys");
		ServerTraits = YamlList(yaml, "ServerTraits");
		if (!yaml.TryGetValue("LoadScreen", out LoadScreen))
		{
			throw new InvalidDataException("`LoadScreen` section is not defined.");
		}
		List<string> list2 = new List<string> { Id };
		if (yaml.TryGetValue("SupportsMapsFrom", out var value2))
		{
			list2.AddRange(from c in value2.Value.Split(',')
				select c.Trim());
		}
		MapCompatibility = list2.ToArray();
		if (yaml.TryGetValue("DefaultOrderGenerator", out value2))
		{
			DefaultOrderGenerator = value2.Value;
		}
		if (yaml.TryGetValue("Assemblies", out value2))
		{
			Assemblies = FieldLoader.GetValue<string[]>("Assemblies", value2.Value);
		}
		if (yaml.TryGetValue("PackageFormats", out value2))
		{
			PackageFormats = FieldLoader.GetValue<string[]>("PackageFormats", value2.Value);
		}
		if (yaml.TryGetValue("SoundFormats", out value2))
		{
			SoundFormats = FieldLoader.GetValue<string[]>("SoundFormats", value2.Value);
		}
		if (yaml.TryGetValue("SpriteFormats", out value2))
		{
			SpriteFormats = FieldLoader.GetValue<string[]>("SpriteFormats", value2.Value);
		}
		if (yaml.TryGetValue("VideoFormats", out value2))
		{
			VideoFormats = FieldLoader.GetValue<string[]>("VideoFormats", value2.Value);
		}
		if (yaml.TryGetValue("AllowUnusedFluentMessagesInExternalPackages", out value2))
		{
			AllowUnusedFluentMessagesInExternalPackages = FieldLoader.GetValue<bool>("AllowUnusedFluentMessagesInExternalPackages", value2.Value);
		}
		if (yaml.TryGetValue("FontSheetSize", out value2))
		{
			FontSheetSize = FieldLoader.GetValue<int>("FontSheetSize", value2.Value);
		}
		if (yaml.TryGetValue("CursorSheetSize", out value2))
		{
			CursorSheetSize = FieldLoader.GetValue<int>("CursorSheetSize", value2.Value);
		}
	}

	public void LoadCustomData(ObjectCreator oc)
	{
		foreach (KeyValuePair<string, MiniYaml> item in yaml)
		{
			if (!Enumerable.Contains(reservedModuleNames, item.Key))
			{
				Type type = oc.FindType(item.Key);
				if (type == null || !typeof(IGlobalModData).IsAssignableFrom(type))
				{
					throw new InvalidDataException("`" + item.Key + "` is not a valid mod manifest entry.");
				}
				ConstructorInfo constructor = type.GetConstructor(new Type[1] { typeof(MiniYaml) });
				IGlobalModData globalModData;
				if (constructor != null)
				{
					globalModData = (IGlobalModData)constructor.Invoke(new object[1] { item.Value });
				}
				else
				{
					globalModData = oc.CreateObject<IGlobalModData>(item.Key);
					FieldLoader.Load(globalModData, item.Value);
				}
				modules.Add(globalModData);
			}
		}
		customDataLoaded = true;
	}

	private static string[] YamlList(Dictionary<string, MiniYaml> yaml, string key)
	{
		if (!yaml.TryGetValue(key, out var value))
		{
			return Array.Empty<string>();
		}
		return value.Nodes.Select((MiniYamlNode n) => n.Key).ToArray();
	}

	private static IReadOnlyDictionary<string, string> YamlDictionary(Dictionary<string, MiniYaml> yaml, string key)
	{
		if (!yaml.TryGetValue(key, out var value))
		{
			return new Dictionary<string, string>();
		}
		return value.ToDictionary((MiniYaml my) => my.Value);
	}

	public bool Contains<T>() where T : IGlobalModData
	{
		return modules.Contains<T>();
	}

	public T Get<T>() where T : IGlobalModData
	{
		if (!customDataLoaded)
		{
			throw new InvalidOperationException("Attempted to call Manifest.Get() before loading custom data!");
		}
		T val = modules.GetOrDefault<T>();
		if (val == null)
		{
			val = (T)Game.ModData.ObjectCreator.CreateBasic(typeof(T));
			modules.Add(val);
		}
		return val;
	}

	public T Get<T>(ObjectCreator oc) where T : IGlobalModData
	{
		Type typeFromHandle = typeof(T);
		if (!yaml.TryGetValue(typeFromHandle.Name, out var value))
		{
			return (T)oc.CreateBasic(typeFromHandle);
		}
		ConstructorInfo constructor = typeFromHandle.GetConstructor(new Type[1] { typeof(MiniYaml) });
		IGlobalModData globalModData;
		if (constructor != null)
		{
			globalModData = (IGlobalModData)constructor.Invoke(new object[1] { value.Value });
		}
		else
		{
			globalModData = oc.CreateObject<IGlobalModData>(typeFromHandle.Name);
			FieldLoader.Load(globalModData, value);
		}
		return (T)globalModData;
	}

	public void Dispose()
	{
		foreach (object module in modules)
		{
			if (module is IDisposable disposable)
			{
				disposable.Dispose();
			}
		}
	}
}
