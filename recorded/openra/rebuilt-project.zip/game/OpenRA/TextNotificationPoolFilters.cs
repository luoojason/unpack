using System;

namespace OpenRA;

[Flags]
public enum TextNotificationPoolFilters
{
	None = 0,
	Feedback = 1,
	Transients = 2
}
