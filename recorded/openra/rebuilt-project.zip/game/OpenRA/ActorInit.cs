namespace OpenRA;

public abstract class ActorInit
{
	[FieldLoader.Ignore]
	public readonly string InstanceName;

	protected ActorInit(string instanceName)
	{
		InstanceName = instanceName;
	}

	protected ActorInit()
	{
	}

	public abstract MiniYaml Save();
}
