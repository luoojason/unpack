namespace OpenRA;

public enum TextNotificationPool
{
	System,
	Join,
	Leave,
	Chat,
	Mission,
	Feedback,
	Transients
}
