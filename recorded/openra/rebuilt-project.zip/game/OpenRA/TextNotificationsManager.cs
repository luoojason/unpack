using System.Collections.Generic;
using OpenRA.Primitives;
using OpenRA.Widgets;

namespace OpenRA;

public static class TextNotificationsManager
{
	public const int SystemClientId = -1;

	private static readonly string SystemMessageLabel;

	public static readonly Dictionary<int, bool> MutedPlayers;

	private static readonly List<TextNotification> NotificationsCache;

	public static long ChatDisabledUntil { get; internal set; }

	public static IReadOnlyList<TextNotification> Notifications => NotificationsCache;

	static TextNotificationsManager()
	{
		MutedPlayers = new Dictionary<int, bool>();
		NotificationsCache = new List<TextNotification>();
		if (!ChromeMetrics.TryGet<string>("SystemMessageLabel", out SystemMessageLabel))
		{
			SystemMessageLabel = "Battlefield Control";
		}
	}

	public static void AddTransientLine(Player player, string text)
	{
		if (!string.IsNullOrEmpty(text) && (player == null || player == player.World.LocalPlayer))
		{
			AddTextNotification(TextNotificationPool.Transients, -1, SystemMessageLabel, FluentProvider.GetMessage(text));
		}
	}

	public static void AddFeedbackLine(string text, params object[] args)
	{
		AddTextNotification(TextNotificationPool.Feedback, -1, SystemMessageLabel, FluentProvider.GetMessage(text, args));
	}

	public static void AddMissionLine(string prefix, string text, Color? prefixColor = null)
	{
		AddTextNotification(TextNotificationPool.Mission, -1, prefix, text, prefixColor);
	}

	public static void AddPlayerJoinedLine(string text, params object[] args)
	{
		AddTextNotification(TextNotificationPool.Join, -1, SystemMessageLabel, FluentProvider.GetMessage(text, args));
	}

	public static void AddPlayerLeftLine(string text, params object[] args)
	{
		AddTextNotification(TextNotificationPool.Leave, -1, SystemMessageLabel, FluentProvider.GetMessage(text, args));
	}

	public static void AddSystemLine(string text, params object[] args)
	{
		AddSystemLine(SystemMessageLabel, FluentProvider.GetMessage(text, args));
	}

	public static void AddSystemLine(string prefix, string text)
	{
		AddTextNotification(TextNotificationPool.System, -1, prefix, text);
	}

	public static void AddChatLine(int clientId, string prefix, string text, Color? prefixColor = null, Color? textColor = null)
	{
		AddTextNotification(TextNotificationPool.Chat, clientId, prefix, text, prefixColor, textColor);
	}

	public static void Debug(string format, params object[] args)
	{
		AddSystemLine("Debug", format.FormatCurrent(args));
	}

	private static void AddTextNotification(TextNotificationPool pool, int clientId, string prefix, string text, Color? prefixColor = null, Color? textColor = null)
	{
		if (IsPoolEnabled(pool))
		{
			TextNotification textNotification = new TextNotification(pool, clientId, prefix, text, prefixColor, textColor);
			NotificationsCache.Add(textNotification);
			Ui.Send(textNotification);
		}
	}

	private static bool IsPoolEnabled(TextNotificationPool pool)
	{
		TextNotificationPoolFilters textNotificationPoolFilters = Game.Settings.Game.TextNotificationPoolFilters;
		return pool switch
		{
			TextNotificationPool.Transients => textNotificationPoolFilters.HasFlag(TextNotificationPoolFilters.Transients), 
			TextNotificationPool.Feedback => textNotificationPoolFilters.HasFlag(TextNotificationPoolFilters.Feedback), 
			_ => true, 
		};
	}

	public static void Clear()
	{
		ChatDisabledUntil = Game.RunTime;
		NotificationsCache.Clear();
		MutedPlayers.Clear();
	}
}
