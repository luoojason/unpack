using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenRA.FileSystem;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Support;

namespace OpenRA;

public sealed class MapCache : IEnumerable<MapPreview>, IEnumerable, IDisposable
{
	public static readonly MapPreview UnknownMap = new MapPreview(null, null, MapGridType.Rectangular, null);

	private readonly Dictionary<IReadOnlyPackage, MapClassification> mapLocations = new Dictionary<IReadOnlyPackage, MapClassification>();

	public bool LoadPreviewImages = true;

	private readonly Cache<string, MapPreview> previews;

	private readonly ModData modData;

	private readonly SheetBuilder sheetBuilder;

	private Thread previewLoaderThread;

	private bool previewLoaderThreadShutDown = true;

	private readonly object syncRoot = new object();

	private readonly Queue<MapPreview> generateMinimap = new Queue<MapPreview>();

	private readonly List<MapDirectoryTracker> mapDirectoryTrackers = new List<MapDirectoryTracker>();

	private readonly Dictionary<string, string> mapUpdates = new Dictionary<string, string>();

	private string lastLoadedLastModifiedMap;

	public IReadOnlyDictionary<IReadOnlyPackage, MapClassification> MapLocations => mapLocations;

	public HashSet<string> StringPool { get; } = new HashSet<string>();

	public string LastModifiedMap { get; private set; }

	public MapPreview this[string key]
	{
		get
		{
			UpdateMaps();
			return previews[key];
		}
	}

	public string PickLastModifiedMap(MapVisibility visibility)
	{
		UpdateMaps();
		MapPreview mapPreview = (string.IsNullOrEmpty(LastModifiedMap) ? null : this[LastModifiedMap]);
		if (mapPreview != null && mapPreview.Status == MapStatus.Available && mapPreview.Visibility.HasFlag(visibility) && lastLoadedLastModifiedMap != LastModifiedMap)
		{
			lastLoadedLastModifiedMap = LastModifiedMap;
			return lastLoadedLastModifiedMap;
		}
		return null;
	}

	public MapCache(ModData modData)
	{
		MapCache cache = this;
		this.modData = modData;
		Lazy<MapGridType> gridType = Exts.Lazy(() => modData.Manifest.Get<MapGrid>().Type);
		previews = new Cache<string, MapPreview>((string uid) => new MapPreview(modData, uid, gridType.Value, cache));
		sheetBuilder = new SheetBuilder(SheetType.BGRA);
	}

	public void UpdateMaps()
	{
		foreach (MapDirectoryTracker mapDirectoryTracker in mapDirectoryTrackers)
		{
			mapDirectoryTracker.UpdateMaps(this);
		}
	}

	public void LoadMaps()
	{
		if (!modData.Manifest.Contains<MapGrid>())
		{
			return;
		}
		MapGrid mapGrid = modData.Manifest.Get<MapGrid>();
		foreach (KeyValuePair<string, string> mapFolder in modData.Manifest.MapFolders)
		{
			string text = mapFolder.Key;
			MapClassification mapClassification = ((!string.IsNullOrEmpty(mapFolder.Value)) ? Enum<MapClassification>.Parse(mapFolder.Value) : MapClassification.Unknown);
			bool flag = text.StartsWith('~');
			if (flag)
			{
				text = text.Substring(1);
			}
			IReadOnlyPackage readOnlyPackage;
			try
			{
				string text2 = Platform.ResolvePath(text);
				if (text2.StartsWith(Platform.SupportDir, StringComparison.Ordinal) && !File.Exists(text2))
				{
					Directory.CreateDirectory(text2);
				}
				readOnlyPackage = modData.ModFiles.OpenPackage(text);
			}
			catch
			{
				if (flag)
				{
					continue;
				}
				throw;
			}
			mapLocations.Add(readOnlyPackage, mapClassification);
			mapDirectoryTrackers.Add(new MapDirectoryTracker(mapGrid, readOnlyPackage, mapClassification));
		}
		List<MiniYamlNode>[] rulesYaml = modData.GetRulesYaml();
		foreach (KeyValuePair<IReadOnlyPackage, MapClassification> mapLocation in MapLocations)
		{
			foreach (string content in mapLocation.Key.Contents)
			{
				LoadMapInternal(content, mapLocation.Key, mapLocation.Value, mapGrid, null, rulesYaml);
			}
		}
		LastModifiedMap = null;
	}

	public void LoadMap(string map, IReadOnlyPackage package, MapClassification classification, MapGrid mapGrid, string oldMap)
	{
		LoadMapInternal(map, package, classification, mapGrid, oldMap, null);
	}

	private void LoadMapInternal(string map, IReadOnlyPackage package, MapClassification classification, MapGrid mapGrid, string oldMap, IEnumerable<List<MiniYamlNode>> modDataRules)
	{
		IReadOnlyPackage readOnlyPackage = null;
		try
		{
			using (new PerfTimer(map))
			{
				readOnlyPackage = package.OpenPackage(map, modData.ModFiles);
				if (readOnlyPackage == null)
				{
					return;
				}
				string text = Map.ComputeUID(readOnlyPackage);
				previews[text].UpdateFromMap(readOnlyPackage, package, classification, modData.Manifest.MapCompatibility, mapGrid.Type, modDataRules);
				previews[text].DisposePackage();
				if (oldMap != text)
				{
					LastModifiedMap = text;
					if (oldMap != null)
					{
						mapUpdates[oldMap] = text;
					}
				}
			}
		}
		catch (Exception ex)
		{
			readOnlyPackage?.Dispose();
			Console.WriteLine("Failed to load map: " + map);
			Console.WriteLine("Details:");
			Console.WriteLine(ex);
			Log.Write("debug", "Failed to load map: " + map);
			Log.Write("debug", "Details:");
			Log.Write("debug", ex);
		}
	}

	public IEnumerable<IReadWritePackage> EnumerateMapDirPackages(MapClassification classification = MapClassification.System)
	{
		if (!modData.Manifest.Contains<MapGrid>())
		{
			yield break;
		}
		foreach (KeyValuePair<string, string> mapFolder in modData.Manifest.MapFolders)
		{
			if (!Enum.TryParse<MapClassification>(mapFolder.Value, out var result) || !classification.HasFlag(result))
			{
				continue;
			}
			string text = mapFolder.Key;
			if (text.StartsWith('~'))
			{
				text = text.Substring(1);
			}
			string text2 = Platform.ResolvePath(text);
			if (!text2.StartsWith(Platform.SupportDir, StringComparison.Ordinal) || (Directory.Exists(text2) && File.Exists(text2)))
			{
				using IReadWritePackage package = (IReadWritePackage)modData.ModFiles.OpenPackage(text);
				yield return package;
			}
		}
	}

	public IEnumerable<(IReadWritePackage Package, string Map)> EnumerateMapDirPackagesAndNames(MapClassification classification = MapClassification.System)
	{
		IEnumerable<IReadWritePackage> enumerable = EnumerateMapDirPackages(classification);
		foreach (IReadWritePackage mapDirPackage in enumerable)
		{
			foreach (string content in mapDirPackage.Contents)
			{
				yield return (Package: mapDirPackage, Map: content);
			}
		}
	}

	public IEnumerable<IReadWritePackage> EnumerateMapPackagesWithoutCaching(MapClassification classification = MapClassification.System)
	{
		IEnumerable<IReadWritePackage> enumerable = EnumerateMapDirPackages(classification);
		foreach (IReadWritePackage mapDirPackage in enumerable)
		{
			foreach (string content in mapDirPackage.Contents)
			{
				if (mapDirPackage.OpenPackage(content, modData.ModFiles) is IReadWritePackage readWritePackage)
				{
					yield return readWritePackage;
				}
			}
		}
	}

	public void QueryRemoteMapDetails(string repositoryUrl, IEnumerable<string> uids, Action<MapPreview> mapDetailsReceived = null, Action<MapPreview> mapQueryFailed = null)
	{
		List<string> queryUids = (from uid in uids.Distinct()
			where uid != null
			select previews[uid] into p
			where p.Status == MapStatus.Unavailable
			select p.Uid).ToList();
		foreach (string item in queryUids)
		{
			previews[item].UpdateRemoteSearch(MapStatus.Searching, null, null);
		}
		Task.Run(async () =>
		{
			HttpClient client = HttpClientFactory.Create();
			HashSet<string> stringPool = new HashSet<string>();
			StringBuilder buffer = new StringBuilder();
			for (int i = 0; i < queryUids.Count; i += 50)
			{
				List<string> batchUids = queryUids.Skip(i).Take(50).ToList();
				string url = repositoryUrl + "hash/" + string.Join(",", batchUids) + "/yaml";
				using (new PerfTimer("RemoteMapDetails"))
				{
					_ = 2;
					try
					{
						await using (Stream resultStream = await client.GetStreamAsync(url))
						{
							using StreamReader resultReader = new StreamReader(resultStream);
							while (true)
							{
								string text = await resultReader.ReadLineAsync();
								if (text == null || !text.StartsWith('\t'))
								{
									List<MiniYamlNode> list = MiniYaml.FromString(buffer.ToString(), url, discardCommentsAndWhitespace: true, stringPool);
									buffer.Clear();
									foreach (MiniYamlNode item2 in list)
									{
										previews[item2.Key].UpdateRemoteSearch(MapStatus.DownloadAvailable, item2.Value, modData.Manifest.MapCompatibility, mapDetailsReceived);
									}
									if (text == null)
									{
										break;
									}
								}
								buffer.Append(text);
								buffer.Append('\n');
							}
						}
						foreach (string item3 in batchUids)
						{
							MapPreview mapPreview = previews[item3];
							if (mapPreview.Status != MapStatus.DownloadAvailable)
							{
								mapPreview.UpdateRemoteSearch(MapStatus.Unavailable, null, null);
							}
						}
					}
					catch (Exception e)
					{
						Log.Write("debug", "Remote map query failed with error:");
						Log.Write("debug", e);
						Log.Write("debug", "URL was: " + url);
						foreach (string item4 in batchUids)
						{
							MapPreview mapPreview2 = previews[item4];
							mapPreview2.UpdateRemoteSearch(MapStatus.Unavailable, null, null);
							mapQueryFailed?.Invoke(mapPreview2);
						}
					}
				}
			}
		});
	}

	private void LoadAsyncInternal()
	{
		Log.Write("debug", "MapCache.LoadAsyncInternal started");
		int num = 100;
		while (true)
		{
			List<MapPreview> list;
			lock (syncRoot)
			{
				list = generateMinimap.Where((MapPreview mapPreview) => mapPreview.GetMinimap() == null).ToList();
				generateMinimap.Clear();
				if (num > 0)
				{
					num--;
				}
				if (num == 0 && list.Count == 0)
				{
					previewLoaderThreadShutDown = true;
					break;
				}
			}
			if (list.Count == 0)
			{
				Thread.Sleep(50);
				continue;
			}
			num = 100;
			foreach (MapPreview p in list)
			{
				if (p.Preview != null)
				{
					Game.RunAfterTick(() =>
					{
						try
						{
							p.SetMinimap(sheetBuilder.Add(p.Preview));
						}
						catch (Exception e)
						{
							Log.Write("debug", "Failed to load minimap with exception:");
							Log.Write("debug", e);
						}
					});
				}
				Thread.Sleep((Environment.ProcessorCount == 1) ? 25 : 5);
			}
		}
		Game.RunAfterTick(sheetBuilder.Current.ReleaseBuffer);
		Log.Write("debug", "MapCache.LoadAsyncInternal ended");
	}

	public string GetUpdatedMap(string uid)
	{
		if (uid == null)
		{
			return null;
		}
		while (this[uid].Status != MapStatus.Available)
		{
			if (mapUpdates.TryGetValue(uid, out var value))
			{
				uid = value;
				continue;
			}
			return null;
		}
		return uid;
	}

	public void CacheMinimap(MapPreview preview)
	{
		bool flag;
		lock (syncRoot)
		{
			generateMinimap.Enqueue(preview);
			flag = previewLoaderThreadShutDown;
			previewLoaderThreadShutDown = false;
		}
		if (flag)
		{
			Game.RunAfterTick(() =>
			{
				previewLoaderThread?.Join();
				previewLoaderThread = new Thread(LoadAsyncInternal)
				{
					Name = "Map Preview Loader",
					IsBackground = true
				};
				previewLoaderThread.Start();
			});
		}
	}

	private bool IsSuitableInitialMap(MapPreview map)
	{
		if (map.Status != MapStatus.Available || !map.Visibility.HasFlag(MapVisibility.Lobby))
		{
			return false;
		}
		if (!Enumerable.Contains(map.Categories, "Conquest"))
		{
			return false;
		}
		if (map.Players.Players.Any((KeyValuePair<string, PlayerReference> x) => !x.Value.AllowBots))
		{
			return false;
		}
		if (map.Bounds.Width > 128 || map.Bounds.Height > 128)
		{
			return false;
		}
		return true;
	}

	public string ChooseInitialMap(string initialUid, MersenneTwister random)
	{
		UpdateMaps();
		MapPreview mapPreview = (string.IsNullOrEmpty(initialUid) ? null : previews[initialUid]);
		if (mapPreview == null || mapPreview.Status != MapStatus.Available || !mapPreview.Visibility.HasFlag(MapVisibility.Lobby) || (mapPreview.Class != MapClassification.System && mapPreview.Class != MapClassification.User))
		{
			MapPreview mapPreview2 = previews.Values.Where(IsSuitableInitialMap).RandomOrDefault(random) ?? previews.Values.FirstOrDefault((MapPreview m) => m.Status == MapStatus.Available && m.Visibility.HasFlag(MapVisibility.Lobby) && (m.Class == MapClassification.System || m.Class == MapClassification.User));
			if (mapPreview2 != null)
			{
				return mapPreview2.Uid;
			}
			return string.Empty;
		}
		return initialUid;
	}

	public IEnumerator<MapPreview> GetEnumerator()
	{
		UpdateMaps();
		return previews.Values.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}

	public void Dispose()
	{
		if (previewLoaderThread == null)
		{
			sheetBuilder.Dispose();
			return;
		}
		foreach (MapPreview value in previews.Values)
		{
			value.Dispose();
		}
		foreach (MapDirectoryTracker mapDirectoryTracker in mapDirectoryTrackers)
		{
			mapDirectoryTracker.Dispose();
		}
		ThreadPool.QueueUserWorkItem((object? _) =>
		{
			previewLoaderThread.Join();
			Game.RunAfterTick(sheetBuilder.Dispose);
		});
	}
}
