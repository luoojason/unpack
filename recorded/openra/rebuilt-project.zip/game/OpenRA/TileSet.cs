namespace OpenRA;

public static class TileSet
{
	public const string TerrainPaletteInternalName = "terrain";
}
