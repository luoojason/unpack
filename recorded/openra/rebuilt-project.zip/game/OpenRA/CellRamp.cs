namespace OpenRA;

public readonly struct CellRamp
{
	public readonly int CenterHeightOffset;

	public readonly WVec[] Corners;

	public readonly WVec[][] Polygons;

	public readonly WRot Orientation;

	public CellRamp(MapGridType type, WRot orientation, RampCornerHeight tl = RampCornerHeight.Low, RampCornerHeight tr = RampCornerHeight.Low, RampCornerHeight br = RampCornerHeight.Low, RampCornerHeight bl = RampCornerHeight.Low, RampSplit split = RampSplit.Flat)
	{
		Orientation = orientation;
		if (type == MapGridType.RectangularIsometric)
		{
			Corners = new WVec[4]
			{
				new WVec(0, -724, 724 * (int)tl),
				new WVec(724, 0, 724 * (int)tr),
				new WVec(0, 724, 724 * (int)br),
				new WVec(-724, 0, 724 * (int)bl)
			};
		}
		else
		{
			Corners = new WVec[4]
			{
				new WVec(-512, -512, 512 * (int)tl),
				new WVec(512, -512, 512 * (int)tr),
				new WVec(512, 512, 512 * (int)br),
				new WVec(-512, 512, 512 * (int)bl)
			};
		}
		switch (split)
		{
		case RampSplit.X:
			Polygons = new WVec[2][]
			{
				new WVec[3]
				{
					Corners[0],
					Corners[1],
					Corners[3]
				},
				new WVec[3]
				{
					Corners[1],
					Corners[2],
					Corners[3]
				}
			};
			break;
		case RampSplit.Y:
			Polygons = new WVec[2][]
			{
				new WVec[3]
				{
					Corners[0],
					Corners[1],
					Corners[2]
				},
				new WVec[3]
				{
					Corners[0],
					Corners[2],
					Corners[3]
				}
			};
			break;
		default:
			Polygons = new WVec[1][] { Corners };
			break;
		}
		CenterHeightOffset = 0;
		CenterHeightOffset = HeightOffset(0, 0);
	}

	public int HeightOffset(int dX, int dY)
	{
		WVec[] array = null;
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < Polygons.Length; i++)
		{
			array = Polygons[i];
			num = ((array[1].Y - array[2].Y) * (dX - array[2].X) - (array[1].X - array[2].X) * (dY - array[2].Y)) / 1024;
			num2 = ((array[0].X - array[2].X) * (dY - array[2].Y) - (array[0].Y - array[2].Y) * (dX - array[2].X)) / 1024;
			if (num >= 0 && num <= 1024 && num2 >= 0 && num2 <= 1024)
			{
				break;
			}
		}
		return (num * array[0].Z + num2 * array[1].Z + (1024 - num - num2) * array[2].Z) / 1024;
	}
}
