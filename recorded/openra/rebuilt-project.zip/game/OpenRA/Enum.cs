using System;
using System.Collections.Generic;
using System.Linq;

namespace OpenRA;

public static class Enum<T>
{
	public static T Parse(string s)
	{
		return (T)Enum.Parse(typeof(T), s);
	}

	public static T[] GetValues()
	{
		return (T[])Enum.GetValues(typeof(T));
	}

	public static bool TryParse(string s, bool ignoreCase, out T value)
	{
		IEnumerable<string> enumerable;
		if (!ignoreCase)
		{
			IEnumerable<string> names = Enum.GetNames(typeof(T));
			enumerable = names;
		}
		else
		{
			enumerable = from x in Enum.GetNames(typeof(T))
				select x.ToLowerInvariant();
		}
		IEnumerable<string> names2 = enumerable;
		IEnumerable<string> source = (ignoreCase ? (from x in s.Split(',')
			select x.Trim().ToLowerInvariant()) : (from x in s.Split(',')
			select x.Trim()));
		if (source.Any((string x) => !names2.Contains(x)))
		{
			value = default;
			return false;
		}
		value = (T)Enum.Parse(typeof(T), s, ignoreCase);
		return true;
	}
}
