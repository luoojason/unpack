namespace OpenRA;

public enum WindowMode
{
	Windowed,
	Fullscreen,
	PseudoFullscreen
}
