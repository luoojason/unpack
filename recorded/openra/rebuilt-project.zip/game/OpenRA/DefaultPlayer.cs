using OpenRA.Primitives;

namespace OpenRA;

public class DefaultPlayer : IGlobalModData
{
	public readonly Color Color = Color.FromArgb(238, 238, 238);
}
