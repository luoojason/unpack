using System;

namespace OpenRA;

[AttributeUsage(AttributeTargets.All)]
public sealed class DescAttribute : Attribute
{
	public readonly string[] Lines;

	public DescAttribute(params string[] lines)
	{
		Lines = lines;
	}
}
