using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace OpenRA;

public static class Platform
{
	public static readonly Guid SessionGUID = Guid.NewGuid();

	private static readonly Lazy<PlatformType> LazyCurrentPlatform = Exts.Lazy(GetCurrentPlatform);

	private static bool engineDirAccessed;

	private static string engineDir;

	private static bool supportDirInitialized;

	private static string systemSupportPath;

	private static string legacyUserSupportPath;

	private static string modernUserSupportPath;

	private static string userSupportPath;

	public static PlatformType CurrentPlatform => LazyCurrentPlatform.Value;

	public static Architecture CurrentArchitecture => RuntimeInformation.ProcessArchitecture;

	public static string RuntimeVersion
	{
		get
		{
			Type type = Type.GetType("Mono.Runtime");
			if (!(type == null))
			{
				MethodInfo method = type.GetMethod("GetDisplayName", BindingFlags.Static | BindingFlags.NonPublic);
				if (!(method == null))
				{
					return $"Mono {method.Invoke(null, null)} CLR {Environment.Version}";
				}
				return $"Mono (unknown version) CLR {Environment.Version}";
			}
			return $".NET CLR {Environment.Version}";
		}
	}

	public static string OperatingSystem
	{
		get
		{
			if (CurrentPlatform == PlatformType.Linux)
			{
				string environmentVariable = Environment.GetEnvironmentVariable("XDG_CURRENT_DESKTOP");
				string environmentVariable2 = Environment.GetEnvironmentVariable("XDG_SESSION_TYPE");
				string text;
				if (!string.IsNullOrEmpty(environmentVariable) && !string.IsNullOrEmpty(environmentVariable2))
				{
					text = $" ({environmentVariable};{environmentVariable2})";
				}
				else if (string.IsNullOrEmpty(environmentVariable))
				{
					text = (string.IsNullOrEmpty(environmentVariable2) ? "" : (" (" + environmentVariable2 + ")"));
				}
				else
				{
					text = " (" + environmentVariable + ")";
				}
				try
				{
					ProcessStartInfo startInfo = new ProcessStartInfo("hostnamectl", "status")
					{
						UseShellExecute = false,
						RedirectStandardOutput = true
					};
					Process process = Process.Start(startInfo);
					string text2;
					while ((text2 = process.StandardOutput.ReadLine()) != null)
					{
						if (text2.StartsWith("Operating System: ", StringComparison.Ordinal))
						{
							return text2.Substring(18) + text;
						}
					}
				}
				catch
				{
				}
				if (File.Exists("/etc/os-release"))
				{
					foreach (string item in File.ReadLines("/etc/os-release"))
					{
						if (item.StartsWith("PRETTY_NAME=", StringComparison.Ordinal))
						{
							string text3 = item;
							return text3.Substring(13, text3.Length - 1 - 13) + text;
						}
					}
				}
			}
			else if (CurrentPlatform == PlatformType.OSX)
			{
				try
				{
					ProcessStartInfo startInfo2 = new ProcessStartInfo("system_profiler", "SPSoftwareDataType")
					{
						UseShellExecute = false,
						RedirectStandardOutput = true
					};
					Process process2 = Process.Start(startInfo2);
					string text4;
					while ((text4 = process2.StandardOutput.ReadLine()) != null)
					{
						text4 = text4.Trim();
						if (text4.StartsWith("System Version: ", StringComparison.Ordinal))
						{
							return text4.Substring(16);
						}
					}
				}
				catch
				{
				}
			}
			return Environment.OSVersion.ToString();
		}
	}

	public static string SupportDir => GetSupportDir(SupportDirType.User);

	public static string EngineDir
	{
		get
		{
			if (!engineDirAccessed)
			{
				engineDir = BinDir;
			}
			engineDirAccessed = true;
			return engineDir;
		}
	}

	public static string BinDir
	{
		get
		{
			string text = AppDomain.CurrentDomain.BaseDirectory;
			if (!text.EndsWith(Path.DirectorySeparatorChar.ToString(), StringComparison.Ordinal))
			{
				text += Path.DirectorySeparatorChar;
			}
			return text;
		}
	}

	private static PlatformType GetCurrentPlatform()
	{
		if (Environment.OSVersion.Platform == PlatformID.Win32NT)
		{
			return PlatformType.Windows;
		}
		try
		{
			ProcessStartInfo startInfo = new ProcessStartInfo("uname", "-s")
			{
				UseShellExecute = false,
				RedirectStandardOutput = true
			};
			Process process = Process.Start(startInfo);
			string text = process.StandardOutput.ReadToEnd();
			if (text.Contains("Darwin"))
			{
				return PlatformType.OSX;
			}
			return PlatformType.Linux;
		}
		catch
		{
		}
		return PlatformType.Unknown;
	}

	public static string GetSupportDir(SupportDirType type)
	{
		if (!supportDirInitialized)
		{
			InitializeSupportDir();
		}
		return type switch
		{
			SupportDirType.System => systemSupportPath, 
			SupportDirType.LegacyUser => legacyUserSupportPath, 
			SupportDirType.ModernUser => modernUserSupportPath, 
			_ => userSupportPath, 
		};
	}

	private static void InitializeSupportDir()
	{
		switch (CurrentPlatform)
		{
		case PlatformType.Windows:
			modernUserSupportPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OpenRA") + Path.DirectorySeparatorChar;
			legacyUserSupportPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "OpenRA") + Path.DirectorySeparatorChar;
			systemSupportPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OpenRA") + Path.DirectorySeparatorChar;
			break;
		case PlatformType.OSX:
			modernUserSupportPath = (legacyUserSupportPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Library", "Application Support", "OpenRA") + Path.DirectorySeparatorChar);
			systemSupportPath = "/Library/Application Support/OpenRA/";
			break;
		case PlatformType.Linux:
		{
			legacyUserSupportPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".openra") + Path.DirectorySeparatorChar;
			string text = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME");
			if (string.IsNullOrEmpty(text))
			{
				text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".config") + Path.DirectorySeparatorChar;
			}
			modernUserSupportPath = Path.Combine(text, "openra") + Path.DirectorySeparatorChar;
			systemSupportPath = "/var/games/openra/";
			break;
		}
		default:
			modernUserSupportPath = (legacyUserSupportPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".openra") + Path.DirectorySeparatorChar);
			systemSupportPath = "/var/games/openra/";
			break;
		}
		string path = Path.Combine(EngineDir, "Support") + Path.DirectorySeparatorChar;
		if (Directory.Exists(path))
		{
			userSupportPath = (systemSupportPath = path);
		}
		else if (!Directory.Exists(modernUserSupportPath) && Directory.Exists(legacyUserSupportPath))
		{
			userSupportPath = legacyUserSupportPath;
		}
		else
		{
			userSupportPath = modernUserSupportPath;
		}
		supportDirInitialized = true;
	}

	public static void OverrideSupportDir(string path)
	{
		if (supportDirInitialized)
		{
			throw new InvalidOperationException("Attempted to override user support directory after it has already been accessed.");
		}
		if (!Directory.Exists(path))
		{
			throw new DirectoryNotFoundException(path);
		}
		if (!path.EndsWith(Path.DirectorySeparatorChar.ToString(), StringComparison.Ordinal) && !path.EndsWith(Path.AltDirectorySeparatorChar.ToString(), StringComparison.Ordinal))
		{
			path += Path.DirectorySeparatorChar;
		}
		InitializeSupportDir();
		userSupportPath = path;
	}

	public static void OverrideEngineDir(string path)
	{
		if (engineDirAccessed)
		{
			throw new InvalidOperationException("Attempted to override engine directory after it has already been accessed.");
		}
		if (!Path.IsPathRooted(path))
		{
			path = Path.Combine(BinDir, path);
		}
		if (!Directory.Exists(path))
		{
			throw new DirectoryNotFoundException(path);
		}
		if (!path.EndsWith(Path.DirectorySeparatorChar.ToString(), StringComparison.Ordinal) && !path.EndsWith(Path.AltDirectorySeparatorChar.ToString(), StringComparison.Ordinal))
		{
			path += Path.DirectorySeparatorChar;
		}
		engineDirAccessed = true;
		engineDir = path;
	}

	public static string ResolvePath(string path)
	{
		path = path.TrimEnd(' ', '\t');
		switch (path)
		{
		case "^SupportDir":
			return SupportDir;
		case "^EngineDir":
			return EngineDir;
		case "^BinDir":
			return BinDir;
		default:
			if (path.StartsWith("^SupportDir|", StringComparison.Ordinal))
			{
				path = SupportDir + path.Substring(12);
			}
			if (path.StartsWith("^EngineDir|", StringComparison.Ordinal))
			{
				path = EngineDir + path.Substring(11);
			}
			if (path.StartsWith("^BinDir|", StringComparison.Ordinal))
			{
				path = BinDir + path.Substring(8);
			}
			return path;
		}
	}
}
