using System;

namespace OpenRA;

[Flags]
public enum PowerState
{
	Normal = 1,
	Low = 2,
	Critical = 4
}
