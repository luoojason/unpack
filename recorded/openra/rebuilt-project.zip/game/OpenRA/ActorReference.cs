using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA;

public class ActorReference : IEnumerable<object>, IEnumerable
{
	public string Type;

	private readonly Lazy<TypeDictionary> initDict;

	internal TypeDictionary InitDict => initDict.Value;

	public ActorReference(string type)
		: this(type, new Dictionary<string, MiniYaml>())
	{
	}

	public ActorReference(string type, Dictionary<string, MiniYaml> inits)
	{
		Type = type;
		initDict = Exts.Lazy(() =>
		{
			TypeDictionary typeDictionary = new TypeDictionary();
			foreach (KeyValuePair<string, MiniYaml> init in inits)
			{
				ActorInit actorInit = LoadInit(init.Key, init.Value);
				if (actorInit is ISingleInstanceInit && typeDictionary.Contains(actorInit.GetType()))
				{
					throw new InvalidDataException("Duplicate initializer '" + actorInit.GetType().Name + "'");
				}
				typeDictionary.Add(actorInit);
			}
			return typeDictionary;
		});
	}

	public ActorReference(string type, TypeDictionary inits)
	{
		Type = type;
		initDict = new Lazy<TypeDictionary>(() =>
		{
			TypeDictionary typeDictionary = new TypeDictionary();
			foreach (object init in inits)
			{
				typeDictionary.Add(init);
			}
			return typeDictionary;
		});
	}

	private static ActorInit LoadInit(string initName, MiniYaml initYaml)
	{
		string[] array = initName.Split('@');
		Type type = Game.ModData.ObjectCreator.FindType(array[0] + "Init");
		if (type == null)
		{
			throw new InvalidDataException("Unknown initializer type '" + array[0] + "Init'");
		}
		ActorInit actorInit = (ActorInit)FormatterServices.GetUninitializedObject(type);
		if (array.Length > 1)
		{
			type.GetField("InstanceName").SetValue(actorInit, array[1]);
		}
		MethodInfo method = type.GetMethod("Initialize", new Type[1] { typeof(MiniYaml) });
		if (method == null)
		{
			throw new InvalidDataException(array[0] + "Init does not define a yaml-assignable type.");
		}
		object[] parameters = new MiniYaml[1] { initYaml };
		method.Invoke(actorInit, parameters);
		return actorInit;
	}

	public MiniYaml Save(Func<ActorInit, bool> initFilter = null)
	{
		List<MiniYamlNode> list = new List<MiniYamlNode>();
		foreach (object item in initDict.Value)
		{
			if (item is ActorInit actorInit && !(item is ISuppressInitExport) && (initFilter == null || initFilter(actorInit)))
			{
				string name = actorInit.GetType().Name;
				string text = name;
				string text2 = text.Substring(0, text.Length - 4);
				if (!string.IsNullOrEmpty(actorInit.InstanceName))
				{
					text2 = text2 + "@" + actorInit.InstanceName;
				}
				list.Add(new MiniYamlNode(text2, actorInit.Save()));
			}
		}
		return new MiniYaml(Type, list);
	}

	public IEnumerator<object> GetEnumerator()
	{
		return initDict.Value.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}

	public ActorReference Clone()
	{
		ActorReference actorReference = new ActorReference(Type);
		foreach (object item in initDict.Value)
		{
			actorReference.initDict.Value.Add(item);
		}
		return actorReference;
	}

	public void Add(ActorInit init)
	{
		if (init is ISingleInstanceInit && InitDict.Contains(init.GetType()))
		{
			throw new InvalidDataException("Duplicate initializer '" + init.GetType().Name + "'");
		}
		InitDict.Add(init);
	}

	public void Remove(ActorInit o)
	{
		initDict.Value.Remove(o);
	}

	public int RemoveAll<T>() where T : ActorInit
	{
		int num = 0;
		foreach (T item in initDict.Value.WithInterface<T>().ToList())
		{
			num++;
			initDict.Value.Remove(item);
		}
		return num;
	}

	public IReadOnlyCollection<T> GetAll<T>() where T : ActorInit
	{
		return initDict.Value.WithInterface<T>();
	}

	public T GetOrDefault<T>(TraitInfo info) where T : ActorInit
	{
		IReadOnlyCollection<T> source = initDict.Value.WithInterface<T>();
		if (info != null && !string.IsNullOrEmpty(info.InstanceName))
		{
			return source.LastOrDefault((T i) => i.InstanceName == info.InstanceName) ?? source.LastOrDefault((T i) => string.IsNullOrEmpty(i.InstanceName));
		}
		return source.LastOrDefault((T i) => string.IsNullOrEmpty(i.InstanceName));
	}

	public T Get<T>(TraitInfo info) where T : ActorInit
	{
		T orDefault = GetOrDefault<T>(info);
		if (orDefault == null)
		{
			throw new InvalidOperationException($"TypeDictionary does not contain instance of type `{typeof(T)}`");
		}
		return orDefault;
	}

	public U GetValue<T, U>(TraitInfo info) where T : ValueActorInit<U>
	{
		return Get<T>(info).Value;
	}

	public U GetValue<T, U>(TraitInfo info, U fallback) where T : ValueActorInit<U>
	{
		T orDefault = GetOrDefault<T>(info);
		if (orDefault == null)
		{
			return fallback;
		}
		return orDefault.Value;
	}

	public bool Contains<T>(TraitInfo info) where T : ActorInit
	{
		return GetOrDefault<T>(info) != null;
	}

	public T GetOrDefault<T>() where T : ActorInit, ISingleInstanceInit
	{
		return initDict.Value.GetOrDefault<T>();
	}

	public T Get<T>() where T : ActorInit, ISingleInstanceInit
	{
		return initDict.Value.Get<T>();
	}

	public U GetValue<T, U>() where T : ValueActorInit<U>, ISingleInstanceInit
	{
		return Get<T>().Value;
	}

	public U GetValue<T, U>(U fallback) where T : ValueActorInit<U>, ISingleInstanceInit
	{
		T orDefault = GetOrDefault<T>();
		if (orDefault == null)
		{
			return fallback;
		}
		return orDefault.Value;
	}

	public bool Contains<T>() where T : ActorInit, ISingleInstanceInit
	{
		return GetOrDefault<T>() != null;
	}
}
