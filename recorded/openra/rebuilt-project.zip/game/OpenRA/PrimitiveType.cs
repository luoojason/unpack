namespace OpenRA;

public enum PrimitiveType
{
	PointList,
	LineList,
	TriangleList
}
