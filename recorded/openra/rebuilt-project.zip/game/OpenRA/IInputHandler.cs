namespace OpenRA;

public interface IInputHandler
{
	void ModifierKeys(Modifiers mods);

	void OnKeyInput(KeyInput input);

	void OnMouseInput(MouseInput input);

	void OnTextInput(string text);
}
