namespace OpenRA;

public interface ISuppressInitExport
{
}
