using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA;

public static class WorldUtils
{
	public static Actor ClosestToIgnoringPath(this IEnumerable<Actor> actors, Actor actor)
	{
		return actors.ClosestToIgnoringPath(actor.CenterPosition);
	}

	public static Actor ClosestToIgnoringPath(this IEnumerable<Actor> actors, WPos position)
	{
		return actors.MinByOrDefault((Actor a) => (a.CenterPosition - position).LengthSquared);
	}

	public static T ClosestToIgnoringPath<T>(IEnumerable<T> items, Func<T, Actor> selector, Actor actor)
	{
		return ClosestToIgnoringPath(items, selector, actor.CenterPosition);
	}

	public static T ClosestToIgnoringPath<T>(IEnumerable<T> items, Func<T, Actor> selector, WPos position)
	{
		return items.MinByOrDefault((T x) => (selector(x).CenterPosition - position).LengthSquared);
	}

	public static WPos ClosestToIgnoringPath(this IEnumerable<WPos> positions, WPos position)
	{
		return positions.MinByOrDefault((WPos p) => (p - position).LengthSquared);
	}

	public static IEnumerable<Actor> FindActorsInCircle(this World world, WPos origin, WDist r)
	{
		WVec b = new WVec(r, r, WDist.Zero);
		return from a in world.ActorMap.ActorsInBox(origin - b, origin + b)
			where (a.CenterPosition - origin).HorizontalLengthSquared <= r.LengthSquared
			select a;
	}

	public static bool ContainsTemporaryBlocker(this World world, CPos cell, Actor ignoreActor = null)
	{
		if (!world.RulesContainTemporaryBlocker)
		{
			return false;
		}
		IEnumerable<Actor> actorsAt = world.ActorMap.GetActorsAt(cell);
		foreach (Actor item in actorsAt)
		{
			if (item == ignoreActor)
			{
				continue;
			}
			IEnumerable<ITemporaryBlocker> enumerable = item.TraitsImplementing<ITemporaryBlocker>();
			foreach (ITemporaryBlocker item2 in enumerable)
			{
				if (item2.IsBlocking(item, cell))
				{
					return true;
				}
			}
		}
		return false;
	}

	public static void DoTimed<T>(this IEnumerable<T> e, Action<T> a, string text)
	{
		using IEnumerator<T> enumerator = e.GetEnumerator();
		long startTimestamp = PerfTickLogger.GetTimestamp();
		while (enumerator.MoveNext())
		{
			a(enumerator.Current);
			startTimestamp = PerfTickLogger.LogLongTick(startTimestamp, text, enumerator.Current);
		}
	}
}
