namespace OpenRA;

public enum BlendMode : byte
{
	None,
	Alpha,
	Additive,
	Subtractive,
	Multiply,
	Multiplicative,
	DoubleMultiplicative,
	LowAdditive,
	Screen,
	Translucent
}
