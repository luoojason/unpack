using System;
using OpenRA.Primitives;

namespace OpenRA;

public class RemoteMapData
{
	public readonly string title;

	public readonly string author;

	public readonly string[] categories;

	public readonly int players;

	public readonly Rectangle bounds;

	public readonly short[] spawnpoints = Array.Empty<short>();

	public readonly MapGridType map_grid_type;

	public readonly string minimap;

	public readonly bool downloading;

	public readonly string tileset;

	public readonly string rules;

	public readonly string players_block;

	public readonly int mapformat;

	public readonly string game_mod;
}
