using System;

namespace OpenRA;

public readonly struct float3 : IEquatable<float3>
{
	public readonly float X;

	public readonly float Y;

	public readonly float Z;

	public static readonly float3 Zero = new float3(0f, 0f, 0f);

	public static readonly float3 Ones = new float3(1f, 1f, 1f);

	public float2 XY => new float2(X, Y);

	public float3(float x, float y, float z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	public float3(float2 xy, float z)
	{
		X = xy.X;
		Y = xy.Y;
		Z = z;
	}

	public static implicit operator float3(int2 src)
	{
		return new float3(src.X, src.Y, 0f);
	}

	public static implicit operator float3(float2 src)
	{
		return new float3(src.X, src.Y, 0f);
	}

	public static float3 operator +(in float3 a, in float3 b)
	{
		return new float3(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
	}

	public static float3 operator -(in float3 a, in float3 b)
	{
		return new float3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
	}

	public static float3 operator -(in float3 a)
	{
		return new float3(0f - a.X, 0f - a.Y, 0f - a.Z);
	}

	public static float3 operator *(in float3 a, in float3 b)
	{
		return new float3(a.X * b.X, a.Y * b.Y, a.Z * b.Z);
	}

	public static float3 operator *(float a, in float3 b)
	{
		return new float3(a * b.X, a * b.Y, a * b.Z);
	}

	public static float3 operator /(in float3 a, in float3 b)
	{
		return new float3(a.X / b.X, a.Y / b.Y, a.Z / b.Z);
	}

	public static float3 operator /(in float3 a, float b)
	{
		return new float3(a.X / b, a.Y / b, a.Z / b);
	}

	public static float3 Lerp(float3 a, float3 b, float t)
	{
		return new float3(float2.Lerp(a.X, b.X, t), float2.Lerp(a.Y, b.Y, t), float2.Lerp(a.Z, b.Z, t));
	}

	public static bool operator ==(in float3 me, in float3 other)
	{
		if (me.X == other.X && me.Y == other.Y)
		{
			return me.Z == other.Z;
		}
		return false;
	}

	public static bool operator !=(in float3 me, in float3 other)
	{
		return !(me == other);
	}

	public override int GetHashCode()
	{
		return X.GetHashCode() ^ Y.GetHashCode() ^ Z.GetHashCode();
	}

	public bool Equals(float3 other)
	{
		return other == this;
	}

	public override bool Equals(object obj)
	{
		if (obj is float3 me)
		{
			return me == this;
		}
		return false;
	}

	public override string ToString()
	{
		return $"{X},{Y},{Z}";
	}
}
