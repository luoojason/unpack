using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ICSharpCode.SharpZipLib.Zip;

namespace OpenRA.FileSystem;

public class ZipFileLoader : IPackageLoader
{
	public class ReadOnlyZipFile : IReadOnlyPackage, IDisposable
	{
		protected ZipFile pkg;

		public string Name { get; protected set; }

		public IEnumerable<string> Contents
		{
			get
			{
				foreach (ZipEntry item in pkg)
				{
					if (item.IsFile)
					{
						yield return item.Name;
					}
				}
			}
		}

		protected ReadOnlyZipFile()
		{
		}

		public ReadOnlyZipFile(Stream s, string filename)
		{
			Name = filename;
			pkg = new ZipFile(s);
		}

		public Stream GetStream(string filename)
		{
			ZipEntry entry = pkg.GetEntry(filename);
			if (entry == null)
			{
				return null;
			}
			using Stream stream = pkg.GetInputStream(entry);
			MemoryStream memoryStream = new MemoryStream((int)entry.Size);
			stream.CopyTo(memoryStream);
			memoryStream.Seek(0L, SeekOrigin.Begin);
			return memoryStream;
		}

		public bool Contains(string filename)
		{
			return pkg.GetEntry(filename) != null;
		}

		public void Dispose()
		{
			pkg?.Close();
			GC.SuppressFinalize(this);
		}

		public IReadOnlyPackage OpenPackage(string filename, FileSystem context)
		{
			ZipEntry zipEntry = pkg.GetEntry(filename) ?? pkg.GetEntry(filename + "/");
			if (zipEntry == null)
			{
				return null;
			}
			if (zipEntry.IsDirectory)
			{
				return new ZipFolder(this, filename);
			}
			Stream stream = GetStream(filename);
			if (stream == null)
			{
				return null;
			}
			if (context.TryParsePackage(stream, filename, out var package))
			{
				return package;
			}
			stream.Dispose();
			return null;
		}
	}

	public sealed class ReadWriteZipFile : ReadOnlyZipFile, IReadWritePackage, IReadOnlyPackage, IDisposable
	{
		private readonly MemoryStream pkgStream = new MemoryStream();

		public ReadWriteZipFile(string filename, bool create = false)
		{
			if (!create)
			{
				using MemoryStream memoryStream = new MemoryStream(File.ReadAllBytes(filename));
				pkgStream.Capacity = (int)memoryStream.Length;
				memoryStream.CopyTo(pkgStream);
			}
			pkgStream.Position = 0L;
			pkg = new ZipFile(pkgStream);
			Name = filename;
			foreach (ZipEntry item in pkg)
			{
				item.ExtraData = null;
			}
		}

		private void Commit()
		{
			File.WriteAllBytes(Name, pkgStream.ToArray());
		}

		public void Update(string filename, byte[] contents)
		{
			pkg.BeginUpdate();
			pkg.Add(new StaticStreamDataSource(new MemoryStream(contents)), filename);
			pkg.CommitUpdate();
			Commit();
		}

		public void Delete(string filename)
		{
			pkg.BeginUpdate();
			pkg.Delete(filename);
			pkg.CommitUpdate();
			Commit();
		}
	}

	private sealed class ZipFolder : IReadOnlyPackage, IDisposable
	{
		public string Name { get; }

		public ReadOnlyZipFile Parent { get; }

		public IEnumerable<string> Contents
		{
			get
			{
				foreach (string content in Parent.Contents)
				{
					if (content.StartsWith(Name, StringComparison.Ordinal) && content != Name)
					{
						string text = content.Substring(Name.Length + 1);
						int num = text.Split('/').Count((string c) => !string.IsNullOrEmpty(c));
						if (num == 1)
						{
							yield return text;
						}
					}
				}
			}
		}

		public ZipFolder(ReadOnlyZipFile parent, string path)
		{
			if (path.EndsWith('/'))
			{
				string text = path;
				path = text.Substring(0, text.Length - 1);
			}
			Name = path;
			Parent = parent;
		}

		public Stream GetStream(string filename)
		{
			return Parent.GetStream(Name + "/" + filename);
		}

		public bool Contains(string filename)
		{
			return Parent.Contains(Name + "/" + filename);
		}

		public IReadOnlyPackage OpenPackage(string filename, FileSystem context)
		{
			return Parent.OpenPackage(Name + "/" + filename, context);
		}

		public void Dispose()
		{
		}
	}

	private sealed class StaticStreamDataSource : IStaticDataSource
	{
		private readonly Stream s;

		public StaticStreamDataSource(Stream s)
		{
			this.s = s;
		}

		public Stream GetSource()
		{
			return s;
		}
	}

	private const uint ZipSignature = 67324752u;

	public bool TryParsePackage(Stream s, string filename, FileSystem context, out IReadOnlyPackage package)
	{
		uint num = s.ReadUInt32();
		s.Position -= 4L;
		if (num != 67324752)
		{
			package = null;
			return false;
		}
		package = new ReadOnlyZipFile(s, filename);
		return true;
	}

	public static bool TryParseReadWritePackage(string filename, out IReadWritePackage package)
	{
		using (FileStream s = File.OpenRead(filename))
		{
			if (s.ReadUInt32() != 67324752)
			{
				package = null;
				return false;
			}
		}
		package = new ReadWriteZipFile(filename);
		return true;
	}

	public static IReadWritePackage Create(string filename)
	{
		return new ReadWriteZipFile(filename, create: true);
	}
}
