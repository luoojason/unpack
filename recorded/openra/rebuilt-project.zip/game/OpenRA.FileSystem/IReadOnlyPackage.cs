using System;
using System.Collections.Generic;
using System.IO;

namespace OpenRA.FileSystem;

public interface IReadOnlyPackage : IDisposable
{
	string Name { get; }

	IEnumerable<string> Contents { get; }

	Stream GetStream(string filename);

	bool Contains(string filename);

	IReadOnlyPackage OpenPackage(string filename, FileSystem context);
}
