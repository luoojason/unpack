using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenRA.Primitives;

namespace OpenRA.FileSystem;

public class FileSystem : IReadOnlyFileSystem
{
	private readonly Dictionary<IReadOnlyPackage, int> mountedPackages = new Dictionary<IReadOnlyPackage, int>();

	private readonly Dictionary<string, IReadOnlyPackage> explicitMounts = new Dictionary<string, IReadOnlyPackage>();

	private readonly string modID;

	private readonly List<IReadOnlyPackage> modPackages = new List<IReadOnlyPackage>();

	private readonly IReadOnlyDictionary<string, Manifest> installedMods;

	private readonly IPackageLoader[] packageLoaders;

	private Cache<string, List<IReadOnlyPackage>> fileIndex = new Cache<string, List<IReadOnlyPackage>>((string _) => new List<IReadOnlyPackage>());

	public IEnumerable<IReadOnlyPackage> MountedPackages => mountedPackages.Keys;

	public FileSystem(string modID, IReadOnlyDictionary<string, Manifest> installedMods, IPackageLoader[] packageLoaders)
	{
		this.modID = modID;
		this.installedMods = installedMods;
		this.packageLoaders = packageLoaders.Append(new ZipFileLoader()).ToArray();
	}

	public bool TryParsePackage(Stream stream, string filename, out IReadOnlyPackage package)
	{
		package = null;
		IPackageLoader[] array = packageLoaders;
		foreach (IPackageLoader packageLoader in array)
		{
			if (packageLoader.TryParsePackage(stream, filename, this, out package))
			{
				return true;
			}
		}
		return false;
	}

	public IReadOnlyPackage OpenPackage(string filename)
	{
		string text = Platform.ResolvePath(filename);
		if (!text.Contains('|') && Directory.Exists(text))
		{
			return new Folder(text);
		}
		if (TryGetPackageContaining(filename, out var package, out var filename2))
		{
			return package.OpenPackage(filename2, this);
		}
		Stream stream = Open(filename);
		if (TryParsePackage(stream, filename, out var package2))
		{
			return package2;
		}
		stream.Dispose();
		return null;
	}

	public void Mount(string name, string explicitName = null)
	{
		bool flag = name.StartsWith('~');
		if (flag)
		{
			name = name.Substring(1);
		}
		try
		{
			IReadOnlyPackage readOnlyPackage;
			if (name.StartsWith('$'))
			{
				name = name.Substring(1);
				if (!installedMods.TryGetValue(name, out var value))
				{
					throw new InvalidOperationException("Could not load mod '" + name + "'. Available mods: " + installedMods.Keys.JoinWith(", "));
				}
				readOnlyPackage = value.Package;
				modPackages.Add(readOnlyPackage);
			}
			else
			{
				readOnlyPackage = OpenPackage(name);
				if (readOnlyPackage == null)
				{
					throw new InvalidOperationException("Could not open package '" + name + "', file not found or its format is not supported.");
				}
			}
			Mount(readOnlyPackage, explicitName);
		}
		catch when (flag)
		{
		}
	}

	public void Mount(IReadOnlyPackage package, string explicitName = null)
	{
		if (mountedPackages.TryGetValue(package, out var value))
		{
			mountedPackages[package] = value + 1;
			{
				foreach (string content in package.Contents)
				{
					fileIndex[content].Remove(package);
					fileIndex[content].Add(package);
				}
				return;
			}
		}
		mountedPackages.Add(package, 1);
		if (explicitName != null)
		{
			explicitMounts.Add(explicitName, package);
		}
		foreach (string content2 in package.Contents)
		{
			fileIndex[content2].Add(package);
		}
	}

	public bool Unmount(IReadOnlyPackage package)
	{
		if (!mountedPackages.TryGetValue(package, out var value))
		{
			return false;
		}
		if (--value <= 0)
		{
			foreach (List<IReadOnlyPackage> value2 in fileIndex.Values)
			{
				value2.RemoveAll((IReadOnlyPackage p) => p == package);
			}
			mountedPackages.Remove(package);
			List<string> list = (from kv in explicitMounts
				where kv.Value == package
				select kv.Key).ToList();
			foreach (string item in list)
			{
				explicitMounts.Remove(item);
			}
			if (!modPackages.Remove(package))
			{
				package.Dispose();
			}
		}
		else
		{
			mountedPackages[package] = value;
		}
		return true;
	}

	public void UnmountAll()
	{
		foreach (IReadOnlyPackage key in mountedPackages.Keys)
		{
			if (!modPackages.Contains(key))
			{
				key.Dispose();
			}
		}
		mountedPackages.Clear();
		explicitMounts.Clear();
		modPackages.Clear();
		fileIndex = new Cache<string, List<IReadOnlyPackage>>((string _) => new List<IReadOnlyPackage>());
	}

	public void TrimExcess()
	{
		mountedPackages.TrimExcess();
		explicitMounts.TrimExcess();
		modPackages.TrimExcess();
		foreach (List<IReadOnlyPackage> value in fileIndex.Values)
		{
			value.TrimExcess();
		}
	}

	private Stream GetFromCache(string filename)
	{
		return fileIndex[filename].LastOrDefault((IReadOnlyPackage x) => x.Contains(filename))?.GetStream(filename);
	}

	public Stream Open(string filename)
	{
		if (!TryOpen(filename, out var s))
		{
			throw new FileNotFoundException("File not found: " + filename, filename);
		}
		return s;
	}

	public bool TryGetPackageContaining(string path, out IReadOnlyPackage package, out string filename)
	{
		int num = path.IndexOf('|');
		if (num > 0 && explicitMounts.TryGetValue(path.Substring(0, num), out package))
		{
			filename = path.Substring(num + 1);
			return true;
		}
		package = fileIndex[path].LastOrDefault((IReadOnlyPackage x) => x.Contains(path));
		filename = path;
		return package != null;
	}

	public bool TryOpen(string filename, out Stream s)
	{
		int num = filename.IndexOf('|');
		if (num > 0 && explicitMounts.TryGetValue(filename.Substring(0, num), out var value))
		{
			s = value.GetStream(filename.Substring(num + 1));
			if (s != null)
			{
				return true;
			}
		}
		s = GetFromCache(filename);
		if (s != null)
		{
			return true;
		}
		if (num > 0)
		{
			return false;
		}
		IReadOnlyPackage readOnlyPackage = mountedPackages.Keys.LastOrDefault((IReadOnlyPackage x) => x.Contains(filename));
		if (readOnlyPackage != null)
		{
			s = readOnlyPackage.GetStream(filename);
			return s != null;
		}
		s = null;
		return false;
	}

	public bool Exists(string filename)
	{
		int num = filename.IndexOf('|');
		if (num > 0 && explicitMounts.TryGetValue(filename.Substring(0, num), out var value) && value.Contains(filename.Substring(num + 1)))
		{
			return true;
		}
		return fileIndex.ContainsKey(filename);
	}

	public bool IsExternalFile(string filename)
	{
		return !filename.StartsWith(modID + "|", StringComparison.Ordinal);
	}

	public static string ResolveCaseInsensitivePath(string path)
	{
		string resolved = Path.GetPathRoot(path);
		if (resolved == null)
		{
			return null;
		}
		string[] array = path.Substring(resolved.Length).Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
		foreach (string name in array)
		{
			if (!(name == "."))
			{
				resolved = Directory.GetFileSystemEntries(resolved).FirstOrDefault((string e) => e.Equals(Path.Combine(resolved, name), StringComparison.InvariantCultureIgnoreCase));
				if (resolved == null)
				{
					return null;
				}
			}
		}
		return resolved;
	}

	public string GetPrefix(IReadOnlyPackage package)
	{
		if (!explicitMounts.ContainsValue(package))
		{
			return null;
		}
		return explicitMounts.First((KeyValuePair<string, IReadOnlyPackage> f) => f.Value == package).Key;
	}
}
