using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace OpenRA.FileSystem;

public sealed class Folder : IReadWritePackage, IReadOnlyPackage, IDisposable
{
	public string Name { get; }

	public IEnumerable<string> Contents => from f in Directory.GetFiles(Name, "*", SearchOption.TopDirectoryOnly).Concat(Directory.GetDirectories(Name)).Select(Path.GetFileName)
		orderby f
		select f;

	public Folder(string path)
	{
		Name = path;
		if (!Directory.Exists(path))
		{
			Directory.CreateDirectory(path);
		}
	}

	public Stream GetStream(string filename)
	{
		string path = Path.Combine(Name, filename);
		if (!File.Exists(path))
		{
			return null;
		}
		try
		{
			return File.OpenRead(path);
		}
		catch
		{
			return null;
		}
	}

	public bool Contains(string filename)
	{
		string text = Path.Combine(Name, filename);
		if (text.StartsWith(Name, StringComparison.Ordinal))
		{
			return File.Exists(text);
		}
		return false;
	}

	public IReadOnlyPackage OpenPackage(string filename, FileSystem context)
	{
		string text = Platform.ResolvePath(Path.Combine(Name, filename));
		if (Directory.Exists(text))
		{
			return new Folder(text);
		}
		if (ZipFileLoader.TryParseReadWritePackage(text, out var package))
		{
			return package;
		}
		Stream stream = GetStream(filename);
		if (stream == null)
		{
			return null;
		}
		if (context.TryParsePackage(stream, filename, out var package2))
		{
			return package2;
		}
		stream.Dispose();
		return null;
	}

	public void Update(string filename, byte[] contents)
	{
		string path = (filename.StartsWith(Name, StringComparison.Ordinal) ? filename : Path.Combine(Name, filename));
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		using FileStream fileStream = File.Create(path);
		fileStream.Write(contents, 0, contents.Length);
	}

	public void Delete(string filename)
	{
		string path = (filename.StartsWith(Name, StringComparison.Ordinal) ? filename : Path.Combine(Name, filename));
		if (Directory.Exists(path))
		{
			Directory.Delete(path, recursive: true);
		}
		else if (File.Exists(path))
		{
			File.Delete(path);
		}
	}

	public void Dispose()
	{
	}
}
