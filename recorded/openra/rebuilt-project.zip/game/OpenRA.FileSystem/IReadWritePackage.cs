using System;

namespace OpenRA.FileSystem;

public interface IReadWritePackage : IReadOnlyPackage, IDisposable
{
	void Update(string filename, byte[] contents);

	void Delete(string filename);
}
