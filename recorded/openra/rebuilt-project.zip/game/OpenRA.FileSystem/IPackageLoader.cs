using System.IO;

namespace OpenRA.FileSystem;

public interface IPackageLoader
{
	bool TryParsePackage(Stream s, string filename, FileSystem context, out IReadOnlyPackage package);
}
