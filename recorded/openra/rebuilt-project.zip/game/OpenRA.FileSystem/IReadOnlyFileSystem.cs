using System.IO;

namespace OpenRA.FileSystem;

public interface IReadOnlyFileSystem
{
	Stream Open(string filename);

	bool TryGetPackageContaining(string path, out IReadOnlyPackage package, out string filename);

	bool TryOpen(string filename, out Stream s);

	bool Exists(string filename);

	bool IsExternalFile(string filename);
}
