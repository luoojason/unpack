namespace OpenRA.Server;

public interface INotifySyncLobbyInfo
{
	void LobbyInfoSynced(Server server);
}
