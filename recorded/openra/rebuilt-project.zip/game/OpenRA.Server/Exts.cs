using System.Collections.Generic;
using System.Linq;

namespace OpenRA.Server;

internal static class Exts
{
	public static IEnumerable<T> Except<T>(this IEnumerable<T> ts, T t)
	{
		return ts.Except(new T[1] { t });
	}
}
