using System.Collections.Generic;
using System.Diagnostics;
using OpenRA.Network;

namespace OpenRA.Server;

public sealed class VoteKickTracker
{
	[FluentReference(new string[] { "kickee" })]
	private const string InsufficientVotes = "notification-insufficient-votes-to-kick";

	[FluentReference]
	private const string AlreadyVoted = "notification-kick-already-voted";

	[FluentReference(new string[] { "kicker", "kickee" })]
	private const string VoteKickStarted = "notification-vote-kick-started";

	[FluentReference]
	private const string UnableToStartAVote = "notification-unable-to-start-a-vote";

	[FluentReference(new string[] { "kickee", "percentage" })]
	private const string VoteKickProgress = "notification-vote-kick-in-progress";

	[FluentReference(new string[] { "kickee" })]
	private const string VoteKickEnded = "notification-vote-kick-ended";

	private readonly Dictionary<int, bool> voteTracker = new Dictionary<int, bool>();

	private readonly Dictionary<Session.Client, long> failedVoteKickers = new Dictionary<Session.Client, long>();

	private readonly Server server;

	private Stopwatch voteKickTimer;

	private (Session.Client Client, Connection Conn) kickee;

	private (Session.Client Client, Connection Conn) voteKickerStarter;

	public VoteKickTracker(Server server)
	{
		this.server = server;
	}

	private bool ClientHasPower(Session.Client client)
	{
		if (!client.IsAdmin)
		{
			if (!client.IsObserver)
			{
				return !server.HasClientWonOrLost(client);
			}
			return false;
		}
		return true;
	}

	public void Tick()
	{
		if (voteKickTimer != null)
		{
			if (!server.Conns.Contains(kickee.Conn))
			{
				EndKickVote();
			}
			else if (voteKickTimer.ElapsedMilliseconds > server.Settings.VoteKickTimer)
			{
				EndKickVoteAndBlockKicker();
			}
		}
	}

	public bool VoteKick(Connection conn, Session.Client kicker, Connection kickeeConn, Session.Client kickee, int kickeeID, bool vote)
	{
		bool flag = voteKickTimer != null;
		if (server.State != ServerState.GameStarted || (kickee.IsAdmin && server.Type != ServerType.Dedicated) || (!flag && !vote) || (flag && this.kickee.Client != kickee) || !ClientHasPower(kicker))
		{
			server.SendFluentMessageTo(conn, "notification-unable-to-start-a-vote");
			return false;
		}
		short num = 0;
		bool flag2 = false;
		bool flag3 = false;
		foreach (Connection conn2 in server.Conns)
		{
			Session.Client client = server.GetClient(conn2);
			if (client != kickee && ClientHasPower(client))
			{
				num++;
			}
			if (conn2 == kickeeConn)
			{
				flag2 = true;
			}
			if (client.IsAdmin && (client.IsObserver || server.HasClientWonOrLost(client)))
			{
				flag3 = true;
			}
		}
		if (!flag2)
		{
			EndKickVote();
			return false;
		}
		if (num < 2 || (flag3 && !kickee.IsAdmin && num < 3))
		{
			if (!kickee.IsObserver && !server.HasClientWonOrLost(kickee))
			{
				server.SendFluentMessageTo(conn, "notification-insufficient-votes-to-kick", new object[2] { "kickee", kickee.Name });
				EndKickVote();
				return false;
			}
			if (vote)
			{
				EndKickVote(sendMessage: false);
				return true;
			}
		}
		if (!flag)
		{
			if (failedVoteKickers.TryGetValue(kicker, out var value))
			{
				if (value + server.Settings.VoteKickerCooldown > kickeeConn.ConnectionTimer.ElapsedMilliseconds)
				{
					server.SendFluentMessageTo(conn, "notification-unable-to-start-a-vote");
					return false;
				}
				failedVoteKickers.Remove(kicker);
			}
			Log.Write("server", $"Vote kick started on {kickeeID}.");
			voteKickTimer = Stopwatch.StartNew();
			server.SendFluentMessage("notification-vote-kick-started", "kicker", kicker.Name, "kickee", kickee.Name);
			server.DispatchServerOrdersToClients(new Order("StartKickVote", null, queued: false)
			{
				ExtraData = (uint)kickeeID
			}.Serialize());
			this.kickee = (Client: kickee, Conn: kickeeConn);
			voteKickerStarter = (Client: kicker, Conn: conn);
		}
		if (!voteTracker.ContainsKey(conn.PlayerIndex))
		{
			voteTracker[conn.PlayerIndex] = vote;
			short num2 = 0;
			short num3 = 0;
			foreach (KeyValuePair<int, bool> item in voteTracker)
			{
				if (item.Value)
				{
					num2++;
				}
				else
				{
					num3++;
				}
			}
			if (ClientHasPower(kickee))
			{
				num++;
				num3++;
			}
			int num4 = num / 2 + 1;
			server.SendFluentMessage("notification-vote-kick-in-progress", "kickee", kickee.Name, "percentage", num2 * 100 / num);
			if (vote && num2 >= num4)
			{
				EndKickVote(sendMessage: false);
				return true;
			}
			if (num - num3 < num4)
			{
				EndKickVoteAndBlockKicker();
				return false;
			}
			voteKickTimer.Restart();
			return false;
		}
		server.SendFluentMessageTo(conn, "notification-kick-already-voted");
		return false;
	}

	private void EndKickVoteAndBlockKicker()
	{
		if (voteKickTimer != null)
		{
			if (server.Conns.Contains(voteKickerStarter.Conn))
			{
				failedVoteKickers[voteKickerStarter.Client] = voteKickerStarter.Conn.ConnectionTimer.ElapsedMilliseconds;
			}
			EndKickVote();
		}
	}

	private void EndKickVote(bool sendMessage = true)
	{
		if (voteKickTimer != null)
		{
			if (sendMessage)
			{
				server.SendFluentMessage("notification-vote-kick-ended", "kickee", kickee.Client.Name);
			}
			server.DispatchServerOrdersToClients(new Order("EndKickVote", null, queued: false)
			{
				ExtraData = (uint)kickee.Client.Index
			}.Serialize());
			voteKickTimer = null;
			voteKickerStarter = (Client: null, Conn: null);
			kickee = (Client: null, Conn: null);
			voteTracker.Clear();
		}
	}
}
