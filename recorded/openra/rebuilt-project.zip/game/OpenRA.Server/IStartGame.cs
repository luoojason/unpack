namespace OpenRA.Server;

public interface IStartGame
{
	void GameStarted(Server server);
}
