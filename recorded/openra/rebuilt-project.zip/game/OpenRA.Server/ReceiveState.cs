namespace OpenRA.Server;

public enum ReceiveState
{
	Header,
	Data
}
