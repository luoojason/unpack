using System;
using System.Collections.Generic;

namespace OpenRA.Server;

internal sealed class PlayerMessageTracker
{
	[FluentReference(new string[] { "remaining" })]
	private const string ChatTemporaryDisabled = "notification-chat-temp-disabled";

	private readonly Dictionary<int, List<long>> messageTracker = new Dictionary<int, List<long>>();

	private readonly Server server;

	private readonly Action<Connection, int, int, byte[]> dispatchOrdersToClient;

	private readonly Action<Connection, string, object[]> sendFluentMessageTo;

	public PlayerMessageTracker(Server server, Action<Connection, int, int, byte[]> dispatchOrdersToClient, Action<Connection, string, object[]> sendFluentMessageTo)
	{
		this.server = server;
		this.dispatchOrdersToClient = dispatchOrdersToClient;
		this.sendFluentMessageTo = sendFluentMessageTo;
	}

	public void DisableChatUI(Connection conn, int time)
	{
		dispatchOrdersToClient(conn, 0, 0, new Order("DisableChatEntry", null, queued: false)
		{
			ExtraData = (uint)time
		}.Serialize());
	}

	public bool IsPlayerAtFloodLimit(Connection conn)
	{
		if (!messageTracker.ContainsKey(conn.PlayerIndex))
		{
			messageTracker.Add(conn.PlayerIndex, new List<long>());
		}
		bool flag = server.GetClient(conn)?.IsAdmin ?? false;
		ServerSettings settings = server.Settings;
		long time = conn.ConnectionTimer.ElapsedMilliseconds;
		List<long> list = messageTracker[conn.PlayerIndex];
		list.RemoveAll((long t) => t + settings.FloodLimitInterval < time);
		if (!flag && time < settings.FloodLimitJoinCooldown)
		{
			long num = CalculateRemaining(settings.FloodLimitJoinCooldown);
			sendFluentMessageTo(conn, "notification-chat-temp-disabled", new object[2] { "remaining", num });
			return true;
		}
		if (list.Count >= settings.FloodLimitMessageCount)
		{
			long num2 = CalculateRemaining(list[0] + settings.FloodLimitInterval);
			sendFluentMessageTo(conn, "notification-chat-temp-disabled", new object[2] { "remaining", num2 });
			return true;
		}
		list.Add(time);
		if (list.Count >= settings.FloodLimitMessageCount)
		{
			int num3 = Math.Max(0, settings.FloodLimitCooldown - settings.FloodLimitInterval);
			for (int num4 = 0; num4 < list.Count; num4++)
			{
				list[num4] = time + num3;
			}
			DisableChatUI(conn, settings.FloodLimitCooldown);
		}
		return false;
		long CalculateRemaining(long cooldown)
		{
			return (cooldown - time + 999) / 1000;
		}
	}
}
