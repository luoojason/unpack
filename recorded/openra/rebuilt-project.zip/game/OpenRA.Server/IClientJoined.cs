namespace OpenRA.Server;

public interface IClientJoined
{
	void ClientJoined(Server server, Connection conn);
}
