using OpenRA.Network;

namespace OpenRA.Server;

public interface IInterpretCommand
{
	bool InterpretCommand(Server server, Connection conn, Session.Client client, string cmd);
}
