using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenRA.FileFormats;
using OpenRA.Network;
using OpenRA.Primitives;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA.Server;

public sealed class Server
{
	private interface IServerEvent
	{
		void Invoke(Server server);
	}

	private sealed class ConnectionConnectEvent : IServerEvent
	{
		private readonly Socket socket;

		public ConnectionConnectEvent(Socket socket)
		{
			this.socket = socket;
		}

		void IServerEvent.Invoke(Server server)
		{
			server.AcceptConnection(socket);
		}
	}

	private sealed class ConnectionDisconnectEvent : IServerEvent
	{
		private readonly Connection connection;

		public ConnectionDisconnectEvent(Connection connection)
		{
			this.connection = connection;
		}

		void IServerEvent.Invoke(Server server)
		{
			server.DropClient(connection);
		}
	}

	private sealed class ConnectionPacketEvent : IServerEvent
	{
		private readonly Connection connection;

		private readonly int frame;

		private readonly byte[] data;

		public ConnectionPacketEvent(Connection connection, int frame, byte[] data)
		{
			this.connection = connection;
			this.frame = frame;
			this.data = data;
		}

		void IServerEvent.Invoke(Server server)
		{
			server.ReceiveOrders(connection, frame, data);
		}
	}

	private sealed class ConnectionPingEvent : IServerEvent
	{
		private readonly Connection connection;

		private readonly int[] pingHistory;

		private readonly byte queueLength;

		public ConnectionPingEvent(Connection connection, int[] pingHistory, byte queueLength)
		{
			this.connection = connection;
			this.pingHistory = pingHistory;
			this.queueLength = queueLength;
		}

		void IServerEvent.Invoke(Server server)
		{
			server.ReceivePing(connection, pingHistory);
		}
	}

	private sealed class CallbackEvent : IServerEvent
	{
		private readonly Action action;

		public CallbackEvent(Action action)
		{
			this.action = action;
		}

		void IServerEvent.Invoke(Server server)
		{
			action();
		}
	}

	[FluentReference]
	private const string CustomRules = "notification-custom-rules";

	[FluentReference]
	private const string BotsDisabled = "notification-map-bots-disabled";

	[FluentReference]
	private const string TwoHumansRequired = "notification-two-humans-required";

	[FluentReference]
	private const string ErrorGameStarted = "notification-error-game-started";

	[FluentReference]
	private const string RequiresPassword = "notification-requires-password";

	[FluentReference]
	private const string IncorrectPassword = "notification-incorrect-password";

	[FluentReference]
	private const string IncompatibleMod = "notification-incompatible-mod";

	[FluentReference]
	private const string IncompatibleVersion = "notification-incompatible-version";

	[FluentReference]
	private const string IncompatibleProtocol = "notification-incompatible-protocol";

	[FluentReference]
	private const string Banned = "notification-you-were-banned";

	[FluentReference]
	private const string TempBanned = "notification-you-were-temp-banned";

	[FluentReference]
	private const string Full = "notification-game-full";

	[FluentReference(new string[] { "player" })]
	private const string Joined = "notification-joined";

	[FluentReference]
	private const string RequiresAuthentication = "notification-requires-authentication";

	[FluentReference]
	private const string NoPermission = "notification-no-permission-to-join";

	[FluentReference(new string[] { "command" })]
	private const string UnknownServerCommand = "notification-unknown-server-command";

	[FluentReference(new string[] { "player" })]
	private const string LobbyDisconnected = "notification-lobby-disconnected";

	[FluentReference(new string[] { "player" })]
	private const string PlayerDisconnected = "notification-player-disconnected";

	[FluentReference(new string[] { "player", "team" })]
	private const string PlayerTeamDisconnected = "notification-team-player-disconnected";

	[FluentReference(new string[] { "player" })]
	private const string ObserverDisconnected = "notification-observer-disconnected";

	[FluentReference(new string[] { "player" })]
	private const string NewAdmin = "notification-new-admin";

	[FluentReference]
	private const string YouWereKicked = "notification-you-were-kicked";

	[FluentReference]
	private const string GameStarted = "notification-game-started";

	public readonly MersenneTwister Random = new MersenneTwister();

	public readonly ServerType Type;

	public readonly List<Connection> Conns = new List<Connection>();

	public Session LobbyInfo;

	public ServerSettings Settings;

	public ModData ModData;

	public List<string> TempBans = new List<string>();

	public MapPreview Map;

	public readonly MapStatusCache MapStatusCache;

	public GameSave GameSave;

	public HashSet<string> MapPool;

	public int OrderLatency = 1;

	private readonly int randomSeed;

	private readonly List<TcpListener> listeners = new List<TcpListener>();

	private readonly TypeDictionary serverTraits = new TypeDictionary();

	private readonly PlayerDatabase playerDatabase;

	private OrderBuffer orderBuffer;

	private volatile ServerState internalState = ServerState.WaitingPlayers;

	private readonly BlockingCollection<IServerEvent> events = new BlockingCollection<IServerEvent>();

	private ReplayRecorder recorder;

	private GameInformation gameInfo;

	private readonly List<GameInformation.Player> worldPlayers = new List<GameInformation.Player>();

	private readonly Stopwatch pingUpdated = Stopwatch.StartNew();

	public readonly VoteKickTracker VoteKickTracker;

	private readonly PlayerMessageTracker playerMessageTracker;

	private int nextPlayerIndex;

	private readonly Dictionary<int, byte[]> syncForFrame = new Dictionary<int, byte[]>();

	private int lastDefeatStateFrame;

	private ulong lastDefeatState;

	public bool IsMultiplayer
	{
		get
		{
			if (Type != ServerType.Dedicated)
			{
				return Type == ServerType.Multiplayer;
			}
			return true;
		}
	}

	public ServerState State
	{
		get
		{
			return internalState;
		}
		set
		{
			internalState = value;
		}
	}

	public static void SyncClientToPlayerReference(Session.Client c, PlayerReference pr)
	{
		if (pr != null)
		{
			if (pr.LockFaction)
			{
				c.Faction = pr.Faction;
			}
			if (pr.LockSpawn)
			{
				c.SpawnPoint = pr.Spawn;
			}
			if (pr.LockTeam)
			{
				c.Team = pr.Team;
			}
			if (pr.LockHandicap)
			{
				c.Handicap = pr.Handicap;
			}
			c.Color = (pr.LockColor ? pr.Color : c.PreferredColor);
		}
	}

	public void Shutdown()
	{
		State = ServerState.ShuttingDown;
	}

	public void EndGame()
	{
		foreach (IEndGame item in serverTraits.WithInterface<IEndGame>())
		{
			item.GameEnded(this);
		}
		recorder?.Dispose();
		recorder = null;
	}

	public void RecordFakeHandshake()
	{
		HandshakeRequest handshakeRequest = new HandshakeRequest
		{
			Mod = ModData.Manifest.Id,
			Version = ModData.Manifest.Metadata.Version
		};
		recorder.ReceiveFrame(0, 0, new Order("HandshakeRequest", null, queued: false)
		{
			Type = OrderType.Handshake,
			IsImmediate = true,
			TargetString = handshakeRequest.Serialize()
		}.Serialize());
		HandshakeResponse handshakeResponse = new HandshakeResponse
		{
			Mod = ModData.Manifest.Id,
			Version = ModData.Manifest.Metadata.Version,
			OrdersProtocol = 21,
			Client = new Session.Client()
		};
		recorder.ReceiveFrame(0, 0, new Order("HandshakeResponse", null, queued: false)
		{
			Type = OrderType.Handshake,
			IsImmediate = true,
			TargetString = handshakeResponse.Serialize()
		}.Serialize());
	}

	private void MapStatusChanged(string uid, Session.MapStatus status)
	{
		lock (LobbyInfo)
		{
			if (LobbyInfo.GlobalSettings.Map == uid)
			{
				LobbyInfo.GlobalSettings.MapStatus = status;
			}
			SyncLobbyInfo();
		}
	}

	public Server(List<IPEndPoint> endpoints, ServerSettings settings, ModData modData, ServerType type)
	{
		Log.AddChannel("server", "server.log", isTimestamped: true);
		SocketException ex = null;
		foreach (IPEndPoint endpoint in endpoints)
		{
			TcpListener listener = new TcpListener(endpoint);
			try
			{
				try
				{
					listener.Server.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.IPv6Only, 1);
				}
				catch (Exception ex2) when (ex2 is SocketException || ex2 is ArgumentException)
				{
					Log.Write("server", $"Failed to set socket option on {endpoint}: {ex2.Message}");
				}
				listener.Start();
				listeners.Add(listener);
				Thread thread = new Thread(() =>
				{
					while (State == ServerState.WaitingPlayers)
					{
						if (listener.Server.Poll(1000000, SelectMode.SelectRead))
						{
							try
							{
								events.Add(new ConnectionConnectEvent(listener.AcceptSocket()));
							}
							catch (Exception)
							{
							}
						}
					}
					listener.Stop();
				});
				thread.Name = $"Connection listener ({listener.LocalEndpoint})";
				thread.IsBackground = true;
				thread.Start();
			}
			catch (SocketException ex3)
			{
				ex = ex3;
				Log.Write("server", $"Failed to listen on {endpoint}: {ex3.Message}");
			}
		}
		if (listeners.Count == 0)
		{
			throw ex;
		}
		Type = type;
		Settings = settings;
		Settings.Name = Game.Settings.SanitizedServerName(Settings.Name);
		ModData = modData;
		playerDatabase = modData.Manifest.Get<PlayerDatabase>();
		randomSeed = (int)DateTime.Now.ToBinary();
		if (IsMultiplayer && settings.EnableGeoIP)
		{
			GeoIP.Initialize();
		}
		if (IsMultiplayer)
		{
			Nat.TryForwardPort(Settings.ListenPort, Settings.ListenPort);
		}
		string[] array = modData.Manifest.ServerTraits;
		foreach (string className in array)
		{
			serverTraits.Add(modData.ObjectCreator.CreateObject<ServerTrait>(className));
		}
		serverTraits.TrimExcess();
		MapStatusCache = new MapStatusCache(modData, MapStatusChanged, type == ServerType.Dedicated && settings.EnableLintChecks);
		playerMessageTracker = new PlayerMessageTracker(this, DispatchOrdersToClient, SendFluentMessageTo);
		VoteKickTracker = new VoteKickTracker(this);
		LobbyInfo = new Session
		{
			GlobalSettings = 
			{
				RandomSeed = randomSeed,
				ServerName = settings.Name,
				EnableSingleplayer = (settings.EnableSingleplayer || Type != ServerType.Dedicated),
				EnableSyncReports = settings.EnableSyncReports,
				GameUid = Guid.NewGuid().ToString(),
				Dedicated = (Type == ServerType.Dedicated)
			}
		};
		if (Settings.RecordReplays && Type == ServerType.Dedicated)
		{
			recorder = new ReplayRecorder(() => Game.TimestampedFilename(includemilliseconds: false, "-Server"));
			RecordFakeHandshake();
		}
		Thread thread2 = new Thread((object? _) =>
		{
			foreach (INotifyServerStart item3 in serverTraits.WithInterface<INotifyServerStart>())
			{
				item3.ServerStarted(this);
			}
			Log.Write("server", "Initial mod: " + ModData.Manifest.Id);
			Log.Write("server", "Initial map: " + LobbyInfo.GlobalSettings.Map);
			do
			{
				if (State != ServerState.ShuttingDown)
				{
					if (events.TryTake(out var item, 1000))
					{
						item.Invoke(this);
					}
					if (Type == ServerType.Dedicated)
					{
						Game.PerformDelayedActions();
					}
					foreach (ITick item4 in serverTraits.WithInterface<ITick>())
					{
						item4.Tick(this);
					}
					if (State == ServerState.GameStarted)
					{
						foreach (var tickScale in orderBuffer.GetTickScales())
						{
							int playerIndex = tickScale.PlayerIndex;
							float item2 = tickScale.TickScale;
							byte[] frameData = CreateTickScaleFrame(item2);
							Connection connection = Conns.SingleOrDefault((Connection c) => c.PlayerIndex == playerIndex);
							if (connection != null && connection.Validated)
							{
								DispatchFrameToClient(connection, playerIndex, frameData);
							}
						}
					}
				}
			}
			while (State != ServerState.ShuttingDown);
			EndGame();
			if (IsMultiplayer)
			{
				Nat.TryRemovePortForward();
			}
			foreach (INotifyServerShutdown item5 in serverTraits.WithInterface<INotifyServerShutdown>())
			{
				item5.ServerShutdown(this);
			}
			foreach (Connection conn in Conns)
			{
				conn.Dispose();
			}
			Conns.Clear();
		});
		thread2.IsBackground = true;
		thread2.Start();
	}

	public int ChooseFreePlayerIndex()
	{
		return nextPlayerIndex++;
	}

	internal void OnConnectionPacket(Connection conn, int frame, byte[] data)
	{
		events.Add(new ConnectionPacketEvent(conn, frame, data));
	}

	internal void OnConnectionPing(Connection conn, int[] pingHistory, byte queueLength)
	{
		events.Add(new ConnectionPingEvent(conn, pingHistory, queueLength));
	}

	internal void OnConnectionDisconnect(Connection conn)
	{
		events.Add(new ConnectionDisconnectEvent(conn));
	}

	private void AcceptConnection(Socket socket)
	{
		if (State == ServerState.WaitingPlayers)
		{
			string authToken = Convert.ToBase64String(OpenRA.Exts.MakeArray(256, (int _) => (byte)Random.Next()));
			Connection connection = new Connection(this, socket, authToken);
			try
			{
				MemoryStream memoryStream = new MemoryStream(8);
				memoryStream.Write(7);
				memoryStream.Write(connection.PlayerIndex);
				connection.TrySendData(memoryStream.ToArray());
				HandshakeRequest handshakeRequest = new HandshakeRequest
				{
					Mod = ModData.Manifest.Id,
					Version = ModData.Manifest.Metadata.Version,
					AuthToken = authToken
				};
				DispatchOrdersToClient(connection, 0, 0, new Order("HandshakeRequest", null, queued: false)
				{
					Type = OrderType.Handshake,
					IsImmediate = true,
					TargetString = handshakeRequest.Serialize()
				}.Serialize());
			}
			catch (Exception value)
			{
				Log.Write("server", $"Handshake for client {connection.EndPoint} failed: {value}");
			}
			Conns.Add(connection);
		}
	}

	private void ValidateClient(Connection newConn, string data, string name)
	{
		Session.Client client;
		try
		{
			if (State == ServerState.GameStarted)
			{
				Log.Write("server", $"Rejected connection from {newConn.EndPoint}; game is already started.");
				SendOrderTo(newConn, "ServerError", "notification-error-game-started");
				DropClient(newConn);
				return;
			}
			HandshakeResponse handshake = HandshakeResponse.Deserialize(data, name);
			if (!string.IsNullOrEmpty(Settings.Password) && handshake.Password != Settings.Password)
			{
				string data2 = (string.IsNullOrEmpty(handshake.Password) ? "notification-requires-password" : "notification-incorrect-password");
				SendOrderTo(newConn, "AuthenticationError", data2);
				DropClient(newConn);
				return;
			}
			IPAddress address = ((IPEndPoint)newConn.EndPoint).Address;
			client = new Session.Client
			{
				Name = OpenRA.Settings.SanitizedPlayerName(handshake.Client.Name),
				IPAddress = address.ToString(),
				AnonymizedIPAddress = ((IsMultiplayer && Settings.ShareAnonymizedIPs) ? Session.AnonymizeIP(address) : null),
				Location = GeoIP.LookupCountry(address),
				Index = newConn.PlayerIndex,
				PreferredColor = handshake.Client.PreferredColor,
				Color = handshake.Client.Color,
				Faction = "Random",
				SpawnPoint = 0,
				Team = 0,
				Handicap = 0,
				State = Session.ClientState.Invalid
			};
			if (ModData.Manifest.Id != handshake.Mod)
			{
				Log.Write("server", $"Rejected connection from {newConn.EndPoint}; mods do not match.");
				SendOrderTo(newConn, "ServerError", "notification-incompatible-mod");
				DropClient(newConn);
				return;
			}
			if (ModData.Manifest.Metadata.Version != handshake.Version)
			{
				Log.Write("server", $"Rejected connection from {newConn.EndPoint}; Not running the same version.");
				SendOrderTo(newConn, "ServerError", "notification-incompatible-version");
				DropClient(newConn);
				return;
			}
			if (handshake.OrdersProtocol != 21)
			{
				Log.Write("server", $"Rejected connection from {newConn.EndPoint}; incompatible Orders protocol version {handshake.OrdersProtocol}.");
				SendOrderTo(newConn, "ServerError", "notification-incompatible-protocol");
				DropClient(newConn);
				return;
			}
			IEnumerable<string> source = Settings.Ban.Union(TempBans);
			if (source.Contains(client.IPAddress))
			{
				Log.Write("server", $"Rejected connection from {newConn.EndPoint}; Banned.");
				string data3 = (Enumerable.Contains(Settings.Ban, client.IPAddress) ? "notification-you-were-banned" : "notification-you-were-temp-banned");
				SendOrderTo(newConn, "ServerError", data3);
				DropClient(newConn);
			}
			else if (!IsMultiplayer)
			{
				client.Fingerprint = handshake.Fingerprint;
				CompleteConnection();
			}
			else if (!string.IsNullOrEmpty(handshake.Fingerprint) && !string.IsNullOrEmpty(handshake.AuthSignature))
			{
				Task.Run(async () =>
				{
					PlayerProfile profile = null;
					try
					{
						HttpClient httpClient = HttpClientFactory.Create();
						string url = playerDatabase.Profile + handshake.Fingerprint;
						MiniYamlNode miniYamlNode = MiniYaml.FromStream(await (await httpClient.GetAsync(url)).Content.ReadAsStreamAsync(), url).First();
						if (miniYamlNode.Key == "Player")
						{
							profile = FieldLoader.Load<PlayerProfile>(miniYamlNode.Value);
							string key = Encoding.ASCII.GetString(Convert.FromBase64String(profile.PublicKey));
							RSAParameters parameters = CryptoUtil.DecodePEMPublicKey(key);
							if (!profile.KeyRevoked && CryptoUtil.VerifySignature(parameters, newConn.AuthToken, handshake.AuthSignature))
							{
								client.Fingerprint = handshake.Fingerprint;
								Log.Write("server", $"{newConn.EndPoint} authenticated as {profile.ProfileName} (UID {profile.ProfileID})");
							}
							else if (profile.KeyRevoked)
							{
								profile = null;
								Log.Write("server", $"{newConn.EndPoint} failed to authenticate as {handshake.Fingerprint} (key revoked)");
							}
							else
							{
								profile = null;
								Log.Write("server", $"{newConn.EndPoint} failed to authenticate as {handshake.Fingerprint} (signature verification failed)");
							}
						}
						else
						{
							Log.Write("server", $"{newConn.EndPoint} failed to authenticate as {handshake.Fingerprint} (invalid server response: `{miniYamlNode.Key}` is not `Player`)");
						}
					}
					catch (Exception ex2)
					{
						Log.Write("server", $"{newConn.EndPoint} failed to authenticate as {handshake.Fingerprint} (exception occurred)");
						Log.Write("server", ex2.ToString());
					}
					events.Add(new CallbackEvent(() =>
					{
						bool flag = Type == ServerType.Dedicated && profile == null && (Settings.RequireAuthentication || Settings.ProfileIDWhitelist.Length != 0);
						bool flag2 = Type == ServerType.Dedicated && profile != null && Enumerable.Contains(Settings.ProfileIDBlacklist, profile.ProfileID);
						bool flag3 = Type == ServerType.Dedicated && Settings.ProfileIDWhitelist.Length != 0 && (profile == null || !Enumerable.Contains(Settings.ProfileIDWhitelist, profile.ProfileID));
						if (flag)
						{
							Log.Write("server", $"Rejected connection from {newConn.EndPoint}; Not authenticated.");
							SendOrderTo(newConn, "ServerError", "notification-requires-authentication");
							DropClient(newConn);
						}
						else if (flag2 | flag3)
						{
							if (flag2)
							{
								Log.Write("server", $"Rejected connection from {newConn.EndPoint}; In server blacklist.");
							}
							else
							{
								Log.Write("server", $"Rejected connection from {newConn.EndPoint}; Not in server whitelist.");
							}
							SendOrderTo(newConn, "ServerError", "notification-no-permission-to-join");
							DropClient(newConn);
						}
						else
						{
							CompleteConnection();
						}
					}));
				});
			}
			else if (Type == ServerType.Dedicated && (Settings.RequireAuthentication || Settings.ProfileIDWhitelist.Length != 0))
			{
				Log.Write("server", $"Rejected connection from {newConn.EndPoint}; Not authenticated.");
				SendOrderTo(newConn, "ServerError", "notification-requires-authentication");
				DropClient(newConn);
			}
			else
			{
				CompleteConnection();
			}
		}
		catch (Exception ex)
		{
			Log.Write("server", $"Dropping connection {newConn.EndPoint} because an error occurred:");
			Log.Write("server", ex.ToString());
			DropClient(newConn);
		}
		void CompleteConnection()
		{
			lock (LobbyInfo)
			{
				client.Slot = LobbyInfo.FirstEmptySlot();
				client.IsAdmin = !LobbyInfo.Clients.Any((Session.Client c) => c.IsAdmin);
				if (client.IsObserver && !LobbyInfo.GlobalSettings.AllowSpectators)
				{
					SendOrderTo(newConn, "ServerError", "notification-game-full");
					DropClient(newConn);
				}
				else
				{
					if (client.Slot != null)
					{
						SyncClientToPlayerReference(client, Map.Players.Players[client.Slot]);
					}
					else
					{
						client.Color = Color.White;
					}
					LobbyInfo.Clients.Add(client);
					newConn.Validated = true;
					if (!client.IsAdmin && Settings.FloodLimitJoinCooldown > 0)
					{
						playerMessageTracker.DisableChatUI(newConn, Settings.FloodLimitJoinCooldown);
					}
					Log.Write("server", $"Client {newConn.PlayerIndex}: Accepted connection from {newConn.EndPoint}.");
					if (client.Fingerprint != null)
					{
						Log.Write("server", $"Client {newConn.PlayerIndex}: Player fingerprint is {client.Fingerprint}.");
					}
					foreach (IClientJoined item in serverTraits.WithInterface<IClientJoined>())
					{
						item.ClientJoined(this, newConn);
					}
					SyncLobbyInfo();
					Log.Write("server", $"{client.Name} ({newConn.EndPoint}) has joined the game.");
					SendFluentMessage("notification-joined", "player", client.Name);
					if (Type == ServerType.Dedicated)
					{
						string path = Path.Combine(Platform.SupportDir, "motd.txt");
						if (!File.Exists(path))
						{
							File.WriteAllText(path, "Welcome, have fun and good luck!");
						}
						string text = File.ReadAllText(path);
						if (!string.IsNullOrEmpty(text))
						{
							SendOrderTo(newConn, "Message", text);
						}
					}
					if ((LobbyInfo.GlobalSettings.MapStatus & Session.MapStatus.UnsafeCustomRules) != 0)
					{
						SendFluentMessageTo(newConn, "notification-custom-rules");
					}
					if (!LobbyInfo.GlobalSettings.EnableSingleplayer)
					{
						SendFluentMessageTo(newConn, "notification-two-humans-required");
					}
					else if (Map.Players.Players.Where((KeyValuePair<string, PlayerReference> p) => p.Value.Playable).All((KeyValuePair<string, PlayerReference> p) => !p.Value.AllowBots))
					{
						SendFluentMessageTo(newConn, "notification-map-bots-disabled");
					}
				}
			}
		}
	}

	private static byte[] CreateFrame(int client, int frame, byte[] data)
	{
		MemoryStream memoryStream = new MemoryStream(data.Length + 12);
		memoryStream.Write(data.Length + 4);
		memoryStream.Write(client);
		memoryStream.Write(frame);
		memoryStream.Write(data);
		return memoryStream.GetBuffer();
	}

	private static byte[] CreateAckFrame(int frame, byte count)
	{
		MemoryStream memoryStream = new MemoryStream(14);
		memoryStream.Write(6);
		memoryStream.Write(0);
		memoryStream.Write(frame);
		memoryStream.WriteByte(16);
		memoryStream.WriteByte(count);
		return memoryStream.GetBuffer();
	}

	private static byte[] CreateTickScaleFrame(float scale)
	{
		MemoryStream memoryStream = new MemoryStream(17);
		memoryStream.Write(9);
		memoryStream.Write(0);
		memoryStream.Write(0);
		memoryStream.WriteByte(118);
		memoryStream.Write(scale);
		return memoryStream.GetBuffer();
	}

	private void DispatchOrdersToClient(Connection c, int client, int frame, byte[] data)
	{
		DispatchFrameToClient(c, client, CreateFrame(client, frame, data));
	}

	private void DispatchFrameToClient(Connection c, int client, byte[] frameData)
	{
		if (!c.TrySendData(frameData))
		{
			DropClient(c);
			Log.Write("server", "Dropping client " + client.ToString(CultureInfo.InvariantCulture) + " because dispatching orders failed!");
		}
	}

	private bool AnyUndefinedWinStates()
	{
		int num = -1;
		IEnumerable<GameInformation.Player> enumerable = gameInfo.Players.Where((GameInformation.Player p) => p.Outcome == WinState.Undefined);
		foreach (GameInformation.Player item in enumerable)
		{
			if (num >= 0 && (item.Team != num || item.Team == 0))
			{
				return true;
			}
			num = item.Team;
		}
		return false;
	}

	private void SetPlayerDefeat(int playerIndex)
	{
		GameInformation.Player player = worldPlayers[playerIndex];
		if (player == null || player.Outcome != WinState.Undefined)
		{
			return;
		}
		player.Outcome = WinState.Lost;
		player.OutcomeTimestampUtc = DateTime.UtcNow;
		if (AnyUndefinedWinStates())
		{
			return;
		}
		DateTime utcNow = DateTime.UtcNow;
		IEnumerable<GameInformation.Player> enumerable = gameInfo.Players.Where((GameInformation.Player p) => p.Outcome == WinState.Undefined);
		foreach (GameInformation.Player item in enumerable)
		{
			item.Outcome = WinState.Won;
			item.OutcomeTimestampUtc = utcNow;
		}
	}

	private void OutOfSync(int frame)
	{
		Log.Write("server", $"Out of sync detected at frame {frame}, cancel replay recording");
		if (recorder != null)
		{
			recorder.Metadata = null;
			recorder.Dispose();
		}
		recorder = null;
	}

	private void HandleSyncOrder(int frame, byte[] packet)
	{
		if (syncForFrame.TryGetValue(frame, out var value))
		{
			if (packet.Length != value.Length)
			{
				OutOfSync(frame);
				return;
			}
			for (int i = 0; i < packet.Length; i++)
			{
				if (packet[i] != value[i])
				{
					OutOfSync(frame);
					break;
				}
			}
			return;
		}
		ulong num = BitConverter.ToUInt64(packet, 5);
		if (frame > lastDefeatStateFrame && lastDefeatState != num)
		{
			ulong num2 = num & ~lastDefeatState;
			for (int j = 0; j < worldPlayers.Count; j++)
			{
				if ((num2 & (ulong)(1L << j)) != 0L)
				{
					SetPlayerDefeat(j);
				}
			}
			lastDefeatState = num;
			lastDefeatStateFrame = frame;
		}
		syncForFrame.Add(frame, packet);
	}

	public void DispatchOrdersToClients(Connection conn, int frame, byte[] data)
	{
		int playerIndex = conn.PlayerIndex;
		byte[] frameData = CreateFrame(playerIndex, frame, data);
		foreach (Connection item in Conns.ToList())
		{
			if (item != conn && item.Validated)
			{
				DispatchFrameToClient(item, playerIndex, frameData);
			}
		}
		RecordOrder(frame, data, playerIndex);
	}

	private void RecordOrder(int frame, byte[] data, int from)
	{
		recorder?.ReceiveFrame(from, frame, data);
		if (data.Length != 0 && data[0] == 101)
		{
			if (data.Length == 13)
			{
				HandleSyncOrder(frame, data);
				return;
			}
			Log.Write("server", $"Dropped sync order with length {data.Length} from client {from}. Expected length {13}.");
		}
	}

	public void DispatchServerOrdersToClients(Order order)
	{
		DispatchServerOrdersToClients(order.Serialize());
	}

	public void DispatchServerOrdersToClients(byte[] data, int frame = 0)
	{
		byte[] frameData = CreateFrame(0, frame, data);
		foreach (Connection item in Conns.ToList())
		{
			if (item.Validated)
			{
				DispatchFrameToClient(item, 0, frameData);
			}
		}
		RecordOrder(frame, data, 0);
	}

	public void ReceiveOrders(Connection conn, int frame, byte[] data)
	{
		if (!Conns.Contains(conn))
		{
			return;
		}
		if (frame == 0)
		{
			InterpretServerOrders(conn, data);
		}
		else
		{
			if (data.Length == 0 || data[0] != 101)
			{
				frame += OrderLatency;
				DispatchFrameToClient(conn, conn.PlayerIndex, CreateAckFrame(frame, 1));
				orderBuffer.AddOrderTimestamp(conn.PlayerIndex);
				conn.LastOrdersFrame = frame;
			}
			DispatchOrdersToClients(conn, frame, data);
		}
		GameSave?.DispatchOrders(conn, frame, data);
	}

	private void InterpretServerOrders(Connection conn, byte[] data)
	{
		MemoryStream memoryStream = new MemoryStream(data);
		BinaryReader r = new BinaryReader(memoryStream);
		try
		{
			while (memoryStream.Position < memoryStream.Length)
			{
				Order order = Order.Deserialize(null, r);
				if (order != null)
				{
					InterpretServerOrder(conn, order);
				}
			}
		}
		catch (EndOfStreamException)
		{
		}
		catch (NotImplementedException)
		{
		}
	}

	public void SendOrderTo(Connection conn, string order, string data)
	{
		DispatchOrdersToClient(conn, 0, 0, Order.FromTargetString(order, data, isImmediate: true).Serialize());
	}

	public void SendMessage(string text)
	{
		DispatchServerOrdersToClients(Order.FromTargetString("Message", text, isImmediate: true));
		if (Type == ServerType.Dedicated)
		{
			WriteLineWithTimeStamp(text);
		}
	}

	public void SendFluentMessage(string key, params object[] args)
	{
		string targetString = FluentMessage.Serialize(key, args);
		DispatchServerOrdersToClients(Order.FromTargetString("FluentMessage", targetString, isImmediate: true));
		if (Type == ServerType.Dedicated)
		{
			WriteLineWithTimeStamp(FluentProvider.GetMessage(key, args));
		}
	}

	public void SendFluentMessageTo(Connection conn, string key, object[] args = null)
	{
		string targetString = FluentMessage.Serialize(key, args);
		DispatchOrdersToClient(conn, 0, 0, Order.FromTargetString("FluentMessage", targetString, isImmediate: true).Serialize());
	}

	private void WriteLineWithTimeStamp(string line)
	{
		Console.WriteLine("[" + DateTime.Now.ToString(Settings.TimestampFormat, CultureInfo.CurrentCulture) + "] " + line);
	}

	private void InterpretServerOrder(Connection conn, Order o)
	{
		lock (LobbyInfo)
		{
			if (!conn.Validated)
			{
				if (o.OrderString == "HandshakeResponse")
				{
					ValidateClient(conn, o.TargetString, o.OrderString);
					return;
				}
				Log.Write("server", $"Rejected connection from {conn.EndPoint}; Order `{o.OrderString}` is not a `HandshakeResponse`.");
				DropClient(conn);
				return;
			}
			switch (o.OrderString)
			{
			case "Command":
				if (!InterpretCommand(o.TargetString, conn))
				{
					Log.Write("server", "Unknown server command: " + o.TargetString);
					SendFluentMessageTo(conn, "notification-unknown-server-command", new object[2] { "command", o.TargetString });
				}
				break;
			case "Chat":
				if (!IsMultiplayer || !playerMessageTracker.IsPlayerAtFloodLimit(conn))
				{
					DispatchOrdersToClients(conn, 0, o.Serialize());
				}
				break;
			case "GameSaveTraitData":
				if (GameSave != null)
				{
					MiniYamlNode miniYamlNode = MiniYaml.FromString(o.TargetString, o.OrderString)[0];
					GameSave.AddTraitData(OpenRA.Exts.ParseInt32Invariant(miniYamlNode.Key), miniYamlNode.Value);
				}
				break;
			case "CreateGameSave":
				if (GameSave != null)
				{
					string text2 = o.TargetString;
					int num2 = -1;
					char[] invalidFileNameChars2 = Path.GetInvalidFileNameChars();
					while ((num2 = text2.IndexOfAny(invalidFileNameChars2)) != -1)
					{
						text2 = text2.Remove(num2, 1);
					}
					string text3 = Path.Combine(Platform.SupportDir, "Saves", ModData.Manifest.Id, ModData.Manifest.Metadata.Version);
					if (!Directory.Exists(text3))
					{
						Directory.CreateDirectory(text3);
					}
					GameSave.Save(Path.Combine(text3, text2));
					DispatchServerOrdersToClients(Order.FromTargetString("GameSaved", text2, isImmediate: true));
				}
				break;
			case "LoadGameSave":
			{
				if (Type == ServerType.Dedicated || State >= ServerState.GameStarted)
				{
					break;
				}
				string text = o.TargetString;
				int num = -1;
				char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
				while ((num = text.IndexOfAny(invalidFileNameChars)) != -1)
				{
					text = text.Remove(num, 1);
				}
				string filepath = Path.Combine(Platform.SupportDir, "Saves", ModData.Manifest.Id, ModData.Manifest.Metadata.Version, text);
				GameSave = new GameSave(filepath);
				LobbyInfo.GlobalSettings = GameSave.GlobalSettings;
				LobbyInfo.Slots = GameSave.Slots;
				foreach (Session.Client client3 in LobbyInfo.Clients)
				{
					if (client3.Bot != null)
					{
						LobbyInfo.Clients.Remove(client3);
					}
					else
					{
						client3.Slot = null;
					}
				}
				int index = LobbyInfo.Clients.First((Session.Client c) => c.IsAdmin).Index;
				foreach (KeyValuePair<string, SlotClient> slotClient in GameSave.SlotClients)
				{
					if (slotClient.Value.Bot != null)
					{
						Session.Client client = new Session.Client
						{
							Index = ChooseFreePlayerIndex(),
							State = Session.ClientState.NotReady,
							BotControllerClientIndex = index
						};
						slotClient.Value.ApplyTo(client);
						LobbyInfo.Clients.Add(client);
					}
					else
					{
						Session.Client client2 = LobbyInfo.Clients.First((Session.Client c) => c.Slot == null);
						slotClient.Value.ApplyTo(client2);
					}
				}
				SyncLobbyInfo();
				SyncLobbyClients();
				break;
			}
			}
		}
	}

	public void ReceivePing(Connection conn, int[] pingHistory)
	{
		int num = pingHistory.Sum() / pingHistory.Length;
		Session.ConnectionQuality connectionQuality = ((num >= 240) ? ((num < 360) ? Session.ConnectionQuality.Moderate : Session.ConnectionQuality.Poor) : Session.ConnectionQuality.Good);
		lock (LobbyInfo)
		{
			foreach (Session.Client client in LobbyInfo.Clients)
			{
				if (client.Index == conn.PlayerIndex || (client.Bot != null && client.BotControllerClientIndex == conn.PlayerIndex))
				{
					client.ConnectionQuality = connectionQuality;
				}
			}
			if (pingUpdated.ElapsedMilliseconds <= 5000)
			{
				return;
			}
			List<MiniYamlNode> list = new List<MiniYamlNode>();
			foreach (Session.Client client2 in LobbyInfo.Clients)
			{
				list.Add(new MiniYamlNode($"ConnectionQuality@{client2.Index}", FieldSaver.FormatValue(client2.ConnectionQuality)));
			}
			DispatchServerOrdersToClients(Order.FromTargetString("SyncConnectionQuality", list.WriteToString(), isImmediate: true));
			pingUpdated.Restart();
		}
	}

	public Session.Client GetClient(Connection conn)
	{
		if (conn == null)
		{
			return null;
		}
		return LobbyInfo.ClientWithIndex(conn.PlayerIndex);
	}

	public bool HasClientWonOrLost(Session.Client client)
	{
		GameInformation.Player player = worldPlayers.FirstOrDefault((GameInformation.Player p) => p?.ClientIndex == client.Index);
		if (player == null)
		{
			return true;
		}
		return player.Outcome != WinState.Undefined;
	}

	public void DropClient(Connection toDrop)
	{
		lock (LobbyInfo)
		{
			orderBuffer?.RemovePlayer(toDrop.PlayerIndex);
			Conns.Remove(toDrop);
			Session.Client client = LobbyInfo.Clients.FirstOrDefault((Session.Client c) => c.Index == toDrop.PlayerIndex);
			if (client == null)
			{
				toDrop.Dispose();
				return;
			}
			if (State == ServerState.GameStarted)
			{
				if (client.IsObserver)
				{
					SendFluentMessage("notification-observer-disconnected", "player", client.Name);
				}
				else if (client.Team > 0)
				{
					SendFluentMessage("notification-team-player-disconnected", "player", client.Name, "team", client.Team);
				}
				else
				{
					SendFluentMessage("notification-player-disconnected", "player", client.Name);
				}
			}
			else
			{
				SendFluentMessage("notification-lobby-disconnected", "player", client.Name);
			}
			LobbyInfo.Clients.RemoveAll((Session.Client c) => c.Index == toDrop.PlayerIndex);
			if (Type == ServerType.Dedicated && client.IsAdmin && State == ServerState.WaitingPlayers)
			{
				LobbyInfo.Clients.RemoveAll((Session.Client c) => c.Bot != null && c.BotControllerClientIndex == toDrop.PlayerIndex);
				Session.Client client2 = LobbyInfo.Clients.Where((Session.Client c1) => c1.Bot == null).MinByOrDefault((Session.Client c) => c.Index);
				if (client2 != null)
				{
					client2.IsAdmin = true;
					SendFluentMessage("notification-new-admin", "player", client2.Name);
				}
			}
			MemoryStream memoryStream = new MemoryStream(5);
			memoryStream.WriteByte(191);
			memoryStream.Write(toDrop.PlayerIndex);
			DispatchServerOrdersToClients(memoryStream.ToArray(), toDrop.LastOrdersFrame + 1);
			if (gameInfo != null)
			{
				foreach (GameInformation.Player item in gameInfo.Players.Where((GameInformation.Player p) => p.ClientIndex == toDrop.PlayerIndex))
				{
					item.DisconnectFrame = toDrop.LastOrdersFrame + 1;
				}
			}
			if (!Conns.Any((Connection c) => c.Validated))
			{
				foreach (INotifyServerEmpty item2 in serverTraits.WithInterface<INotifyServerEmpty>())
				{
					item2.ServerEmpty(this);
				}
			}
			if (Conns.Any((Connection c) => c.Validated) || Type == ServerType.Dedicated)
			{
				SyncLobbyClients();
			}
			if (Type != ServerType.Dedicated && client.IsAdmin)
			{
				Shutdown();
			}
		}
		toDrop.Dispose();
	}

	public void SyncLobbyInfo()
	{
		lock (LobbyInfo)
		{
			if (State == ServerState.WaitingPlayers)
			{
				DispatchServerOrdersToClients(Order.FromTargetString("SyncInfo", LobbyInfo.Serialize(), isImmediate: true));
			}
			foreach (INotifySyncLobbyInfo item in serverTraits.WithInterface<INotifySyncLobbyInfo>())
			{
				item.LobbyInfoSynced(this);
			}
		}
	}

	public void SyncLobbyClients()
	{
		if (State != ServerState.WaitingPlayers)
		{
			return;
		}
		lock (LobbyInfo)
		{
			List<MiniYamlNode> y = LobbyInfo.Clients.ConvertAll((Session.Client client) => client.Serialize());
			DispatchServerOrdersToClients(Order.FromTargetString("SyncLobbyClients", y.WriteToString(), isImmediate: true));
			foreach (INotifySyncLobbyInfo item in serverTraits.WithInterface<INotifySyncLobbyInfo>())
			{
				item.LobbyInfoSynced(this);
			}
			pingUpdated.Restart();
		}
	}

	public void SyncLobbySlots()
	{
		if (State != ServerState.WaitingPlayers)
		{
			return;
		}
		lock (LobbyInfo)
		{
			List<MiniYamlNode> y = LobbyInfo.Slots.Select((KeyValuePair<string, Session.Slot> slot) => slot.Value.Serialize()).ToList();
			DispatchServerOrdersToClients(Order.FromTargetString("SyncLobbySlots", y.WriteToString(), isImmediate: true));
			foreach (INotifySyncLobbyInfo item in serverTraits.WithInterface<INotifySyncLobbyInfo>())
			{
				item.LobbyInfoSynced(this);
			}
		}
	}

	public void SyncLobbyGlobalSettings()
	{
		if (State != ServerState.WaitingPlayers)
		{
			return;
		}
		lock (LobbyInfo)
		{
			List<MiniYamlNode> y = new List<MiniYamlNode> { LobbyInfo.GlobalSettings.Serialize() };
			DispatchServerOrdersToClients(Order.FromTargetString("SyncLobbyGlobalSettings", y.WriteToString(), isImmediate: true));
			foreach (INotifySyncLobbyInfo item in serverTraits.WithInterface<INotifySyncLobbyInfo>())
			{
				item.LobbyInfoSynced(this);
			}
		}
	}

	public void StartGame()
	{
		lock (LobbyInfo)
		{
			WriteLineWithTimeStamp(FluentProvider.GetMessage("notification-game-started"));
			Connection[] array = Conns.Where((Connection c) => !c.Validated || GetClient(c).IsInvalid).ToArray();
			foreach (Connection connection in array)
			{
				SendOrderTo(connection, "ServerError", "notification-you-were-kicked");
				DropClient(connection);
			}
			LobbyInfo.GlobalSettings.GameSavesEnabled = Type != ServerType.Dedicated && LobbyInfo.NonBotClients.Count() == 1;
			MersenneTwister playerRandom = new MersenneTwister(LobbyInfo.GlobalSettings.RandomSeed);
			foreach (ICreatePlayersInfo item in Map.WorldActorInfo.TraitInfos<ICreatePlayersInfo>())
			{
				item.CreateServerPlayers(Map, LobbyInfo, worldPlayers, playerRandom);
			}
			gameInfo = new GameInformation
			{
				Mod = Game.ModData.Manifest.Id,
				Version = Game.ModData.Manifest.Metadata.Version,
				MapUid = Map.Uid,
				MapTitle = Map.Title,
				StartTimeUtc = DateTime.UtcNow
			};
			foreach (GameInformation.Player worldPlayer in worldPlayers)
			{
				if (worldPlayer != null)
				{
					gameInfo.Players.Add(worldPlayer);
				}
			}
			if (recorder != null)
			{
				recorder.Metadata = new ReplayMetadata(gameInfo);
			}
			SyncLobbyInfo();
			GameSpeeds gameSpeeds = Game.ModData.Manifest.Get<GameSpeeds>();
			string key = LobbyInfo.GlobalSettings.OptionOrDefault("gamespeed", gameSpeeds.DefaultSpeed);
			GameSpeed gameSpeed = gameSpeeds.Speeds[key];
			orderBuffer = new OrderBuffer();
			orderBuffer.Start(gameSpeed, from c in Conns
				where c.Validated
				select c.PlayerIndex);
			State = ServerState.GameStarted;
			if (IsMultiplayer)
			{
				OrderLatency = gameSpeed.OrderLatency;
			}
			if (GameSave == null && LobbyInfo.GlobalSettings.GameSavesEnabled)
			{
				GameSave = new GameSave();
			}
			string targetString = "";
			if (GameSave != null)
			{
				GameSave.StartGame(LobbyInfo, Map);
				if (GameSave.LastOrdersFrame >= 0)
				{
					targetString = new List<MiniYamlNode>
					{
						new MiniYamlNode("SaveLastOrdersFrame", GameSave.LastOrdersFrame.ToStringInvariant()),
						new MiniYamlNode("SaveSyncFrame", GameSave.LastSyncFrame.ToStringInvariant())
					}.WriteToString();
				}
			}
			DispatchServerOrdersToClients(Order.FromTargetString("StartGame", targetString, isImmediate: true));
			foreach (IStartGame item2 in serverTraits.WithInterface<IStartGame>())
			{
				item2.GameStarted(this);
			}
			int num2 = 1;
			if (GameSave != null && GameSave.LastOrdersFrame >= 0)
			{
				GameSave.ParseOrders(LobbyInfo, (int frame, int client, byte[] data) =>
				{
					foreach (Connection conn in Conns)
					{
						if (conn.Validated)
						{
							DispatchOrdersToClient(conn, client, frame, data);
						}
					}
				});
				num2 += GameSave.LastOrdersFrame;
			}
			List<Connection> list = Conns.Where((Connection c) => c.Validated).ToList();
			foreach (Connection item3 in list)
			{
				for (int num3 = 0; num3 < OrderLatency; num3++)
				{
					item3.LastOrdersFrame = num2 + num3;
					byte[] frameData = CreateFrame(item3.PlayerIndex, item3.LastOrdersFrame, Array.Empty<byte>());
					foreach (Connection item4 in list)
					{
						DispatchFrameToClient(item4, item3.PlayerIndex, frameData);
					}
					RecordOrder(item3.LastOrdersFrame, Array.Empty<byte>(), item3.PlayerIndex);
					GameSave?.DispatchOrders(item3, item3.LastOrdersFrame, Array.Empty<byte>());
				}
			}
		}
	}

	public bool InterpretCommand(string command, Connection conn)
	{
		foreach (IInterpretCommand item in serverTraits.WithInterface<IInterpretCommand>())
		{
			if (item.InterpretCommand(this, conn, GetClient(conn), command))
			{
				return true;
			}
		}
		return false;
	}

	public ConnectionTarget GetEndpointForLocalConnection()
	{
		List<DnsEndPoint> list = new List<DnsEndPoint>();
		foreach (TcpListener listener in listeners)
		{
			IPEndPoint iPEndPoint = (IPEndPoint)listener.LocalEndpoint;
			if (IPAddress.IPv6Any.Equals(iPEndPoint.Address))
			{
				list.Add(new DnsEndPoint(IPAddress.IPv6Loopback.ToString(), iPEndPoint.Port));
			}
			else if (IPAddress.Any.Equals(iPEndPoint.Address))
			{
				list.Add(new DnsEndPoint(IPAddress.Loopback.ToString(), iPEndPoint.Port));
			}
			else
			{
				list.Add(new DnsEndPoint(iPEndPoint.Address.ToString(), iPEndPoint.Port));
			}
		}
		return new ConnectionTarget(list);
	}

	public bool MapIsUnknown(string uid)
	{
		if (string.IsNullOrEmpty(uid))
		{
			return true;
		}
		MapStatus status = ModData.MapCache[uid].Status;
		if (status != MapStatus.Available)
		{
			return status != MapStatus.DownloadAvailable;
		}
		return false;
	}

	public bool MapIsKnown(string uid)
	{
		if (string.IsNullOrEmpty(uid))
		{
			return false;
		}
		if (MapPool != null && !MapPool.Contains(uid))
		{
			return false;
		}
		MapStatus status = ModData.MapCache[uid].Status;
		if (status != MapStatus.Available)
		{
			return status == MapStatus.DownloadAvailable;
		}
		return true;
	}
}
