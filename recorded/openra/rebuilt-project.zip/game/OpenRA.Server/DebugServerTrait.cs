using System;
using OpenRA.Network;

namespace OpenRA.Server;

public class DebugServerTrait : ServerTrait, IInterpretCommand, IStartGame, INotifySyncLobbyInfo, INotifyServerStart, INotifyServerShutdown, IEndGame
{
	public bool InterpretCommand(Server server, Connection conn, Session.Client client, string cmd)
	{
		Console.WriteLine("Server received command from player {1}: {0}", cmd, conn.PlayerIndex);
		return false;
	}

	public void GameStarted(Server server)
	{
		Console.WriteLine("GameStarted()");
	}

	public void LobbyInfoSynced(Server server)
	{
		Console.WriteLine("LobbyInfoSynced()");
	}

	public void ServerStarted(Server server)
	{
		Console.WriteLine("ServerStarted()");
	}

	public void ServerShutdown(Server server)
	{
		Console.WriteLine("ServerShutdown()");
	}

	public void GameEnded(Server server)
	{
		Console.WriteLine("GameEnded()");
	}
}
