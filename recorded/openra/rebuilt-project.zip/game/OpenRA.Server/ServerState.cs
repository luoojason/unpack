namespace OpenRA.Server;

public enum ServerState
{
	WaitingPlayers = 1,
	GameStarted,
	ShuttingDown
}
