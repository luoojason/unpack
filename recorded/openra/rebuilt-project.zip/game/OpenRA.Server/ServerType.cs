namespace OpenRA.Server;

public enum ServerType
{
	Local,
	Skirmish,
	Multiplayer,
	Dedicated
}
