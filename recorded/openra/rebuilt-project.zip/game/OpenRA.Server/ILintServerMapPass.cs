using System;

namespace OpenRA.Server;

public interface ILintServerMapPass
{
	void Run(Action<string> emitError, Action<string> emitWarning, ModData modData, MapPreview map, Ruleset mapRules);
}
