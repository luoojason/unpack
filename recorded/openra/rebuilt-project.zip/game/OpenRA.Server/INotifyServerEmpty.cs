namespace OpenRA.Server;

public interface INotifyServerEmpty
{
	void ServerEmpty(Server server);
}
