using System;
using System.Collections.Generic;
using System.Threading;
using OpenRA.Network;

namespace OpenRA.Server;

public class MapStatusCache
{
	private readonly Dictionary<MapPreview, Session.MapStatus> cache = new Dictionary<MapPreview, Session.MapStatus>();

	private readonly Action<string, Session.MapStatus> onStatusChanged;

	private readonly bool enableRemoteLinting;

	private readonly ModData modData;

	public Session.MapStatus this[MapPreview map]
	{
		get
		{
			if (cache.TryGetValue(map, out var value))
			{
				return value;
			}
			Ruleset rules = null;
			try
			{
				rules = map.LoadRuleset();
				value = ((enableRemoteLinting && map.Status != MapStatus.Available) ? Session.MapStatus.Validating : Session.MapStatus.Playable);
				if (map.DefinesUnsafeCustomRules())
				{
					value |= Session.MapStatus.UnsafeCustomRules;
				}
			}
			catch (Exception ex)
			{
				Log.Write("server", "Failed to load rules for `" + map.Title + "` with error: " + ex.Message);
				value = Session.MapStatus.Incompatible;
			}
			if (map.Players.Players.Count > 63)
			{
				Log.Write("server", $"Failed to load `{map.Title}`: Player count exceeds maximum ({map.Players.Players.Count}/{63}).");
				value = Session.MapStatus.Incompatible;
			}
			cache[map] = value;
			if ((value & Session.MapStatus.Validating) != 0)
			{
				ThreadPool.QueueUserWorkItem((object? _) =>
				{
					RunLintTests(map, rules);
				});
			}
			return value;
		}
	}

	public MapStatusCache(ModData modData, Action<string, Session.MapStatus> onStatusChanged, bool enableRemoteLinting)
	{
		this.modData = modData;
		this.enableRemoteLinting = enableRemoteLinting;
		this.onStatusChanged = onStatusChanged;
	}

	private void RunLintTests(MapPreview map, Ruleset rules)
	{
		Session.MapStatus mapStatus = cache[map];
		bool failed = false;
		foreach (Type item in modData.ObjectCreator.GetTypesImplementing<ILintServerMapPass>())
		{
			try
			{
				ILintServerMapPass lintServerMapPass = (ILintServerMapPass)modData.ObjectCreator.CreateBasic(item);
				lintServerMapPass.Run(OnLintFailure, OnLintWarning, modData, map, rules);
			}
			catch (Exception ex)
			{
				OnLintFailure(ex.ToString());
			}
		}
		mapStatus &= ~Session.MapStatus.Validating;
		mapStatus = (Session.MapStatus)((int)mapStatus | (failed ? 4 : 2));
		cache[map] = mapStatus;
		onStatusChanged?.Invoke(map.Uid, mapStatus);
		void OnLintFailure(string message)
		{
			Log.Write("server", "Map " + map.Title + " failed lint with error: " + message);
			failed = true;
		}
		static void OnLintWarning(string _)
		{
		}
	}
}
