namespace OpenRA.Server;

public interface ITick
{
	void Tick(Server server);
}
