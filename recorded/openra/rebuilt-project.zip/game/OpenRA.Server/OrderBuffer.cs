using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace OpenRA.Server;

public class OrderBuffer
{
	private const int NumberOfFrames = 20;

	private const int Interval = 1000;

	private const float MaxTickScale = 1.1f;

	private const int EmptyValue = -1;

	private Stopwatch gameTimer;

	private long nextUpdate;

	private readonly ConcurrentDictionary<int, long> timestamps = new ConcurrentDictionary<int, long>();

	private readonly ConcurrentDictionary<int, Queue<long>> deltas = new ConcurrentDictionary<int, Queue<long>>();

	private int timestep;

	private int ticksPerInterval;

	private int baselinePlayer;

	private List<int> players;

	public void AddOrderTimestamp(int playerIndex)
	{
		timestamps[playerIndex] = gameTimer.ElapsedMilliseconds;
		if (!timestamps.Values.All((long t) => t != -1))
		{
			return;
		}
		long num = timestamps[baselinePlayer];
		foreach (var (key, num4) in timestamps)
		{
			long item = num - num4;
			Queue<long> queue = deltas[key];
			queue.Enqueue(item);
			if (queue.Count > 20)
			{
				queue.Dequeue();
			}
			timestamps[key] = -1L;
		}
	}

	public void Start(GameSpeed gameSpeed, IEnumerable<int> players)
	{
		timestep = gameSpeed.Timestep;
		ticksPerInterval = 1000 / timestep;
		this.players = players.ToList();
		baselinePlayer = this.players[0];
		foreach (int player in this.players)
		{
			timestamps.TryAdd(player, -1L);
			deltas.TryAdd(player, new Queue<long>());
		}
		gameTimer = Stopwatch.StartNew();
		nextUpdate = gameTimer.ElapsedMilliseconds + 1000;
	}

	public IEnumerable<(int PlayerIndex, float TickScale)> GetTickScales()
	{
		long elapsedMilliseconds = gameTimer.ElapsedMilliseconds;
		if (elapsedMilliseconds < nextUpdate)
		{
			yield break;
		}
		nextUpdate = elapsedMilliseconds + 1000;
		if (deltas.IsEmpty || deltas.Values.Any((Queue<long> q) => q.Count != 20))
		{
			yield break;
		}
		List<(int, long)> list = deltas.Select((KeyValuePair<int, Queue<long>> d) => (PlayerIndex: d.Key, Delta: Median(d.Value.ToArray()))).ToList();
		long item = list.MinBy(((int PlayerIndex, long Delta) p) => p.Delta).Item2;
		long offset = ((item < 0) ? Math.Abs(item) : 0);
		foreach (var item5 in list)
		{
			int item2 = item5.Item1;
			long item3 = item5.Item2;
			float num = (float)(item3 + offset) / (float)ticksPerInterval;
			float val = ((float)timestep + num) / (float)timestep;
			float item4 = val.Clamp(1f, 1.1f);
			yield return (PlayerIndex: item2, TickScale: item4);
		}
	}

	private static long Median(long[] a)
	{
		Array.Sort(a);
		int num = a.Length;
		if (num % 2 != 0)
		{
			return a[num / 2];
		}
		return (a[(num - 1) / 2] + a[num / 2]) / 2;
	}

	public void RemovePlayer(int player)
	{
		players.Remove(player);
		if (player == baselinePlayer && players.Count > 0)
		{
			int value = players[0];
			Interlocked.Exchange(ref baselinePlayer, value);
		}
		timestamps.TryRemove(player, out var _);
		deltas.TryRemove(player, out var _);
	}
}
