namespace OpenRA.Server;

public abstract class ServerTrait
{
}
