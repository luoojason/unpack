namespace OpenRA.Server;

public static class ProtocolVersion
{
	public const int Handshake = 7;

	public const int Orders = 21;
}
