namespace OpenRA.Server;

public interface INotifyServerShutdown
{
	void ServerShutdown(Server server);
}
