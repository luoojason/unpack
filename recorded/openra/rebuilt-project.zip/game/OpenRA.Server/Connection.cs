using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace OpenRA.Server;

public sealed class Connection : IDisposable
{
	public const int MaxOrderLength = 131072;

	private const int MaxPingSamples = 15;

	public readonly int PlayerIndex;

	public readonly string AuthToken;

	public readonly EndPoint EndPoint;

	public readonly Stopwatch ConnectionTimer = Stopwatch.StartNew();

	public bool TimeoutMessageShown;

	public bool Validated;

	public int LastOrdersFrame;

	private long lastReceivedTime;

	private readonly BlockingCollection<byte[]> sendQueue = new BlockingCollection<byte[]>();

	private readonly Queue<int> pingHistory = new Queue<int>();

	public long TimeSinceLastResponse => Game.RunTime - lastReceivedTime;

	public Connection(Server server, Socket socket, string authToken)
	{
		PlayerIndex = server.ChooseFreePlayerIndex();
		AuthToken = authToken;
		EndPoint = socket.RemoteEndPoint;
		Thread thread = new Thread(SendReceiveLoop);
		thread.Name = $"Client communication ({EndPoint}";
		thread.IsBackground = true;
		thread.Start((server, socket));
	}

	private static byte[] CreatePingFrame()
	{
		MemoryStream memoryStream = new MemoryStream(21);
		memoryStream.Write(13);
		memoryStream.Write(0);
		memoryStream.Write(0);
		memoryStream.WriteByte(32);
		memoryStream.Write(Game.RunTime);
		return memoryStream.GetBuffer();
	}

	private void SendReceiveLoop(object s)
	{
		(Server, Socket) tuple = ((Server, Socket))s;
		Server item = tuple.Item1;
		Socket item2 = tuple.Item2;
		item2.Blocking = false;
		item2.NoDelay = true;
		byte[] array = new byte[1024];
		List<byte> list = new List<byte>();
		ReceiveState receiveState = ReceiveState.Header;
		int num = 8;
		int frame = 0;
		Stopwatch stopwatch = Stopwatch.StartNew();
		try
		{
			while (true)
			{
				if (item2.Poll(100000, SelectMode.SelectRead))
				{
					int num2 = item2.Receive(array);
					if (num2 == 0)
					{
						break;
					}
					if (num2 > 0)
					{
						list.AddRange(array.Take(num2));
						lastReceivedTime = Game.RunTime;
						TimeoutMessageShown = false;
					}
					while (list.Count >= num)
					{
						byte[] array2 = list.GetRange(0, num).ToArray();
						list.RemoveRange(0, num);
						switch (receiveState)
						{
						case ReceiveState.Header:
							num = BitConverter.ToInt32(array2, 0) - 4;
							frame = BitConverter.ToInt32(array2, 4);
							receiveState = ReceiveState.Data;
							if (num < 0 || (item.IsMultiplayer && num > 131072))
							{
								Log.Write("server", $"Closing socket connection to {EndPoint} because of excessive order length: {num}");
								return;
							}
							break;
						case ReceiveState.Data:
							if (num == 10 && array2[0] == 32)
							{
								if (pingHistory.Count == 15)
								{
									pingHistory.Dequeue();
								}
								pingHistory.Enqueue((int)(Game.RunTime - BitConverter.ToInt64(array2, 1)));
								item.OnConnectionPing(this, pingHistory.ToArray(), array2[9]);
							}
							else
							{
								item.OnConnectionPacket(this, frame, array2);
							}
							num = 8;
							receiveState = ReceiveState.Header;
							break;
						}
					}
				}
				if (sendQueue.IsCompleted)
				{
					break;
				}
				if (stopwatch.ElapsedMilliseconds > 1000 && TrySendData(CreatePingFrame()))
				{
					stopwatch.Restart();
				}
				byte[] item3;
				while (sendQueue.TryTake(out item3, 0))
				{
					int i = 0;
					int num4;
					for (int num3 = item3.Length; i < num3; i += num4)
					{
						num4 = item2.Send(item3, i, num3 - i, SocketFlags.None, out var errorCode);
						switch (errorCode)
						{
						case SocketError.WouldBlock:
							Log.Write("server", $"Non-blocking send of {num3 - i} bytes failed. Falling back to blocking send.");
							item2.Blocking = true;
							num4 = item2.Send(item3, i, num3 - i, SocketFlags.None);
							item2.Blocking = false;
							break;
						default:
							throw new SocketException((int)errorCode);
						case SocketError.Success:
							break;
						}
					}
				}
			}
		}
		catch (SocketException value)
		{
			Log.Write("server", $"Closing socket connection to {EndPoint} because of socket error: {value}");
		}
		finally
		{
			item.OnConnectionDisconnect(this);
			item2.Dispose();
		}
	}

	public bool TrySendData(byte[] data)
	{
		if (sendQueue.IsAddingCompleted)
		{
			return false;
		}
		try
		{
			sendQueue.Add(data);
			return true;
		}
		catch (InvalidOperationException)
		{
			return false;
		}
	}

	public void Dispose()
	{
		sendQueue.CompleteAdding();
	}
}
