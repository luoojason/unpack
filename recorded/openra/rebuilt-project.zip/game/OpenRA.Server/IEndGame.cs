namespace OpenRA.Server;

public interface IEndGame
{
	void GameEnded(Server server);
}
