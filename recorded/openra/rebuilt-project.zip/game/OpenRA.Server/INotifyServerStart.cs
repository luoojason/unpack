namespace OpenRA.Server;

public interface INotifyServerStart
{
	void ServerStarted(Server server);
}
