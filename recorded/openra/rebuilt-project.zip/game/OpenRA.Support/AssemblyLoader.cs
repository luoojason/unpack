using System.IO;
using System.Reflection;
using System.Runtime.Loader;

namespace OpenRA.Support;

public class AssemblyLoader
{
	private readonly string mainAssembly;

	private readonly AssemblyLoadContext context;

	public Assembly LoadDefaultAssembly()
	{
		return context.LoadFromAssemblyPath(mainAssembly);
	}

	public AssemblyLoader(string assemblyFile)
	{
		mainAssembly = assemblyFile;
		string directoryName = Path.GetDirectoryName(assemblyFile);
		context = CreateLoadContext(directoryName, assemblyFile);
	}

	private static AssemblyLoadContext CreateLoadContext(string baseDir, string assemblyFile)
	{
		string depsFilePath = Path.Combine(baseDir, Path.GetFileNameWithoutExtension(assemblyFile) + ".deps.json");
		AssemblyLoadContextBuilder assemblyLoadContextBuilder = new AssemblyLoadContextBuilder();
		assemblyLoadContextBuilder.TryAddDependencyContext(depsFilePath, out var _);
		assemblyLoadContextBuilder.SetBaseDirectory(baseDir);
		return assemblyLoadContextBuilder.Build();
	}
}
