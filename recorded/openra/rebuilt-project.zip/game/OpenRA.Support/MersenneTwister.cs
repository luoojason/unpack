using System;

namespace OpenRA.Support;

public class MersenneTwister
{
	private readonly uint[] mt = new uint[624];

	private int index;

	public int Last;

	public int TotalCount;

	public MersenneTwister()
		: this(Environment.TickCount)
	{
	}

	public MersenneTwister(int seed)
	{
		mt[0] = (uint)seed;
		for (uint num = 1u; num < mt.Length; num++)
		{
			mt[num] = 1812433253 * (mt[num - 1] ^ (mt[num - 1] >> 30)) + num;
		}
	}

	public int Next()
	{
		if (index == 0)
		{
			Generate();
		}
		uint num = mt[index];
		num ^= num >> 11;
		num ^= (num << 7) & 0x9D2C5680u;
		num ^= (num << 15) & 0xEFC60000u;
		num ^= num >> 18;
		index = (index + 1) % 624;
		TotalCount++;
		Last = (int)(num % int.MaxValue);
		return Last;
	}

	public int Next(int low, int high)
	{
		if (high < low)
		{
			throw new ArgumentOutOfRangeException("high", "Maximum value is less than the minimum value.");
		}
		int num = high - low;
		if (num <= 1)
		{
			return low;
		}
		return low + Next() % num;
	}

	public int Next(int high)
	{
		return Next(0, high);
	}

	public float NextFloat()
	{
		return Math.Abs((float)Next() / 2.1474836E+09f);
	}

	private void Generate()
	{
		for (uint num = 0u; num < mt.Length; num++)
		{
			uint num2 = (mt[num] & 0x80000000u) | (mt[(num + 1) % 624] & 0x7FFFFFFF);
			mt[num] = mt[(num + 397) % 624] ^ (num2 >> 1);
			if ((num2 & 1) == 1)
			{
				mt[num] ^= 2567483615u;
			}
		}
	}
}
