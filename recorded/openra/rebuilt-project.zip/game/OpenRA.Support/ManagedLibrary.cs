using System.IO;
using System.Reflection;

namespace OpenRA.Support;

public class ManagedLibrary
{
	public AssemblyName Name { get; private set; }

	public static ManagedLibrary CreateFromPackage(string assetPath)
	{
		return new ManagedLibrary
		{
			Name = new AssemblyName(Path.GetFileNameWithoutExtension(assetPath))
		};
	}
}
