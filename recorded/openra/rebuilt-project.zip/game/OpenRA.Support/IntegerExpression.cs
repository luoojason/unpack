using System;
using System.Collections.Generic;

namespace OpenRA.Support;

public class IntegerExpression : VariableExpression
{
	private readonly Func<IReadOnlyDictionary<string, int>, int> asFunction;

	public IntegerExpression(string expression)
		: base(expression)
	{
		asFunction = Compile<int>();
	}

	public int Evaluate(IReadOnlyDictionary<string, int> symbols)
	{
		return asFunction(symbols);
	}
}
