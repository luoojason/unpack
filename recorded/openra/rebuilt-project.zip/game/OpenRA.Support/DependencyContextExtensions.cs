using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.Extensions.DependencyModel;

namespace OpenRA.Support;

public static class DependencyContextExtensions
{
	public static AssemblyLoadContextBuilder TryAddDependencyContext(this AssemblyLoadContextBuilder builder, string depsFilePath, out Exception error)
	{
		error = null;
		try
		{
			builder.AddDependencyContext(depsFilePath);
		}
		catch (Exception ex)
		{
			error = ex;
		}
		return builder;
	}

	public static AssemblyLoadContextBuilder AddDependencyContext(this AssemblyLoadContextBuilder builder, string depsFilePath)
	{
		using DependencyContextJsonReader dependencyContextJsonReader = new DependencyContextJsonReader();
		using FileStream stream = File.OpenRead(depsFilePath);
		DependencyContext dependencyContext = dependencyContextJsonReader.Read(stream);
		builder.SetBaseDirectory(Path.GetDirectoryName(depsFilePath));
		builder.AddDependencyContext(dependencyContext);
		return builder;
	}

	private static string GetFallbackRid()
	{
		string text;
		if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
		{
			text = "win10";
		}
		else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
		{
			text = "linux";
		}
		else
		{
			if (!RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
			{
				return "any";
			}
			text = "osx.10.12";
		}
		return RuntimeInformation.OSArchitecture switch
		{
			Architecture.X86 => text + "-x86", 
			Architecture.X64 => text + "-x64", 
			Architecture.Arm => text + "-arm", 
			Architecture.Arm64 => text + "-arm64", 
			_ => text, 
		};
	}

	public static AssemblyLoadContextBuilder AddDependencyContext(this AssemblyLoadContextBuilder builder, DependencyContext dependencyContext)
	{
		IReadOnlyList<RuntimeFallbacks> source = ((dependencyContext.RuntimeGraph.Count > 0) ? dependencyContext.RuntimeGraph : DependencyContext.Default.RuntimeGraph);
		string rid = RuntimeInformation.RuntimeIdentifier;
		string fallbackRid = GetFallbackRid();
		RuntimeFallbacks runtimeGraph = source.FirstOrDefault((RuntimeFallbacks g) => g.Runtime == rid) ?? source.FirstOrDefault((RuntimeFallbacks g) => g.Runtime == fallbackRid) ?? new RuntimeFallbacks("any");
		foreach (ManagedLibrary item in dependencyContext.ResolveRuntimeAssemblies(runtimeGraph))
		{
			builder.AddManagedLibrary(item);
		}
		foreach (NativeLibrary item2 in dependencyContext.ResolveNativeAssets(runtimeGraph))
		{
			builder.AddNativeLibrary(item2);
		}
		return builder;
	}

	private static IEnumerable<ManagedLibrary> ResolveRuntimeAssemblies(this DependencyContext depContext, RuntimeFallbacks runtimeGraph)
	{
		IEnumerable<string> rids = GetRids(runtimeGraph);
		return from library in depContext.RuntimeLibraries
			from assetPath in SelectAssets(rids, library.RuntimeAssemblyGroups)
			select ManagedLibrary.CreateFromPackage(assetPath);
	}

	private static IEnumerable<NativeLibrary> ResolveNativeAssets(this DependencyContext depContext, RuntimeFallbacks runtimeGraph)
	{
		IEnumerable<string> rids = GetRids(runtimeGraph);
		return from library in depContext.RuntimeLibraries
			from assetPath in SelectAssets(rids, library.NativeLibraryGroups)
			where !assetPath.EndsWith(".a", StringComparison.Ordinal)
			select NativeLibrary.CreateFromPackage(assetPath);
	}

	private static IEnumerable<string> GetRids(RuntimeFallbacks runtimeGraph)
	{
		string[] first = new string[1] { runtimeGraph.Runtime };
		IEnumerable<string> enumerable = runtimeGraph?.Fallbacks;
		return first.Concat(enumerable ?? Enumerable.Empty<string>());
	}

	private static IEnumerable<string> SelectAssets(IEnumerable<string> rids, IReadOnlyCollection<RuntimeAssetGroup> groups)
	{
		foreach (string rid in rids)
		{
			RuntimeAssetGroup runtimeAssetGroup = groups.FirstOrDefault((RuntimeAssetGroup g) => g.Runtime == rid);
			if (runtimeAssetGroup != null)
			{
				return runtimeAssetGroup.AssetPaths;
			}
		}
		return groups.GetDefaultAssets();
	}
}
