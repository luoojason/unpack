using System;
using System.Diagnostics;

namespace OpenRA.Support;

public readonly struct PerfSample(string item) : IDisposable
{
	private readonly string item = item;

	private readonly long ticks = Stopwatch.GetTimestamp();

	public void Dispose()
	{
		PerfHistory.Increment(item, 1000.0 * (double)Math.Max(0L, Stopwatch.GetTimestamp() - ticks) / (double)Stopwatch.Frequency);
	}
}
