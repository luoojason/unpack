using System;
using System.Net.Http;

namespace OpenRA.Support;

public static class HttpClientFactory
{
	private const int MaxConnectionPerServer = 20;

	private static readonly TimeSpan ConnectionLifeTime = TimeSpan.FromMinutes(1.0);

	private static readonly Lazy<HttpMessageHandler> Handler = new Lazy<HttpMessageHandler>(GetHandler);

	public static HttpClient Create()
	{
		return new HttpClient(Handler.Value, disposeHandler: false);
	}

	private static HttpMessageHandler GetHandler()
	{
		return new SocketsHttpHandler
		{
			PooledConnectionLifetime = ConnectionLifeTime,
			PooledConnectionIdleTimeout = ConnectionLifeTime,
			MaxConnectionsPerServer = 20
		};
	}
}
