using System.Collections.Generic;
using System.Globalization;

namespace OpenRA.Support;

internal sealed class Benchmark
{
	private sealed class BenchmarkPoint
	{
		public int Tick { get; }

		public double Value { get; }

		public BenchmarkPoint(int tick, double value)
		{
			Tick = tick;
			Value = value;
		}
	}

	private readonly string prefix;

	private readonly Dictionary<string, List<BenchmarkPoint>> samples = new Dictionary<string, List<BenchmarkPoint>>();

	public Benchmark(string prefix)
	{
		this.prefix = prefix;
	}

	public void Tick(int localTick)
	{
		foreach (KeyValuePair<string, PerfItem> item in PerfHistory.Items)
		{
			samples.GetOrAdd(item.Key).Add(new BenchmarkPoint(localTick, item.Value.LastValue));
		}
	}

	public void Write()
	{
		foreach (KeyValuePair<string, List<BenchmarkPoint>> sample in samples)
		{
			string key = sample.Key;
			Log.AddChannel(key, prefix + key + ".csv");
			Log.Write(key, "tick,time [ms]");
			foreach (BenchmarkPoint item in sample.Value)
			{
				Log.Write(key, $"{item.Tick},{item.Value.ToString(CultureInfo.InvariantCulture)}");
			}
		}
	}

	public void Reset()
	{
		samples.Clear();
	}
}
