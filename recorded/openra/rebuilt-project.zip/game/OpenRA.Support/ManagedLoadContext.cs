using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;

namespace OpenRA.Support;

internal sealed class ManagedLoadContext : AssemblyLoadContext
{
	private readonly string basePath;

	private readonly Dictionary<string, ManagedLibrary> managedAssemblies;

	private readonly Dictionary<string, NativeLibrary> nativeLibraries;

	private static readonly string[] NativeLibraryExtensions;

	private static readonly string[] NativeLibraryPrefixes;

	private static readonly string[] ManagedAssemblyExtensions;

	static ManagedLoadContext()
	{
		ManagedAssemblyExtensions = new string[4] { ".dll", ".ni.dll", ".exe", ".ni.exe" };
		if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
		{
			NativeLibraryPrefixes = new string[1] { "" };
			NativeLibraryExtensions = new string[1] { ".dll" };
		}
		else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
		{
			NativeLibraryPrefixes = new string[2] { "", "lib" };
			NativeLibraryExtensions = new string[1] { ".dylib" };
		}
		else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
		{
			NativeLibraryPrefixes = new string[2] { "", "lib" };
			NativeLibraryExtensions = new string[2] { ".so", ".so.1" };
		}
		else
		{
			NativeLibraryPrefixes = Array.Empty<string>();
			NativeLibraryExtensions = Array.Empty<string>();
		}
	}

	public ManagedLoadContext(string baseDirectory, Dictionary<string, ManagedLibrary> managedAssemblies, Dictionary<string, NativeLibrary> nativeLibraries)
	{
		basePath = baseDirectory ?? throw new ArgumentNullException("baseDirectory");
		this.managedAssemblies = managedAssemblies ?? throw new ArgumentNullException("managedAssemblies");
		this.nativeLibraries = nativeLibraries ?? throw new ArgumentNullException("nativeLibraries");
	}

	protected override Assembly Load(AssemblyName assemblyName)
	{
		try
		{
			Assembly assembly = AssemblyLoadContext.Default.LoadFromAssemblyName(assemblyName);
			if (assembly != null)
			{
				return null;
			}
		}
		catch
		{
		}
		if (managedAssemblies.TryGetValue(assemblyName.Name, out var value) && SearchForLibrary(value, out var path))
		{
			return LoadFromAssemblyPath(path);
		}
		return null;
	}

	protected override IntPtr LoadUnmanagedDll(string unmanagedDllName)
	{
		string[] nativeLibraryPrefixes = NativeLibraryPrefixes;
		foreach (string text in nativeLibraryPrefixes)
		{
			if (nativeLibraries.TryGetValue(text + unmanagedDllName, out var value) && SearchForLibrary(value, text, out var path))
			{
				return LoadUnmanagedDllFromPath(path);
			}
		}
		return base.LoadUnmanagedDll(unmanagedDllName);
	}

	private bool SearchForLibrary(ManagedLibrary library, out string path)
	{
		string[] managedAssemblyExtensions = ManagedAssemblyExtensions;
		foreach (string text in managedAssemblyExtensions)
		{
			string text2 = Path.Combine(basePath, library.Name.Name + text);
			if (File.Exists(text2))
			{
				path = text2;
				return true;
			}
		}
		path = null;
		return false;
	}

	private bool SearchForLibrary(NativeLibrary library, string prefix, out string path)
	{
		string[] nativeLibraryExtensions = NativeLibraryExtensions;
		foreach (string text in nativeLibraryExtensions)
		{
			string text2 = Path.Combine(basePath, prefix + library.Name + text);
			if (File.Exists(text2))
			{
				path = text2;
				return true;
			}
		}
		string text3 = Path.Combine(basePath, library.AppLocalPath);
		if (File.Exists(text3))
		{
			path = text3;
			return true;
		}
		path = null;
		return false;
	}
}
