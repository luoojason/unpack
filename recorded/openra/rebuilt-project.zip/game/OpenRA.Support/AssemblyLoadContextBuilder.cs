using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Loader;

namespace OpenRA.Support;

public class AssemblyLoadContextBuilder
{
	private readonly Dictionary<string, ManagedLibrary> managedLibraries = new Dictionary<string, ManagedLibrary>(StringComparer.Ordinal);

	private readonly Dictionary<string, NativeLibrary> nativeLibraries = new Dictionary<string, NativeLibrary>(StringComparer.Ordinal);

	private string basePath;

	public AssemblyLoadContext Build()
	{
		return new ManagedLoadContext(basePath, managedLibraries, nativeLibraries);
	}

	public AssemblyLoadContextBuilder SetBaseDirectory(string path)
	{
		if (string.IsNullOrEmpty(path))
		{
			throw new ArgumentException("Argument must not be null or empty.", "path");
		}
		if (!Path.IsPathRooted(path))
		{
			throw new ArgumentException("Argument must be a full path.", "path");
		}
		basePath = path;
		return this;
	}

	public AssemblyLoadContextBuilder AddManagedLibrary(ManagedLibrary library)
	{
		managedLibraries.Add(library.Name.Name, library);
		return this;
	}

	public AssemblyLoadContextBuilder AddNativeLibrary(NativeLibrary library)
	{
		ValidateRelativePath(library.AppLocalPath);
		nativeLibraries.Add(library.Name, library);
		return this;
	}

	private static void ValidateRelativePath(string probingPath)
	{
		if (string.IsNullOrEmpty(probingPath))
		{
			throw new ArgumentException("Value must not be null or empty.", "probingPath");
		}
		if (Path.IsPathRooted(probingPath))
		{
			throw new ArgumentException("Argument must be a relative path.", "probingPath");
		}
	}
}
