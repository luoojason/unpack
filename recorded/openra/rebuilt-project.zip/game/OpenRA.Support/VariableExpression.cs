using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;

namespace OpenRA.Support;

public abstract class VariableExpression
{
	private enum CharClass
	{
		Whitespace,
		Operator,
		Mixed,
		Id,
		Digit
	}

	private enum Associativity
	{
		Left,
		Right
	}

	[Flags]
	private enum Sides
	{
		None = 0,
		Left = 1,
		Right = 2,
		Both = Left | Right
	}

	private enum Grouping
	{
		None,
		Parens
	}

	private enum TokenType
	{
		False,
		True,
		Number,
		Variable,
		OpenParen,
		CloseParen,
		Not,
		Negate,
		OnesComplement,
		And,
		Or,
		Equals,
		NotEquals,
		LessThan,
		LessThanOrEqual,
		GreaterThan,
		GreaterThanOrEqual,
		Add,
		Subtract,
		Multiply,
		Divide,
		Modulo,
		Invalid
	}

	private enum Precedence
	{
		Unary = 16,
		Multiplication = 12,
		Addition = 11,
		Relation = 9,
		Equality = 8,
		And = 4,
		Or = 3,
		Binary = 0,
		Value = Binary,
		Parens = -1,
		Invalid = Parens
	}

	private readonly struct TokenTypeInfo
	{
		public readonly string Symbol;

		public readonly Precedence Precedence;

		public readonly Sides OperandSides;

		public readonly Sides WhitespaceSides;

		public readonly Associativity Associativity;

		public readonly Grouping Opens;

		public readonly Grouping Closes;

		public TokenTypeInfo(string symbol, Precedence precedence, Sides operandSides = Sides.None, Associativity associativity = Associativity.Left, Grouping opens = Grouping.None, Grouping closes = Grouping.None)
		{
			Symbol = symbol;
			Precedence = precedence;
			OperandSides = operandSides;
			WhitespaceSides = Sides.None;
			Associativity = associativity;
			Opens = opens;
			Closes = closes;
		}

		public TokenTypeInfo(string symbol, Precedence precedence, Sides operandSides, Sides whitespaceSides, Associativity associativity = Associativity.Left, Grouping opens = Grouping.None, Grouping closes = Grouping.None)
		{
			Symbol = symbol;
			Precedence = precedence;
			OperandSides = operandSides;
			WhitespaceSides = whitespaceSides;
			Associativity = associativity;
			Opens = opens;
			Closes = closes;
		}

		public TokenTypeInfo(string symbol, Precedence precedence, Grouping opens, Grouping closes = Grouping.None, Associativity associativity = Associativity.Left)
		{
			Symbol = symbol;
			Precedence = precedence;
			WhitespaceSides = Sides.None;
			OperandSides = ((opens != Grouping.None) ? ((closes == Grouping.None) ? Sides.Right : Sides.Both) : ((closes != Grouping.None) ? Sides.Left : Sides.None));
			Associativity = associativity;
			Opens = opens;
			Closes = closes;
		}
	}

	private class Token
	{
		public readonly TokenType Type;

		public readonly int Index;

		public virtual string Symbol => TokenTypeInfos[(int)Type].Symbol;

		public int Precedence => (int)TokenTypeInfos[(int)Type].Precedence;

		public Sides OperandSides => TokenTypeInfos[(int)Type].OperandSides;

		public Associativity Associativity => TokenTypeInfos[(int)Type].Associativity;

		public bool LeftOperand => (TokenTypeInfos[(int)Type].OperandSides & Sides.Left) != 0;

		public bool RightOperand => (TokenTypeInfos[(int)Type].OperandSides & Sides.Right) != 0;

		public Grouping Opens => TokenTypeInfos[(int)Type].Opens;

		public Grouping Closes => TokenTypeInfos[(int)Type].Closes;

		public Token(TokenType type, int index)
		{
			Type = type;
			Index = index;
		}

		private static bool ScanIsNumber(string expression, int start, ref int i)
		{
			CharClass charClass = CharClassOf(expression[i]);
			if (charClass == CharClass.Digit)
			{
				i++;
				while (i < expression.Length)
				{
					switch (CharClassOf(expression[i]))
					{
					default:
					{
						DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(37, 2);
						defaultInterpolatedStringHandler.AppendLiteral("Number ");
						defaultInterpolatedStringHandler.AppendFormatted(Exts.ParseInt32Invariant(expression.Substring(start, i - start)));
						defaultInterpolatedStringHandler.AppendLiteral(" and variable merged at index ");
						defaultInterpolatedStringHandler.AppendFormatted(start);
						throw new InvalidDataException(defaultInterpolatedStringHandler.ToStringAndClear());
					}
					case CharClass.Whitespace:
					case CharClass.Operator:
					case CharClass.Mixed:
						return true;
					case CharClass.Digit:
						break;
					}
					i++;
				}
				return true;
			}
			return false;
		}

		private static TokenType VariableOrKeyword(string expression, int start, ref int i)
		{
			if (CharClassOf(expression[i - 1]) == CharClass.Mixed)
			{
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(49, 2);
				defaultInterpolatedStringHandler.AppendLiteral("Invalid identifier end character at index ");
				defaultInterpolatedStringHandler.AppendFormatted(i - 1);
				defaultInterpolatedStringHandler.AppendLiteral(" for `");
				defaultInterpolatedStringHandler.AppendFormatted(expression.Substring(start, i - start));
				defaultInterpolatedStringHandler.AppendLiteral("`");
				throw new InvalidDataException(defaultInterpolatedStringHandler.ToStringAndClear());
			}
			return VariableOrKeyword(expression, start, i - start);
		}

		private static TokenType VariableOrKeyword(string expression, int start, int length)
		{
			int index = start;
			if (length == 4 && expression[index++] == 't' && expression[index++] == 'r' && expression[index++] == 'u' && expression[index] == 'e')
			{
				return TokenType.True;
			}
			if (length == 5 && expression[index++] == 'f' && expression[index++] == 'a' && expression[index++] == 'l' && expression[index++] == 's' && expression[index] == 'e')
			{
				return TokenType.False;
			}
			return TokenType.Variable;
		}

		public static TokenType GetNextType(string expression, ref int i, TokenType lastType = TokenType.Invalid)
		{
			int num = i;
			switch (expression[i])
			{
			case '!':
				i++;
				if (i < expression.Length && expression[i] == '=')
				{
					i++;
					return TokenType.NotEquals;
				}
				return TokenType.Not;
			case '<':
				i++;
				if (i < expression.Length && expression[i] == '=')
				{
					i++;
					return TokenType.LessThanOrEqual;
				}
				return TokenType.LessThan;
			case '>':
				i++;
				if (i < expression.Length && expression[i] == '=')
				{
					i++;
					return TokenType.GreaterThanOrEqual;
				}
				return TokenType.GreaterThan;
			case '=':
				i++;
				if (i < expression.Length && expression[i] == '=')
				{
					i++;
					return TokenType.Equals;
				}
				throw new InvalidDataException($"Unexpected character '=' at index {num} - should it be `==`?");
			case '&':
				i++;
				if (i < expression.Length && expression[i] == '&')
				{
					i++;
					return TokenType.And;
				}
				throw new InvalidDataException($"Unexpected character '&' at index {num} - should it be `&&`?");
			case '|':
				i++;
				if (i < expression.Length && expression[i] == '|')
				{
					i++;
					return TokenType.Or;
				}
				throw new InvalidDataException($"Unexpected character '|' at index {num} - should it be `||`?");
			case '(':
				i++;
				return TokenType.OpenParen;
			case ')':
				i++;
				return TokenType.CloseParen;
			case '~':
				i++;
				return TokenType.OnesComplement;
			case '+':
				i++;
				return TokenType.Add;
			case '-':
				if (++i < expression.Length && ScanIsNumber(expression, num, ref i))
				{
					return TokenType.Number;
				}
				i = num + 1;
				if (IsLeftOperandOrNone(lastType))
				{
					return TokenType.Negate;
				}
				return TokenType.Subtract;
			case '*':
				i++;
				return TokenType.Multiply;
			case '/':
				i++;
				return TokenType.Divide;
			case '%':
				i++;
				return TokenType.Modulo;
			default:
			{
				if (ScanIsNumber(expression, num, ref i))
				{
					return TokenType.Number;
				}
				CharClass charClass = CharClassOf(expression[num]);
				if (charClass != CharClass.Id)
				{
					throw new InvalidDataException($"Invalid character '{expression[i]}' at index {num}");
				}
				i = num;
				while (i < expression.Length)
				{
					charClass = CharClassOf(expression[i]);
					if (charClass == CharClass.Whitespace || charClass == CharClass.Operator)
					{
						return VariableOrKeyword(expression, num, ref i);
					}
					i++;
				}
				return VariableOrKeyword(expression, num, ref i);
			}
			}
		}

		public static Token GetNext(string expression, ref int i, TokenType lastType = TokenType.Invalid)
		{
			if (i == expression.Length)
			{
				return null;
			}
			bool flag = false;
			if (CharClassOf(expression[i]) == CharClass.Whitespace)
			{
				flag = true;
				while (CharClassOf(expression[i]) == CharClass.Whitespace)
				{
					if (++i == expression.Length)
					{
						return null;
					}
				}
			}
			else if (lastType == TokenType.Invalid)
			{
				flag = true;
			}
			else if (RequiresWhitespaceAfter(lastType))
			{
				throw new InvalidDataException($"Missing whitespace at index {i}, after `{GetTokenSymbol(lastType)}` operator.");
			}
			int num = i;
			TokenType nextType = GetNextType(expression, ref i, lastType);
			if (!flag && RequiresWhitespaceBefore(nextType))
			{
				throw new InvalidDataException($"Missing whitespace at index {i}, before `{GetTokenSymbol(nextType)}` operator.");
			}
			switch (nextType)
			{
			case TokenType.Number:
			{
				int num2 = num;
				return new NumberToken(num, expression.Substring(num2, i - num2));
			}
			case TokenType.Variable:
			{
				int num2 = num;
				return new VariableToken(num, expression.Substring(num2, i - num2));
			}
			default:
				return new Token(nextType, num);
			}
		}
	}

	private sealed class VariableToken : Token
	{
		public readonly string Name;

		public override string Symbol => Name;

		public VariableToken(int index, string symbol)
			: base(TokenType.Variable, index)
		{
			Name = symbol;
		}
	}

	private sealed class NumberToken : Token
	{
		public readonly int Value;

		private readonly string symbol;

		public override string Symbol => symbol;

		public NumberToken(int index, string symbol)
			: base(TokenType.Number, index)
		{
			Value = Exts.ParseInt32Invariant(symbol);
			this.symbol = symbol;
		}
	}

	private enum ExpressionType
	{
		Int,
		Bool
	}

	private sealed class AstStack
	{
		private readonly List<Expression> expressions = new List<Expression>();

		private readonly List<ExpressionType> types = new List<ExpressionType>();

		public ExpressionType PeekType()
		{
			List<ExpressionType> list = types;
			return list[list.Count - 1];
		}

		public Expression Peek(ExpressionType toType)
		{
			List<ExpressionType> list = types;
			ExpressionType expressionType = list[list.Count - 1];
			List<Expression> list2 = expressions;
			Expression expression = list2[list2.Count - 1];
			if (toType == expressionType)
			{
				return expression;
			}
			return toType switch
			{
				ExpressionType.Bool => IfThenElse(AsBool(expression), True, False), 
				ExpressionType.Int => IfThenElse(expression, One, Zero), 
				_ => throw new InvalidProgramException("Unable to convert " + $"ExpressionType.{Enum<ExpressionType>.GetValues()[(int)expressionType]} to " + $"ExpressionType.{Enum<ExpressionType>.GetValues()[(int)toType]}"), 
			};
		}

		public Expression Pop(ExpressionType type)
		{
			Expression result = Peek(type);
			expressions.RemoveAt(expressions.Count - 1);
			types.RemoveAt(types.Count - 1);
			return result;
		}

		public void Push(Expression expression, ExpressionType type)
		{
			expressions.Add(expression);
			if (type == ExpressionType.Int && expression.Type != typeof(int))
			{
				throw new InvalidOperationException($"Expected System.Int type instead of {expression.Type} for {expression}");
			}
			if (type == ExpressionType.Bool && expression.Type != typeof(bool))
			{
				throw new InvalidOperationException($"Expected System.Boolean type instead of {expression.Type} for {expression}");
			}
			types.Add(type);
		}

		public void Push(Expression expression)
		{
			expressions.Add(expression);
			if (expression.Type == typeof(int))
			{
				types.Add(ExpressionType.Int);
				return;
			}
			if (expression.Type == typeof(bool))
			{
				types.Add(ExpressionType.Bool);
				return;
			}
			throw new InvalidOperationException($"Unhandled result type {expression.Type} for {expression}");
		}
	}

	private sealed class Compiler
	{
		private readonly AstStack ast = new AstStack();

		public Expression Build(Token[] postfix, ExpressionType resultType)
		{
			foreach (Token token in postfix)
			{
				switch (token.Type)
				{
				case TokenType.And:
				{
					Expression right11 = ast.Pop(ExpressionType.Bool);
					Expression left13 = ast.Pop(ExpressionType.Bool);
					ast.Push(System.Linq.Expressions.Expression.And(left13, right11));
					break;
				}
				case TokenType.Or:
				{
					Expression right10 = ast.Pop(ExpressionType.Bool);
					Expression left12 = ast.Pop(ExpressionType.Bool);
					ast.Push(System.Linq.Expressions.Expression.Or(left12, right10));
					break;
				}
				case TokenType.NotEquals:
				{
					Expression right9 = ast.Pop(ExpressionType.Int);
					Expression left11 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.NotEqual(left11, right9));
					break;
				}
				case TokenType.Equals:
				{
					Expression right8 = ast.Pop(ExpressionType.Int);
					Expression left10 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.Equal(left10, right8));
					break;
				}
				case TokenType.Not:
					ast.Push(System.Linq.Expressions.Expression.Not(ast.Pop(ExpressionType.Bool)));
					break;
				case TokenType.Negate:
					ast.Push(System.Linq.Expressions.Expression.Negate(ast.Pop(ExpressionType.Int)));
					break;
				case TokenType.OnesComplement:
					ast.Push(System.Linq.Expressions.Expression.OnesComplement(ast.Pop(ExpressionType.Int)));
					break;
				case TokenType.LessThan:
				{
					Expression right7 = ast.Pop(ExpressionType.Int);
					Expression left9 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.LessThan(left9, right7));
					break;
				}
				case TokenType.LessThanOrEqual:
				{
					Expression right6 = ast.Pop(ExpressionType.Int);
					Expression left8 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.LessThanOrEqual(left8, right6));
					break;
				}
				case TokenType.GreaterThan:
				{
					Expression right5 = ast.Pop(ExpressionType.Int);
					Expression left7 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.GreaterThan(left7, right5));
					break;
				}
				case TokenType.GreaterThanOrEqual:
				{
					Expression right4 = ast.Pop(ExpressionType.Int);
					Expression left6 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.GreaterThanOrEqual(left6, right4));
					break;
				}
				case TokenType.Add:
				{
					Expression right3 = ast.Pop(ExpressionType.Int);
					Expression left5 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.Add(left5, right3));
					break;
				}
				case TokenType.Subtract:
				{
					Expression right2 = ast.Pop(ExpressionType.Int);
					Expression left4 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.Subtract(left4, right2));
					break;
				}
				case TokenType.Multiply:
				{
					Expression right = ast.Pop(ExpressionType.Int);
					Expression left3 = ast.Pop(ExpressionType.Int);
					ast.Push(System.Linq.Expressions.Expression.Multiply(left3, right));
					break;
				}
				case TokenType.Divide:
				{
					Expression expression2 = ast.Pop(ExpressionType.Int);
					Expression left2 = ast.Pop(ExpressionType.Int);
					BinaryExpression test2 = System.Linq.Expressions.Expression.NotEqual(expression2, Zero);
					BinaryExpression ifTrue2 = System.Linq.Expressions.Expression.Divide(left2, expression2);
					ast.Push(IfThenElse(test2, ifTrue2, Zero));
					break;
				}
				case TokenType.Modulo:
				{
					Expression expression = ast.Pop(ExpressionType.Int);
					Expression left = ast.Pop(ExpressionType.Int);
					BinaryExpression test = System.Linq.Expressions.Expression.NotEqual(expression, Zero);
					BinaryExpression ifTrue = System.Linq.Expressions.Expression.Modulo(left, expression);
					ast.Push(IfThenElse(test, ifTrue, Zero));
					break;
				}
				case TokenType.False:
					ast.Push(False);
					break;
				case TokenType.True:
					ast.Push(True);
					break;
				case TokenType.Number:
					ast.Push(System.Linq.Expressions.Expression.Constant(((NumberToken)token).Value));
					break;
				case TokenType.Variable:
				{
					ConstantExpression arg = System.Linq.Expressions.Expression.Constant(((VariableToken)token).Symbol);
					Func<string, IReadOnlyDictionary<string, int>, int> func = ParseSymbol;
					ast.Push(System.Linq.Expressions.Expression.Call(func.Method, arg, SymbolsParam));
					break;
				}
				default:
					throw new InvalidProgramException("ConditionExpression.Compiler.Compile() is missing an expression builder for " + $"TokenType.{Enum<TokenType>.GetValues()[(int)token.Type]}");
				}
			}
			return ast.Pop(resultType);
		}
	}

	public static readonly IReadOnlyDictionary<string, int> NoVariables = new ReadOnlyDictionary<string, int>(new Dictionary<string, int>());

	public readonly string Expression;

	private readonly HashSet<string> variables = new HashSet<string>();

	private static readonly TokenTypeInfo[] TokenTypeInfos = CreateTokenTypeInfoEnumeration().ToArray();

	private static readonly ParameterExpression SymbolsParam = System.Linq.Expressions.Expression.Parameter(typeof(IReadOnlyDictionary<string, int>), "symbols");

	private static readonly ConstantExpression Zero = System.Linq.Expressions.Expression.Constant(0);

	private static readonly ConstantExpression One = System.Linq.Expressions.Expression.Constant(1);

	private static readonly ConstantExpression False = System.Linq.Expressions.Expression.Constant(false);

	private static readonly ConstantExpression True = System.Linq.Expressions.Expression.Constant(true);

	public IEnumerable<string> Variables => variables;

	private static CharClass CharClassOf(char c)
	{
		switch (c)
		{
		case '!':
		case '"':
		case '%':
		case '&':
		case '\'':
		case '(':
		case ')':
		case '*':
		case '+':
		case ',':
		case '/':
		case ':':
		case ';':
		case '<':
		case '=':
		case '>':
		case '?':
		case '[':
		case ']':
		case '^':
		case '{':
		case '|':
		case '}':
		case '~':
			return CharClass.Operator;
		case '$':
		case '-':
		case '.':
		case '@':
			return CharClass.Mixed;
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			return CharClass.Digit;
		case '\t':
		case '\n':
		case '\r':
		case ' ':
			return CharClass.Whitespace;
		default:
			if (!char.IsWhiteSpace(c))
			{
				return CharClass.Id;
			}
			return CharClass.Whitespace;
		}
	}

	private static IEnumerable<TokenTypeInfo> CreateTokenTypeInfoEnumeration()
	{
		for (int i = 0; i <= 22; i++)
		{
			switch ((TokenType)i)
			{
			case TokenType.Invalid:
				yield return new TokenTypeInfo("(<INVALID>)", Precedence.Parens);
				break;
			case TokenType.False:
				yield return new TokenTypeInfo("false", Precedence.Binary);
				break;
			case TokenType.True:
				yield return new TokenTypeInfo("true", Precedence.Binary);
				break;
			case TokenType.Number:
				yield return new TokenTypeInfo("(<number>)", Precedence.Binary);
				break;
			case TokenType.Variable:
				yield return new TokenTypeInfo("(<variable>)", Precedence.Binary);
				break;
			case TokenType.OpenParen:
				yield return new TokenTypeInfo("(", Precedence.Parens, Grouping.Parens);
				break;
			case TokenType.CloseParen:
				yield return new TokenTypeInfo(")", Precedence.Parens, Grouping.None, Grouping.Parens);
				break;
			case TokenType.Not:
				yield return new TokenTypeInfo("!", Precedence.Unary, Sides.Right, Associativity.Right);
				break;
			case TokenType.OnesComplement:
				yield return new TokenTypeInfo("~", Precedence.Unary, Sides.Right, Associativity.Right);
				break;
			case TokenType.Negate:
				yield return new TokenTypeInfo("-", Precedence.Unary, Sides.Right, Associativity.Right);
				break;
			case TokenType.And:
				yield return new TokenTypeInfo("&&", Precedence.And, Sides.Both, Sides.Both);
				break;
			case TokenType.Or:
				yield return new TokenTypeInfo("||", Precedence.Or, Sides.Both, Sides.Both);
				break;
			case TokenType.Equals:
				yield return new TokenTypeInfo("==", Precedence.Equality, Sides.Both, Sides.Both);
				break;
			case TokenType.NotEquals:
				yield return new TokenTypeInfo("!=", Precedence.Equality, Sides.Both, Sides.Both);
				break;
			case TokenType.LessThan:
				yield return new TokenTypeInfo("<", Precedence.Relation, Sides.Both, Sides.Both);
				break;
			case TokenType.LessThanOrEqual:
				yield return new TokenTypeInfo("<=", Precedence.Relation, Sides.Both, Sides.Both);
				break;
			case TokenType.GreaterThan:
				yield return new TokenTypeInfo(">", Precedence.Relation, Sides.Both, Sides.Both);
				break;
			case TokenType.GreaterThanOrEqual:
				yield return new TokenTypeInfo(">=", Precedence.Relation, Sides.Both, Sides.Both);
				break;
			case TokenType.Add:
				yield return new TokenTypeInfo("+", Precedence.Addition, Sides.Both, Sides.Both);
				break;
			case TokenType.Subtract:
				yield return new TokenTypeInfo("-", Precedence.Addition, Sides.Both, Sides.Both);
				break;
			case TokenType.Multiply:
				yield return new TokenTypeInfo("*", Precedence.Multiplication, Sides.Both, Sides.Both);
				break;
			case TokenType.Divide:
				yield return new TokenTypeInfo("/", Precedence.Multiplication, Sides.Both, Sides.Both);
				break;
			case TokenType.Modulo:
				yield return new TokenTypeInfo("%", Precedence.Multiplication, Sides.Both, Sides.Both);
				break;
			default:
				throw new InvalidProgramException($"CreateTokenTypeInfoEnumeration is missing a TokenTypeInfo entry for TokenType.{Enum<TokenType>.GetValues()[i]}");
			}
		}
	}

	private static bool HasRightOperand(TokenType type)
	{
		return (TokenTypeInfos[(int)type].OperandSides & Sides.Right) != 0;
	}

	private static bool IsLeftOperandOrNone(TokenType type)
	{
		if (type != TokenType.Invalid)
		{
			return HasRightOperand(type);
		}
		return true;
	}

	private static bool RequiresWhitespaceAfter(TokenType type)
	{
		return (TokenTypeInfos[(int)type].WhitespaceSides & Sides.Right) != 0;
	}

	private static bool RequiresWhitespaceBefore(TokenType type)
	{
		return (TokenTypeInfos[(int)type].WhitespaceSides & Sides.Left) != 0;
	}

	private static string GetTokenSymbol(TokenType type)
	{
		return TokenTypeInfos[(int)type].Symbol;
	}

	protected VariableExpression(string expression)
	{
		Expression = expression;
	}

	private Expression Build(ExpressionType resultType)
	{
		List<Token> list = new List<Token>();
		Stack<Token> stack = new Stack<Token>();
		Token token = null;
		int i = 0;
		while (true)
		{
			Token next = Token.GetNext(Expression, ref i, token?.Type ?? TokenType.Invalid);
			if (next == null)
			{
				if (token == null)
				{
					throw new InvalidDataException("Empty expression");
				}
				if (!token.RightOperand)
				{
					break;
				}
				throw new InvalidDataException("Missing value or sub-expression at end for `" + token.Symbol + "` operator");
			}
			if (next.Closes != Grouping.None)
			{
				if (stack.Count == 0)
				{
					throw new InvalidDataException($"Unmatched closing parenthesis at index {next.Index}");
				}
				stack.Pop();
			}
			if (next.Opens != Grouping.None)
			{
				stack.Push(next);
			}
			if (token == null)
			{
				if (next.LeftOperand)
				{
					throw new InvalidDataException("Missing value or sub-expression at beginning for `" + next.Symbol + "` operator");
				}
			}
			else
			{
				if (token.Opens != Grouping.None && next.Closes != Grouping.None)
				{
					throw new InvalidDataException($"Empty parenthesis at index {token.Index}");
				}
				if (token.RightOperand == next.LeftOperand)
				{
					if (token.RightOperand)
					{
						throw new InvalidDataException("Missing value or sub-expression or there is an extra operator " + $"`{token.Symbol}` at index {token.Index} or `{next.Symbol}` at index {next.Index}");
					}
					throw new InvalidDataException($"Missing binary operation before `{next.Symbol}` at index {next.Index}");
				}
			}
			if (next.Type == TokenType.Variable)
			{
				variables.Add(next.Symbol);
			}
			list.Add(next);
			token = next;
		}
		if (stack.Count > 0)
		{
			throw new InvalidDataException($"Unclosed opening parenthesis at index {stack.Peek().Index}");
		}
		return new Compiler().Build(ToPostfix(list).ToArray(), resultType);
	}

	protected Func<IReadOnlyDictionary<string, int>, T> Compile<T>()
	{
		ExpressionType resultType;
		if (typeof(T) == typeof(int))
		{
			resultType = ExpressionType.Int;
		}
		else
		{
			if (!(typeof(T) == typeof(bool)))
			{
				throw new InvalidCastException("Variable expressions can only be int or bool.");
			}
			resultType = ExpressionType.Bool;
		}
		return System.Linq.Expressions.Expression.Lambda<Func<IReadOnlyDictionary<string, int>, T>>(Build(resultType), new ParameterExpression[1] { SymbolsParam }).Compile();
	}

	private static int ParseSymbol(string symbol, IReadOnlyDictionary<string, int> symbols)
	{
		symbols.TryGetValue(symbol, out var value);
		return value;
	}

	private static IEnumerable<Token> ToPostfix(IEnumerable<Token> tokens)
	{
		Stack<Token> s = new Stack<Token>();
		foreach (Token t in tokens)
		{
			if (t.Opens != Grouping.None)
			{
				s.Push(t);
				continue;
			}
			if (t.Closes != Grouping.None)
			{
				Token token;
				while ((token = s.Pop()).Opens == Grouping.None)
				{
					yield return token;
				}
				continue;
			}
			if (t.OperandSides == Sides.None)
			{
				yield return t;
				continue;
			}
			while (s.Count > 0 && ((t.Associativity == Associativity.Right && t.Precedence < s.Peek().Precedence) || (t.Associativity == Associativity.Left && t.Precedence <= s.Peek().Precedence)))
			{
				yield return s.Pop();
			}
			s.Push(t);
		}
		while (s.Count > 0)
		{
			yield return s.Pop();
		}
	}

	private static Expression AsBool(Expression expression)
	{
		return System.Linq.Expressions.Expression.NotEqual(expression, Zero);
	}

	private static Expression IfThenElse(Expression test, Expression ifTrue, Expression ifFalse)
	{
		return System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse);
	}
}
