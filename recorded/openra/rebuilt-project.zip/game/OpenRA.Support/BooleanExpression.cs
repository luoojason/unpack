using System;
using System.Collections.Generic;

namespace OpenRA.Support;

public class BooleanExpression : VariableExpression
{
	private readonly Func<IReadOnlyDictionary<string, int>, bool> asFunction;

	public BooleanExpression(string expression)
		: base(expression)
	{
		asFunction = Compile<bool>();
	}

	public bool Evaluate(IReadOnlyDictionary<string, int> symbols)
	{
		return asFunction(symbols);
	}
}
