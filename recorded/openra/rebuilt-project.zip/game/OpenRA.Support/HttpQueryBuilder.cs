using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace OpenRA.Support;

public class HttpQueryBuilder : IEnumerable<KeyValuePair<string, string>>, IEnumerable
{
	private readonly string url;

	private readonly List<KeyValuePair<string, string>> parameters = new List<KeyValuePair<string, string>>();

	public HttpQueryBuilder(string url)
	{
		this.url = url;
	}

	public void Add(string name, object value)
	{
		parameters.Add(KeyValuePair.Create(name, Uri.EscapeDataString(value.ToString())));
	}

	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(url);
		stringBuilder.Append('?');
		foreach (KeyValuePair<string, string> parameter in parameters)
		{
			stringBuilder.Append(parameter.Key + "=" + parameter.Value + "&");
		}
		return stringBuilder.ToString();
	}

	public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
	{
		return parameters.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}
