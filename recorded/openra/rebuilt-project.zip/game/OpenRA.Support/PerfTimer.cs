using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace OpenRA.Support;

public sealed class PerfTimer : IDisposable
{
	private const int Digits = 6;

	private const string IndentationString = "|   ";

	private const string FormatSeperation = " ms ";

	private static readonly string FormatString = "{0," + 6 + ":0} ms {1}";

	private static readonly string FormatStringLongTick = "{0," + 6 + ":0} ms [{1}] {2}: {3}";

	private readonly string name;

	private readonly long thresholdTicks;

	private readonly byte depth;

	private readonly PerfTimer parent;

	private List<PerfTimer> children;

	private long ticks;

	private static readonly ThreadLocal<PerfTimer> ParentThreadLocal = new ThreadLocal<PerfTimer>();

	private float ElapsedMs => 1000f * (float)ticks / (float)Stopwatch.Frequency;

	private string Indentation
	{
		get
		{
			if (depth <= 0)
			{
				return string.Empty;
			}
			if (depth == 1)
			{
				return "|   ";
			}
			if (depth == 2)
			{
				return "|   " + "|   ";
			}
			return string.Concat(Enumerable.Repeat("|   ", depth));
		}
	}

	public PerfTimer(string name, float thresholdMs = 0f)
	{
		this.name = name;
		thresholdTicks = MillisToTicks(thresholdMs);
		parent = ParentThreadLocal.Value;
		depth = (byte)((parent != null) ? ((byte)(parent.depth + 1)) : 0);
		ParentThreadLocal.Value = this;
		ticks = Stopwatch.GetTimestamp();
	}

	public void Dispose()
	{
		ticks = Stopwatch.GetTimestamp() - ticks;
		ParentThreadLocal.Value = parent;
		if (parent == null)
		{
			Write();
		}
		else if (ticks > thresholdTicks)
		{
			PerfTimer perfTimer = parent;
			if (perfTimer.children == null)
			{
				perfTimer.children = new List<PerfTimer>();
			}
			parent.children.Add(this);
		}
	}

	private void Write()
	{
		if (children != null)
		{
			Log.Write("perf", GetHeader(Indentation, name));
			foreach (PerfTimer child in children)
			{
				child.Write();
			}
			Log.Write("perf", FormatString.FormatInvariant(ElapsedMs, GetFooter(Indentation)));
		}
		else if (ticks >= thresholdTicks)
		{
			Log.Write("perf", FormatString.FormatInvariant(ElapsedMs, Indentation + name));
		}
	}

	public static long MillisToTicks(float millis)
	{
		return (long)((float)Stopwatch.Frequency * millis / 1000f);
	}

	public static void LogLongTick(long startStopwatchTicks, long endStopwatchTicks, string name, object item)
	{
		Type type = item.GetType();
		string text = ((type == typeof(string) || type.IsGenericType) ? item.ToString() : type.Name);
		Log.Write("perf", FormatStringLongTick.FormatInvariant(1000f * (float)(endStopwatchTicks - startStopwatchTicks) / (float)Stopwatch.Frequency, Game.LocalTick, name, text));
	}

	private static string GetHeader(string indentation, string label)
	{
		return new string(' ', 6 + " ms ".Length) + indentation + label;
	}

	private static string GetFooter(string indentation)
	{
		return indentation + new string('-', Math.Max(15, 50 - indentation.Length));
	}
}
