using System.Diagnostics;

namespace OpenRA.Support;

public static class PerfTickLogger
{
	public const long TimestampDisabled = 0L;

	private static float durationThresholdMs = Game.Settings.Debug.LongTickThresholdMs;

	private static long durationThresholdTicks = PerfTimer.MillisToTicks(Game.Settings.Debug.LongTickThresholdMs);

	public static long GetTimestamp()
	{
		DebugSettings debug = Game.Settings.Debug;
		if (!debug.EnableSimulationPerfLogging)
		{
			return 0L;
		}
		if (durationThresholdMs != debug.LongTickThresholdMs)
		{
			durationThresholdMs = Game.Settings.Debug.LongTickThresholdMs;
			durationThresholdTicks = PerfTimer.MillisToTicks(durationThresholdMs);
		}
		return Stopwatch.GetTimestamp();
	}

	public static long LogLongTick(long startTimestamp, string name, object item)
	{
		if (startTimestamp == 0L)
		{
			return 0L;
		}
		long timestamp = Stopwatch.GetTimestamp();
		if (timestamp - startTimestamp > durationThresholdTicks)
		{
			PerfTimer.LogLongTick(startTimestamp, timestamp, name, item);
		}
		return timestamp;
	}
}
