using System.IO;

namespace OpenRA.Support;

public class NativeLibrary
{
	public string Name { get; private set; }

	public string AppLocalPath { get; private set; }

	public static NativeLibrary CreateFromPackage(string assetPath)
	{
		return new NativeLibrary
		{
			Name = Path.GetFileNameWithoutExtension(assetPath),
			AppLocalPath = assetPath
		};
	}
}
