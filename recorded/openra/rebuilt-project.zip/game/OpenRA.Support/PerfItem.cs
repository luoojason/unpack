using System.Collections.Generic;
using OpenRA.Primitives;

namespace OpenRA.Support;

public class PerfItem
{
	public readonly Color C;

	public readonly string Name;

	private readonly double[] samples = new double[100];

	public double Val;

	private int head = 1;

	private int tail;

	public bool HasNormalTick = true;

	public double LastValue
	{
		get
		{
			int num = head;
			if (--num < 0)
			{
				num = samples.Length - 1;
			}
			return samples[num];
		}
	}

	public PerfItem(string name, Color c)
	{
		Name = name;
		C = c;
	}

	public void Tick()
	{
		samples[head++] = Val;
		if (head == samples.Length)
		{
			head = 0;
		}
		if (head == tail && ++tail == samples.Length)
		{
			tail = 0;
		}
		Val = 0.0;
	}

	public IEnumerable<double> Samples()
	{
		int n = head;
		while (n != tail)
		{
			int num = n - 1;
			n = num;
			if (n < 0)
			{
				n = samples.Length - 1;
			}
			yield return samples[n];
		}
	}

	public double Average(int count)
	{
		int i = 0;
		int num = head;
		double num2 = 0.0;
		for (; i < count; i++)
		{
			if (num == tail)
			{
				break;
			}
			if (--num < 0)
			{
				num = samples.Length - 1;
			}
			num2 += samples[num];
		}
		if (i != 0)
		{
			return num2 / (double)i;
		}
		return num2;
	}

	public void ResetSamples()
	{
		head = 1;
		tail = 0;
		Val = 0.0;
	}
}
