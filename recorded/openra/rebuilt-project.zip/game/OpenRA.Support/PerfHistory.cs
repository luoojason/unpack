using OpenRA.Primitives;

namespace OpenRA.Support;

public static class PerfHistory
{
	private static readonly Color[] Colors = new Color[14]
	{
		Color.Red,
		Color.Green,
		Color.Orange,
		Color.Yellow,
		Color.Fuchsia,
		Color.Lime,
		Color.Cyan,
		Color.Blue,
		Color.White,
		Color.Teal,
		Color.Pink,
		Color.MediumPurple,
		Color.Olive,
		Color.CornflowerBlue
	};

	private static int nextColor;

	public static Cache<string, PerfItem> Items = new Cache<string, PerfItem>((string s) =>
	{
		PerfItem result = new PerfItem(s, Colors[nextColor++]);
		if (nextColor >= Colors.Length)
		{
			nextColor = 0;
		}
		return result;
	});

	public static void Increment(string item, double x)
	{
		Items[item].Val += x;
	}

	public static void Tick()
	{
		foreach (PerfItem value in Items.Values)
		{
			if (value.HasNormalTick)
			{
				value.Tick();
			}
		}
	}

	public static void Reset()
	{
		foreach (PerfItem value in Items.Values)
		{
			value.ResetSamples();
		}
	}
}
